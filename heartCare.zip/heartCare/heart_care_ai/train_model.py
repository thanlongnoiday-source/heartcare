import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import joblib

# Đọc dữ liệu
df = pd.read_csv("data/cleaned_merged_heart_dataset.csv")

# Chia dữ liệu đầu vào và kết quả
X = df.drop("target", axis=1)
y = df["target"]

# Chia tập huấn luyện và kiểm tra
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Huấn luyện mô hình
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Đánh giá mô hình
predictions = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, predictions))

# Lưu mô hình
joblib.dump(model, "heart_model.pkl")
print("Đã lưu mô hình thành công!")