from datetime import datetime
from decimal import Decimal

from sqlalchemy import BigInteger, DateTime, Identity, Numeric, SmallInteger, String, func, text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.database import Base

class HistoryMod(Base):
    __tablename__ = "historys"
    __table_args__ = {"schema": "heart"}

    history_id: Mapped[int] = mapped_column(
        BigInteger,
        Identity(always=True, start=1, increment=1, minvalue=1, maxvalue=9223372036854775807, cache=1),
        primary_key=True,
    )
    users_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    metric_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    model_version: Mapped[str] = mapped_column(String(50), nullable=False)  # Ví dụ: 'XGBoost_v1.0'
    risk_score: Mapped[Decimal] = mapped_column(
        Numeric(8, 2), nullable=False, server_default=text("0.00")
    )  # Tỷ lệ phần trăm nguy cơ (vd: 78.50)
    risk_level: Mapped[int] = mapped_column(SmallInteger, nullable=False)  # 1: 'Low', 2: 'Medium', 3: 'High'
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return (
            f"<HistoryMod(history_id={self.history_id}, users_id={self.users_id}, "
            f"risk_score={self.risk_score}, risk_level={self.risk_level})>"
        )
