from datetime import datetime

from sqlalchemy import BigInteger, DateTime, Identity, SmallInteger, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.db.database import Base

class UserMod(Base):
    __tablename__ = "users"
    __table_args__ = {"schema": "heart"}

    users_id: Mapped[int] = mapped_column(
        BigInteger,
        Identity(always=True, start=1, increment=1, minvalue=1, maxvalue=9223372036854775807, cache=1),
        primary_key=True,
    )
    username: Mapped[str] = mapped_column(String(50), nullable=False)
    pw: Mapped[str | None] = mapped_column(String(100))
    full_name: Mapped[str | None] = mapped_column(String(100))
    addr: Mapped[str] = mapped_column(String(100))
    dob: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)  # Ngày sinh
    gender: Mapped[int] = mapped_column(SmallInteger, nullable=False)  # 1: Nam, 2: Nữ
    roles: Mapped[int] = mapped_column(SmallInteger, nullable=False)  # 1: 'patient', 2: 'admin'
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<User(users_id={self.users_id}, username={self.username!r}, roles={self.roles})>"
