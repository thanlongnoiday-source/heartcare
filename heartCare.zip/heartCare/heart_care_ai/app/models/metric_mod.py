from datetime import datetime
from decimal import Decimal

from sqlalchemy import BigInteger, DateTime, Identity, Numeric, SmallInteger, func, text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.database import Base

class MetricMod(Base):
    __tablename__ = "metrics"
    __table_args__ = {"schema": "heart"}

    metric_id: Mapped[int] = mapped_column(
        BigInteger,
        Identity(always=True, start=1, increment=1, minvalue=1, maxvalue=9223372036854775807, cache=1),
        primary_key=True,
    )
    users_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    age: Mapped[int] = mapped_column(SmallInteger, nullable=False)
    sex: Mapped[int] = mapped_column(SmallInteger, nullable=False)  # 1: Nam, 0: Nữ
    cp: Mapped[int] = mapped_column(SmallInteger, nullable=False)  # Loại đau ngực (0-3)
    resting_bp: Mapped[Decimal] = mapped_column(
        Numeric(8, 2), nullable=False, server_default=text("0.00")
    )  # Huyết áp lúc nghỉ (trestbps)
    cholesterol: Mapped[Decimal] = mapped_column(
        Numeric(8, 2), nullable=False, server_default=text("0.00")
    )  # Hàm lượng Cholesterol (chol)
    fasting_bs: Mapped[int] = mapped_column(SmallInteger, nullable=False)  # Đường huyết lúc đói > 120 mg/dl (1: Đúng, 0: Sai)
    restecg: Mapped[int] = mapped_column(SmallInteger, nullable=False)  # Điện tâm đồ lúc nghỉ (0-2)
    max_hr: Mapped[Decimal] = mapped_column(
        Numeric(8, 2), nullable=False, server_default=text("0.00")
    )  # Nhịp tim tối đa (thalach)
    exercise_angina: Mapped[int] = mapped_column(SmallInteger, nullable=False)  # Đau ngực khi vận động (1: Có, 0: Không)
    oldpeak: Mapped[Decimal] = mapped_column(
        Numeric(8, 2), nullable=False, server_default=text("0.00")
    )  # Chênh xuống ST
    slope: Mapped[int] = mapped_column(SmallInteger, nullable=False)  # Độ dốc đoạn ST (0-2)
    ca: Mapped[int] = mapped_column(SmallInteger, nullable=False)  # Số mạch máu chính soi tia X (0-3)
    thal: Mapped[int] = mapped_column(SmallInteger, nullable=False)  # Thallium scan (1-3)
    recorded_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<MetricMod(metric_id={self.metric_id}, users_id={self.users_id}, recorded_at={self.recorded_at})>"
