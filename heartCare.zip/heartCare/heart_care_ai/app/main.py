from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import text

from app.api import user_api
from app.api import predict_api
from app.api import train_model_api
from app.api import history_api
from app.api import metric_api
from app.db.database import Base, SessionLocal, engine, init_db
# import các model để chúng được đăng ký vào Base.metadata
from app.models import user_mod  # noqa: F401
from app.models import history_mod  # noqa: F401
from app.models import metric_mod  # noqa: F401
from app.schemas.response_sch import APIResponse, PTErrorFieldRes

# ---------------------------------------------------------
# LIFESPAN — chạy Startup & Shutdown theo chuẩn FastAPI 2024
# ---------------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    with engine.begin() as conn:
        # tạo schema nếu chưa có
        conn.execute(text("CREATE SCHEMA IF NOT EXISTS heart"))

        # tạo bảng theo model
        Base.metadata.create_all(bind=conn)

    # tạo dữ liệu khởi tạo (tài khoản admin)
    with SessionLocal() as session:
        init_db(session)

    yield  # App sẽ chạy tại đây

    # Shutdown
    engine.dispose()

app = FastAPI(
    title="Heart Disease Prediction API",
    version="1.0.0",
    lifespan=lifespan,
)

# Body/query sai kiểu hoặc JSON không hợp lệ: trả về định dạng APIResponse (400)
# kèm danh sách trường lỗi, thay cho 422 mặc định của FastAPI
@app.exception_handler(RequestValidationError)
async def request_validation_handler(request: Request, exc: RequestValidationError):
    errors = [
        PTErrorFieldRes(
            # loc dạng ("body", "age") -> bỏ phần "body", giữ tên trường
            field=".".join(str(p) for p in err.get("loc", ())[1:]) or "body",
            message=err.get("msg", "Invalid value"),
        )
        for err in exc.errors()
    ]
    body = APIResponse(status=400, message="Validation failed", errors=errors)
    return JSONResponse(status_code=400, content=body.model_dump())

# Đăng ký các router
app.include_router(user_api.router, prefix="/api")
app.include_router(predict_api.router, prefix="/api")
app.include_router(train_model_api.router, prefix="/api")
app.include_router(history_api.router, prefix="/api")
app.include_router(metric_api.router, prefix="/api")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],  # thêm domain frontend production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=[
#         "http://localhost:5173",
#         "http://127.0.0.1:5173",
#         "http://localhost:5174",
#         "http://127.0.0.1:5174",
#         "https://rodent.sgtechniques.com",
#         "http://103.216.118.143",  # Nếu deploy frontend thật
#     ],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

@app.get("/")
def root():
    return {"message": "Welcome to Heart Disease Risk Prediction API"}

