from pydantic import BaseModel, Field
from typing import Generic, TypeVar, Optional

T = TypeVar("T")

class SGValidationError(Exception):
    def __init__(self, errors: list[dict]):
        self.errors = errors

class SGAuthError(Exception):
    # status: 401 (chưa đăng nhập / token không hợp lệ), 403 (không đủ quyền)
    def __init__(self, status: int, message: str):
        self.status = status
        self.message = message

# sẽ bỏ class này (FieldResponse)
class FieldResponse(BaseModel):
    code: int
    field: str
    message: str

class PTErrorFieldRes(BaseModel):
    code: int | None = None
    field: str
    message: str

class APIResponse(BaseModel, Generic[T]):
    status: int = Field(..., description="HTTP Code")
    message: str = Field("Successful response")
    items: T | list[T] | None = None
    errors: list[PTErrorFieldRes] | None = None

class APIResponsePage(BaseModel, Generic[T]):
    status: int
    message: str
    items: list[T] = []
    page: int = 0
    page_size: int = 0
    total: int = 0
    total_pages: int = 0

