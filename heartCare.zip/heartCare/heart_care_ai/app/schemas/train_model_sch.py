from pydantic import BaseModel, Field

class ModelInfoResponse(BaseModel):
    version: str = Field(..., max_length=50)
    accuracy: float
    precision: float
    recall: float
    f1_score: float
    status: str