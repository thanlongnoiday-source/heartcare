from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field

class HistoryBase(BaseModel):
    users_id: int
    metric_id: int
    model_version: str = Field(..., max_length=50)  # Ví dụ: 'XGBoost_v1.0'
    risk_score: Decimal = Field(Decimal("0.00"), ge=0, le=100, max_digits=8, decimal_places=2)  # Tỷ lệ phần trăm nguy cơ (vd: 78.50)
    risk_level: int = Field(..., ge=1, le=3)  # 1: 'Low', 2: 'Medium', 3: 'High'

class HistoryCreate(HistoryBase):
    pass

class HistoryUpdate(BaseModel):
    users_id: int | None = None
    metric_id: int | None = None
    model_version: str | None = Field(None, max_length=50)
    risk_score: Decimal | None = Field(None, ge=0, le=100, max_digits=8, decimal_places=2)
    risk_level: int | None = Field(None, ge=1, le=3)

class HistoryRead(HistoryBase):
    model_config = ConfigDict(from_attributes=True)

    history_id: int
    created_at: datetime

class HistoryPagred(BaseModel):
    page: int = 1
    page_size: int = 20
    full_name: str | None = Field(None, max_length=100)

class HistoryPageItem(HistoryRead):
    # Thông tin bệnh nhân lấy từ bảng users
    full_name: str | None = None
    addr: str | None = None

class HistoryPageRes(BaseModel):
    items: list[HistoryPageItem] = []
    page: int = 1
    page_size: int = 20
    total: int = 0
    total_pages: int = 0
