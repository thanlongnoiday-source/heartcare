from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field

# Schema chỉ khai báo kiểu dữ liệu, KHÔNG đặt ràng buộc bắt buộc/ge/le:
# nếu đặt ở đây, FastAPI trả 422 trước khi vào service. Việc kiểm tra thiếu trường và
# miền giá trị do metric_srv đảm nhiệm (trả 400 kèm lỗi từng trường).
# Không dùng max_digits/decimal_places cho Decimal: số thực từ JSON (vd: 0.30000000000000004)
# sẽ bị trả 422; service tự làm tròn về 2 chữ số thập phân trước khi lưu.
class MetricBase(BaseModel):
    users_id: int
    age: int
    sex: int  # 1: Nam, 0: Nữ
    cp: int  # Loại đau ngực (0-3)
    resting_bp: Decimal  # Huyết áp lúc nghỉ (trestbps)
    cholesterol: Decimal  # Hàm lượng Cholesterol (chol)
    fasting_bs: int  # Đường huyết lúc đói > 120 mg/dl (1: Đúng, 0: Sai)
    restecg: int  # Điện tâm đồ lúc nghỉ (0-2)
    max_hr: Decimal  # Nhịp tim tối đa (thalach)
    exercise_angina: int  # Đau ngực khi vận động (1: Có, 0: Không)
    oldpeak: Decimal  # Chênh xuống ST
    slope: int  # Độ dốc đoạn ST (0-3)
    ca: int  # Số mạch máu chính soi tia X (0-4)
    thal: int  # Thallium scan (0, 1, 2, 3, 6, 7)

class MetricCreate(BaseModel):
    users_id: int | None = None
    age: int | None = None
    sex: int | None = None
    cp: int | None = None
    resting_bp: Decimal | None = None
    cholesterol: Decimal | None = None
    fasting_bs: int | None = None
    restecg: int | None = None
    max_hr: Decimal | None = None
    exercise_angina: int | None = None
    oldpeak: Decimal | None = None
    slope: int | None = None
    ca: int | None = None
    thal: int | None = None

class MetricUpdate(MetricCreate):
    pass

class MetricRead(MetricBase):
    model_config = ConfigDict(from_attributes=True)

    metric_id: int
    recorded_at: datetime

class MetricPagred(BaseModel):
    page: int = 1
    page_size: int = 20
    full_name: str | None = Field(None, max_length=100)
    age: int | None = Field(None, ge=1, le=120)

class MetricPageRes(BaseModel):
    items: list[MetricRead] = []
    page: int = 1
    page_size: int = 20
    total: int = 0
    total_pages: int = 0
