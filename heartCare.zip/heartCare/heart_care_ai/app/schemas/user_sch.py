from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

class UserBase(BaseModel):
    username: str = Field(..., max_length=50)
    full_name: str | None = Field(None, max_length=100)
    addr: str = Field(..., max_length=100)  # Địa chỉ
    dob: datetime  # Ngày sinh
    gender: int = Field(..., ge=1, le=2)  # 1: Nam, 2: Nữ
    roles: int = Field(1, ge=1, le=2)  # 1: 'patient', 2: 'admin'

class UserCreate(UserBase):
    pw: str | None = Field(None, max_length=100)

class UserUpdate(BaseModel):
    username: str | None = Field(None, max_length=50)
    pw: str | None = Field(None, max_length=100)
    full_name: str | None = Field(None, max_length=100)
    addr: str | None = Field(None, max_length=100)
    dob: datetime | None = None
    gender: int | None = Field(None, ge=1, le=2)
    roles: int | None = Field(None, ge=1, le=2)

class UserLogin(BaseModel):
    username: str = Field(..., max_length=50)
    password: str | None = Field(None, max_length=100)

class UserRead(UserBase):
    model_config = ConfigDict(from_attributes=True)

    users_id: int
    created_at: datetime

class UserPagred(BaseModel):
    # Không ràng buộc ge/le để tránh lỗi 422, giá trị sai được chuẩn hóa trong get_user_page
    page: int = 1
    page_size: int = 20
    full_name: str | None = Field(None, max_length=100)

class UserPageRes(BaseModel):
    items: list[UserRead] = []
    page: int = 1
    page_size: int = 20
    total: int = 0
    total_pages: int = 0

class UserToken(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserRead
