from pydantic import BaseModel, Field
from typing import Dict, Optional

class HealthData(BaseModel):
    age: int = Field(..., ge=1, le=120)
    sex: int = Field(..., ge=0, le=1)
    cp: int = Field(..., ge=0, le=10)
    trestbps: int = Field(..., ge=1, le=400)
    chol: int = Field(..., ge=1, le=1000)
    fbs: int = Field(..., ge=0, le=1)
    restecg: int = Field(..., ge=0, le=10)
    thalach: int = Field(..., ge=1, le=400)
    exang: int = Field(..., ge=0, le=1)
    oldpeak: float = Field(..., ge=0, le=20)
    slope: int = Field(..., ge=0, le=10)
    ca: int = Field(..., ge=0, le=10)
    thal: int = Field(..., ge=0, le=10)


class PredictResult(BaseModel):
    prediction: int = Field(..., ge=0, le=1)
    result: str
    notice: str
    # Xác suất theo từng lớp, ví dụ {"lop_0": 0.2, "lop_1": 0.8}
    probabilities: Optional[Dict[str, float]] = None


