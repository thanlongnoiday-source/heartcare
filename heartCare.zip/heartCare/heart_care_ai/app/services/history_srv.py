from decimal import Decimal, InvalidOperation

from sqlalchemy import func, select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.models.history_mod import HistoryMod
from app.models.user_mod import UserMod
from app.schemas.history_sch import HistoryCreate, HistoryPageItem, HistoryPageRes, HistoryPagred, HistoryRead, HistoryUpdate
from app.schemas.response_sch import PTErrorFieldRes, SGValidationError
from app.services.user_srv import ROLE_PATIENT, get_user_by_id

RISK_LOW = 1
RISK_MEDIUM = 2
RISK_HIGH = 3

def _validate_users_id(db: Session, users_id, errors: list[PTErrorFieldRes]) -> None:
    if users_id is None:
        errors.append(PTErrorFieldRes(field="users_id", message="User ID must not be empty"))
    elif isinstance(users_id, bool) or not isinstance(users_id, int) or users_id < 1:
        errors.append(PTErrorFieldRes(field="users_id", message="User ID is invalid"))
    elif get_user_by_id(db, users_id) is None:
        errors.append(PTErrorFieldRes(field="users_id", message="Người dùng không tồn tại"))

def _validate_metric_id(metric_id, errors: list[PTErrorFieldRes]) -> None:
    if metric_id is None:
        errors.append(PTErrorFieldRes(field="metric_id", message="Metric ID must not be empty"))
    elif isinstance(metric_id, bool) or not isinstance(metric_id, int) or metric_id < 1:
        errors.append(PTErrorFieldRes(field="metric_id", message="Metric ID is invalid"))

def _validate_model_version(model_version, errors: list[PTErrorFieldRes]) -> None:
    if not str(model_version or "").strip():
        errors.append(PTErrorFieldRes(field="model_version", message="Model version must not be empty"))
    elif len(str(model_version)) > 50:
        errors.append(PTErrorFieldRes(field="model_version", message="Model version must not exceed 50 characters"))

def _validate_risk_score(risk_score, errors: list[PTErrorFieldRes]) -> None:
    if risk_score is None:
        errors.append(PTErrorFieldRes(field="risk_score", message="Risk score must not be empty"))
        return

    try:
        risk_score = Decimal(str(risk_score))
    except InvalidOperation:
        errors.append(PTErrorFieldRes(field="risk_score", message="Risk score is invalid"))
        return

    if not risk_score.is_finite() or risk_score < 0 or risk_score > 100:
        errors.append(PTErrorFieldRes(field="risk_score", message="Risk score must be between 0 and 100"))

def _validate_risk_level(risk_level, errors: list[PTErrorFieldRes]) -> None:
    if risk_level is None:
        errors.append(PTErrorFieldRes(field="risk_level", message="Risk level must not be empty"))
    elif isinstance(risk_level, bool) or risk_level not in (RISK_LOW, RISK_MEDIUM, RISK_HIGH):
        errors.append(PTErrorFieldRes(field="risk_level", message="Risk level must be 1 (Low), 2 (Medium) or 3 (High)"))

def _validate_create(db: Session, data: dict) -> list[PTErrorFieldRes]:
    errors: list[PTErrorFieldRes] = []

    _validate_users_id(db, data.get("users_id"), errors)
    _validate_metric_id(data.get("metric_id"), errors)
    _validate_model_version(data.get("model_version"), errors)
    _validate_risk_score(data.get("risk_score"), errors)
    _validate_risk_level(data.get("risk_level"), errors)

    return errors

def _validate_update(db: Session, history: HistoryMod, data: dict) -> list[PTErrorFieldRes]:
    errors: list[PTErrorFieldRes] = []

    if "users_id" in data and data["users_id"] != history.users_id:
        _validate_users_id(db, data["users_id"], errors)
    if "metric_id" in data:
        _validate_metric_id(data["metric_id"], errors)
    if "model_version" in data:
        _validate_model_version(data["model_version"], errors)
    if "risk_score" in data:
        _validate_risk_score(data["risk_score"], errors)
    if "risk_level" in data:
        _validate_risk_level(data["risk_level"], errors)

    return errors

def _get_history(db: Session, history_id: int) -> HistoryMod | None:
    return db.get(HistoryMod, history_id)

def get_history_by_id(db: Session, history_id: int) -> HistoryRead | None:
    history = _get_history(db, history_id)
    if history is None:
        return None
    return HistoryRead.model_validate(history)

def get_histories(db: Session, skip: int = 0, limit: int = 100) -> list[HistoryRead]:
    stmt = select(HistoryMod).order_by(HistoryMod.history_id).offset(skip).limit(limit)
    return [HistoryRead.model_validate(h) for h in db.scalars(stmt)]

def get_histories_by_user(db: Session, users_id: int, skip: int = 0, limit: int = 100) -> list[HistoryRead]:
    # Lịch sử mới nhất hiển thị trước
    stmt = (
        select(HistoryMod)
        .where(HistoryMod.users_id == users_id)
        .order_by(HistoryMod.created_at.desc(), HistoryMod.history_id.desc())
        .offset(skip)
        .limit(limit)
    )
    return [HistoryRead.model_validate(h) for h in db.scalars(stmt)]

def create_history(db: Session, history_in: HistoryCreate) -> HistoryRead:
    data = history_in.model_dump()
    errors = _validate_create(db, data)
    if errors:
        raise SGValidationError(errors)

    history = HistoryMod(**data)
    try:
        db.add(history)
        db.commit()
        db.refresh(history)
    except SQLAlchemyError:
        db.rollback()
        raise

    return HistoryRead.model_validate(history)

def update_history(db: Session, history_id: int, history_in: HistoryUpdate) -> HistoryRead | None:
    history = _get_history(db, history_id)
    if history is None:
        return None

    data = history_in.model_dump(exclude_unset=True)
    errors = _validate_update(db, history, data)
    if errors:
        raise SGValidationError(errors)

    try:
        for field, value in data.items():
            setattr(history, field, value)
        db.commit()
        db.refresh(history)
    except SQLAlchemyError:
        db.rollback()
        raise

    return HistoryRead.model_validate(history)

def delete_history(db: Session, history_id: int) -> HistoryRead | None:
    history = _get_history(db, history_id)
    if history is None:
        return None

    # Lấy dữ liệu trả về trước khi xóa vì sau khi commit object không còn trong DB
    deleted_history = HistoryRead.model_validate(history)
    try:
        db.delete(history)
        db.commit()
    except SQLAlchemyError:
        db.rollback()
        raise

    return deleted_history

def get_history_page(db: Session, payload: HistoryPagred) -> HistoryPageRes:
    # Chỉ lấy lịch sử của bệnh nhân, không bao gồm tài khoản admin
    base = (
        select(HistoryMod)
        .join(UserMod, UserMod.users_id == HistoryMod.users_id)
        .where(UserMod.roles == ROLE_PATIENT)
    )

    if payload.full_name and payload.full_name.strip():
        base = base.where(UserMod.full_name.ilike(f"%{payload.full_name.strip()}%"))

    page = payload.page if payload.page and payload.page > 0 else 1
    page_size = min(payload.page_size, 200) if payload.page_size and payload.page_size > 0 else 20

    total = db.scalar(select(func.count()).select_from(base.subquery())) or 0
    total_pages = (total + page_size - 1) // page_size

    stmt = (
        # Lịch sử mới nhất hiển thị trước
        base.add_columns(UserMod.full_name, UserMod.addr)
        .order_by(HistoryMod.created_at.desc(), HistoryMod.history_id.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    )

    rows = db.execute(stmt).all()

    return HistoryPageRes(
        items=[
            HistoryPageItem(
                **HistoryRead.model_validate(h).model_dump(),
                full_name=full_name,
                addr=addr,
            )
            for h, full_name, addr in rows
        ],
        page=page,
        page_size=page_size,
        total=total,
        total_pages=total_pages,
    )
