from app.schemas.predict_sch import HealthData, PredictResult
from fastapi import HTTPException
from pathlib import Path
import joblib
import os
import pandas as pd


BASE_DIR = Path(__file__).resolve().parents[2]  # thư mục gốc heart_care_ai
MODEL_PATH = BASE_DIR / "heart_model.pkl"

FEATURES = [
    "age", "sex", "cp", "trestbps", "chol", "fbs", "restecg",
    "thalach", "exang", "oldpeak", "slope", "ca", "thal",
]

NOTICE = "Kết quả chỉ mang tính tham khảo, không thay thế chẩn đoán của bác sĩ."

# Miền giá trị hợp lệ (min, max) theo bộ dữ liệu bệnh tim UCI
VALID_RANGES = {
    "age": (1, 120),
    "sex": (0, 1),
    "cp": (0, 3),
    "trestbps": (50, 250),
    "chol": (100, 700),
    "fbs": (0, 1),
    "restecg": (0, 2),
    "thalach": (50, 250),
    "exang": (0, 1),
    "oldpeak": (0, 10),
    "slope": (0, 2),
    "ca": (0, 4),
    "thal": (0, 3),
}


def validate_health_data(data: HealthData) -> dict:
    if data is None:
        raise HTTPException(status_code=422, detail="Thiếu dữ liệu đầu vào")

    if not isinstance(data, HealthData):
        raise HTTPException(
            status_code=422, detail="Dữ liệu đầu vào phải có kiểu HealthData"
        )

    row = data.model_dump()
    errors = []
    for field, (low, high) in VALID_RANGES.items():
        value = row.get(field)
        if value is None:
            errors.append(f"Thiếu trường '{field}'")
        elif not low <= value <= high:
            errors.append(f"'{field}' = {value} nằm ngoài khoảng [{low}, {high}]")

    if errors:
        raise HTTPException(status_code=422, detail=errors)

    return row


def predict_heart_disease(data: HealthData) -> PredictResult:
    row = validate_health_data(data)

    if not os.path.exists(MODEL_PATH):
        raise HTTPException(
            status_code=500,
            detail="Mô hình chưa được huấn luyện. Vui lòng gọi API /train trước!"
        )

    try:
        # Load Model & Scaler
        model = joblib.load(MODEL_PATH)
    except Exception as exc:
        model = None
        print(f"[LỖI] Không nạp được mô hình tại {MODEL_PATH}: {exc}")

    if model is None:
        raise HTTPException(status_code=503, detail="Mô hình chưa được nạp")

    columns = list(getattr(model, "feature_names_in_", FEATURES))
    # Dữ liệu huấn luyện đặt tên cột là "thalachh", schema dùng "thalach"
    row.setdefault("thalachh", row["thalach"])
    try:
        df = pd.DataFrame([[row[c] for c in columns]], columns=columns)
    except KeyError as exc:
        raise HTTPException(
            status_code=500, detail=f"Mô hình cần cột không có trong đầu vào: {exc}"
        )

    prediction = int(model.predict(df)[0])

    probabilities = None
    if hasattr(model, "predict_proba"):
        probs = model.predict_proba(df)[0]
        probabilities = {
            f"lop_{cls}": round(float(p), 4) for cls, p in zip(model.classes_, probs)
        }

    return PredictResult(
        prediction=prediction,
        result=(
            "Có dấu hiệu nguy cơ bệnh tim"
            if prediction == 1
            else "Chưa phát hiện dấu hiệu nguy cơ theo mô hình"
        ),
        notice=NOTICE,
        probabilities=probabilities,
    )
