from decimal import Decimal, InvalidOperation

from sqlalchemy import func, select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.models.history_mod import HistoryMod
from app.models.metric_mod import MetricMod
from app.models.user_mod import UserMod
from app.schemas.metric_sch import MetricCreate, MetricPageRes, MetricPagred, MetricRead, MetricUpdate
from app.schemas.predict_sch import HealthData
from app.schemas.response_sch import PTErrorFieldRes, SGValidationError
from app.services.history_srv import RISK_HIGH, RISK_LOW, RISK_MEDIUM
from app.services.predict_srv import predict_heart_disease
from app.services.user_srv import ROLE_PATIENT, get_user_by_id

MODEL_VERSION = "RandomForest_v1.0"

# Ngưỡng risk_score (%) để phân loại mức nguy cơ
RISK_MEDIUM_THRESHOLD = 30
RISK_HIGH_THRESHOLD = 70

# Các trường dạng phân loại: (tên hiển thị, giá trị hợp lệ, mô tả giá trị hợp lệ)
CHOICE_FIELDS = {
    "sex": ("Sex", (0, 1), "0 (Female) or 1 (Male)"),
    "cp": ("Chest pain type", (0, 1, 2, 3), "between 0 and 3"),
    "fasting_bs": ("Fasting blood sugar", (0, 1), "0 (False) or 1 (True)"),
    "restecg": ("Resting ECG", (0, 1, 2), "between 0 and 2"),
    "exercise_angina": ("Exercise angina", (0, 1), "0 (No) or 1 (Yes)"),
    # Miền giá trị khớp với dữ liệu huấn luyện (app/data/cleaned_merged_heart_dataset.csv)
    "slope": ("ST slope", (0, 1, 2, 3), "between 0 and 3"),
    "ca": ("Number of major vessels", (0, 1, 2, 3, 4), "between 0 and 4"),
    "thal": ("Thallium scan", (0, 1, 2, 3, 6, 7), "one of 0, 1, 2, 3, 6, 7"),
}

# Các trường dạng số: (tên hiển thị, giá trị nhỏ nhất, giá trị lớn nhất)
NUMBER_FIELDS = {
    "age": ("Age", 1, 120),
    "resting_bp": ("Resting blood pressure", 1, 400),
    "cholesterol": ("Cholesterol", 1, 1000),
    "max_hr": ("Max heart rate", 1, 400),
    "oldpeak": ("Oldpeak", 0, 20),
}

def _validate_users_id(db: Session, users_id, errors: list[PTErrorFieldRes]) -> None:
    if users_id is None:
        errors.append(PTErrorFieldRes(field="users_id", message="User ID must not be empty"))
    elif isinstance(users_id, bool) or not isinstance(users_id, int) or users_id < 1:
        errors.append(PTErrorFieldRes(field="users_id", message="User ID is invalid"))
    elif get_user_by_id(db, users_id) is None:
        errors.append(PTErrorFieldRes(field="users_id", message="Người dùng không tồn tại"))

def _validate_choice(field: str, value, errors: list[PTErrorFieldRes]) -> None:
    label, choices, allowed = CHOICE_FIELDS[field]
    if value is None:
        errors.append(PTErrorFieldRes(field=field, message=f"{label} must not be empty"))
    elif isinstance(value, bool) or value not in choices:
        errors.append(PTErrorFieldRes(field=field, message=f"{label} must be {allowed}"))

def _validate_number(field: str, value, errors: list[PTErrorFieldRes]) -> None:
    label, min_value, max_value = NUMBER_FIELDS[field]
    if value is None:
        errors.append(PTErrorFieldRes(field=field, message=f"{label} must not be empty"))
        return

    try:
        number = Decimal(str(value))
    except InvalidOperation:
        errors.append(PTErrorFieldRes(field=field, message=f"{label} is invalid"))
        return

    if isinstance(value, bool) or not number.is_finite() or number < min_value or number > max_value:
        errors.append(PTErrorFieldRes(field=field, message=f"{label} must be between {min_value} and {max_value}"))

def _validate_create(db: Session, data: dict) -> list[PTErrorFieldRes]:
    errors: list[PTErrorFieldRes] = []

    _validate_users_id(db, data.get("users_id"), errors)
    for field in NUMBER_FIELDS:
        _validate_number(field, data.get(field), errors)
    for field in CHOICE_FIELDS:
        _validate_choice(field, data.get(field), errors)

    return errors

def _validate_update(db: Session, metric: MetricMod, data: dict) -> list[PTErrorFieldRes]:
    errors: list[PTErrorFieldRes] = []

    if "users_id" in data and data["users_id"] != metric.users_id:
        _validate_users_id(db, data["users_id"], errors)
    for field in NUMBER_FIELDS:
        if field in data:
            _validate_number(field, data[field], errors)
    for field in CHOICE_FIELDS:
        if field in data:
            _validate_choice(field, data[field], errors)

    return errors

def _round_decimals(data: dict) -> None:
    # Làm tròn các trường số về 2 chữ số thập phân cho khớp cột Numeric(8, 2)
    for field in NUMBER_FIELDS:
        if isinstance(data.get(field), Decimal):
            data[field] = data[field].quantize(Decimal("0.01"))

def _get_risk_level(risk_score: Decimal) -> int:
    if risk_score < RISK_MEDIUM_THRESHOLD:
        return RISK_LOW
    if risk_score < RISK_HIGH_THRESHOLD:
        return RISK_MEDIUM
    return RISK_HIGH

def _run_diagnosis(data: dict) -> tuple[Decimal, int]:
    # Chuyển tên trường của bảng metrics sang tên đặc trưng mà mô hình sử dụng
    health_data = HealthData(
        age=data["age"],
        sex=data["sex"],
        cp=data["cp"],
        trestbps=round(data["resting_bp"]),
        chol=round(data["cholesterol"]),
        fbs=data["fasting_bs"],
        restecg=data["restecg"],
        thalach=round(data["max_hr"]),
        exang=data["exercise_angina"],
        oldpeak=float(data["oldpeak"]),
        slope=data["slope"],
        ca=data["ca"],
        thal=data["thal"],
    )
    result = predict_heart_disease(health_data)

    # risk_score là xác suất mắc bệnh (lớp 1) theo phần trăm; nếu mô hình không có xác suất thì dùng nhãn dự đoán
    probability = (result.probabilities or {}).get("lop_1", float(result.prediction))
    risk_score = Decimal(str(probability * 100)).quantize(Decimal("0.01"))

    return risk_score, _get_risk_level(risk_score)

def get_metric_by_id(db: Session, metric_id: int) -> MetricMod | None:
    return db.get(MetricMod, metric_id)

def get_metrics(db: Session, skip: int = 0, limit: int = 100) -> list[MetricRead]:
    metrics = db.scalars(select(MetricMod).order_by(MetricMod.metric_id).offset(skip).limit(limit))
    return [MetricRead.model_validate(metric) for metric in metrics]

def get_metrics_by_user(db: Session, users_id: int, skip: int = 0, limit: int = 100) -> list[MetricRead]:
    # Chỉ số đo mới nhất hiển thị trước
    stmt = (
        select(MetricMod)
        .where(MetricMod.users_id == users_id)
        .order_by(MetricMod.recorded_at.desc(), MetricMod.metric_id.desc())
        .offset(skip)
        .limit(limit)
    )
    return [MetricRead.model_validate(metric) for metric in db.scalars(stmt)]

def create_metric(db: Session, metric_in: MetricCreate) -> MetricRead:
    data = metric_in.model_dump()
    errors = _validate_create(db, data)
    if errors:
        raise SGValidationError(errors)
    _round_decimals(data)

    # Chẩn đoán trước khi ghi DB để nếu mô hình lỗi thì không lưu dữ liệu dở dang
    risk_score, risk_level = _run_diagnosis(data)

    metric = MetricMod(**data)
    try:
        db.add(metric)
        # flush để có metric_id trước khi ghi lịch sử, commit chung một transaction
        db.flush()
        db.add(HistoryMod(
            users_id=metric.users_id,
            metric_id=metric.metric_id,
            model_version=MODEL_VERSION,
            risk_score=risk_score,
            risk_level=risk_level,
        ))
        db.commit()
        db.refresh(metric)
    except SQLAlchemyError:
        db.rollback()
        raise

    return MetricRead.model_validate(metric)

def update_metric(db: Session, metric_id: int, metric_in: MetricUpdate) -> MetricRead | None:
    metric = get_metric_by_id(db, metric_id)
    if metric is None:
        return None

    data = metric_in.model_dump(exclude_unset=True)
    errors = _validate_update(db, metric, data)
    if errors:
        raise SGValidationError(errors)
    _round_decimals(data)

    try:
        for field, value in data.items():
            setattr(metric, field, value)
        db.commit()
        db.refresh(metric)
    except SQLAlchemyError:
        db.rollback()
        raise

    return MetricRead.model_validate(metric)

def delete_metric(db: Session, metric_id: int) -> MetricRead | None:
    metric = get_metric_by_id(db, metric_id)
    if metric is None:
        return None

    # Lấy dữ liệu trả về trước khi xóa vì sau khi commit object không còn trong DB
    deleted_metric = MetricRead.model_validate(metric)
    try:
        db.delete(metric)
        db.commit()
    except SQLAlchemyError:
        db.rollback()
        raise

    return deleted_metric

def get_metric_page(db: Session, payload: MetricPagred) -> MetricPageRes:
    # Chỉ lấy chỉ số của bệnh nhân, không bao gồm tài khoản admin
    base = (
        select(MetricMod)
        .join(UserMod, UserMod.users_id == MetricMod.users_id)
        .where(UserMod.roles == ROLE_PATIENT)
    )

    if payload.full_name and payload.full_name.strip():
        base = base.where(UserMod.full_name.ilike(f"%{payload.full_name.strip()}%"))
    if payload.age is not None:
        base = base.where(MetricMod.age == payload.age)

    page = payload.page if payload.page and payload.page > 0 else 1
    page_size = min(payload.page_size, 200) if payload.page_size and payload.page_size > 0 else 20

    total = db.scalar(select(func.count()).select_from(base.subquery())) or 0
    total_pages = (total + page_size - 1) // page_size

    stmt = (
        # Chỉ số đo mới nhất hiển thị trước
        base.order_by(MetricMod.recorded_at.desc(), MetricMod.metric_id.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    )

    metrics = db.scalars(stmt).all()

    return MetricPageRes(
        items=[MetricRead.model_validate(m) for m in metrics],
        page=page,
        page_size=page_size,
        total=total,
        total_pages=total_pages,
    )
