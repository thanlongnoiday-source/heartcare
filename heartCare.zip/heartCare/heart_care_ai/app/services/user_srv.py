import base64
import hashlib
import hmac
import json
import os
from datetime import datetime, timedelta, timezone

from sqlalchemy import func, select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.models.user_mod import UserMod
from app.schemas.response_sch import PTErrorFieldRes, SGAuthError, SGValidationError
from app.schemas.user_sch import UserCreate, UserPageRes, UserPagred, UserRead, UserUpdate

ROLE_PATIENT = 1
ROLE_ADMIN = 2

# .env đã được nạp khi import app.db.database (qua app.models.user_mod)
SECRET_KEY = os.getenv("SECRET_KEY", "change-me-in-env")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "60"))

def _validate_dob(dob, errors: list[PTErrorFieldRes]) -> None:
    if dob is None or (isinstance(dob, str) and not dob.strip()):
        errors.append(PTErrorFieldRes(field="dob", message="Date of birth must not be empty"))
        return

    if isinstance(dob, str):
        try:
            dob = datetime.fromisoformat(dob)
        except ValueError:
            errors.append(PTErrorFieldRes(field="dob", message="Date of birth is invalid"))
            return
    elif not isinstance(dob, datetime):
        errors.append(PTErrorFieldRes(field="dob", message="Date of birth is invalid"))
        return

    now = datetime.now(dob.tzinfo) if dob.tzinfo else datetime.now()
    if dob > now:
        errors.append(PTErrorFieldRes(field="dob", message="Date of birth must not be in the future"))

def _validate_create(db: Session, data: dict) -> list[PTErrorFieldRes]:
    errors: list[PTErrorFieldRes] = []

    # username cho phép trùng hoặc trống, chỉ giới hạn độ dài
    username = data.get("username")
    if username is not None and len(str(username)) > 50:
        errors.append(PTErrorFieldRes(field="username", message="User name must not exceed 50 characters"))

    pw = data.get("pw")
    if pw is not None and len(str(pw)) > 100:
        errors.append(PTErrorFieldRes(field="pw", message="Password must not exceed 100 characters"))

    full_name = data.get("full_name")
    if full_name is not None and len(str(full_name)) > 100:
        errors.append(PTErrorFieldRes(field="full_name", message="Full name must not exceed 100 characters"))

    addr = data.get("addr")
    if not addr or not str(addr).strip():
        errors.append(PTErrorFieldRes(field="addr", message="Address must not be empty"))
    elif len(str(addr)) > 100:
        errors.append(PTErrorFieldRes(field="addr", message="Address must not exceed 100 characters"))

    _validate_dob(data.get("dob"), errors)

    gender = data.get("gender")
    if gender is None:
        errors.append(PTErrorFieldRes(field="gender", message="Gender must not be empty"))
    elif isinstance(gender, bool) or gender not in (1, 2):
        errors.append(PTErrorFieldRes(field="gender", message="Gender must be 1 (Male) or 2 (Female)"))

    roles = data.get("roles")
    if roles is None:
        errors.append(PTErrorFieldRes(field="roles", message="Role must not be empty"))
    elif isinstance(roles, bool) or roles not in (1, 2):
        errors.append(PTErrorFieldRes(field="roles", message="Role must be 1 (patient) or 2 (admin)"))

    return errors

def _validate_update(db: Session, user: UserMod, data: dict) -> list[PTErrorFieldRes]:
    errors: list[PTErrorFieldRes] = []

    # username cho phép trùng hoặc trống, chỉ giới hạn độ dài
    username = data.get("username")
    if username is not None and len(str(username)) > 50:
        errors.append(PTErrorFieldRes(field="username", message="User name must not exceed 50 characters"))

    pw = data.get("pw")
    if pw is not None and len(str(pw)) > 100:
        errors.append(PTErrorFieldRes(field="pw", message="Password must not exceed 100 characters"))

    full_name = data.get("full_name")
    if full_name is not None and len(str(full_name)) > 100:
        errors.append(PTErrorFieldRes(field="full_name", message="Full name must not exceed 100 characters"))

    if "addr" in data:
        addr = data["addr"]
        if not str(addr or "").strip():
            errors.append(PTErrorFieldRes(field="addr", message="Address must not be empty"))
        elif len(str(addr)) > 100:
            errors.append(PTErrorFieldRes(field="addr", message="Address must not exceed 100 characters"))

    if "dob" in data:
        _validate_dob(data["dob"], errors)

    if "gender" in data:
        gender = data["gender"]
        if gender is None:
            errors.append(PTErrorFieldRes(field="gender", message="Gender must not be empty"))
        elif isinstance(gender, bool) or gender not in (1, 2):
            errors.append(PTErrorFieldRes(field="gender", message="Gender must be 1 (Male) or 2 (Female)"))

    if "roles" in data:
        roles = data["roles"]
        if roles is None:
            errors.append(PTErrorFieldRes(field="roles", message="Role must not be empty"))
        elif isinstance(roles, bool) or roles not in (1, 2):
            errors.append(PTErrorFieldRes(field="roles", message="Role must be 1 (patient) or 2 (admin)"))

    return errors

def _validate_login(data: dict) -> list[PTErrorFieldRes]:
    errors: list[PTErrorFieldRes] = []

    if not str(data.get("username") or "").strip():
        errors.append(PTErrorFieldRes(field="username", message="User name must not be empty"))

    if not data.get("password"):
        errors.append(PTErrorFieldRes(field="password", message="Password must not be empty"))

    return errors

def get_user_by_id(db: Session, users_id: int) -> UserMod | None:
    return db.get(UserMod, users_id)

def get_user_by_username(db: Session, username: str) -> UserMod | None:
    return db.scalar(select(UserMod).where(UserMod.username == username))

def get_users(db: Session, skip: int = 0, limit: int = 100) -> list[UserMod]:
    return list(db.scalars(select(UserMod).order_by(UserMod.users_id).offset(skip).limit(limit)))

def create_user(db: Session, user_in: UserCreate) -> UserRead:
    data = user_in.model_dump()
    errors = _validate_create(db, data)
    if errors:
        raise SGValidationError(errors)

    user = UserMod(**data)
    try:
        db.add(user)
        db.commit()
        db.refresh(user)
    except SQLAlchemyError:
        db.rollback()
        raise

    return UserRead.model_validate(user)

def update_user(db: Session, users_id: int, user_in: UserUpdate) -> UserRead | None:
    user = get_user_by_id(db, users_id)
    if user is None:
        return None

    data = user_in.model_dump(exclude_unset=True)
    # Cột username NOT NULL nên username trống được lưu là chuỗi rỗng
    if "username" in data and data["username"] is None:
        data["username"] = ""
    errors = _validate_update(db, user, data)
    if errors:
        raise SGValidationError(errors)

    try:
        for field, value in data.items():
            setattr(user, field, value)
        db.commit()
        db.refresh(user)
    except SQLAlchemyError:
        db.rollback()
        raise

    return UserRead.model_validate(user)

def delete_user(db: Session, users_id: int) -> UserRead | None:
    user = get_user_by_id(db, users_id)
    if user is None:
        return None

    # Lấy dữ liệu trả về trước khi xóa vì sau khi commit object không còn trong DB
    deleted_user = UserRead.model_validate(user)
    try:
        db.delete(user)
        db.commit()
    except SQLAlchemyError:
        db.rollback()
        raise

    return deleted_user

def authenticate_user(db: Session, username: str, password: str) -> UserRead | None:
    errors = _validate_login({"username": username, "password": password})
    if errors:
        raise SGValidationError(errors)

    # TODO: So sánh mật khẩu đã băm khi chuyển sang lưu password dạng hash
    # username có thể trùng nên phải kiểm tra mật khẩu trên tất cả tài khoản cùng username
    users = db.scalars(select(UserMod).where(UserMod.username == username).order_by(UserMod.users_id))
    for user in users:
        if user.pw == password:
            return UserRead.model_validate(user)
    return None

def get_user_page(db: Session, payload: UserPagred) -> UserPageRes:
    # Chỉ lấy danh sách bệnh nhân, không bao gồm tài khoản admin
    base = select(UserMod).where(UserMod.roles == ROLE_PATIENT)

    if payload.full_name and payload.full_name.strip():
        base = base.where(UserMod.full_name.ilike(f"%{payload.full_name.strip()}%"))

    page = payload.page if payload.page and payload.page > 0 else 1
    page_size = min(payload.page_size, 200) if payload.page_size and payload.page_size > 0 else 20

    total = db.scalar(select(func.count()).select_from(base.subquery())) or 0
    total_pages = (total + page_size - 1) // page_size

    stmt = (
        base.order_by(UserMod.users_id.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    )

    users = db.scalars(stmt).all()

    return UserPageRes(
        items=[UserRead.model_validate(u) for u in users],
        page=page,
        page_size=page_size,
        total=total,
        total_pages=total_pages,
    )

# ---------------------------------------------------------
# Token đăng nhập: "<payload base64>.<chữ ký HMAC-SHA256>"
# ---------------------------------------------------------
def _b64encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()

def _b64decode(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))

def _sign(payload: str) -> str:
    return _b64encode(hmac.new(SECRET_KEY.encode(), payload.encode(), hashlib.sha256).digest())

def create_access_token(user: UserRead) -> str:
    expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    payload = _b64encode(json.dumps({"sub": user.users_id, "exp": int(expire.timestamp())}).encode())
    return f"{payload}.{_sign(payload)}"

def get_current_user(db: Session, token: str | None) -> UserMod:
    if not token:
        raise SGAuthError(401, "Bạn cần đăng nhập để thực hiện chức năng này")

    try:
        payload, signature = token.split(".")
        if not hmac.compare_digest(signature, _sign(payload)):
            raise ValueError("invalid signature")
        data = json.loads(_b64decode(payload))
        users_id = int(data["sub"])
        expire = int(data["exp"])
    except (ValueError, KeyError, TypeError):
        raise SGAuthError(401, "Token đăng nhập không hợp lệ")

    if expire < datetime.now(timezone.utc).timestamp():
        raise SGAuthError(401, "Phiên đăng nhập đã hết hạn, vui lòng đăng nhập lại")

    user = get_user_by_id(db, users_id)
    if user is None:
        raise SGAuthError(401, "Tài khoản đăng nhập không còn tồn tại")
    return user

# ---------------------------------------------------------
# Phân quyền: toàn bộ chức năng chỉ admin được thao tác, patient không có quyền
# ---------------------------------------------------------
def check_admin(current_user: UserMod) -> None:
    if current_user.roles != ROLE_ADMIN:
        raise SGAuthError(403, "Chỉ admin mới được thực hiện chức năng này")
