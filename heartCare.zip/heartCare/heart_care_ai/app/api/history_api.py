from fastapi import APIRouter, Body, Depends, HTTPException, Query
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.api.user_api import error_response, require_login, success_response
from app.db.database import get_db
from app.models.user_mod import UserMod
from app.schemas.history_sch import HistoryCreate, HistoryPageRes, HistoryPagred, HistoryRead, HistoryUpdate
from app.schemas.response_sch import APIResponse, SGAuthError, SGValidationError
from app.services.history_srv import (
    create_history,
    delete_history,
    get_histories,
    get_histories_by_user,
    get_history_by_id,
    get_history_page,
    update_history,
)
from app.services.user_srv import check_admin

router = APIRouter(prefix="/histories", tags=["Histories"])

@router.get("/", response_model=APIResponse[list[HistoryRead]], summary="Danh sách lịch sử dự đoán (admin)")
def list_histories(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: UserMod = Depends(require_login),
):
    try:
        check_admin(current_user)
    except SGAuthError as e:
        return error_response(e.status, e.message)

    histories = get_histories(db, skip=skip, limit=limit)
    return success_response(histories)

@router.post("/page", response_model=APIResponse[HistoryPageRes], summary="Phân trang lịch sử dự đoán (admin)")
def page_histories(
    payload: HistoryPagred | None = Body(None),
    db: Session = Depends(get_db),
    current_user: UserMod = Depends(require_login),
):
    try:
        check_admin(current_user)
        # Body rỗng thì dùng giá trị mặc định (page=1, page_size=20)
        return success_response(get_history_page(db, payload or HistoryPagred()))
    except SGAuthError as e:
        return error_response(e.status, e.message)
    except SQLAlchemyError:
        raise HTTPException(status_code=500, detail="Lỗi khi truy vấn danh sách lịch sử dự đoán")

@router.get("/by_user/{users_id}", response_model=APIResponse[list[HistoryRead]], summary="Lịch sử dự đoán của người dùng")
def list_histories_by_user(
    users_id: int,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: UserMod = Depends(require_login),
):
    try:
        check_admin(current_user)
    except SGAuthError as e:
        return error_response(e.status, e.message)

    histories = get_histories_by_user(db, users_id, skip=skip, limit=limit)
    return success_response(histories)

@router.get("/{history_id}", response_model=APIResponse[HistoryRead], summary="Chi tiết lịch sử dự đoán")
def read_history(history_id: int, db: Session = Depends(get_db), current_user: UserMod = Depends(require_login)):
    try:
        check_admin(current_user)
    except SGAuthError as e:
        return error_response(e.status, e.message)

    history = get_history_by_id(db, history_id)
    if history is None:
        return error_response(404, "Không tìm thấy lịch sử dự đoán")
    return success_response(history)

@router.post("/", response_model=APIResponse[HistoryRead], summary="Tạo lịch sử dự đoán")
def create_history_api(
    history_in: HistoryCreate,
    db: Session = Depends(get_db),
    current_user: UserMod = Depends(require_login),
):
    try:
        check_admin(current_user)
        return success_response(create_history(db, history_in))
    except SGAuthError as e:
        return error_response(e.status, e.message)
    except SGValidationError as e:
        return error_response(400, "Validation failed", err_field=e.errors)
    except SQLAlchemyError:
        raise HTTPException(status_code=500, detail="Lỗi khi ghi dữ liệu lịch sử dự đoán")

@router.put("/by_id/{history_id}", response_model=APIResponse[HistoryRead], summary="Cập nhật lịch sử dự đoán (admin)")
def update_history_api(
    history_id: int,
    history_in: HistoryUpdate,
    db: Session = Depends(get_db),
    current_user: UserMod = Depends(require_login),
):
    try:
        # Kết quả dự đoán là dữ liệu do hệ thống sinh ra, chỉ admin được chỉnh sửa
        check_admin(current_user)
        history = update_history(db, history_id, history_in)
    except SGAuthError as e:
        return error_response(e.status, e.message)
    except SGValidationError as e:
        return error_response(400, "Validation failed", err_field=e.errors)
    except SQLAlchemyError:
        raise HTTPException(status_code=500, detail="Lỗi khi cập nhật dữ liệu lịch sử dự đoán")

    if history is None:
        return error_response(404, "Không tìm thấy lịch sử dự đoán")
    return success_response(history)

@router.delete("/by_id/{history_id}", response_model=APIResponse[HistoryRead], summary="Xóa lịch sử dự đoán (admin)")
def delete_history_api(history_id: int, db: Session = Depends(get_db), current_user: UserMod = Depends(require_login)):
    try:
        check_admin(current_user)
        history = delete_history(db, history_id)
    except SGAuthError as e:
        return error_response(e.status, e.message)
    except SQLAlchemyError:
        raise HTTPException(status_code=500, detail="Lỗi khi xóa lịch sử dự đoán")

    if history is None:
        return error_response(404, "Không tìm thấy lịch sử dự đoán")
    return success_response(history)
