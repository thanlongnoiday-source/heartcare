from fastapi import APIRouter, BackgroundTasks, Depends

from app.api.user_api import require_admin
from app.schemas.train_model_sch import ModelInfoResponse

# Toàn bộ chức năng chỉ admin được thao tác
router = APIRouter(prefix="/model-train", tags=["Model Management"], dependencies=[Depends(require_admin)])

def background_training_task():
   
    print("Đang tiến hành huấn luyện lại mô hình AI ngầm...")

@router.get("/info", response_model=ModelInfoResponse)
def get_model_info():
    """Lấy thông tin mô hình hiện tại đang được nạp."""
    return {
        "version": "v1.0.2",
        "accuracy": 0.88,
        "precision": 0.85,
        "recall": 0.86,
        "f1_score": 0.855,
        "status": "Active"
    }

@router.post("/train")
def trigger_model_training(background_tasks: BackgroundTasks):
    """Trigger quá trình tiền xử lý và huấn luyện lại mô hình chạy ngầm."""
    background_tasks.add_task(background_training_task)
    return {"message": "Quá trình huấn luyện lại mô hình đã được kích hoạt dưới nền (Background Task)."}
