from fastapi import APIRouter, Body, Depends, HTTPException, Query
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.models.user_mod import UserMod as User
from app.schemas.response_sch import APIResponse, SGAuthError, SGValidationError
from app.schemas.user_sch import UserCreate, UserLogin, UserPageRes, UserPagred, UserRead, UserToken, UserUpdate
from app.services.user_srv import (
    authenticate_user,
    check_admin,
    create_access_token,
    create_user,
    delete_user,
    get_current_user,
    get_user_by_id,
    get_user_page,
    get_users,
    update_user,
)

router = APIRouter(prefix="/users", tags=["Users"])

bearer_scheme = HTTPBearer(auto_error=False)

def success_response(items=None) -> APIResponse:
    return APIResponse(status=200, message="Success", items=items)

def error_response(code: int, message: str, items=None, err_field=None) -> APIResponse:
    return APIResponse(status=code, message=message, items=items, errors=err_field)

def require_login(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    db: Session = Depends(get_db),
) -> User:
    # Dependency dùng chung: mọi API nghiệp vụ phải đăng nhập trước khi thao tác
    try:
        return get_current_user(db, credentials.credentials if credentials else None)
    except SGAuthError as e:
        raise HTTPException(status_code=e.status, detail=e.message, headers={"WWW-Authenticate": "Bearer"})

def require_admin(current_user: User = Depends(require_login)) -> User:
    # Dependency dùng chung: toàn bộ chức năng chỉ admin được thao tác
    try:
        check_admin(current_user)
    except SGAuthError as e:
        raise HTTPException(status_code=e.status, detail=e.message)
    return current_user

@router.get("/", response_model=APIResponse[UserRead], summary="Danh sách người dùng (admin)")
def list_users(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_login),
):
    try:
        check_admin(current_user)
    except SGAuthError as e:
        return error_response(e.status, e.message)

    users = get_users(db, skip=skip, limit=limit)
    return success_response([UserRead.model_validate(u) for u in users])

@router.post("/page", response_model=APIResponse[UserPageRes], summary="Phân trang người dùng (admin)")
def page_users(
    payload: UserPagred | None = Body(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_login),
):
    try:
        check_admin(current_user)
        # Body rỗng thì dùng giá trị mặc định (page=1, page_size=20)
        return success_response(get_user_page(db, payload or UserPagred()))
    except SGAuthError as e:
        return error_response(e.status, e.message)
    except SQLAlchemyError:
        raise HTTPException(status_code=500, detail="Lỗi khi truy vấn danh sách người dùng")

@router.get("/{users_id}", response_model=APIResponse[UserRead], summary="Chi tiết người dùng (admin)")
def read_user(users_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_login)):
    try:
        check_admin(current_user)
    except SGAuthError as e:
        return error_response(e.status, e.message)

    user = get_user_by_id(db, users_id)
    if user is None:
        return error_response(404, "Không tìm thấy người dùng")
    return success_response(UserRead.model_validate(user))

@router.post("/", response_model=APIResponse[UserRead], summary="Tạo người dùng (admin)")
def create_user_api(user_in: UserCreate, db: Session = Depends(get_db), current_user: User = Depends(require_login)):
    try:
        check_admin(current_user)
        return success_response(create_user(db, user_in))
    except SGAuthError as e:
        return error_response(e.status, e.message)
    except SGValidationError as e:
        return error_response(400, "Validation failed", err_field=e.errors)
    except SQLAlchemyError:
        raise HTTPException(status_code=500, detail="Lỗi khi ghi dữ liệu người dùng")

@router.put("/by_id/{users_id}", response_model=APIResponse[UserRead], summary="Cập nhật người dùng (admin)")
def update_user_api(
    users_id: int,
    user_in: UserUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_login),
):
    try:
        check_admin(current_user)
        user = update_user(db, users_id, user_in)
    except SGAuthError as e:
        return error_response(e.status, e.message)
    except SGValidationError as e:
        return error_response(400, "Validation failed", err_field=e.errors)
    except SQLAlchemyError:
        raise HTTPException(status_code=500, detail="Lỗi khi cập nhật dữ liệu người dùng")

    if user is None:
        return error_response(404, "Không tìm thấy người dùng")
    return success_response(user)

@router.delete("/by_id/{users_id}", response_model=APIResponse[UserRead], summary="Xóa người dùng (admin)")
def delete_user_api(users_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_login)):
    try:
        check_admin(current_user)
        user = delete_user(db, users_id)
    except SGAuthError as e:
        return error_response(e.status, e.message)
    except SQLAlchemyError:
        raise HTTPException(status_code=500, detail="Lỗi khi xóa người dùng")

    if user is None:
        return error_response(404, "Không tìm thấy người dùng")
    return success_response(user)

@router.post("/login", response_model=APIResponse[UserToken], summary="Đăng nhập")
def login_user(user_in: UserLogin, db: Session = Depends(get_db)):
    try:
        user = authenticate_user(db, user_in.username, user_in.password)
    except SGValidationError as e:
        return error_response(400, "Validation failed", err_field=e.errors)

    if user is None:
        return error_response(401, "Tên đăng nhập hoặc mật khẩu không đúng")
    
    return success_response(UserToken(access_token=create_access_token(user), user=user))
