from app.schemas.predict_sch import HealthData, PredictResult
from app.services import predict_srv
from fastapi import APIRouter, Depends

from app.api.user_api import require_admin

# Toàn bộ chức năng chỉ admin được thao tác
router = APIRouter(prefix="/predicts", tags=["Predicts"], dependencies=[Depends(require_admin)])

@router.post(
    "/predict",
    summary="Dự đoán nguy cơ mắc bệnh tim",
    response_model=PredictResult,
)
def predict_heart_disease(data: HealthData):
    return predict_srv.predict_heart_disease(data)
