from fastapi import APIRouter, Body, Depends, HTTPException, Query
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.api.user_api import error_response, require_login, success_response
from app.db.database import get_db
from app.models.user_mod import UserMod
from app.schemas.metric_sch import MetricCreate, MetricPageRes, MetricPagred, MetricRead, MetricUpdate
from app.schemas.response_sch import APIResponse, SGAuthError, SGValidationError
from app.services.metric_srv import (
    create_metric,
    delete_metric,
    get_metric_by_id,
    get_metric_page,
    get_metrics,
    get_metrics_by_user,
    update_metric,
)
from app.services.user_srv import check_admin

router = APIRouter(prefix="/metrics", tags=["Metrics"])

@router.get("/", response_model=APIResponse[list[MetricRead]], summary="Danh sách chỉ số sức khỏe (admin)")
def list_metrics(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: UserMod = Depends(require_login),
):
    try:
        check_admin(current_user)
    except SGAuthError as e:
        return error_response(e.status, e.message)

    metrics = get_metrics(db, skip=skip, limit=limit)
    return success_response(metrics)

@router.post("/page", response_model=APIResponse[MetricPageRes], summary="Phân trang chỉ số sức khỏe (admin)")
def page_metrics(
    payload: MetricPagred | None = Body(None),
    db: Session = Depends(get_db),
    current_user: UserMod = Depends(require_login),
):
    try:
        check_admin(current_user)
        # Body rỗng thì dùng giá trị mặc định (page=1, page_size=20)
        return success_response(get_metric_page(db, payload or MetricPagred()))
    except SGAuthError as e:
        return error_response(e.status, e.message)
    except SQLAlchemyError:
        raise HTTPException(status_code=500, detail="Lỗi khi truy vấn danh sách chỉ số sức khỏe")

@router.get("/by_user/{users_id}", response_model=APIResponse[list[MetricRead]], summary="Chỉ số sức khỏe của người dùng")
def list_metrics_by_user(
    users_id: int,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: UserMod = Depends(require_login),
):
    try:
        check_admin(current_user)
    except SGAuthError as e:
        return error_response(e.status, e.message)

    metrics = get_metrics_by_user(db, users_id, skip=skip, limit=limit)
    return success_response(metrics)

@router.get("/{metric_id}", response_model=APIResponse[MetricRead], summary="Chi tiết chỉ số sức khỏe")
def read_metric(metric_id: int, db: Session = Depends(get_db), current_user: UserMod = Depends(require_login)):
    try:
        check_admin(current_user)
    except SGAuthError as e:
        return error_response(e.status, e.message)

    metric = get_metric_by_id(db, metric_id)
    if metric is None:
        return error_response(404, "Không tìm thấy chỉ số sức khỏe")
    return success_response(MetricRead.model_validate(metric))

@router.post("/", response_model=APIResponse[MetricRead], summary="Tạo chỉ số sức khỏe")
def create_metric_api(
    metric_in: MetricCreate,
    db: Session = Depends(get_db),
    current_user: UserMod = Depends(require_login),
):
    try:
        # Chỉ admin đang đăng nhập mới được tạo chỉ số, không so khớp users_id
        check_admin(current_user)
        return success_response(create_metric(db, metric_in))
    except SGAuthError as e:
        return error_response(e.status, e.message)
    except SGValidationError as e:
        return error_response(400, "Validation failed", err_field=e.errors)
    except SQLAlchemyError:
        raise HTTPException(status_code=500, detail="Lỗi khi ghi dữ liệu chỉ số sức khỏe")

@router.put("/by_id/{metric_id}", response_model=APIResponse[MetricRead], summary="Cập nhật chỉ số sức khỏe")
def update_metric_api(
    metric_id: int,
    metric_in: MetricUpdate,
    db: Session = Depends(get_db),
    current_user: UserMod = Depends(require_login),
):
    try:
        check_admin(current_user)
        metric = update_metric(db, metric_id, metric_in)
    except SGAuthError as e:
        return error_response(e.status, e.message)
    except SGValidationError as e:
        return error_response(400, "Validation failed", err_field=e.errors)
    except SQLAlchemyError:
        raise HTTPException(status_code=500, detail="Lỗi khi cập nhật dữ liệu chỉ số sức khỏe")

    if metric is None:
        return error_response(404, "Không tìm thấy chỉ số sức khỏe")
    return success_response(metric)

@router.delete("/by_id/{metric_id}", response_model=APIResponse[MetricRead], summary="Xóa chỉ số sức khỏe")
def delete_metric_api(metric_id: int, db: Session = Depends(get_db), current_user: UserMod = Depends(require_login)):
    try:
        check_admin(current_user)
        deleted_metric = delete_metric(db, metric_id)
    except SGAuthError as e:
        return error_response(e.status, e.message)
    except SQLAlchemyError:
        raise HTTPException(status_code=500, detail="Lỗi khi xóa chỉ số sức khỏe")

    if deleted_metric is None:
        return error_response(404, "Không tìm thấy chỉ số sức khỏe")
    return success_response(deleted_metric)
