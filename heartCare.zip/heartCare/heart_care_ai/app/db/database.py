import os
from collections.abc import Generator

from dotenv import load_dotenv
from sqlalchemy import URL, create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

# Nạp biến môi trường từ file .env (biến đã có sẵn trong hệ thống được ưu tiên)
load_dotenv()

# Ưu tiên DATABASE_URL nếu có, nếu không thì ghép từ các biến DB_*
DATABASE_URL = os.getenv("DATABASE_URL") or URL.create(
    "postgresql+psycopg2",
    username=os.getenv("DB_USER", "postgres"),
    password=os.getenv("DB_PASS", "postgres"),
    host=os.getenv("DB_HOST", "localhost"),
    port=int(os.getenv("DB_PORT", "5432")),
    database=os.getenv("DB_NAME", "heart_care"),
)

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

# Base chung cho tất cả các model
class Base(DeclarativeBase):
    pass

def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def init_db(db: Session) -> None:
    # Import trong hàm để tránh import vòng giữa database và services
    from datetime import datetime, timezone

    from app.schemas.user_sch import UserCreate
    from app.services.user_srv import create_user, get_user_by_username

    admin_name = os.getenv("FIRST_SUPERUSER_ID", "admin")
    if get_user_by_username(db, admin_name):
        return

    create_user(
        db,
        UserCreate(
            username=admin_name,
            pw=os.getenv("FIRST_SUPERUSER_PASSWORD", "admin123"),
            full_name="Administrator",
            addr="N/A",
            dob=datetime(2000, 1, 1, tzinfo=timezone.utc),
            gender=1,
            roles=2,
        ),
    )
