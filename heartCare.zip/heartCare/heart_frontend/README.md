# Vue 3.5.38 + TypeScript 5.8.3 + Vite 5.4.19
# tailwindcss 3.4.17
# lucide-vue-next 0.543.0
# vue-tsc 3.3.5
# pinia 3.0.4
# vue-router 4.5.1
# axios 1.12.2
# zod 4.1.12

This template should help get you started developing with Vue 3 and TypeScript in Vite. The template uses Vue 3 `<script setup>` SFCs, check out the [script setup docs](https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup) to learn more.

Learn more about the recommended Project Setup and IDE Support in the [Vue Docs TypeScript Guide](https://vuejs.org/guide/typescript/overview.html#project-setup).
