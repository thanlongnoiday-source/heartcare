import colors from 'tailwindcss/colors'

/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{vue,js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        pmis: {
          bg: colors.slate[50], // Màu nền mặc định (ví dụ: Slate 50 - '#f8fafc')
          text: colors.slate[900], // Màu chữ mặc định (ví dụ: Slate 900 - '#0f172a')
          // primary: colors.blue[500], // Màu xanh đặc trưng PMP (ví dụ: Blue 800 - '#1e40af')
          // primary: '#0078d7', // Màu xanh đặc trưng PMP
          primary: {
            DEFAULT: '#0078d7',
            50: '#f0f7ff',
            100: '#e0efff',
            200: '#b8dcff',
            300: '#84c3ff',
            400: '#4aa6ff',
            500: '#1e8eff',
            600: '#0078d7', // PRIMARY
            700: '#0064b3',
            800: '#004f8f',
            900: '#003a6b'
          },
          label: colors.slate[500],
          lightlabel: colors.slate[800],
          placeholder: colors.slate[500],
          disabled: colors.slate[300],
          success: colors.green[500],
          danger: colors.red[500],
          warning: colors.yellow[500],
          info: colors.indigo[600],
          bordernormal: colors.slate[400],
          bordertab: colors.slate[300],
          borderinput: colors.slate[200]
        },
        // label: colors.slate[600],
        // placeholder: colors.slate[500],
        // disabled: colors.slate[400],
        // success: colors.green,
        // danger: colors.red,
        // warning: colors.yellow,
        status: {
          draft: colors.slate[400], // slate-400
          pending: colors.orange[500], // slate-500
          cancelled: colors.slate[500], // slate-300
          completed: colors.slate[300], // green-500
          approved: colors.green[600], // green-600
          closed: colors.slate[400], // slate-400
          active: colors.green[600], // green-600
          inactive: colors.slate[400], // slate-400
          ready: colors.emerald[700],
          clean: colors.emerald[700],
          vacant: colors.slate[600],
          outoforder: colors.red[600],
          checkin: colors.green[600],
          checkout: colors.slate[500],
          noshow: colors.red[600],
          confirmed: colors.blue[500]
        },
        msgbox: {
          success: colors.blue[500],
          error: colors.red[500],
          warning: colors.indigo[500],
          info: colors.blue[600],
          confirm: colors.blue[500]
        }
      },
      fontFamily: {
        pmis: ['Cambria', 'Merriweather', 'serif']
      },
      // Cấu hình cỡ chữ tùy chỉnh nếu muốn (Ví dụ: 14px hoặc 15px cho hệ thống ERP/PMIS)
      fontSize: {
        'pmis-normal': ['16px', { lineHeight: '24px' }], // Cỡ chữ 16px, chiều cao dòng 24px
        'pmis-label-input': ['14px', { lineHeight: '22px' }],
        'pmis-input': ['20px', { lineHeight: '28px' }],
        'pmis-title-group': ['20px', { lineHeight: '28px' }]
      }
    }
  },
  plugins: []
}
