# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project overview

Stack: Vue 3.5 (`<script setup>` SFCs) + TypeScript 5.8 + Vite 5.4, Tailwind CSS 3.4, Pinia 3, Vue Router 4, axios, zod, chart.js/vue-chartjs, lucide-vue-next icons, @headlessui/vue, dayjs. No i18n library — UI text is Vietnamese only.

## Commands

```
npm run dev            # start Vite dev server (port 5173, strictPort)
npm run build           # type-check (vue-tsc -b) then production build
npm run preview         # preview a production build
npm run type-check      # vue-tsc --noEmit
npm run lint            # eslint .
npm run lint:fix        # eslint . --fix
npm run format          # prettier . --write
npm run format:check    # prettier . --check
```

There is no test runner configured in this repo (no test script, no test files).

## Project-wide architecture

These conventions are shared infrastructure and apply no matter which actor you're working on.

### Feature-module structure

Each actor lives under `src/features/<actor>/` with its own `pages/`, `components/`, `modals/`, `types/`, `constants/`, and `services/` subfolders, plus a `pt_<abbrev>_main.vue` shell page that owns that actor's sidebar/menu structure. `services/` folders exist in every actor but are currently **empty** — pages hold their data as local `ref()`/mock arrays typed against feature-local `types/pt_*_common.ts` files, not fetched from an API yet.

### Config

Runtime env vars are read via `import.meta.env` and re-exported through `src/config/env.ts` (`ENV.APP_NAME`, `ENV.API_URL`, `ENV.API_TIMEOUT`, `ENV.ENABLE_LOG`). `VITE_API_URL` is not set in the committed `.env` (only in `.env.development` / `.env.production`). `@` is aliased to `src/` in both `vite.config.ts` and `tsconfig.app.json`.

### State

Pinia is installed and initialized in `main.ts`, but there are currently no `defineStore` usages anywhere in `src/` — no stores exist yet despite `src/stores/` being present.
