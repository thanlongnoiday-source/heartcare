<script setup lang="ts">
import { computed, ref } from 'vue'
import type { Component } from 'vue'
import {
  Users,
  LayoutDashboard,
  Stethoscope,
  FolderPlus,
  History,
  Settings,
  UserCircle2,
  LogOut
} from 'lucide-vue-next'
import { Menu, MenuButton, MenuItems, MenuItem as HMenuItem } from '@headlessui/vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/sg_auth_store'
import pt_sys_dashboard from '@/features/system_admin/pages/pt_sys_dashboard.vue'
import pt_sys_user_list from '@/features/system_admin/pages/pt_sys_user_list.vue'
import pt_sys_history_list from '@/features/system_admin/pages/pt_sys_history_list.vue'
// import sg_engr_cust_list from '@/features/engineer/pages/sg_engr_cust_list.vue'
// import sg_engr_project_list from '@/features/engineer/pages/sg_engr_project_list.vue'
// import sg_engr_simulation from '@/features/engineer/pages/sg_engr_simulation.vue'
// import { useToast } from '@/utils/sg_use_toast'
// import { PROJECT_STATUS } from '@/constants/sg_engr_project_const'
// import type { SGProjectRead } from '@/types/sg_project'

// ======================================================================
// Layout chia 2 hàng theo chiều dọc:
//   Vùng 1 (Header)      — tiêu đề "iHEART" + Vùng 2 + thông tin user đăng nhập
//   Vùng 2 (Menu chính)  — Khách hàng / Dự án / Báo cáo / Cài đặt, nằm trong Header
//   Vùng 3 (Nội dung)    — 1 trang vue động, đổi theo ngữ cảnh thao tác
// ======================================================================

// --- Vùng 1: thông tin user đăng nhập (lấy từ auth store, ghi lúc đăng nhập) ---
const authStore = useAuthStore()

const currentUser = computed(() => ({
  name: authStore.displayName,
  role: authStore.roleLabel
}))

// Menu con dưới icon user: "Đăng xuất" — xoá thông tin user rồi quay về trang login
const router = useRouter()

function onLogout(): void {
  authStore.logout()
  router.replace({ name: 'sg-login' })
}

// --- Vùng 2: menu chính ---
type MenuId = 'dashboard' | 'patient' | 'predict' | 'history' | 'model' | 'dataset'

interface MenuItem {
  id: MenuId
  label: string
  icon: Component
}

const menuItems: MenuItem[] = [
  { id: 'dashboard', label: 'Tổng quan', icon: LayoutDashboard },
  { id: 'patient', label: 'Bệnh nhân', icon: Users },
  { id: 'predict', label: 'Chẩn đoán', icon: Stethoscope },
  { id: 'history', label: 'Lịch sử', icon: History },
  { id: 'model', label: 'Mô hình', icon: Settings },
  { id: 'dataset', label: 'Dữ liệu', icon: FolderPlus }
]

// const toast = useToast()

const activeMenu = ref<MenuId>('dashboard')

// Trạng thái "đang xem trang mô phỏng" — bật khi bấm icon "Mô phỏng" trên 1 dòng
// dự án (sg_engr_project_list.vue phát sự kiện `simulate` kèm bản ghi dự án);
// tắt khi chọn lại menu chính. simulatingProject giữ dự án đang mô phỏng, truyền
// làm thuộc tính "project" cho pt_sys_dashboard.vue.
const showSimulation = ref(false)
// const simulatingProject = ref<SGProjectRead | null>(null)

function selectMenu(id: MenuId): void {
  activeMenu.value = id
  showSimulation.value = false
}

// function onProjectSimulate(project: SGProjectRead): void {
//   // Chỉ cho phép mô phỏng dự án đang ở trạng thái "Đang hoạt động".
//   if (project.project_status !== PROJECT_STATUS.ACTIVE) {
//     toast.warning('Chỉ có thể mô phỏng dự án ở trạng thái "Đang hoạt động".')
//     return
//   }

//   simulatingProject.value = project
//   showSimulation.value = true
// }

// --- Vùng 3: trang vue động theo ngữ cảnh ---
// Map menu -> component trang. Khi trang tương ứng được tạo dưới
// src/features/engineer/pages/, khai báo ở đây để render động theo activeMenu.
// const contentComponents: Partial<Record<MenuId, Component>> = {
//   customer: sg_engr_cust_list,
//   project: sg_engr_project_list
// }

// const activeContentComponent = computed<Component | undefined>(
//   () => contentComponents[activeMenu.value]
// )

const activeMenuLabel = computed(
  () => menuItems.find((m) => m.id === activeMenu.value)?.label ?? ''
)
</script>

<template>
  <div class="flex h-screen w-full flex-col overflow-hidden bg-pmis-bg text-pmis-text">
    <!-- ============================================================ -->
    <!-- Vùng 1: Header -->
    <!-- ============================================================ -->
    <header
      class="flex shrink-0 items-center justify-between gap-4 border-b border-slate-200 bg-white px-6 py-3 shadow-sm"
    >
      <div class="flex min-w-0 items-center gap-6">
        <h1 class="w-64 shrink-0 text-xl font-bold italic tracking-tight text-pmis-primary">
          iHEART
        </h1>

        <!-- Vùng 2: Menu chính (nằm trong Header) -->
        <nav class="flex items-center gap-1 overflow-x-auto">
          <button
            v-for="item in menuItems"
            :key="item.id"
            type="button"
            class="flex shrink-0 items-center gap-2 rounded-md px-4 py-2 text-sm font-medium transition-colors"
            :class="
              activeMenu === item.id
                ? 'bg-pmis-primary text-white'
                : 'text-pmis-label hover:bg-pmis-primary-50 hover:text-pmis-primary'
            "
            @click="selectMenu(item.id)"
          >
            <component :is="item.icon" class="h-4 w-4" />
            <span>{{ item.label }}</span>
          </button>
        </nav>
      </div>

      <div class="flex shrink-0 items-center gap-3">
        <div class="text-right leading-tight">
          <p class="text-sm font-semibold text-pmis-text">{{ currentUser.name }}</p>
          <p class="text-xs text-pmis-placeholder">{{ currentUser.role }}</p>
        </div>
        <Menu as="div" class="relative">
          <MenuButton
            class="flex rounded-full text-pmis-placeholder transition-colors hover:text-pmis-primary focus:outline-none"
            title="Tài khoản"
          >
            <UserCircle2 class="h-8 w-8" stroke-width="1" />
          </MenuButton>

          <MenuItems
            class="absolute right-0 z-50 mt-2 w-40 rounded-md border border-slate-200 bg-white py-1 shadow-lg focus:outline-none"
          >
            <HMenuItem v-slot="{ active }">
              <button
                type="button"
                class="flex w-full items-center gap-2 px-4 py-2 text-left text-sm"
                :class="active ? 'bg-pmis-primary-50 text-pmis-primary' : 'text-pmis-text'"
                @click="onLogout"
              >
                <LogOut class="h-4 w-4" />
                <span>Đăng xuất</span>
              </button>
            </HMenuItem>
          </MenuItems>
        </Menu>
      </div>
    </header>

    <!-- ============================================================ -->
    <!-- Vùng 3: Nội dung Main — trang vue động theo ngữ cảnh -->
    <!-- ============================================================ -->
    <main class="flex-1 overflow-auto bg-slate-100 p-6">
      <pt_sys_dashboard v-if="activeMenu === 'dashboard'" />

      <pt_sys_user_list v-else-if="activeMenu === 'patient'" />

      <pt_sys_history_list v-else-if="activeMenu === 'predict'" />

      <div
        v-else
        class="flex h-full flex-col items-center justify-center gap-2 text-center text-pmis-placeholder"
      >
        <p class="text-sm">Nội dung cho mục "{{ activeMenuLabel }}" sẽ hiển thị tại đây.</p>
      </div>
    </main>
  </div>
</template>

<style scoped></style>
