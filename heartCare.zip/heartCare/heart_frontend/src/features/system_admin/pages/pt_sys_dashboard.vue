<template>
  <div class="dashboard-container p-6 bg-gray-50 min-h-screen">
    <!-- Header -->
    <div class="flex justify-between items-center mb-6">
      <h1 class="text-2xl font-bold text-gray-800">📊 Overview Analytics & Heart Risk Dashboard</h1>
      <button class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
        + Thực hiện Chẩn đoán mới
      </button>
    </div>

    <!-- Khối KPI Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
      <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
        <p class="text-sm text-gray-500">Tổng Bệnh nhân</p>
        <p class="text-2xl font-bold text-gray-800">1,250</p>
      </div>
      <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
        <p class="text-sm text-gray-500">Tổng Lượt Chẩn đoán</p>
        <p class="text-2xl font-bold text-gray-800">3,420</p>
      </div>
      <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
        <p class="text-sm text-gray-500">Tỷ lệ Nguy cơ Cao</p>
        <p class="text-2xl font-bold text-red-600">28.5%</p>
      </div>
      <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
        <p class="text-sm text-gray-500">Mô hình AI Active</p>
        <p class="text-2xl font-bold text-green-600">XGBoost (89.2%)</p>
      </div>
    </div>

    <!-- Khối Biểu đồ -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
      <div class="lg:col-span-2 bg-white p-5 rounded-xl shadow-sm">
        <h3 class="font-semibold text-gray-700 mb-4">
          Mối tương quan Huyết áp & Cholesterol với Nguy cơ Tim mạch
        </h3>
        <!-- Slot render Chart (ApexCharts / Chart.js) -->
        <div class="h-64 bg-gray-100 rounded flex items-center justify-center text-gray-400">
          [Line / Scatter Chart Render Here]
        </div>
      </div>
      <div class="bg-white p-5 rounded-xl shadow-sm">
        <h3 class="font-semibold text-gray-700 mb-4">Phân bố Độ tuổi & Giới tính</h3>
        <!-- Slot render Donut Chart -->
        <div class="h-64 bg-gray-100 rounded flex items-center justify-center text-gray-400">
          [Donut Chart Render Here]
        </div>
      </div>
    </div>
  </div>
</template>
