<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import dayjs from 'dayjs'
import { Search, Plus, Eye, Pencil, Trash2, LoaderCircle } from 'lucide-vue-next'
import sg_input_text from '@/components/base/sg_input_text.vue'
import sg_select from '@/components/base/sg_select.vue'
import sg_pagination from '@/components/base/sg_pagination.vue'
import sg_message_box from '@/components/base/sg_message_box.vue'
import pt_sys_user_add from '@/features/system_admin/modals/pt_sys_user_add.vue'
import pt_sys_user_edit from '@/features/system_admin/modals/pt_sys_user_edit.vue'
import { getUserPaged, deleteUser } from '@/services/pt_user_srv'
import { useToast } from '@/utils/sg_use_toast'
import { PAGE_SIZE_OPTIONS } from '@/options/sg_site_option'
import type { PTUserGender, PTUserRead, UserPagedParams } from '@/types/pt_user'
import type { MsgBoxOptions, MsgType } from '@/types/sg_msg_box.types'

// ======================================================================
// Trang "Danh sách người dùng" — layout chia 4 vùng theo chiều dọc:
//   Vùng 1 (Header)   — tiêu đề + nút "Thêm mới"
//   Vùng 2 (Bộ lọc)   — ô tìm kiếm + số dòng / trang
//   Vùng 3 (Danh sách)— bảng người dùng
//   Vùng 4 (Phân trang)
// Lọc & phân trang phía server qua getUserPaged() (POST /users/page):
// mỗi lần đổi trang / số dòng / tìm kiếm đều gọi lại API.
// ======================================================================

const GENDER_LABELS: Record<PTUserGender, string> = { 1: 'Nam', 2: 'Nữ' }

const toast = useToast()

// Người dùng của trang hiện tại (backend đã phân trang).
const users = ref<PTUserRead[]>([])
const totalItems = ref(0)
const totalPages = ref(1)

function formatDate(value: string | null | undefined): string {
  return value ? dayjs(value).format('DD/MM/YYYY') : ''
}

// --- Vùng 2: điều kiện lọc + tham số phân trang ---
const filterForm = reactive<UserPagedParams>({
  page: 1,
  page_size: 10,
  full_name: ''
})

// Từ khóa đã áp dụng — chỉ cập nhật khi nhấn Enter / icon tìm kiếm,
// để khi chuyển trang không gửi kèm chữ đang gõ dở trong ô tìm kiếm.
const appliedFullName = ref('')

// Bật sẵn khi mới vào trang để không lóe lên "Không có người dùng phù hợp."
// trong khoảng chờ tải danh sách lần đầu.
const loading = ref(true)

// Số thứ tự lần gọi API gần nhất — bỏ qua response cũ về trễ khi người dùng đổi trang liên tục.
let loadSeq = 0

// Tải trang người dùng hiện tại từ backend.
async function loadUsers(): Promise<void> {
  const seq = ++loadSeq
  loading.value = true
  try {
    const res = await getUserPaged({
      page: filterForm.page,
      page_size: filterForm.page_size,
      full_name: appliedFullName.value || null
    })
    if (seq !== loadSeq) return

    // Trang hiện tại vượt quá tổng số trang (vd sau khi xóa dòng cuối) -> lùi lại rồi tải lại.
    if (res.items.length === 0 && res.total_pages > 0 && filterForm.page > res.total_pages) {
      filterForm.page = res.total_pages
      await loadUsers()
      return
    }

    users.value = res.items
    totalItems.value = res.total
    totalPages.value = Math.max(1, res.total_pages)
  } catch (error) {
    if (seq !== loadSeq) return
    const message = error instanceof Error ? error.message : 'Không thể tải danh sách người dùng.'
    toast.error(message)
  } finally {
    if (seq === loadSeq) loading.value = false
  }
}

onMounted(loadUsers)

// Áp dụng điều kiện lọc — gọi khi nhấn "Enter" trong ô tìm kiếm hoặc bấm icon tìm kiếm.
// Luôn quay về trang 1.
function applyFilter(): void {
  appliedFullName.value = (filterForm.full_name ?? '').trim()
  filterForm.page = 1
  void loadUsers()
}

function changePageSize(): void {
  filterForm.page = 1
  void loadUsers()
}

function changePage(page: number): void {
  filterForm.page = page
  void loadUsers()
}

// --- Vùng 1 / Vùng 3: thao tác ---
// Trạng thái hiển thị modal "Thêm mới người dùng".
const showAddModal = ref(false)

function onCreate(): void {
  showAddModal.value = true
}

function onCloseAddModal(): void {
  showAddModal.value = false
}

async function onUserSaved(): Promise<void> {
  // Modal đã gọi API thành công — giữ nguyên trang hiện hành và tải lại danh sách.
  await loadUsers()
  showAddModal.value = false
}

function onView(user: PTUserRead): void {
  // TODO: xem chi tiết người dùng
  void user
}

// Trạng thái + dữ liệu cho modal "Sửa người dùng".
const showEditModal = ref(false)
const editingUser = ref<PTUserRead | null>(null)

function onEdit(user: PTUserRead): void {
  editingUser.value = { ...user }
  showEditModal.value = true
}

function onCloseEditModal(): void {
  showEditModal.value = false
  editingUser.value = null
}

// Modal "Sửa người dùng" đã gọi API updateUser thành công — tải lại danh sách rồi đóng modal.
async function onEditModalSaved(): Promise<void> {
  onCloseEditModal()
  await loadUsers()
}

// --- Xóa người dùng ---
// Một hộp thoại dùng chung: hỏi xác nhận trước khi xóa, và báo lỗi nếu API thất bại.
const msgBox = reactive<MsgBoxOptions>({
  show: false,
  type: 'confirm',
  title: '',
  message: '',
  text_ok: 'Xóa',
  text_cancel: 'Hủy',
  show_ok: true,
  show_cancel: true
})

// Chế độ hiện tại của hộp thoại: 'confirm' = đang hỏi xóa, 'error' = đang báo lỗi / thông báo.
const msgBoxMode = ref<'confirm' | 'error'>('confirm')

// Người dùng đang chờ xác nhận xóa.
const deletingUser = ref<PTUserRead | null>(null)
const deleting = ref(false)

// Mở hộp thoại ở chế độ "thông báo": chỉ 1 nút OK.
// Luôn set đủ cả 3 cờ nút để không bị dính giá trị cũ từ lần mở trước (msgBox dùng chung).
function openInfoBox(title: string, message: string, type: MsgType = 'info'): void {
  deletingUser.value = null
  msgBoxMode.value = 'error' // onMsgBoxOk / onMsgBoxCancel chỉ đóng hộp thoại
  msgBox.type = type
  msgBox.title = title
  msgBox.message = message
  msgBox.text_ok = 'OK'
  msgBox.show_ok = true
  msgBox.show_danger = false
  msgBox.show_cancel = false
  msgBox.show = true
}

function onDelete(user: PTUserRead): void {
  // 1. Hỏi xác nhận trước khi xóa — set đủ cả 3 cờ nút.
  deletingUser.value = user
  msgBoxMode.value = 'confirm'
  msgBox.type = 'confirm'
  msgBox.title = 'Xác nhận xóa'
  msgBox.message = `Bạn có chắc chắn muốn xóa người dùng "${user.full_name}" không?`
  msgBox.text_ok = 'Xóa'
  msgBox.text_cancel = 'Hủy'
  msgBox.show_ok = true
  msgBox.show_danger = false
  msgBox.show_cancel = true
  msgBox.show = true
}

function onMsgBoxCancel(): void {
  msgBox.show = false
  if (msgBoxMode.value === 'confirm') deletingUser.value = null
}

async function onMsgBoxOk(): Promise<void> {
  // Đang ở chế độ báo lỗi -> chỉ đóng hộp thoại.
  if (msgBoxMode.value === 'error') {
    msgBox.show = false
    return
  }

  // Chế độ xác nhận -> tiến hành xóa.
  const user = deletingUser.value
  if (!user || deleting.value) return

  deleting.value = true
  try {
    // 2. Gọi API xóa người dùng.
    await deleteUser(user.users_id)

    // 3. Thành công: đóng hộp thoại, thông báo và tải lại danh sách.
    msgBox.show = false
    deletingUser.value = null
    toast.success('Xóa người dùng thành công.')
    // loadUsers() tự lùi trang nếu trang hiện tại vượt quá tổng số trang sau khi xóa.
    await loadUsers()
  } catch (error) {
    // 4. Lỗi: chuyển hộp thoại sang chế độ báo lỗi (chỉ 1 nút OK).
    const message = error instanceof Error ? error.message : 'Không thể xóa người dùng.'
    openInfoBox('Lỗi', message, 'error')
  } finally {
    deleting.value = false
  }
}
</script>

<template>
  <div class="flex h-full w-full flex-col gap-4">
    <!-- ============================================================ -->
    <!-- Vùng 1: Header -->
    <!-- ============================================================ -->
    <header class="flex shrink-0 items-center justify-between gap-4">
      <h1 class="sg-title-page uppercase text-lg">Danh sách bệnh nhân</h1>

      <button type="button" class="sg-button-primary" @click="onCreate">
        <Plus class="h-4 w-4" />
        <span>Thêm mới</span>
      </button>
    </header>

    <!-- ============================================================ -->
    <!-- Vùng 2: Điều kiện lọc -->
    <!-- ============================================================ -->
    <section class="flex shrink-0 items-center justify-between gap-3">
      <div class="w-72">
        <sg_input_text
          v-model="filterForm.full_name"
          placeholder="Tìm theo họ tên"
          input-c-s-s="py-1 sg-input w-full"
          :iconright="Search"
          @enter="applyFilter"
          @icon-right-click="applyFilter"
        />
      </div>

      <div class="w-48 shrink-0">
        <sg_select
          v-model="filterForm.page_size"
          :items="PAGE_SIZE_OPTIONS"
          :show-add="false"
          :show-edit="false"
          :show-delete="false"
          placeholder="Số dòng / trang"
          @on-change="changePageSize"
        />
      </div>
    </section>

    <!-- ============================================================ -->
    <!-- Vùng 3: Danh sách người dùng -->
    <!-- ============================================================ -->
    <section class="min-h-0 flex-1 overflow-auto sg-table-wrapper">
      <table class="w-full border-collapse text-sm">
        <thead class="sticky top-0 z-10 bg-slate-50 text-left text-pmis-label">
          <tr>
            <th class="py-3 px-4 border-b border-gray-200 font-semibold" style="min-width: 200px">
              Họ tên
            </th>
            <th class="py-3 px-4 border-b border-gray-200 font-semibold" style="min-width: 200px">
              Địa chỉ
            </th>
            <th class="py-3 px-4 border-b border-gray-200 font-semibold" style="width: 120px">
              Ngày sinh
            </th>
            <th class="py-3 px-4 border-b border-gray-200 font-semibold" style="width: 100px">
              Giới tính
            </th>
            <th class="py-3 px-4 border-b border-gray-200 font-semibold" style="width: 120px">
              Ngày tạo
            </th>
            <th class="py-3 px-4 border-b border-gray-200 font-semibold" style="width: 120px">
              Thao tác
            </th>
          </tr>
        </thead>

        <tbody>
          <!-- Đang tải dữ liệu từ backend -->
          <tr v-if="loading">
            <td colspan="6" class="py-8 text-center text-pmis-placeholder">
              <span class="inline-flex items-center gap-2">
                <LoaderCircle class="h-6 w-6 animate-spin" />
                Đang tải dữ liệu...
              </span>
            </td>
          </tr>

          <tr
            v-for="user in users"
            v-show="!loading"
            :key="user.users_id"
            class="hover:bg-pmis-primary-50/50"
          >
            <td class="py-3 px-4 border-b border-gray-200" style="min-width: 200px">
              {{ user.full_name }}
            </td>
            <td class="py-3 px-4 border-b border-gray-200" style="min-width: 200px">
              {{ user.addr }}
            </td>
            <td class="py-3 px-4 border-b border-gray-200" style="width: 120px">
              {{ formatDate(user.dob) }}
            </td>
            <td class="py-3 px-4 border-b border-gray-200" style="width: 100px">
              {{ GENDER_LABELS[user.gender] }}
            </td>
            <td class="py-3 px-4 border-b border-gray-200" style="width: 120px">
              {{ formatDate(user.created_at) }}
            </td>
            <td class="py-3 px-4 border-b border-gray-200" style="width: 120px">
              <div class="flex items-center gap-3">
                <button type="button" class="sg-button-only-icon" title="Xem" @click="onView(user)">
                  <Eye class="h-4 w-4" />
                </button>
                <button type="button" class="sg-button-only-icon" title="Sửa" @click="onEdit(user)">
                  <Pencil class="h-4 w-4" />
                </button>
                <button
                  type="button"
                  class="sg-button-only-icon-del"
                  title="Xóa"
                  @click="onDelete(user)"
                >
                  <Trash2 class="h-4 w-4" />
                </button>
              </div>
            </td>
          </tr>

          <tr v-if="!loading && users.length === 0">
            <td colspan="6" class="py-8 text-center text-pmis-placeholder">
              Không có người dùng phù hợp.
            </td>
          </tr>
        </tbody>
      </table>
    </section>

    <!-- ============================================================ -->
    <!-- Vùng 4: Phân trang (nằm bên trái) -->
    <!-- ============================================================ -->
    <footer class="flex shrink-0 items-center justify-start">
      <sg_pagination
        :curr-page="filterForm.page"
        :total-pages="totalPages"
        :total-items="totalItems"
        :page-size="filterForm.page_size"
        item-name="người dùng"
        @update:page="changePage"
      />
    </footer>

    <!-- ============================================================ -->
    <!-- Modal: Thêm mới người dùng -->
    <!-- ============================================================ -->
    <pt_sys_user_add :open="showAddModal" @close="onCloseAddModal" @saved="onUserSaved" />

    <!-- ============================================================ -->
    <!-- Modal: Sửa người dùng -->
    <!-- ============================================================ -->
    <pt_sys_user_edit
      :open="showEditModal"
      :user="editingUser"
      @close="onCloseEditModal"
      @saved="onEditModalSaved"
    />

    <!-- ============================================================ -->
    <!-- Hộp thoại: xác nhận xóa / báo lỗi khi xóa -->
    <!-- ============================================================ -->
    <sg_message_box
      :show="msgBox.show"
      :type="msgBox.type"
      :title="msgBox.title"
      :message="msgBox.message"
      :text_ok="msgBox.text_ok"
      :text_cancel="msgBox.text_cancel"
      :show_ok="msgBox.show_ok"
      :show_cancel="msgBox.show_cancel"
      @ok="onMsgBoxOk"
      @cancel="onMsgBoxCancel"
    />
  </div>
</template>

<style scoped></style>
