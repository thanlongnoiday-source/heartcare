<script setup lang="ts">
import { reactive, ref, watch } from 'vue'
import dayjs from 'dayjs'
import { X, Save, Ban } from 'lucide-vue-next'
import sg_input_text from '@/components/base/sg_input_text.vue'
import sg_input_date from '@/components/base/sg_input_date.vue'
import sg_radio from '@/components/base/sg_radio.vue'
import sg_message_box from '@/components/base/sg_message_box.vue'
import { useToast } from '@/utils/sg_use_toast'
import { createUser } from '@/services/pt_user_srv'
import type { PTUserCreate, PTUserGender, PTUserRead } from '@/types/pt_user'
import type { MsgBoxOptions } from '@/types/sg_msg_box.types'

// ======================================================================
// Modal "Thêm mới người dùng" — form nhập liệu thông tin người dùng.
//   Header : tiêu đề bên trái, nút icon "Đóng" bên phải
//   Body   : các trường lấy từ PTUserCreate (@/types/pt_user.ts)
//   Footer : nút "Close" và "Lưu" căn phải
// Nút "Lưu": validate -> gọi API createUser -> Toast + đóng modal khi
// thành công, hiển thị MessageBox khi có lỗi.
// ======================================================================

interface Props {
  /** Điều khiển hiển thị modal */
  open?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  open: false
})

const emit = defineEmits<{
  (event: 'close'): void
  // Phát ra sau khi tạo người dùng thành công — trang cha dùng để refresh danh sách.
  (event: 'saved', user: PTUserRead): void
}>()

const toast = useToast()

// Ngày sinh không được sau hôm nay.
const today = dayjs().format('YYYY-MM-DD')

// Tên đăng nhập / mật khẩu không nhập trên form — gán cố định.
const DEFAULT_USERNAME = 'test'
const DEFAULT_PASSWORD = 'test'
// Vai trò luôn là 1: 'patient'.
const DEFAULT_ROLE = 1

// Trạng thái gọi API + hộp thoại báo lỗi.
const saving = ref(false)

const msgBox = reactive<MsgBoxOptions>({
  show: false,
  type: 'error',
  title: 'Lỗi',
  message: '',
  show_ok: true,
  show_cancel: false
})

function showError(message: string): void {
  msgBox.message = message
  msgBox.show = true
}

// --- Trạng thái form ---
// dob giữ dạng 'YYYY-MM-DD' (giá trị của sg_input_date), đổi sang ISO datetime khi gửi lên.
interface UserForm {
  full_name: string
  dob: string
  gender: PTUserGender
  addr: string
}

function emptyForm(): UserForm {
  return {
    full_name: '',
    dob: '',
    gender: 1, // 1: Nam, 2: Nữ
    addr: ''
  }
}

const form = reactive<UserForm>(emptyForm())

type ErrorField = 'full_name' | 'dob' | 'addr'

const errors = reactive<Record<ErrorField, string>>({
  full_name: '',
  dob: '',
  addr: ''
})

function clearErrors(): void {
  errors.full_name = ''
  errors.dob = ''
  errors.addr = ''
}

// Reset form + lỗi mỗi khi modal được mở lại.
watch(
  () => props.open,
  (isOpen) => {
    if (isOpen) resetForm()
  }
)

function resetForm(): void {
  Object.assign(form, emptyForm())
  clearErrors()
}

// Người dùng vừa gõ vào ô nào thì xóa ngay báo lỗi của ô đó.
;(['full_name', 'dob', 'addr'] as const).forEach((field) => {
  watch(
    () => form[field],
    () => {
      if (errors[field]) errors[field] = ''
    }
  )
})

function validate(): boolean {
  clearErrors()

  const fullName = form.full_name.trim()

  if (fullName.length > 100) errors.full_name = 'Họ tên tối đa 100 ký tự.'

  if (!form.dob) errors.dob = 'Vui lòng chọn ngày sinh.'
  else if (dayjs(form.dob).isAfter(today, 'day')) errors.dob = 'Ngày sinh không hợp lệ.'

  // Backend bắt buộc addr (không rỗng, tối đa 100 ký tự)
  const addr = form.addr.trim()
  if (!addr) errors.addr = 'Vui lòng nhập địa chỉ.'
  else if (addr.length > 100) errors.addr = 'Địa chỉ tối đa 100 ký tự.'

  return !errors.full_name && !errors.dob && !errors.addr
}

function onClose(): void {
  if (saving.value) return
  emit('close')
}

async function onSave(): Promise<void> {
  // 1. Kiểm tra dữ liệu hợp lệ
  if (!validate()) return
  if (saving.value) return

  const payload: PTUserCreate = {
    username: DEFAULT_USERNAME,
    full_name: form.full_name.trim() || null,
    dob: dayjs(form.dob).format('YYYY-MM-DDTHH:mm:ss'),
    gender: form.gender,
    addr: form.addr.trim(),
    roles: DEFAULT_ROLE,
    pw: DEFAULT_PASSWORD
  }

  saving.value = true
  try {
    // 2. Gọi API lưu vào DB
    const created = await createUser(payload)

    // 3. Thành công: Toast + quay về trang "Danh sách người dùng" (đóng modal)
    toast.success('Thêm mới người dùng thành công.')
    emit('saved', created)
    emit('close')
  } catch (error) {
    // 4. Có lỗi: hiển thị MessageBox
    const message =
      error instanceof Error ? error.message : 'Không thể lưu người dùng. Vui lòng thử lại.'
    showError(message)
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <div v-if="open" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
    <div class="flex max-h-full w-full max-w-lg flex-col rounded-xl bg-white shadow-xl">
      <!-- ============================================================ -->
      <!-- Header -->
      <!-- ============================================================ -->
      <header
        class="flex shrink-0 items-center justify-between gap-4 border-b border-gray-200 px-5 py-4"
      >
        <h1 class="sg-title-page">Thêm mới bệnh nhân</h1>

        <button type="button" class="sg-button-only-icon" title="Đóng" @click="onClose">
          <X class="h-5 w-5" />
        </button>
      </header>

      <!-- ============================================================ -->
      <!-- Nội dung -->
      <!-- ============================================================ -->
      <section class="min-h-0 flex-1 overflow-auto px-5 py-4">
        <div class="flex flex-col gap-4">
          <sg_input_text
            v-model="form.full_name"
            label="Họ tên"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-2 sg-input w-full"
            placeholder="Nhập họ tên"
            :error="errors.full_name"
          />

          <sg_input_date
            v-model="form.dob"
            label="Ngày sinh"
            label-c-s-s="sg-label-input"
            input-c-s-s="p-2 sg-input w-full"
            :required-input="true"
            placeholder="Chọn ngày sinh"
            :max="today"
            :year-select="true"
            :error="errors.dob"
          />

          <div>
            <span class="sg-label-input">Giới tính</span>
            <div class="flex items-center gap-6 pt-1.5">
              <sg_radio v-model="form.gender" :value="1" label="Nam" name="user_add_gender" />
              <sg_radio v-model="form.gender" :value="2" label="Nữ" name="user_add_gender" />
            </div>
          </div>

          <sg_input_text
            v-model="form.addr"
            label="Địa chỉ"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-2 sg-input w-full"
            :required-input="true"
            placeholder="Nhập địa chỉ"
            :error="errors.addr"
          />
        </div>
      </section>

      <!-- ============================================================ -->
      <!-- Footer -->
      <!-- ============================================================ -->
      <footer
        class="flex shrink-0 items-center justify-end gap-3 border-t border-gray-200 px-5 py-4"
      >
        <button type="button" class="sg-button-secondary" :disabled="saving" @click="onClose">
          <Ban class="w-5 h-5" stroke-width="1" />Close
        </button>
        <button type="button" class="sg-button-primary" :disabled="saving" @click="onSave">
          <Save class="w-5 h-5" stroke-width="1" />{{ saving ? 'Đang lưu...' : 'Lưu' }}
        </button>
      </footer>
    </div>
  </div>

  <!-- Hộp thoại báo lỗi khi gọi API thất bại -->
  <sg_message_box
    :show="msgBox.show"
    :type="msgBox.type"
    :title="msgBox.title"
    :message="msgBox.message"
    :show_ok="msgBox.show_ok"
    :show_cancel="msgBox.show_cancel"
    @ok="msgBox.show = false"
    @cancel="msgBox.show = false"
  />
</template>

<style scoped></style>
