<script setup lang="ts">
import { reactive, ref, watch } from 'vue'
import { X, Save, Ban } from 'lucide-vue-next'
import sg_input_text from '@/components/base/sg_input_text.vue'
import sg_input_number from '@/components/base/sg_input_number.vue'
import sg_select from '@/components/base/sg_select.vue'
import sg_message_box from '@/components/base/sg_message_box.vue'
import { useToast } from '@/utils/sg_use_toast'
import { createHistory } from '@/services/pt_history_srv'
import { getUsers } from '@/services/pt_user_srv'
import type { PTHistoryCreate, PTHistoryRead, PTHistoryRiskLevel } from '@/types/pt_history'
import type { SGSelectItem } from '@/types/sg_site_type'
import type { MsgBoxOptions } from '@/types/sg_msg_box.types'

// ======================================================================
// Modal "Thêm mới chẩn đoán" — form nhập liệu 1 bản ghi lịch sử dự đoán.
//   Header : tiêu đề bên trái, nút icon "Đóng" bên phải
//   Body   : các trường lấy từ PTHistoryCreate (@/types/pt_history.ts)
//   Footer : nút "Close" và "Lưu" căn phải
// Nút "Lưu": validate -> gọi API createHistory -> Toast + đóng modal khi
// thành công, hiển thị MessageBox khi có lỗi.
// ======================================================================

interface Props {
  /** Điều khiển hiển thị modal */
  open?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  open: false
})

const emit = defineEmits<{
  (event: 'close'): void
  // Phát ra sau khi tạo lịch sử dự đoán thành công — trang cha dùng để refresh danh sách.
  (event: 'saved', history: PTHistoryRead): void
}>()

const toast = useToast()

const RISK_LEVEL_OPTIONS: SGSelectItem[] = [
  { label: 'Thấp', value: 1 },
  { label: 'Trung bình', value: 2 },
  { label: 'Cao', value: 3 }
]

// Trạng thái gọi API + hộp thoại báo lỗi.
const saving = ref(false)

const msgBox = reactive<MsgBoxOptions>({
  show: false,
  type: 'error',
  title: 'Lỗi',
  message: '',
  show_ok: true,
  show_cancel: false
})

function showError(message: string): void {
  msgBox.message = message
  msgBox.show = true
}

// --- Danh sách bệnh nhân cho ô chọn "Bệnh nhân" ---
const userOptions = ref<SGSelectItem[]>([])

async function loadUserOptions(): Promise<void> {
  try {
    // Backend giới hạn limit tối đa 100.
    const users = await getUsers({ skip: 0, limit: 100 })
    userOptions.value = users.map((u) => ({
      label: u.full_name || u.username,
      value: u.users_id
    }))
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể tải danh sách bệnh nhân.'
    toast.error(message)
  }
}

// --- Trạng thái form ---
// users_id / risk_level giữ null khi chưa chọn (giá trị rỗng của sg_select).
interface HistoryForm {
  users_id: number | null
  metric_id: number
  model_version: string
  risk_score: number
  risk_level: PTHistoryRiskLevel | null
}

function emptyForm(): HistoryForm {
  return {
    users_id: null,
    metric_id: 0,
    model_version: '',
    risk_score: 0, // 0..100, 2 chữ số thập phân
    risk_level: null // 1: 'Low', 2: 'Medium', 3: 'High'
  }
}

const form = reactive<HistoryForm>(emptyForm())

type ErrorField = 'users_id' | 'metric_id' | 'model_version' | 'risk_score' | 'risk_level'

const ERROR_FIELDS: readonly ErrorField[] = [
  'users_id',
  'metric_id',
  'model_version',
  'risk_score',
  'risk_level'
]

const errors = reactive<Record<ErrorField, string>>({
  users_id: '',
  metric_id: '',
  model_version: '',
  risk_score: '',
  risk_level: ''
})

function clearErrors(): void {
  ERROR_FIELDS.forEach((field) => (errors[field] = ''))
}

// Reset form + lỗi và tải danh sách bệnh nhân mỗi khi modal được mở lại.
watch(
  () => props.open,
  (isOpen) => {
    if (!isOpen) return
    resetForm()
    void loadUserOptions()
  }
)

function resetForm(): void {
  Object.assign(form, emptyForm())
  clearErrors()
}

// Người dùng vừa sửa ô nào thì xóa ngay báo lỗi của ô đó.
ERROR_FIELDS.forEach((field) => {
  watch(
    () => form[field],
    () => {
      if (errors[field]) errors[field] = ''
    }
  )
})

function validate(): boolean {
  clearErrors()

  if (!form.users_id) errors.users_id = 'Vui lòng chọn bệnh nhân.'

  if (!Number.isInteger(form.metric_id) || form.metric_id < 1)
    errors.metric_id = 'Mã chỉ số không hợp lệ.'

  // Backend bắt buộc model_version (tối đa 50 ký tự)
  const modelVersion = form.model_version.trim()
  if (!modelVersion) errors.model_version = 'Vui lòng nhập mô hình.'
  else if (modelVersion.length > 50) errors.model_version = 'Mô hình tối đa 50 ký tự.'

  if (Number.isNaN(form.risk_score) || form.risk_score < 0 || form.risk_score > 100)
    errors.risk_score = 'Tỷ lệ nguy cơ phải trong khoảng 0 - 100.'

  if (!form.risk_level) errors.risk_level = 'Vui lòng chọn mức nguy cơ.'

  return ERROR_FIELDS.every((field) => !errors[field])
}

function onClose(): void {
  if (saving.value) return
  emit('close')
}

async function onSave(): Promise<void> {
  // 1. Kiểm tra dữ liệu hợp lệ
  if (!validate()) return
  if (saving.value) return

  const payload: PTHistoryCreate = {
    users_id: form.users_id as number,
    metric_id: form.metric_id,
    model_version: form.model_version.trim(),
    risk_score: Math.round(form.risk_score * 100) / 100,
    risk_level: form.risk_level as PTHistoryRiskLevel
  }

  saving.value = true
  try {
    // 2. Gọi API lưu vào DB
    const created = await createHistory(payload)

    // 3. Thành công: Toast + quay về trang "Danh sách chẩn đoán" (đóng modal)
    toast.success('Thêm mới chẩn đoán thành công.')
    emit('saved', created)
    emit('close')
  } catch (error) {
    // 4. Có lỗi: hiển thị MessageBox
    const message =
      error instanceof Error ? error.message : 'Không thể lưu chẩn đoán. Vui lòng thử lại.'
    showError(message)
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <div v-if="open" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
    <div class="flex max-h-full w-full max-w-lg flex-col rounded-xl bg-white shadow-xl">
      <!-- ============================================================ -->
      <!-- Header -->
      <!-- ============================================================ -->
      <header
        class="flex shrink-0 items-center justify-between gap-4 border-b border-gray-200 px-5 py-4"
      >
        <h1 class="sg-title-page">Thêm mới chẩn đoán</h1>

        <button type="button" class="sg-button-only-icon" title="Đóng" @click="onClose">
          <X class="h-5 w-5" />
        </button>
      </header>

      <!-- ============================================================ -->
      <!-- Nội dung -->
      <!-- ============================================================ -->
      <section class="min-h-0 flex-1 overflow-auto px-5 py-4">
        <div class="flex flex-col gap-4">
          <sg_select
            v-model="form.users_id"
            :items="userOptions"
            label="Bệnh nhân"
            label-c-s-s="sg-label-input"
            :required-input="true"
            :show-add="false"
            :show-edit="false"
            :show-delete="false"
            :teleport-dropdown="true"
            placeholder="Chọn bệnh nhân"
            :error="errors.users_id"
          />

          <sg_input_number
            v-model="form.metric_id"
            label="Mã chỉ số"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-2 sg-input w-full text-right"
            :required-input="true"
            :min="0"
            placeholder="Nhập mã chỉ số"
            :error="errors.metric_id"
          />

          <sg_input_text
            v-model="form.model_version"
            label="Mô hình"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-2 sg-input w-full"
            :required-input="true"
            placeholder="Vd: XGBoost_v1.0"
            :error="errors.model_version"
          />

          <sg_input_number
            v-model="form.risk_score"
            label="Tỷ lệ nguy cơ (%)"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-2 sg-input w-full text-right"
            :required-input="true"
            :decimal="2"
            :min="0"
            :max="100"
            placeholder="0 - 100"
            :error="errors.risk_score"
          />

          <sg_select
            v-model="form.risk_level"
            :items="RISK_LEVEL_OPTIONS"
            label="Mức nguy cơ"
            label-c-s-s="sg-label-input"
            :required-input="true"
            :show-add="false"
            :show-edit="false"
            :show-delete="false"
            :teleport-dropdown="true"
            placeholder="Chọn mức nguy cơ"
            :error="errors.risk_level"
          />
        </div>
      </section>

      <!-- ============================================================ -->
      <!-- Footer -->
      <!-- ============================================================ -->
      <footer
        class="flex shrink-0 items-center justify-end gap-3 border-t border-gray-200 px-5 py-4"
      >
        <button type="button" class="sg-button-secondary" :disabled="saving" @click="onClose">
          <Ban class="w-5 h-5" stroke-width="1" />Close
        </button>
        <button type="button" class="sg-button-primary" :disabled="saving" @click="onSave">
          <Save class="w-5 h-5" stroke-width="1" />{{ saving ? 'Đang lưu...' : 'Lưu' }}
        </button>
      </footer>
    </div>
  </div>

  <!-- Hộp thoại báo lỗi khi gọi API thất bại -->
  <sg_message_box
    :show="msgBox.show"
    :type="msgBox.type"
    :title="msgBox.title"
    :message="msgBox.message"
    :show_ok="msgBox.show_ok"
    :show_cancel="msgBox.show_cancel"
    @ok="msgBox.show = false"
    @cancel="msgBox.show = false"
  />
</template>

<style scoped></style>
