<script setup lang="ts">
import { reactive, ref, watch } from 'vue'
import { X, Save, Ban } from 'lucide-vue-next'
import sg_input_number from '@/components/base/sg_input_number.vue'
import sg_select from '@/components/base/sg_select.vue'
import sg_radio from '@/components/base/sg_radio.vue'
import sg_message_box from '@/components/base/sg_message_box.vue'
import { useToast } from '@/utils/sg_use_toast'
import { createMetric } from '@/services/pt_metric_srv'
import { getUsers } from '@/services/pt_user_srv'
import type {
  PTMetricBinary,
  PTMetricCa,
  PTMetricCp,
  PTMetricCreate,
  PTMetricRead,
  PTMetricRestecg,
  PTMetricSex,
  PTMetricSlope,
  PTMetricThal
} from '@/types/pt_metric'
import type { SGSelectItem } from '@/types/sg_site_type'
import type { MsgBoxOptions } from '@/types/sg_msg_box.types'

// ======================================================================
// Modal "Thêm mới chỉ số" — form nhập liệu 1 bản ghi chỉ số sức khỏe tim mạch.
//   Header : tiêu đề bên trái, nút icon "Đóng" bên phải
//   Body   : các trường lấy từ PTMetricCreate (@/types/pt_metric.ts)
//   Footer : nút "Close" và "Lưu" căn phải
// Nút "Lưu": validate -> gọi API createMetric -> Toast + đóng modal khi
// thành công, hiển thị MessageBox khi có lỗi.
// ======================================================================

interface Props {
  /** Điều khiển hiển thị modal */
  open?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  open: false
})

const emit = defineEmits<{
  (event: 'close'): void
  // Phát ra sau khi tạo chỉ số thành công — trang cha dùng để refresh danh sách.
  (event: 'saved', metric: PTMetricRead): void
}>()

const toast = useToast()

const CP_OPTIONS: SGSelectItem[] = [
  { label: '0 - Đau thắt ngực điển hình', value: 0 },
  { label: '1 - Đau thắt ngực không điển hình', value: 1 },
  { label: '2 - Đau không do thắt ngực', value: 2 },
  { label: '3 - Không triệu chứng', value: 3 }
]

const RESTECG_OPTIONS: SGSelectItem[] = [
  { label: '0 - Bình thường', value: 0 },
  { label: '1 - Bất thường sóng ST-T', value: 1 },
  { label: '2 - Phì đại thất trái', value: 2 }
]

const SLOPE_OPTIONS: SGSelectItem[] = [
  { label: '0 - Dốc lên', value: 0 },
  { label: '1 - Phẳng', value: 1 },
  { label: '2 - Dốc xuống', value: 2 }
]

// Backend cho phép 0..3
const CA_OPTIONS: SGSelectItem[] = [
  { label: '0', value: 0 },
  { label: '1', value: 1 },
  { label: '2', value: 2 },
  { label: '3', value: 3 }
]

const THAL_OPTIONS: SGSelectItem[] = [
  { label: '1 - Bình thường', value: 1 },
  { label: '2 - Khiếm khuyết cố định', value: 2 },
  { label: '3 - Khiếm khuyết có hồi phục', value: 3 }
]

// Trạng thái gọi API + hộp thoại báo lỗi.
const saving = ref(false)

const msgBox = reactive<MsgBoxOptions>({
  show: false,
  type: 'error',
  title: 'Lỗi',
  message: '',
  show_ok: true,
  show_cancel: false
})

function showError(message: string): void {
  msgBox.message = message
  msgBox.show = true
}

// --- Danh sách bệnh nhân cho ô chọn "Bệnh nhân" ---
const userOptions = ref<SGSelectItem[]>([])

async function loadUserOptions(): Promise<void> {
  try {
    // Backend giới hạn limit tối đa 100.
    const users = await getUsers({ skip: 0, limit: 100 })
    userOptions.value = users.map((u) => ({
      label: u.full_name || u.username,
      value: u.users_id
    }))
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể tải danh sách bệnh nhân.'
    toast.error(message)
  }
}

// --- Trạng thái form ---
// Các ô chọn (sg_select) giữ null khi chưa chọn (giá trị rỗng của sg_select).
interface MetricForm {
  users_id: number | null
  age: number
  sex: PTMetricSex
  cp: PTMetricCp | null
  resting_bp: number
  cholesterol: number
  fasting_bs: PTMetricBinary
  restecg: PTMetricRestecg | null
  max_hr: number
  exercise_angina: PTMetricBinary
  oldpeak: number
  slope: PTMetricSlope | null
  ca: PTMetricCa | null
  thal: PTMetricThal | null
}

function emptyForm(): MetricForm {
  return {
    users_id: null,
    age: 0, // 1..120
    sex: 1, // 1: Nam, 0: Nữ
    cp: null, // 0..3
    resting_bp: 0, // 1..400
    cholesterol: 0, // 1..1000
    fasting_bs: 0, // 1: Đúng, 0: Sai
    restecg: null, // 0..2
    max_hr: 0, // 1..400
    exercise_angina: 0, // 1: Có, 0: Không
    oldpeak: 0, // 0..20
    slope: null, // 0..2
    ca: null, // 0..4
    thal: null // 1..3
  }
}

const form = reactive<MetricForm>(emptyForm())

type ErrorField =
  | 'users_id'
  | 'age'
  | 'cp'
  | 'resting_bp'
  | 'cholesterol'
  | 'restecg'
  | 'max_hr'
  | 'oldpeak'
  | 'slope'
  | 'ca'
  | 'thal'

const ERROR_FIELDS: readonly ErrorField[] = [
  'users_id',
  'age',
  'cp',
  'resting_bp',
  'cholesterol',
  'restecg',
  'max_hr',
  'oldpeak',
  'slope',
  'ca',
  'thal'
]

const errors = reactive<Record<ErrorField, string>>({
  users_id: '',
  age: '',
  cp: '',
  resting_bp: '',
  cholesterol: '',
  restecg: '',
  max_hr: '',
  oldpeak: '',
  slope: '',
  ca: '',
  thal: ''
})

function clearErrors(): void {
  ERROR_FIELDS.forEach((field) => (errors[field] = ''))
}

// Reset form + lỗi và tải danh sách bệnh nhân mỗi khi modal được mở lại.
watch(
  () => props.open,
  (isOpen) => {
    if (!isOpen) return
    resetForm()
    void loadUserOptions()
  }
)

function resetForm(): void {
  Object.assign(form, emptyForm())
  clearErrors()
}

// Người dùng vừa sửa ô nào thì xóa ngay báo lỗi của ô đó.
ERROR_FIELDS.forEach((field) => {
  watch(
    () => form[field],
    () => {
      if (errors[field]) errors[field] = ''
    }
  )
})

function outOfRange(value: number, min: number, max: number): boolean {
  return Number.isNaN(value) || value < min || value > max
}

// sg_select có thể emit '' khi xóa lựa chọn -> coi như chưa chọn.
function isEmptySelect(value: unknown): boolean {
  return value === null || value === undefined || value === ''
}

function validate(): boolean {
  clearErrors()

  if (!form.users_id) errors.users_id = 'Vui lòng chọn bệnh nhân.'

  if (!Number.isInteger(form.age) || outOfRange(form.age, 1, 120))
    errors.age = 'Tuổi phải trong khoảng 1 - 120.'

  if (isEmptySelect(form.cp)) errors.cp = 'Vui lòng chọn loại đau ngực.'

  // Khoảng giá trị khớp với VALID_RANGES của mô hình dự đoán (backend predict_srv.py);
  // backend chạy chẩn đoán ngay khi tạo chỉ số, giá trị ngoài khoảng sẽ bị trả lỗi 422.
  if (outOfRange(form.resting_bp, 50, 250))
    errors.resting_bp = 'Huyết áp lúc nghỉ phải trong khoảng 50 - 250.'

  if (outOfRange(form.cholesterol, 100, 700))
    errors.cholesterol = 'Cholesterol phải trong khoảng 100 - 700.'

  if (isEmptySelect(form.restecg)) errors.restecg = 'Vui lòng chọn kết quả điện tâm đồ.'

  if (outOfRange(form.max_hr, 50, 250))
    errors.max_hr = 'Nhịp tim tối đa phải trong khoảng 50 - 250.'

  if (outOfRange(form.oldpeak, 0, 10)) errors.oldpeak = 'Chênh xuống ST phải trong khoảng 0 - 10.'

  if (isEmptySelect(form.slope)) errors.slope = 'Vui lòng chọn độ dốc đoạn ST.'

  if (isEmptySelect(form.ca)) errors.ca = 'Vui lòng chọn số mạch máu chính.'

  if (isEmptySelect(form.thal)) errors.thal = 'Vui lòng chọn kết quả Thallium.'

  return ERROR_FIELDS.every((field) => !errors[field])
}

function onClose(): void {
  if (saving.value) return
  emit('close')
}

async function onSave(): Promise<void> {
  // 1. Kiểm tra dữ liệu hợp lệ
  if (!validate()) return
  if (saving.value) return

  const payload: PTMetricCreate = {
    users_id: form.users_id as number,
    age: form.age,
    sex: form.sex,
    cp: form.cp as PTMetricCp,
    resting_bp: form.resting_bp,
    cholesterol: form.cholesterol,
    fasting_bs: form.fasting_bs,
    restecg: form.restecg as PTMetricRestecg,
    max_hr: form.max_hr,
    exercise_angina: form.exercise_angina,
    oldpeak: Math.round(form.oldpeak * 100) / 100,
    slope: form.slope as PTMetricSlope,
    ca: form.ca as PTMetricCa,
    thal: form.thal as PTMetricThal
  }

  saving.value = true
  try {
    // 2. Gọi API lưu vào DB
    const created = await createMetric(payload)

    // 3. Thành công: Toast + quay về trang danh sách (đóng modal)
    toast.success('Thêm mới chỉ số thành công.')
    emit('saved', created)
    emit('close')
  } catch (error) {
    // 4. Có lỗi: hiển thị MessageBox
    const message =
      error instanceof Error ? error.message : 'Không thể lưu chỉ số. Vui lòng thử lại.'
    showError(message)
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <div v-if="open" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
    <div class="flex max-h-full w-full max-w-3xl flex-col rounded-xl bg-white shadow-xl">
      <!-- ============================================================ -->
      <!-- Header -->
      <!-- ============================================================ -->
      <header
        class="flex shrink-0 items-center justify-between gap-4 border-b border-gray-200 px-5 py-4"
      >
        <h1 class="sg-title-page">Thêm mới chỉ số</h1>

        <button type="button" class="sg-button-only-icon" title="Đóng" @click="onClose">
          <X class="h-5 w-5" />
        </button>
      </header>

      <!-- ============================================================ -->
      <!-- Nội dung -->
      <!-- ============================================================ -->
      <section class="min-h-0 flex-1 overflow-auto px-5 py-4">
        <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <sg_select
            v-model="form.users_id"
            :items="userOptions"
            label="Bệnh nhân"
            label-c-s-s="sg-label-input"
            :required-input="true"
            :show-add="false"
            :show-edit="false"
            :show-delete="false"
            :teleport-dropdown="true"
            placeholder="Chọn bệnh nhân"
            :error="errors.users_id"
          />

          <sg_input_number
            v-model="form.age"
            label="Tuổi"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-2 sg-input w-full text-right"
            :required-input="true"
            :min="1"
            :max="120"
            placeholder="1 - 120"
            :error="errors.age"
          />

          <div>
            <span class="sg-label-input">Giới tính</span>
            <div class="flex items-center gap-6 pt-1.5">
              <sg_radio v-model="form.sex" :value="1" label="Nam" name="metric_add_sex" />
              <sg_radio v-model="form.sex" :value="0" label="Nữ" name="metric_add_sex" />
            </div>
          </div>

          <sg_select
            v-model="form.cp"
            :items="CP_OPTIONS"
            label="Loại đau ngực (cp)"
            label-c-s-s="sg-label-input"
            :required-input="true"
            :show-add="false"
            :show-edit="false"
            :show-delete="false"
            :teleport-dropdown="true"
            placeholder="Chọn loại đau ngực"
            :error="errors.cp"
          />

          <sg_input_number
            v-model="form.resting_bp"
            label="Huyết áp lúc nghỉ (mmHg)"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-2 sg-input w-full text-right"
            :required-input="true"
            :min="50"
            :max="250"
            placeholder="50 - 250"
            :error="errors.resting_bp"
          />

          <sg_input_number
            v-model="form.cholesterol"
            label="Cholesterol (mg/dl)"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-2 sg-input w-full text-right"
            :required-input="true"
            :min="100"
            :max="700"
            placeholder="100 - 700"
            :error="errors.cholesterol"
          />

          <div>
            <span class="sg-label-input">Đường huyết lúc đói &gt; 120 mg/dl</span>
            <div class="flex items-center gap-6 pt-1.5">
              <sg_radio
                v-model="form.fasting_bs"
                :value="1"
                label="Đúng"
                name="metric_add_fasting_bs"
              />
              <sg_radio
                v-model="form.fasting_bs"
                :value="0"
                label="Sai"
                name="metric_add_fasting_bs"
              />
            </div>
          </div>

          <sg_select
            v-model="form.restecg"
            :items="RESTECG_OPTIONS"
            label="Điện tâm đồ lúc nghỉ (restecg)"
            label-c-s-s="sg-label-input"
            :required-input="true"
            :show-add="false"
            :show-edit="false"
            :show-delete="false"
            :teleport-dropdown="true"
            placeholder="Chọn kết quả điện tâm đồ"
            :error="errors.restecg"
          />

          <sg_input_number
            v-model="form.max_hr"
            label="Nhịp tim tối đa (bpm)"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-2 sg-input w-full text-right"
            :required-input="true"
            :min="50"
            :max="250"
            placeholder="50 - 250"
            :error="errors.max_hr"
          />

          <div>
            <span class="sg-label-input">Đau ngực khi vận động</span>
            <div class="flex items-center gap-6 pt-1.5">
              <sg_radio
                v-model="form.exercise_angina"
                :value="1"
                label="Có"
                name="metric_add_exercise_angina"
              />
              <sg_radio
                v-model="form.exercise_angina"
                :value="0"
                label="Không"
                name="metric_add_exercise_angina"
              />
            </div>
          </div>

          <sg_input_number
            v-model="form.oldpeak"
            label="Chênh xuống ST (oldpeak)"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-2 sg-input w-full text-right"
            :required-input="true"
            :decimal="1"
            :min="0"
            :max="10"
            placeholder="0 - 10"
            :error="errors.oldpeak"
          />

          <sg_select
            v-model="form.slope"
            :items="SLOPE_OPTIONS"
            label="Độ dốc đoạn ST (slope)"
            label-c-s-s="sg-label-input"
            :required-input="true"
            :show-add="false"
            :show-edit="false"
            :show-delete="false"
            :teleport-dropdown="true"
            placeholder="Chọn độ dốc"
            :error="errors.slope"
          />

          <sg_select
            v-model="form.ca"
            :items="CA_OPTIONS"
            label="Số mạch máu chính (ca)"
            label-c-s-s="sg-label-input"
            :required-input="true"
            :show-add="false"
            :show-edit="false"
            :show-delete="false"
            :teleport-dropdown="true"
            placeholder="Chọn số mạch máu"
            :error="errors.ca"
          />

          <sg_select
            v-model="form.thal"
            :items="THAL_OPTIONS"
            label="Thallium scan (thal)"
            label-c-s-s="sg-label-input"
            :required-input="true"
            :show-add="false"
            :show-edit="false"
            :show-delete="false"
            :teleport-dropdown="true"
            placeholder="Chọn kết quả Thallium"
            :error="errors.thal"
          />
        </div>
      </section>

      <!-- ============================================================ -->
      <!-- Footer -->
      <!-- ============================================================ -->
      <footer
        class="flex shrink-0 items-center justify-end gap-3 border-t border-gray-200 px-5 py-4"
      >
        <button type="button" class="sg-button-secondary" :disabled="saving" @click="onClose">
          <Ban class="w-5 h-5" stroke-width="1" />Close
        </button>
        <button type="button" class="sg-button-primary" :disabled="saving" @click="onSave">
          <Save class="w-5 h-5" stroke-width="1" />{{ saving ? 'Đang lưu...' : 'Lưu' }}
        </button>
      </footer>
    </div>
  </div>

  <!-- Hộp thoại báo lỗi khi gọi API thất bại -->
  <sg_message_box
    :show="msgBox.show"
    :type="msgBox.type"
    :title="msgBox.title"
    :message="msgBox.message"
    :show_ok="msgBox.show_ok"
    :show_cancel="msgBox.show_cancel"
    @ok="msgBox.show = false"
    @cancel="msgBox.show = false"
  />
</template>

<style scoped></style>
