<script setup lang="ts">
import { reactive } from 'vue'
import sg_input_number from '@/components/base/sg_input_number.vue'
import sg_select from '@/components/base/sg_select.vue'
import type { SGSelectItem } from '@/types/sg_site_type'

// Thuộc tính: Boundary Conditions / Miệng gió cấp (Supply)
const directionOptions: SGSelectItem[] = [
  { label: 'Thổi xuống', value: 'down' },
  { label: 'Thổi ngang', value: 'horizontal' },
  { label: 'Thổi xoáy (swirl)', value: 'swirl' }
]

const defaults = {
  flowRate: 500,
  temperature: 18,
  direction: 'down'
}

const fieldValues = reactive({ ...defaults })

const emit = defineEmits<{
  apply: [value: typeof defaults]
}>()

function resetFields(): void {
  Object.assign(fieldValues, defaults)
}

// Nhấn "Áp dụng" -> phát sự kiện apply mang giá trị hiện tại của form,
// sg_engr_main.vue lắng nghe để đồng bộ về objSGSetupRoomBase
// (flowRate -> velocity_inlet, temperature -> temp_inlet).
function applyFields(): void {
  emit('apply', { ...fieldValues })
}
</script>

<template>
  <div class="border-b border-slate-100 px-4 py-3">
    <h2 class="sg-title-group">Thuộc tính</h2>
    <p class="mt-0.5 truncate text-xs text-pmis-placeholder">
      Boundary Conditions / Miệng gió cấp (Supply)
    </p>
  </div>

  <div class="flex flex-1 flex-col justify-between overflow-y-auto">
    <div class="space-y-4 p-4">
      <sg_input_number
        v-model="fieldValues.flowRate"
        label="Lưu lượng gió (m³/h)"
        :decimal="0"
        :min="0"
      />
      <sg_input_number
        v-model="fieldValues.temperature"
        label="Nhiệt độ gió cấp (°C)"
        :decimal="1"
      />
      <sg_select v-model="fieldValues.direction" label="Hướng thổi" :items="directionOptions" />
    </div>

    <div class="flex shrink-0 gap-2 border-t border-slate-100 p-4">
      <button type="button" class="flex-1 sg-button-secondary" @click="resetFields">Đặt lại</button>
      <button type="button" class="flex-1 sg-button-primary" @click="applyFields">Áp dụng</button>
    </div>
  </div>
</template>

<style scoped></style>
