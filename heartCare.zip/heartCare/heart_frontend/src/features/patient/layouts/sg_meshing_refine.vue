<script setup lang="ts">
import { reactive } from 'vue'
import sg_input_number from '@/components/base/sg_input_number.vue'
import sg_select from '@/components/base/sg_select.vue'
import type { SGSelectItem } from '@/types/sg_site_type'

// Thuộc tính: Meshing / Vùng làm mịn lưới
const regionOptions: SGSelectItem[] = [
  { label: 'Toàn bộ phòng', value: 'whole-room' },
  { label: 'Quanh miệng gió', value: 'around-diffuser' },
  { label: 'Quanh nguồn nhiệt', value: 'around-heat-source' }
]

const defaults = {
  region: 'around-diffuser',
  targetCellSize: 0.03
}

const fieldValues = reactive({ ...defaults })

function resetFields(): void {
  Object.assign(fieldValues, defaults)
}
</script>

<template>
  <div class="border-b border-slate-100 px-4 py-3">
    <h2 class="sg-title-group">Thuộc tính</h2>
    <p class="mt-0.5 truncate text-xs text-pmis-placeholder">Meshing / Vùng làm mịn lưới</p>
  </div>

  <div class="flex flex-1 flex-col justify-between overflow-y-auto">
    <div class="space-y-4 p-4">
      <sg_select v-model="fieldValues.region" label="Vùng làm mịn" :items="regionOptions" />
      <sg_input_number
        v-model="fieldValues.targetCellSize"
        label="Kích thước ô mục tiêu (m)"
        :decimal="3"
        :min="0"
      />
    </div>

    <div class="flex shrink-0 gap-2 border-t border-slate-100 p-4">
      <button type="button" class="flex-1 sg-button-secondary" @click="resetFields">Đặt lại</button>
      <button type="button" class="flex-1 sg-button-primary">Áp dụng</button>
    </div>
  </div>
</template>

<style scoped></style>
