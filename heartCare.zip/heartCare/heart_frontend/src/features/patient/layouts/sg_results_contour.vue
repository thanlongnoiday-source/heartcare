<script setup lang="ts">
import { reactive } from 'vue'
import sg_select from '@/components/base/sg_select.vue'
import type { SGSelectItem } from '@/types/sg_site_type'

// Thuộc tính: Results / Biểu đồ nhiệt độ (Contour)
const variableOptions: SGSelectItem[] = [
  { label: 'Nhiệt độ', value: 'temperature' },
  { label: 'Vận tốc', value: 'velocity' },
  { label: 'Áp suất', value: 'pressure' }
]

const colorScaleOptions: SGSelectItem[] = [
  { label: 'Rainbow', value: 'rainbow' },
  { label: 'Jet', value: 'jet' },
  { label: 'Grayscale', value: 'grayscale' }
]

const defaults = {
  variable: 'temperature',
  colorScale: 'rainbow'
}

const fieldValues = reactive({ ...defaults })

function resetFields(): void {
  Object.assign(fieldValues, defaults)
}
</script>

<template>
  <div class="border-b border-slate-100 px-4 py-3">
    <h2 class="sg-title-group">Thuộc tính</h2>
    <p class="mt-0.5 truncate text-xs text-pmis-placeholder">
      Results / Biểu đồ nhiệt độ (Contour)
    </p>
  </div>

  <div class="flex flex-1 flex-col justify-between overflow-y-auto">
    <div class="space-y-4 p-4">
      <sg_select
        v-model="fieldValues.variable"
        label="Đại lượng hiển thị"
        :items="variableOptions"
      />
      <sg_select v-model="fieldValues.colorScale" label="Thang màu" :items="colorScaleOptions" />
    </div>

    <div class="flex shrink-0 gap-2 border-t border-slate-100 p-4">
      <button type="button" class="flex-1 sg-button-secondary" @click="resetFields">Đặt lại</button>
      <button type="button" class="flex-1 sg-button-primary">Áp dụng</button>
    </div>
  </div>
</template>

<style scoped></style>
