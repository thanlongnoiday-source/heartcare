<script setup lang="ts">
import { reactive } from 'vue'
import sg_input_number from '@/components/base/sg_input_number.vue'

// Thuộc tính: Results / Đường dòng (Streamlines)
const defaults = {
  seedPoints: 40,
  lineWidth: 2
}

const fieldValues = reactive({ ...defaults })

function resetFields(): void {
  Object.assign(fieldValues, defaults)
}
</script>

<template>
  <div class="border-b border-slate-100 px-4 py-3">
    <h2 class="sg-title-group">Thuộc tính</h2>
    <p class="mt-0.5 truncate text-xs text-pmis-placeholder">
      Results / Đường dòng (Streamlines)
    </p>
  </div>

  <div class="flex flex-1 flex-col justify-between overflow-y-auto">
    <div class="space-y-4 p-4">
      <sg_input_number
        v-model="fieldValues.seedPoints"
        label="Số điểm phát dòng (seed)"
        :decimal="0"
        :min="1"
      />
      <sg_input_number
        v-model="fieldValues.lineWidth"
        label="Độ dày đường dòng (px)"
        :decimal="1"
        :min="0"
      />
    </div>

    <div class="flex shrink-0 gap-2 border-t border-slate-100 p-4">
      <button type="button" class="flex-1 sg-button-secondary" @click="resetFields">Đặt lại</button>
      <button type="button" class="flex-1 sg-button-primary">Áp dụng</button>
    </div>
  </div>
</template>

<style scoped></style>
