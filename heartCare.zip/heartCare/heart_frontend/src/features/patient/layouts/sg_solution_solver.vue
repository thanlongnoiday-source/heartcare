<script setup lang="ts">
import { reactive } from 'vue'
import sg_input_number from '@/components/base/sg_input_number.vue'
import sg_select from '@/components/base/sg_select.vue'
import type { SGSelectItem } from '@/types/sg_site_type'

// Thuộc tính: Solution / Bộ giải (Solver)
const schemeOptions: SGSelectItem[] = [
  { label: 'SIMPLE', value: 'simple' },
  { label: 'SIMPLEC', value: 'simplec' },
  { label: 'PISO', value: 'piso' }
]

const defaults = {
  scheme: 'simple',
  relaxationFactor: 0.7
}

const fieldValues = reactive({ ...defaults })

function resetFields(): void {
  Object.assign(fieldValues, defaults)
}
</script>

<template>
  <div class="border-b border-slate-100 px-4 py-3">
    <h2 class="sg-title-group">Thuộc tính</h2>
    <p class="mt-0.5 truncate text-xs text-pmis-placeholder">Solution / Bộ giải (Solver)</p>
  </div>

  <div class="flex flex-1 flex-col justify-between overflow-y-auto">
    <div class="space-y-4 p-4">
      <sg_select v-model="fieldValues.scheme" label="Thuật toán bộ giải" :items="schemeOptions" />
      <sg_input_number
        v-model="fieldValues.relaxationFactor"
        label="Hệ số relaxation"
        :decimal="2"
        :min="0"
      />
    </div>

    <div class="flex shrink-0 gap-2 border-t border-slate-100 p-4">
      <button type="button" class="flex-1 sg-button-secondary" @click="resetFields">Đặt lại</button>
      <button type="button" class="flex-1 sg-button-primary">Áp dụng</button>
    </div>
  </div>
</template>

<style scoped></style>
