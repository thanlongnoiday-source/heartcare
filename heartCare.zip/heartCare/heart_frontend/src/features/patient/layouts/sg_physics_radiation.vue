<script setup lang="ts">
import { reactive } from 'vue'
import sg_input_number from '@/components/base/sg_input_number.vue'
import sg_select from '@/components/base/sg_select.vue'
import type { SGSelectItem } from '@/types/sg_site_type'

// Thuộc tính: Physics / Models / Bức xạ nhiệt
const modelOptions: SGSelectItem[] = [
  { label: 'Không bật', value: 'none' },
  { label: 'Surface-to-Surface (S2S)', value: 's2s' },
  { label: 'Discrete Ordinates (DO)', value: 'do' }
]

const defaults = {
  model: 'none',
  emissivity: 0.9
}

const fieldValues = reactive({ ...defaults })

function resetFields(): void {
  Object.assign(fieldValues, defaults)
}
</script>

<template>
  <div class="border-b border-slate-100 px-4 py-3">
    <h2 class="sg-title-group">Thuộc tính</h2>
    <p class="mt-0.5 truncate text-xs text-pmis-placeholder">Physics / Models / Bức xạ nhiệt</p>
  </div>

  <div class="flex flex-1 flex-col justify-between overflow-y-auto">
    <div class="space-y-4 p-4">
      <sg_select v-model="fieldValues.model" label="Mô hình bức xạ nhiệt" :items="modelOptions" />
      <sg_input_number
        v-model="fieldValues.emissivity"
        label="Độ phát xạ (emissivity)"
        :decimal="2"
        :min="0"
      />
    </div>

    <div class="flex shrink-0 gap-2 border-t border-slate-100 p-4">
      <button type="button" class="flex-1 sg-button-secondary" @click="resetFields">Đặt lại</button>
      <button type="button" class="flex-1 sg-button-primary">Áp dụng</button>
    </div>
  </div>
</template>

<style scoped></style>
