<script setup lang="ts">
import { reactive, watch } from 'vue'
import { Save, Trash2, X } from 'lucide-vue-next'
import sg_input_number from '@/components/base/sg_input_number.vue'
import sg_input_text from '@/components/base/sg_input_text.vue'
import sg_select from '@/components/base/sg_select.vue'
import type { SGOutletRead, SGOutletUpdate } from '@/types/sg_outlet'
import { OUTLET_CONTROL_MODE_OPTIONS, OUTLET_CONTROL_MODE } from '@/constants/sg_engr_outlet_const'
import { newSGOutletRead } from '@/services/sg_outlet_srv'
import { roundDecimal } from '@/utils/sg_formatters'

// Panel "Miệng xả" — chỉnh sửa toàn bộ trường của một outlet, ánh xạ 1-1 theo
// src/types/sg_outlet.ts (SGOutletBase). Khi component cha truyền vào một bản ghi
// đã lưu (SGOutletRead), form được nạp sẵn theo bản ghi đó.
// type OutletFields = {
//   outlet_code: string
//   outlet_name: string
//   control_mode: number
//   flow_rate: number
//   pos_x: number
//   pos_y: number
//   pos_z: number
//   size_w: number
//   size_h: number
//   geometry_id: number
// }

const props = defineProps<{
  // Bản ghi outlet hiện có (đã lưu ở backend) dùng để nạp sẵn giá trị form.
  outlet?: SGOutletRead
}>()

const emit = defineEmits<{
  save: [value: SGOutletUpdate]
  delete: [outletId: number]
  deselect: []
}>()

const defaults: SGOutletRead = newSGOutletRead()
const fieldValues = reactive<SGOutletRead>({ ...defaults })

watch(
  () => props.outlet,
  (outlet) => {
    if (!outlet) {
      Object.assign(fieldValues, defaults)
      return
    }
    fieldValues.outlet_code = outlet.outlet_code ?? ''
    fieldValues.outlet_name = outlet.outlet_name ?? ''
    fieldValues.control_mode = outlet.control_mode ?? 0
    fieldValues.flow_rate = outlet.flow_rate ?? 0
    fieldValues.pressure = outlet.pressure ?? 0
    fieldValues.back_temp = outlet.back_temp ?? 0
    fieldValues.turbulence = outlet.turbulence ?? 0
    fieldValues.pos_x = outlet.pos_x ?? 0
    fieldValues.pos_y = outlet.pos_y ?? 0
    fieldValues.pos_z = outlet.pos_z ?? 0
    fieldValues.size_w = outlet.size_w ?? 0
    fieldValues.size_h = outlet.size_h ?? 0
    fieldValues.geometry_id = outlet.geometry_id ?? 0
  },
  { immediate: true }
)

// Nhấn "Lưu" -> phát sự kiện save mang payload SGOutletUpdate. Tên miệng hồi để
// trống được gửi thành null (đúng quy ước `X | None` của backend).
function saveFields(): void {
  // Mọi field số thực (Decimal ở backend) phải qua roundDecimal() trước khi gửi API
  // để tránh lỗi "decimal_max_digits" (xem sg_formatters.ts).
  const value: SGOutletUpdate = {
    outlet_code: fieldValues.outlet_code,
    outlet_name: fieldValues.outlet_name || null,
    control_mode: fieldValues.control_mode,
    flow_rate: roundDecimal(fieldValues.flow_rate),
    pressure: roundDecimal(fieldValues.pressure),
    back_temp: roundDecimal(fieldValues.back_temp),
    turbulence: roundDecimal(fieldValues.turbulence),
    pos_x: roundDecimal(fieldValues.pos_x),
    pos_y: roundDecimal(fieldValues.pos_y),
    pos_z: roundDecimal(fieldValues.pos_z),
    size_w: roundDecimal(fieldValues.size_w),
    size_h: roundDecimal(fieldValues.size_h),
    geometry_id: fieldValues.geometry_id
  }
  emit('save', value)
}

// Nhấn "Xóa" -> phát sự kiện delete kèm outlet_id. Component cha đảm nhận gọi API
// + xác nhận.
function deleteOutlet(): void {
  if (!props.outlet) return
  emit('delete', props.outlet.outlet_id)
}
</script>

<template>
  <!-- Header -->
  <div class="border-b border-slate-100 px-4 py-3">
    <h2 class="sg-title-group">MIỆNG XẢ</h2>
  </div>

  <!-- Main: các field trải dọc trong 1 cột -->
  <div class="sg-scrollbar-thin flex flex-1 flex-col justify-between overflow-y-auto">
    <div class="flex flex-col gap-4 p-4">
      <sg_input_text
        v-model="fieldValues.outlet_code"
        label="Tên định danh"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input p-1 w-full"
        placeholder="VD: OUT-001"
      />

      <sg_input_text
        v-model="fieldValues.outlet_name"
        label="Diễn giải"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input p-1 w-full"
        placeholder="VD: Miệng xả 01"
      />

      <sg_select
        v-model="fieldValues.control_mode"
        label="Loại miệng xả"
        selectcss="sg-select py-1"
        :show-add="false"
        :show-edit="false"
        :show-delete="false"
        :items="OUTLET_CONTROL_MODE_OPTIONS"
      />

      <template v-if="fieldValues.control_mode === OUTLET_CONTROL_MODE.PRESSURE_OUTLET">
        <sg_input_number
          v-model="fieldValues.back_temp"
          label="Nhiệt độ dòng ngược (oC)"
          label-c-s-s="sg-label-input"
          input-c-s-s="sg-input p-1 w-full"
          :decimal="2"
          :min="0"
        />
      </template>

      <template v-else-if="fieldValues.control_mode === OUTLET_CONTROL_MODE.FLOW_RATE">
        <sg_input_number
          v-model="fieldValues.flow_rate"
          label="Lưu lượng gió (m³/h)"
          label-c-s-s="sg-label-input"
          input-c-s-s="sg-input p-1 w-full"
          :decimal="2"
          :min="0"
        />
      </template>

      <sg_input_number
        v-model="fieldValues.turbulence"
        label="Cường độ xáo trộn (%)"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input p-1 w-full"
        :decimal="2"
        :min="0"
        :max="100"
      />

      <div>
        <span class="mb-1 block text-sm font-medium text-pmis-text">Tâm khối (m)</span>
        <div class="grid grid-cols-3 gap-2">
          <sg_input_number
            v-model="fieldValues.pos_x"
            label="X"
            label-c-s-s="sg-label-input"
            input-c-s-s="sg-input p-1 w-full"
            :decimal="2"
          />
          <sg_input_number
            v-model="fieldValues.pos_y"
            label="Y"
            label-c-s-s="sg-label-input"
            input-c-s-s="sg-input p-1 w-full"
            :decimal="2"
          />
          <sg_input_number
            v-model="fieldValues.pos_z"
            label="Z"
            label-c-s-s="sg-label-input"
            input-c-s-s="sg-input p-1 w-full"
            :decimal="2"
          />
        </div>
      </div>

      <div>
        <span class="mb-1 block text-sm font-medium text-pmis-text">Kích thước (m)</span>
        <div class="grid grid-cols-3 gap-2">
          <sg_input_number
            v-model="fieldValues.size_w"
            label="Rộng (Y)"
            label-c-s-s="sg-label-input"
            input-c-s-s="sg-input p-1 w-full"
            :decimal="2"
            :min="0"
          />
          <sg_input_number
            v-model="fieldValues.size_h"
            label="Cao (Z)"
            label-c-s-s="sg-label-input"
            input-c-s-s="sg-input p-1 w-full"
            :decimal="2"
            :min="0"
          />
        </div>
      </div>
    </div>

    <!-- Footer -->
    <div class="flex shrink-0 flex-col gap-2 border-t border-slate-100 p-4">
      <button type="button" class="sg-button-secondary" @click="emit('deselect')">
        <X class="h-5 w-5" stroke-width="1" />Bỏ chọn
      </button>
      <button type="button" class="sg-button-primary" @click="saveFields">
        <Save class="h-5 w-5" stroke-width="1" />Lưu
      </button>
      <button type="button" class="sg-button-danger" @click="deleteOutlet">
        <Trash2 class="h-5 w-5" stroke-width="1" />Xóa
      </button>
    </div>
  </div>
</template>

<style scoped></style>
