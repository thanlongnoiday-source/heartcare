<script setup lang="ts">
import { computed, reactive, watch } from 'vue'
import { Save, Trash2 } from 'lucide-vue-next'
import sg_input_number from '@/components/base/sg_input_number.vue'
import sg_input_text from '@/components/base/sg_input_text.vue'
import sg_radio from '@/components/base/sg_radio.vue'
import type { SGGeometryRead, SGGeometryUpdate } from '@/types/sg_geometry'
import { GEOMETRY_STATUS } from '@/constants/sg_engr_geometry_const'
import { roundDecimal } from '@/utils/sg_formatters'

// Panel "Các thuộc tính" — chỉnh sửa toàn bộ trường của một geometry, ánh xạ 1-1
// theo src/types/sg_geometry.ts (SGGeometryBase). Khi component cha truyền vào
// một bản ghi đã lưu (SGGeometryRead), form được nạp sẵn theo bản ghi đó.
type GeometryFields = {
  geometry_code: string
  geometry_name: string
  project_id: number
  leng: number
  width: number
  height: number
  cad_file_path: string
  obj_file_path: string
  geometry_type: number
  geometry_status: number
}

const props = defineProps<{
  // Bản ghi geometry hiện có (đã lưu ở backend) dùng để nạp sẵn giá trị form.
  geometry?: SGGeometryRead
}>()

const emit = defineEmits<{
  save: [value: SGGeometryUpdate]
  delete: [geometryId: number]
}>()

const defaults: GeometryFields = {
  geometry_code: '',
  geometry_name: '',
  project_id: 0,
  leng: 0,
  width: 0,
  height: 0,
  cad_file_path: '',
  obj_file_path: '',
  geometry_type: 1,
  geometry_status: 0
}

const fieldValues = reactive<GeometryFields>({ ...defaults })

// Bản ghi hiện tại có đang ở trạng thái "Nháp" (Draft) hay không.
// - Ở "Nháp": cho phép sửa tất cả trường.
// - Ngoài "Nháp": chỉ cho phép sửa trường "Tên geometry".
const isDraft = computed<boolean>(() => props.geometry?.geometry_status === GEOMETRY_STATUS.DRAFT)

// Không cho phép cập nhật geometry về trạng thái "Nháp" (Draft): chỉ được chọn Draft
// khi bản ghi hiện tại vốn đã ở trạng thái Draft (giữ nguyên, không đổi được sang khác
// rồi quay lại).
const isDraftAllowed = isDraft

// Chỉ cho phép xóa geometry đang ở trạng thái "Nháp" (Draft).
const isDeletable = isDraft

// Đồng bộ form theo prop `geometry` mỗi khi component cha truyền bản ghi mới.
watch(
  () => props.geometry,
  (geometry) => {
    if (!geometry) return
    fieldValues.geometry_code = geometry.geometry_code ?? ''
    fieldValues.geometry_name = geometry.geometry_name ?? ''
    fieldValues.project_id = geometry.project_id ?? 0
    fieldValues.leng = geometry.leng ?? 0
    fieldValues.width = geometry.width ?? 0
    fieldValues.height = geometry.height ?? 0
    fieldValues.cad_file_path = geometry.cad_file_path ?? ''
    fieldValues.obj_file_path = geometry.obj_file_path ?? ''
    fieldValues.geometry_type = geometry.geometry_type ?? 1
    fieldValues.geometry_status = geometry.geometry_status ?? 0
  },
  { immediate: true }
)

// Nhấn "Lưu" -> phát sự kiện save mang payload SGGeometryUpdate. Đường dẫn file để
// trống được gửi thành null (đúng quy ước `X | None` của backend).
function saveFields(): void {
  // Chặn cập nhật về "Nháp" (Draft) nếu bản ghi không vốn ở trạng thái này.
  if (fieldValues.geometry_status === GEOMETRY_STATUS.DRAFT && !isDraftAllowed.value) {
    fieldValues.geometry_status = props.geometry?.geometry_status ?? GEOMETRY_STATUS.ACTIVE
  }

  // Mọi field số thực (Decimal ở backend) phải qua roundDecimal() trước khi gửi API
  // để tránh lỗi "decimal_max_digits" (xem sg_formatters.ts).
  const value: SGGeometryUpdate = {
    geometry_code: fieldValues.geometry_code,
    geometry_name: fieldValues.geometry_name,
    project_id: fieldValues.project_id,
    leng: roundDecimal(fieldValues.leng),
    width: roundDecimal(fieldValues.width),
    height: roundDecimal(fieldValues.height),
    cad_file_path: fieldValues.cad_file_path || null,
    obj_file_path: fieldValues.obj_file_path || null,
    geometry_type: fieldValues.geometry_type,
    geometry_status: fieldValues.geometry_status
  }
  emit('save', value)
}

// Nhấn "Xóa" -> phát sự kiện delete kèm geometry_id. Chỉ thực hiện khi geometry
// đang ở trạng thái "Nháp" (Draft); component cha đảm nhận gọi API + xác nhận.
function deleteGeometry(): void {
  if (!isDeletable.value || !props.geometry) return
  emit('delete', props.geometry.geometry_id)
}
</script>

<template>
  <!-- Header -->
  <div class="border-b border-slate-100 px-4 py-3">
    <h2 class="sg-title-pops">Các thuộc tính</h2>
  </div>

  <!-- Main: các field trải dọc trong 1 cột -->
  <div class="sg-scrollbar-thin flex flex-1 flex-col justify-between overflow-y-auto">
    <div class="flex flex-col gap-4 p-4">
      <sg_input_text
        v-model="fieldValues.geometry_code"
        label="Tên định danh"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input py-2 w-full"
        placeholder="VD: GEO-001"
        :disabled="!isDraft"
      />

      <sg_input_text
        v-model="fieldValues.geometry_name"
        label="Diễn giải"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input py-2 w-full"
        placeholder="VD: Phòng họp tầng 1"
      />

      <div>
        <span class="mb-1 block text-sm font-medium text-pmis-text">Kích thước (m)</span>
        <div class="grid grid-cols-3 gap-2">
          <sg_input_number
            v-model="fieldValues.leng"
            label="Dài (X)"
            label-c-s-s="sg-label-input"
            input-c-s-s="sg-input p-2 w-full"
            :decimal="2"
            :min="0"
            :disabled="!isDraft"
          />

          <sg_input_number
            v-model="fieldValues.width"
            label="Rộng (Y)"
            label-c-s-s="sg-label-input"
            input-c-s-s="sg-input p-2 w-full"
            :decimal="2"
            :min="0"
            :disabled="!isDraft"
          />

          <sg_input_number
            v-model="fieldValues.height"
            label="Cao (Z)"
            label-c-s-s="sg-label-input"
            input-c-s-s="sg-input p-2 w-full"
            :decimal="2"
            :min="0"
            :disabled="!isDraft"
          />
        </div>
      </div>

      <sg_radio
        v-model="fieldValues.geometry_status"
        :value="GEOMETRY_STATUS.DRAFT"
        :disabled="!isDraft"
        label="Draft"
        name="status"
      />
      <sg_radio
        v-model="fieldValues.geometry_status"
        :value="GEOMETRY_STATUS.ACTIVE"
        :disabled="!isDraft"
        label="Active"
        name="status"
      />
      <sg_radio
        v-model="fieldValues.geometry_status"
        :value="GEOMETRY_STATUS.INACTIVE"
        :disabled="!isDraft"
        label="Inactive"
        name="status"
      />
    </div>

    <!-- Footer -->
    <hr />
    <div class="flex shrink-0 flex-col gap-2 p-4">
      <button type="button" class="sg-button-primary" @click="saveFields">
        <Save class="w-5 h-5" stroke-width="1" />Lưu
      </button>
      <button
        type="button"
        class="sg-button-danger"
        :disabled="!isDeletable"
        :title="isDeletable ? 'Xóa khối hình học' : 'Chỉ xóa được khối hình học ở trạng thái Nháp'"
        @click="deleteGeometry"
      >
        <Trash2 class="w-5 h-5" stroke-width="1" />Xóa
      </button>
    </div>
  </div>
</template>

<style scoped></style>
