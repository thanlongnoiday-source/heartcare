<script setup lang="ts">
import { reactive, watch } from 'vue'
import { Save, Trash2, X } from 'lucide-vue-next'
import sg_input_number from '@/components/base/sg_input_number.vue'
import sg_input_text from '@/components/base/sg_input_text.vue'
import type { SGInletRead, SGInletUpdate } from '@/types/sg_inlet'
import { roundDecimal } from '@/utils/sg_formatters'
import {
  DEFAULT_INLET_FLOW_RATE_FIX,
  DEFAULT_INLET_SIZE_H,
  DEFAULT_INLET_SIZE_W,
  DEFAULT_INLET_TEMP_COOLING
} from '@/constants/sg_engr_inlet_const'

// Panel "Miệng cấp" — chỉnh sửa toàn bộ trường của một inlet, ánh xạ 1-1 theo
// src/types/sg_inlet.ts (SGInletBase). Khi component cha truyền vào một bản ghi
// đã lưu (SGInletRead), form được nạp sẵn theo bản ghi đó.
type InletFields = {
  inlet_code: string
  inlet_name: string
  flow_rate: number
  temperature: number
  pos_x: number
  pos_y: number
  pos_z: number
  size_w: number
  size_h: number
  geometry_id: number
}

const props = defineProps<{
  // Bản ghi inlet hiện có (đã lưu ở backend) dùng để nạp sẵn giá trị form.
  inlet?: SGInletRead
}>()

const emit = defineEmits<{
  save: [value: SGInletUpdate]
  delete: [inletId: number]
  deselect: []
}>()

const defaults: InletFields = {
  inlet_code: '',
  inlet_name: '',
  flow_rate: DEFAULT_INLET_FLOW_RATE_FIX,
  temperature: DEFAULT_INLET_TEMP_COOLING,
  pos_x: 0,
  pos_y: 0,
  pos_z: 0,
  size_w: DEFAULT_INLET_SIZE_W,
  size_h: DEFAULT_INLET_SIZE_H,
  geometry_id: 0
}

const fieldValues = reactive<InletFields>({ ...defaults })

// Đồng bộ form theo prop `inlet` mỗi khi component cha truyền bản ghi mới.
watch(
  () => props.inlet,
  (inlet) => {
    if (!inlet) {
      Object.assign(fieldValues, defaults)
      return
    }
    fieldValues.inlet_code = inlet.inlet_code ?? ''
    fieldValues.inlet_name = inlet.inlet_name ?? ''
    fieldValues.flow_rate = inlet.flow_rate ?? 0
    fieldValues.temperature = inlet.temperature ?? 0
    fieldValues.pos_x = inlet.pos_x ?? 0
    fieldValues.pos_y = inlet.pos_y ?? 0
    fieldValues.pos_z = inlet.pos_z ?? 0
    fieldValues.size_w = inlet.size_w ?? 0
    fieldValues.size_h = inlet.size_h ?? 0
    fieldValues.geometry_id = inlet.geometry_id ?? 0
  },
  { immediate: true }
)

// Nhấn "Lưu" -> phát sự kiện save mang payload SGInletUpdate. Tên miệng cấp để
// trống được gửi thành null (đúng quy ước `X | None` của backend).
function saveFields(): void {
  // Mọi field số thực (Decimal ở backend) phải qua roundDecimal() trước khi gửi API
  // để tránh lỗi "decimal_max_digits" (xem sg_formatters.ts).
  const value: SGInletUpdate = {
    inlet_code: fieldValues.inlet_code,
    inlet_name: fieldValues.inlet_name || null,
    flow_rate: roundDecimal(fieldValues.flow_rate),
    temperature: roundDecimal(fieldValues.temperature),
    pos_x: roundDecimal(fieldValues.pos_x),
    pos_y: roundDecimal(fieldValues.pos_y),
    pos_z: roundDecimal(fieldValues.pos_z),
    size_w: roundDecimal(fieldValues.size_w),
    size_h: roundDecimal(fieldValues.size_h),
    geometry_id: fieldValues.geometry_id
  }
  emit('save', value)
}

// Nhấn "Xóa" -> phát sự kiện delete kèm inlet_id. Component cha đảm nhận gọi API
// + xác nhận.
function deleteInlet(): void {
  if (!props.inlet) return
  emit('delete', props.inlet.inlet_id)
}
</script>

<template>
  <!-- Header -->
  <div class="border-b border-slate-100 px-4 py-3">
    <h2 class="sg-title-group">MIỆNG CẤP</h2>
  </div>

  <!-- Main: các field trải dọc trong 1 cột -->
  <div class="sg-scrollbar-thin flex flex-1 flex-col justify-between overflow-y-auto">
    <div class="flex flex-col gap-4 p-4">
      <sg_input_text
        v-model="fieldValues.inlet_code"
        label="Tên định danh"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input p-1 w-full"
        placeholder="VD: INL-001"
      />

      <sg_input_text
        v-model="fieldValues.inlet_name"
        label="Diễn giải"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input p-1 w-full"
        placeholder="VD: Miệng cấp 01"
      />

      <sg_input_number
        v-model="fieldValues.flow_rate"
        label="Lưu lượng gió (m³/h)"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input p-1 w-full"
        :decimal="2"
        :min="0"
      />

      <sg_input_number
        v-model="fieldValues.temperature"
        label="Nhiệt độ (oC)"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input p-1 w-full"
        :decimal="2"
      />

      <div>
        <span class="mb-1 block text-sm font-medium text-pmis-text">Tâm khối (m)</span>
        <div class="grid grid-cols-3 gap-2">
          <sg_input_number
            v-model="fieldValues.pos_x"
            label="X"
            label-c-s-s="sg-label-input"
            input-c-s-s="sg-input p-1 w-full"
            :decimal="2"
          />
          <sg_input_number
            v-model="fieldValues.pos_y"
            label="Y"
            label-c-s-s="sg-label-input"
            input-c-s-s="sg-input p-1 w-full"
            :decimal="2"
          />
          <sg_input_number
            v-model="fieldValues.pos_z"
            label="Z"
            label-c-s-s="sg-label-input"
            input-c-s-s="sg-input p-1 w-full"
            :decimal="2"
          />
        </div>
      </div>

      <div>
        <span class="mb-1 block text-sm font-medium text-pmis-text">Kích thước (m)</span>
        <div class="grid grid-cols-3 gap-2">
          <sg_input_number
            v-model="fieldValues.size_w"
            label="Rộng (Y)"
            label-c-s-s="sg-label-input"
            input-c-s-s="sg-input p-1 w-full"
            :decimal="2"
            :min="0"
          />
          <sg_input_number
            v-model="fieldValues.size_w"
            label="Cao (Z)"
            label-c-s-s="sg-label-input"
            input-c-s-s="sg-input p-1 w-full"
            :decimal="2"
            :min="0"
          />
        </div>
      </div>
    </div>

    <!-- Footer -->
    <div class="flex shrink-0 flex-col gap-2 border-t border-slate-100 p-4">
      <button type="button" class="sg-button-secondary" @click="emit('deselect')">
        <X class="h-5 w-5" stroke-width="1" />Bỏ chọn
      </button>
      <button type="button" class="sg-button-primary" @click="saveFields">
        <Save class="h-5 w-5" stroke-width="1" />Lưu
      </button>
      <button type="button" class="sg-button-danger" @click="deleteInlet">
        <Trash2 class="h-5 w-5" stroke-width="1" />Xóa
      </button>
    </div>
  </div>
</template>

<style scoped></style>
