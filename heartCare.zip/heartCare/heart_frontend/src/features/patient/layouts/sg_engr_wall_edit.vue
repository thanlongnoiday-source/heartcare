<script setup lang="ts">
import { reactive, watch } from 'vue'
import { Save, Trash2, X } from 'lucide-vue-next'
import sg_input_number from '@/components/base/sg_input_number.vue'
import sg_input_text from '@/components/base/sg_input_text.vue'
import sg_select from '@/components/base/sg_select.vue'
import type { SGWallRead, SGWallUpdate } from '@/types/sg_wall'
import {
  DEFAULT_WALL_AMBIENT_TEMP,
  DEFAULT_WALL_EMISSIVITY,
  DEFAULT_WALL_FIXED_POWER,
  DEFAULT_WALL_HEAT_TRANSFER_COEFFICIENT,
  DEFAULT_WALL_FIXED_TEMP,
  DEFAULT_WALL_THERMAL_CONDUCTIVITY,
  DEFAULT_WALL_THICKNESS,
  THERMAL_MODE,
  THERMAL_TYPE_OPTIONS
} from '@/constants/sg_engr_wall_const'
import { roundDecimal } from '@/utils/sg_formatters'

// Panel "Tường" — chỉnh sửa toàn bộ trường của một wall, ánh xạ 1-1 theo
// src/types/sg_wall.ts (SGWallBase). Khi component cha truyền vào một bản ghi
// đã lưu (SGWallRead), form được nạp sẵn theo bản ghi đó.
type WallFields = {
  wall_code: string
  wall_name: string
  thermal_type: number
  temperature: number
  heat_flux: number
  thickness: number
  thermal_conductivity: number
  heat_transfer_coefficient: number
  ambient_temp: number
  emissivity: number
  geometry_id: number
}

const props = defineProps<{
  // Bản ghi wall hiện có (đã lưu ở backend) dùng để nạp sẵn giá trị form.
  wall?: SGWallRead
}>()

const emit = defineEmits<{
  save: [value: SGWallUpdate]
  delete: [wallId: number]
  deselect: []
}>()

const defaults: WallFields = {
  wall_code: '',
  wall_name: '',
  thermal_type: THERMAL_MODE.ADIABATIC,
  temperature: DEFAULT_WALL_FIXED_TEMP,
  heat_flux: DEFAULT_WALL_FIXED_POWER,
  thickness: DEFAULT_WALL_THICKNESS,
  thermal_conductivity: DEFAULT_WALL_THERMAL_CONDUCTIVITY,
  heat_transfer_coefficient: DEFAULT_WALL_HEAT_TRANSFER_COEFFICIENT,
  ambient_temp: DEFAULT_WALL_AMBIENT_TEMP,
  emissivity: DEFAULT_WALL_EMISSIVITY,
  geometry_id: 0
}

const fieldValues = reactive<WallFields>({ ...defaults })

// Đồng bộ form theo prop `wall` mỗi khi component cha truyền bản ghi mới.
watch(
  () => props.wall,
  (wall) => {
    if (!wall) {
      Object.assign(fieldValues, defaults)
      return
    }
    fieldValues.wall_code = wall.wall_code ?? ''
    fieldValues.wall_name = wall.wall_name ?? ''
    fieldValues.thermal_type = wall.thermal_type ?? 0
    fieldValues.temperature = wall.temperature ?? 0
    fieldValues.heat_flux = wall.heat_flux ?? 0
    fieldValues.thickness = wall.thickness ?? 0
    fieldValues.thermal_conductivity = wall.thermal_conductivity ?? 0
    fieldValues.heat_transfer_coefficient = wall.heat_transfer_coefficient ?? 0
    fieldValues.ambient_temp = wall.ambient_temp ?? 0
    fieldValues.emissivity = wall.emissivity ?? 0
    fieldValues.geometry_id = wall.geometry_id ?? 0
  },
  { immediate: true }
)

// Nhấn "Lưu" -> phát sự kiện save mang payload SGWallUpdate. Tên tường để
// trống được gửi thành null (đúng quy ước `X | None` của backend).
function saveFields(): void {
  // Mọi field số thực (Decimal ở backend) phải qua roundDecimal() trước khi gửi API
  // để tránh lỗi "decimal_max_digits" (xem sg_formatters.ts).
  const value: SGWallUpdate = {
    wall_code: fieldValues.wall_code,
    wall_name: fieldValues.wall_name || null,
    thermal_type: fieldValues.thermal_type,
    temperature: roundDecimal(fieldValues.temperature),
    heat_flux: roundDecimal(fieldValues.heat_flux),
    thickness: roundDecimal(fieldValues.thickness),
    thermal_conductivity: roundDecimal(fieldValues.thermal_conductivity),
    heat_transfer_coefficient: roundDecimal(fieldValues.heat_transfer_coefficient),
    ambient_temp: roundDecimal(fieldValues.ambient_temp),
    emissivity: roundDecimal(fieldValues.emissivity),
    geometry_id: fieldValues.geometry_id
  }
  emit('save', value)
}

// Nhấn "Xóa" -> phát sự kiện delete kèm wall_id. Component cha đảm nhận gọi API
// + xác nhận.
function deleteWall(): void {
  if (!props.wall) return
  emit('delete', props.wall.wall_id)
}
</script>

<template>
  <!-- Header -->
  <div class="border-b border-slate-100 px-4 py-3">
    <h2 class="sg-title-group">TƯỜNG</h2>
  </div>

  <!-- Main: các field trải dọc trong 1 cột -->
  <div class="sg-scrollbar-thin flex flex-1 flex-col justify-between overflow-y-auto">
    <div class="flex flex-col gap-4 p-4">
      <sg_input_text
        v-model="fieldValues.wall_code"
        label="Tên định danh"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input p-1 w-full"
        placeholder="VD: WALL-001"
      />

      <sg_input_text
        v-model="fieldValues.wall_name"
        label="Diễn giải"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input p-1 w-full"
        placeholder="VD: Tường 01"
      />

      <sg_select
        v-model="fieldValues.thermal_type"
        label="Loại điều kiện nhiệt"
        selectcss="sg-select py-1"
        :show-add="false"
        :show-edit="false"
        :show-delete="false"
        :items="THERMAL_TYPE_OPTIONS"
      />

      <sg_input_number
        v-model="fieldValues.temperature"
        label="Nhiệt độ (°C)"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input p-1 w-full"
        :decimal="2"
      />

      <sg_input_number
        v-model="fieldValues.heat_flux"
        label="Dòng nhiệt (W/m²)"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input p-1 w-full"
        :decimal="2"
      />

      <sg_input_number
        v-model="fieldValues.thickness"
        label="Độ dày (m)"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input p-1 w-full"
        :decimal="2"
        :min="0"
      />

      <sg_input_number
        v-model="fieldValues.thermal_conductivity"
        label="Hệ số dẫn nhiệt (W/m.K)"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input p-1 w-full"
        :decimal="2"
        :min="0"
      />

      <sg_input_number
        v-model="fieldValues.heat_transfer_coefficient"
        label="Hệ số truyền nhiệt (W/m².K)"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input p-1 w-full"
        :decimal="2"
        :min="0"
      />

      <sg_input_number
        v-model="fieldValues.ambient_temp"
        label="Nhiệt độ môi trường (°C)"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input p-1 w-full"
        :decimal="2"
      />

      <sg_input_number
        v-model="fieldValues.emissivity"
        label="Độ phát xạ (0 - 1)"
        label-c-s-s="sg-label-input"
        input-c-s-s="sg-input p-1 w-full"
        :decimal="2"
        :min="0"
      />
    </div>

    <!-- Footer -->
    <div class="flex shrink-0 flex-col gap-2 border-t border-slate-100 p-4">
      <button type="button" class="sg-button-secondary" @click="emit('deselect')">
        <X class="h-5 w-5" stroke-width="1" />Hủy
      </button>
      <button type="button" class="sg-button-primary" @click="saveFields">
        <Save class="h-5 w-5" stroke-width="1" />Lưu
      </button>
      <button type="button" class="sg-button-danger" @click="deleteWall">
        <Trash2 class="h-5 w-5" stroke-width="1" />Xóa
      </button>
    </div>
  </div>
</template>

<style scoped></style>
