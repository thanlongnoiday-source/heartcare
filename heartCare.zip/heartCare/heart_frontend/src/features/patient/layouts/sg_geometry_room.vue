<script setup lang="ts">
import { reactive, watch } from 'vue'
import sg_input_number from '@/components/base/sg_input_number.vue'
import sg_input_text from '@/components/base/sg_input_text.vue'
import type { SGGeometryRead } from '@/types/sg_geometry'

// Thuộc tính: Geometry / Phòng — panel này quản lý mã phòng, tên phòng và
// 3 trường kích thước khối hộp (L/W/H). Khi component cha truyền vào một bản
// ghi geometry đã tồn tại (SGGeometryRead), form sẽ được nạp sẵn theo bản ghi đó.
type RoomBaseFields = {
  geometry_code: string
  geometry_name: string
  length: number
  width: number
  height: number
}

const props = defineProps<{
  // Bản ghi geometry hiện có (đã lưu ở backend) dùng để nạp sẵn giá trị form.
  geometry?: SGGeometryRead
}>()

const defaults: RoomBaseFields = {
  geometry_code: '',
  geometry_name: '',
  length: 6,
  width: 4,
  height: 3
}

const fieldValues = reactive<RoomBaseFields>({ ...defaults })

// Đồng bộ form theo prop `geometry` mỗi khi component cha truyền bản ghi mới.
watch(
  () => props.geometry,
  (geometry) => {
    if (!geometry) return
    fieldValues.geometry_code = geometry.geometry_code ?? ''
    fieldValues.geometry_name = geometry.geometry_name
    fieldValues.length = geometry.leng
    fieldValues.width = geometry.width
    fieldValues.height = geometry.height
  },
  { immediate: true }
)

const emit = defineEmits<{
  apply: [value: SGGeometryRead]
}>()

function resetFields(): void {
  Object.assign(fieldValues, defaults)
}

// Nhấn "Áp dụng" -> phát sự kiện apply mang một bản ghi SGGeometryRead:
// giữ nguyên các trường không nằm trên form (geometry_id, project_id,
// geometry_type, cad_file_path, notes) lấy từ prop `geometry`, và ghi đè
// mã/tên/kích thước bằng giá trị người dùng vừa nhập (length -> leng).
// Component cha (sg_engr_main.vue) lắng nghe để đồng bộ về state geometry.
function applyFields(): void {
  const value: SGGeometryRead = {
    ...props.geometry,
    geometry_id: props.geometry?.geometry_id ?? 0,
    project_id: props.geometry?.project_id ?? 0,
    geometry_type: props.geometry?.geometry_type ?? 0,
    geometry_code: fieldValues.geometry_code,
    geometry_name: fieldValues.geometry_name,
    leng: fieldValues.length,
    width: fieldValues.width,
    height: fieldValues.height
  }
  emit('apply', value)
}
</script>

<template>
  <div class="border-b border-slate-100 px-4 py-3">
    <h2 class="sg-title-group">Thuộc tính</h2>
    <p class="mt-0.5 truncate text-xs text-pmis-placeholder">Geometry / Phòng (kích thước L/W/H)</p>
  </div>

  <div class="flex flex-1 flex-col justify-between overflow-y-auto">
    <div class="space-y-4 p-4">
      <sg_input_text v-model="fieldValues.geometry_code" label="Mã phòng" placeholder="VD: P-101" />

      <sg_input_text
        v-model="fieldValues.geometry_name"
        label="Tên phòng"
        placeholder="VD: Phòng họp tầng 1"
      />

      <sg_input_number
        v-model="fieldValues.length"
        label="Chiều dài phòng (m)"
        :decimal="2"
        :min="0"
      />

      <sg_input_number
        v-model="fieldValues.width"
        label="Chiều rộng phòng (m)"
        :decimal="2"
        :min="0"
      />
      <sg_input_number
        v-model="fieldValues.height"
        label="Chiều cao phòng (m)"
        :decimal="2"
        :min="0"
      />
    </div>

    <div class="flex shrink-0 gap-2 border-t border-slate-100 p-4">
      <button type="button" class="flex-1 sg-button-secondary" @click="resetFields">Đặt lại</button>
      <button type="button" class="flex-1 sg-button-primary" @click="applyFields">Áp dụng</button>
    </div>
  </div>
</template>

<style scoped></style>
