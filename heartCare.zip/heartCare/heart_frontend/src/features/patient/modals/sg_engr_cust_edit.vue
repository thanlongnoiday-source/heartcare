<script setup lang="ts">
import { reactive, ref, watch } from 'vue'
import { X, Save, Ban } from 'lucide-vue-next'
import sg_input_text from '@/components/base/sg_input_text.vue'
import sg_message_box from '@/components/base/sg_message_box.vue'
import { useToast } from '@/utils/sg_use_toast'
import { updateCustomer } from '@/services/sg_customer_srv'
import type { SGCustomerRead, SGCustomerUpdate } from '@/types/sg_customer'
import type { MsgBoxOptions } from '@/types/sg_msg_box.types'

// ======================================================================
// Modal "Sửa khách hàng" — form chỉnh sửa thông tin khách hàng.
//   Header : tiêu đề "Sửa khách hàng" bên trái, nút icon "Đóng" bên phải
//   Body   : các trường lấy từ SGCustomerRead (@/types/sg_customer.ts)
//   Footer : nút "Close" và "Lưu" căn phải
// Nút "Lưu": validate -> gọi API updateCustomer -> Toast + emit bản ghi
// SGCustomerRead + đóng modal khi thành công, hiển thị MessageBox khi lỗi.
// ======================================================================

interface Props {
  /** Điều khiển đóng mở modal */
  open?: boolean
  /** Dữ liệu khách hàng cần sửa (SGCustomerRead) */
  customer?: SGCustomerRead | null
}

const props = withDefaults(defineProps<Props>(), {
  open: false,
  customer: null
})

const emit = defineEmits<{
  (event: 'close'): void
  // Phát ra sau khi cập nhật thành công — trang cha dùng để refresh danh sách.
  (event: 'saved', customer: SGCustomerRead): void
}>()

const toast = useToast()

// Trạng thái gọi API + hộp thoại báo lỗi.
const saving = ref(false)

const msgBox = reactive<MsgBoxOptions>({
  show: false,
  type: 'error',
  title: 'Lỗi',
  message: '',
  show_ok: true,
  show_cancel: false
})

function showError(message: string): void {
  msgBox.message = message
  msgBox.show = true
}

// --- Trạng thái form (SGCustomerRead) ---
function emptyForm(): SGCustomerRead {
  return {
    customer_id: 0,
    customer_name: '',
    addr: '',
    phone: '',
    email: ''
  }
}

const form = reactive<SGCustomerRead>(emptyForm())

const errors = reactive<Record<'customer_name' | 'addr' | 'phone' | 'email', string>>({
  customer_name: '',
  addr: '',
  phone: '',
  email: ''
})

function clearErrors(): void {
  errors.customer_name = ''
  errors.addr = ''
  errors.phone = ''
  errors.email = ''
}

// Nạp lại dữ liệu khách hàng mỗi khi modal được mở lại.
watch(
  () => props.open,
  (isOpen) => {
    if (!isOpen) return
    Object.assign(form, emptyForm(), props.customer ?? {})
    clearErrors()
  },
  { immediate: true }
)

// Người dùng vừa gõ vào ô nào thì xóa ngay báo lỗi của ô đó.
;(['customer_name', 'addr', 'phone', 'email'] as const).forEach((field) => {
  watch(
    () => form[field],
    () => {
      if (errors[field]) errors[field] = ''
    }
  )
})

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

function validate(): boolean {
  clearErrors()

  const name = (form.customer_name ?? '').trim()
  const addr = (form.addr ?? '').trim()
  const phone = (form.phone ?? '').trim()
  const email = (form.email ?? '').trim()

  if (!name) errors.customer_name = 'Vui lòng nhập tên khách hàng.'
  else if (name.length > 100) errors.customer_name = 'Tên khách hàng tối đa 100 ký tự.'

  if (!addr) errors.addr = 'Vui lòng nhập địa chỉ.'
  else if (addr.length > 200) errors.addr = 'Địa chỉ tối đa 200 ký tự.'

  if (phone.length > 50) errors.phone = 'Số điện thoại tối đa 50 ký tự.'

  if (email && !emailPattern.test(email)) errors.email = 'Email không hợp lệ.'
  else if (email.length > 50) errors.email = 'Email tối đa 50 ký tự.'

  return !errors.customer_name && !errors.addr && !errors.phone && !errors.email
}

function onClose(): void {
  if (saving.value) return
  emit('close')
}

async function onSave(): Promise<void> {
  // 1. Kiểm tra dữ liệu hợp lệ
  if (!validate()) return
  if (saving.value) return

  const payload: SGCustomerUpdate = {
    customer_name: (form.customer_name ?? '').trim(),
    addr: (form.addr ?? '').trim(),
    phone: (form.phone ?? '').trim() || null,
    email: (form.email ?? '').trim() || null
  }

  saving.value = true
  try {
    // 2. Gọi API sửa thông tin khách hàng
    const updated = await updateCustomer(form.customer_id, payload)

    // 3. Thành công: Toast + emit bản ghi SGCustomerRead + quay về "Danh sách khách hàng"
    toast.success('Cập nhật khách hàng thành công.')
    emit('saved', updated)
    emit('close')
  } catch (error) {
    // 4. Có lỗi: hiển thị MessageBox
    const message =
      error instanceof Error ? error.message : 'Không thể cập nhật khách hàng. Vui lòng thử lại.'
    showError(message)
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <div
    v-if="open"
    class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
  >
    <div class="flex max-h-full w-full max-w-lg flex-col rounded-xl bg-white shadow-xl">
      <!-- ============================================================ -->
      <!-- Header -->
      <!-- ============================================================ -->
      <header
        class="flex shrink-0 items-center justify-between gap-4 border-b border-gray-200 px-5 py-4"
      >
        <h1 class="sg-title-page">Sửa khách hàng</h1>

        <button type="button" class="sg-button-only-icon" title="Đóng" @click="onClose">
          <X class="h-5 w-5" />
        </button>
      </header>

      <!-- ============================================================ -->
      <!-- Nội dung -->
      <!-- ============================================================ -->
      <section class="min-h-0 flex-1 overflow-auto px-5 py-4">
        <div class="flex flex-col gap-4">
          <sg_input_text
            v-model="form.customer_name"
            label="Tên khách hàng"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-1 sg-input w-full"
            :required-input="true"
            placeholder="Nhập tên khách hàng"
            :error="errors.customer_name"
          />

          <sg_input_text
            v-model="form.addr"
            label="Địa chỉ"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-1 sg-input w-full"
            :required-input="true"
            placeholder="Nhập địa chỉ"
            :error="errors.addr"
          />

          <sg_input_text
            v-model="form.phone"
            label="Số điện thoại"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-1 sg-input w-full"
            placeholder="Nhập số điện thoại"
            :error="errors.phone"
          />

          <sg_input_text
            v-model="form.email"
            label="Email"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-1 sg-input w-full"
            placeholder="Nhập email"
            :error="errors.email"
          />
        </div>
      </section>

      <!-- ============================================================ -->
      <!-- Footer -->
      <!-- ============================================================ -->
      <footer
        class="flex shrink-0 items-center justify-end gap-3 border-t border-gray-200 px-5 py-4"
      >
        <button type="button" class="sg-button-secondary" :disabled="saving" @click="onClose">
          <Ban class="w-5 h-5" stroke-width="1" />Close
        </button>
        <button type="button" class="sg-button-primary" :disabled="saving" @click="onSave">
          <Save class="w-5 h-5" stroke-width="1" />{{ saving ? 'Đang lưu...' : 'Lưu' }}
        </button>
      </footer>
    </div>
  </div>

  <!-- Hộp thoại báo lỗi khi gọi API thất bại -->
  <sg_message_box
    :show="msgBox.show"
    :type="msgBox.type"
    :title="msgBox.title"
    :message="msgBox.message"
    :show_ok="msgBox.show_ok"
    :show_cancel="msgBox.show_cancel"
    @ok="msgBox.show = false"
    @cancel="msgBox.show = false"
  />
</template>

<style scoped></style>
