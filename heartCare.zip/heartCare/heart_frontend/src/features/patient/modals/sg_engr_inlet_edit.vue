<script setup lang="ts">
import { computed, reactive, ref, watch } from 'vue'
import { X, Save, Ban } from 'lucide-vue-next'
import sg_input_text from '@/components/base/sg_input_text.vue'
import sg_input_number from '@/components/base/sg_input_number.vue'
import sg_radio from '@/components/base/sg_radio.vue'
import type { SGInletBoundary } from '@/types/sg_inlet'
import {
  INLET_DIRECTION_MODE,
  INLET_FLOW_MODE,
  INLET_FLOW_RATE_UNIT
} from '@/constants/sg_engr_inlet_const'
// import { INLET_DIRECTION_MODE, INLET_FLOW_MODE, INLET_FLOW_RATE_UNIT } from '@/types/sg_inlet_bc'
// import type { SGInletBoundary } from '@/types/sg_inlet_bc'

// ======================================================================
// Modal "Miệng cấp" (INLET).
//   Header : tiêu đề bên trái, nút icon "Đóng" bên phải
//   Body   : 3 tab
//            - Điều kiện Động lực học
//            - Điều kiện Nhiệt độ
//            - Đặc tính Xáo động Dòng chảy
//   Footer : nút "Đóng" và "Lưu" căn phải
// Nút "Lưu": validate -> emit bản ghi SGInletBoundary + đóng modal.
// (Chưa có API — trang cha tự lưu cấu hình.)
// ======================================================================

interface Props {
  /** Điều khiển đóng mở modal */
  open?: boolean
  /** Cấu hình điều kiện biên hiện tại của miệng cấp (null = dùng giá trị mặc định) */
  inlet?: SGInletBoundary | null
}

const props = withDefaults(defineProps<Props>(), {
  open: false,
  inlet: null
})

const emit = defineEmits<{
  (event: 'close'): void
  (event: 'saved', inlet: SGInletBoundary): void
}>()

// Hiển thị số theo định dạng '0.90' như bản thiết kế.
const NUMBER_LOCALE = 'en-US'

const ROW_CSS = 'grid grid-cols-1 items-start gap-1 sm:grid-cols-[minmax(0,200px)_1fr] sm:gap-4'
const ROW_LABEL_CSS = 'text-[15px] text-slate-700 sm:pt-1.5'
const NUMBER_INPUT_CSS = 'py-1 sg-input w-32 text-right'
const UNIT_CSS = 'pt-1.5 text-sm text-slate-600'
// Khối field con thụt vào dưới mỗi radio.
const SUB_FIELDS_CSS = 'ml-7 flex flex-col gap-3'

const TAB = {
  DYNAMICS: 'dynamics',
  THERMAL: 'thermal',
  TURBULENCE: 'turbulence'
} as const

type TabKey = (typeof TAB)[keyof typeof TAB]

const TABS: { key: TabKey; label: string }[] = [
  { key: TAB.DYNAMICS, label: 'Phương thức điều khiển' },
  { key: TAB.THERMAL, label: 'Thông số vật lý' },
  { key: TAB.TURBULENCE, label: 'Đặc tính xáo động' }
]

const activeTab = ref<TabKey>(TAB.DYNAMICS)

// --- Trạng thái form ---
function defaultForm(): SGInletBoundary {
  return {
    inlet_name: '',
    flow_mode: INLET_FLOW_MODE.FLOW_RATE,
    flow_rate: 0,
    flow_rate_unit: INLET_FLOW_RATE_UNIT.M3_H,
    velocity_magnitude: 0,
    direction_mode: INLET_DIRECTION_MODE.NORMAL,
    direction_x: 0,
    direction_y: 0,
    direction_z: -1,
    total_pressure: 0,
    supply_temperature: 18,
    turbulence_intensity: 5,
    hydraulic_diameter: 0.2,
    hydraulic_diameter_auto: true
  }
}

const form = reactive<SGInletBoundary>(defaultForm())

type FieldKey = 'inlet_name' | 'flow_rate' | 'velocity_magnitude' | 'direction'

const errors = reactive<Record<FieldKey, string>>({
  inlet_name: '',
  flow_rate: '',
  velocity_magnitude: '',
  direction: ''
})

function clearErrors(): void {
  errors.inlet_name = ''
  errors.flow_rate = ''
  errors.velocity_magnitude = ''
  errors.direction = ''
}

// Mỗi lần mở lại modal: nạp lại dữ liệu và quay về tab đầu tiên.
watch(
  () => props.open,
  (isOpen) => {
    if (!isOpen) return
    Object.assign(form, props.inlet ? { ...props.inlet } : defaultForm())
    clearErrors()
    activeTab.value = TAB.DYNAMICS
  },
  { immediate: true }
)

// Người dùng vừa sửa ô nào thì xóa ngay báo lỗi của ô đó.
;(['inlet_name', 'flow_rate', 'velocity_magnitude'] as const).forEach((field) => {
  watch(
    () => form[field],
    () => {
      if (errors[field]) errors[field] = ''
    }
  )
})
watch(
  () => [form.direction_x, form.direction_y, form.direction_z, form.direction_mode],
  () => {
    if (errors.direction) errors.direction = ''
  }
)

const isFlowRate = computed(() => form.flow_mode === INLET_FLOW_MODE.FLOW_RATE)
const isVelocity = computed(() => form.flow_mode === INLET_FLOW_MODE.VELOCITY)
const isTotalPressure = computed(() => form.flow_mode === INLET_FLOW_MODE.TOTAL_PRESSURE)
const isDirectionVector = computed(() => form.direction_mode === INLET_DIRECTION_MODE.VECTOR)

function validate(): boolean {
  clearErrors()

  if (!form.inlet_name.trim()) errors.inlet_name = 'Vui lòng nhập tên miệng cấp.'

  if (isFlowRate.value && !(form.flow_rate > 0))
    errors.flow_rate = 'Lưu lượng thể tích phải lớn hơn 0.'

  if (isVelocity.value) {
    if (!(form.velocity_magnitude > 0)) errors.velocity_magnitude = 'Độ lớn vận tốc phải lớn hơn 0.'

    if (
      isDirectionVector.value &&
      form.direction_x === 0 &&
      form.direction_y === 0 &&
      form.direction_z === 0
    )
      errors.direction = 'Vector hướng không được bằng (0, 0, 0).'
  }

  const hasError = Object.values(errors).some(Boolean)
  // Lỗi đều nằm ở tab Động lực học -> chuyển về tab đó để người dùng thấy.
  if (hasError) activeTab.value = TAB.DYNAMICS
  return !hasError
}

function onClose(): void {
  emit('close')
}

function onSave(): void {
  if (!validate()) return
  emit('saved', { ...form, inlet_name: form.inlet_name.trim() })
  emit('close')
}
</script>

<template>
  <div v-if="open" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
    <div class="flex max-h-full w-full max-w-2xl flex-col rounded-xl bg-white shadow-xl">
      <!-- ============================================================ -->
      <!-- Header -->
      <!-- ============================================================ -->
      <header
        class="flex shrink-0 items-center justify-between gap-4 border-b border-gray-200 px-5 py-4"
      >
        <h1 class="sg-title-page">Miệng cấp</h1>

        <button type="button" class="sg-button-only-icon" title="Đóng" @click="onClose">
          <X class="h-5 w-5" />
        </button>
      </header>

      <!-- ============================================================ -->
      <!-- Tabs -->
      <!-- ============================================================ -->
      <nav class="flex shrink-0 gap-1 border-b border-gray-200 px-5" role="tablist">
        <button
          v-for="tab in TABS"
          :key="tab.key"
          type="button"
          role="tab"
          :aria-selected="activeTab === tab.key"
          class="-mb-px whitespace-nowrap border-b-2 px-3 py-2.5 text-sm font-medium transition-colors"
          :class="
            activeTab === tab.key
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          "
          @click="activeTab = tab.key"
        >
          {{ tab.label }}
        </button>
      </nav>

      <!-- ============================================================ -->
      <!-- Nội dung -->
      <!-- ============================================================ -->
      <section class="min-h-[320px] flex-1 overflow-auto px-5 py-4" role="tabpanel">
        <!-- Tab: Điều kiện Động lực học -->
        <div v-if="activeTab === TAB.DYNAMICS" class="flex flex-col gap-5">
          <div :class="ROW_CSS">
            <span :class="ROW_LABEL_CSS">Tên miệng cấp</span>
            <sg_input_text
              v-model="form.inlet_name"
              input-c-s-s="py-1 sg-input w-full"
              placeholder="Nhập tên miệng cấp gió"
              :error="errors.inlet_name"
            />
          </div>

          <div>
            <div
              class="grid grid-cols-1 items-start gap-1 sm:grid-cols-[minmax(0,200px)_1fr] sm:gap-4"
            >
              <span>Chế độ cấp gió</span>
              <sg_radio
                v-model="form.flow_mode"
                :value="INLET_FLOW_MODE.FLOW_RATE"
                label="Theo lưu lượng"
                name="inlet_flow_mode"
              />

              <sg_radio
                v-model="form.flow_mode"
                :value="INLET_FLOW_MODE.VELOCITY"
                label="Theo vận tốc"
                name="inlet_flow_mode"
              />

              <sg_radio
                v-model="form.flow_mode"
                :value="INLET_FLOW_MODE.TOTAL_PRESSURE"
                label="Áp suất tổng"
                name="inlet_flow_mode"
              />
            </div>
          </div>

          <!-- Theo lưu lượng -->
          <div class="flex flex-col gap-3">
            <div class="flex items-center gap-3">
              <sg_radio
                v-model="form.flow_mode"
                :value="INLET_FLOW_MODE.FLOW_RATE"
                label="Theo lưu lượng"
                name="inlet_flow_mode"
              />
              <!-- Đường kẻ ngang canh giữa theo chiều dọc với radio -->
              <div class="h-px flex-1 bg-pmis-borderinput" />
            </div>
            <div :class="SUB_FIELDS_CSS">
              <div :class="ROW_CSS">
                <span :class="ROW_LABEL_CSS">Lưu lượng thể tích</span>
                <div class="flex items-start gap-2">
                  <sg_input_number
                    v-model="form.flow_rate"
                    :input-c-s-s="NUMBER_INPUT_CSS"
                    :decimal="1"
                    :min="0"
                    :locale="NUMBER_LOCALE"
                    :disabled="!isFlowRate"
                    :error="errors.flow_rate"
                  />
                  <span :class="UNIT_CSS">m³/h</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Theo vận tốc -->
          <div class="flex flex-col gap-3">
            <div class="flex items-center gap-3">
              <sg_radio
                v-model="form.flow_mode"
                :value="INLET_FLOW_MODE.VELOCITY"
                label="Theo vận tốc"
                name="inlet_flow_mode"
              />
              <!-- Đường kẻ ngang canh giữa theo chiều dọc với radio -->
              <div class="h-px flex-1 bg-pmis-borderinput" />
            </div>
            <div :class="SUB_FIELDS_CSS">
              <div :class="ROW_CSS">
                <span :class="ROW_LABEL_CSS">Độ lớn vận tốc</span>
                <div class="flex items-start gap-2">
                  <sg_input_number
                    v-model="form.velocity_magnitude"
                    :input-c-s-s="NUMBER_INPUT_CSS"
                    :decimal="2"
                    :min="0"
                    :locale="NUMBER_LOCALE"
                    :disabled="!isVelocity"
                    :error="errors.velocity_magnitude"
                  />
                  <span :class="UNIT_CSS">m/s</span>
                </div>
              </div>

              <div :class="ROW_CSS">
                <span :class="ROW_LABEL_CSS">Chọn hướng thổi</span>
                <div class="flex flex-col gap-2 sm:pt-1.5">
                  <sg_radio
                    v-model="form.direction_mode"
                    :value="INLET_DIRECTION_MODE.NORMAL"
                    label="Vuông góc miệng gió"
                    name="inlet_direction_mode"
                    :disabled="!isVelocity"
                  />
                  <sg_radio
                    v-model="form.direction_mode"
                    :value="INLET_DIRECTION_MODE.VECTOR"
                    label="Vector hướng"
                    name="inlet_direction_mode"
                    :disabled="!isVelocity"
                  />

                  <!-- Thành phần vector hướng thổi -->
                  <div v-if="isDirectionVector" class="ml-7 flex flex-col gap-1">
                    <div class="flex flex-wrap items-start gap-3">
                      <div
                        v-for="axis in ['x', 'y', 'z'] as const"
                        :key="axis"
                        class="flex items-start gap-1.5"
                      >
                        <span :class="UNIT_CSS">{{ axis.toUpperCase() }}</span>
                        <sg_input_number
                          v-model="form[`direction_${axis}`]"
                          input-c-s-s="py-1 sg-input w-20 text-right"
                          :decimal="2"
                          :locale="NUMBER_LOCALE"
                          :disabled="!isVelocity"
                        />
                      </div>
                    </div>
                    <span v-if="errors.direction" class="text-sm text-red-500">
                      {{ errors.direction }}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Áp suất tổng -->
          <div class="flex flex-col gap-3">
            <div class="flex items-center gap-3">
              <sg_radio
                v-model="form.flow_mode"
                :value="INLET_FLOW_MODE.TOTAL_PRESSURE"
                label="Áp suất tổng"
                name="inlet_flow_mode"
              />
              <!-- Đường kẻ ngang canh giữa theo chiều dọc với radio -->
              <div class="h-px flex-1 bg-pmis-borderinput" />
            </div>
            <div :class="SUB_FIELDS_CSS">
              <div :class="ROW_CSS">
                <span :class="ROW_LABEL_CSS">Áp suất tổng</span>
                <div class="flex items-start gap-2">
                  <sg_input_number
                    v-model="form.total_pressure"
                    :input-c-s-s="NUMBER_INPUT_CSS"
                    :decimal="1"
                    :locale="NUMBER_LOCALE"
                    :disabled="!isTotalPressure"
                  />
                  <span :class="UNIT_CSS">Pa</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Tab: Điều kiện Nhiệt độ -->
        <div v-else-if="activeTab === TAB.THERMAL" class="flex flex-col gap-3">
          <!-- TODO: nội dung tab Điều kiện Nhiệt độ -->
        </div>

        <!-- Tab: Đặc tính Xáo động Dòng chảy -->
        <div v-else-if="activeTab === TAB.TURBULENCE" class="flex flex-col gap-3">
          <!-- TODO: nội dung tab Đặc tính Xáo động Dòng chảy -->
        </div>
      </section>

      <!-- ============================================================ -->
      <!-- Footer -->
      <!-- ============================================================ -->
      <footer
        class="flex shrink-0 items-center justify-end gap-3 border-t border-gray-200 px-5 py-4"
      >
        <button type="button" class="sg-button-secondary" @click="onClose">
          <Ban class="w-5 h-5" stroke-width="1" />Đóng
        </button>
        <button type="button" class="sg-button-primary" @click="onSave">
          <Save class="w-5 h-5" stroke-width="1" />Lưu
        </button>
      </footer>
    </div>
  </div>
</template>

<style scoped></style>
