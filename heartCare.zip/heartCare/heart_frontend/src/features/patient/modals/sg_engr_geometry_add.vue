<script setup lang="ts">
import { reactive, ref, watch } from 'vue'
import { X, Save, Ban } from 'lucide-vue-next'
import sg_input_text from '@/components/base/sg_input_text.vue'
import sg_input_number from '@/components/base/sg_input_number.vue'
import sg_radio from '@/components/base/sg_radio.vue'
import sg_select from '@/components/base/sg_select.vue'
import sg_message_box from '@/components/base/sg_message_box.vue'
import { useToast } from '@/utils/sg_use_toast'
import { createGeometry, newSGGeometryRead } from '@/services/sg_geometry_srv'
import type { SGGeometryCreate, SGGeometryRead } from '@/types/sg_geometry'
import type { MsgBoxOptions } from '@/types/sg_msg_box.types'
import { GEOMETRY_STATUS } from '@/constants/sg_engr_geometry_const'
import { roundDecimal } from '@/utils/sg_formatters'
import { SCALE_OPTIONS } from '@/options/sg_site_option'

// ======================================================================
// Modal "Thêm khối hình học" — form nhập liệu thông tin geometry.
//   Header : tiêu đề bên trái, nút icon "Đóng" bên phải
//   Body   : các trường lấy từ SGGeometryBase (@/types/sg_geometry.ts)
//   Footer : nút "Hủy" và "Lưu" căn phải
// Nút "Lưu": validate -> gọi API createGeometry -> Toast + đóng modal khi
// thành công, hiển thị MessageBox khi có lỗi.
// ======================================================================

interface Props {
  /** Điều khiển hiển thị modal */
  open?: boolean
  /** Dự án đang mô phỏng — geometry mới sẽ gắn vào project_id này */
  projectId: number
}

const props = withDefaults(defineProps<Props>(), {
  open: false
})

const emit = defineEmits<{
  (event: 'close'): void
  // Phát ra sau khi tạo geometry thành công — trang cha dùng để refresh danh sách.
  (event: 'saved', geometry: SGGeometryRead): void
}>()

const toast = useToast()

// Trạng thái gọi API + hộp thoại báo lỗi.
const saving = ref(false)

const msgBox = reactive<MsgBoxOptions>({
  show: false,
  type: 'error',
  title: 'Lỗi',
  message: '',
  show_ok: true,
  show_cancel: false
})

function showError(message: string): void {
  msgBox.message = message
  msgBox.show = true
}

const DEFAULT_SCALE = 1

const form = reactive<SGGeometryRead>({ ...newSGGeometryRead(), scales: DEFAULT_SCALE })

function onScaleChange(value: string | number | null): void {
  form.scales = Number(value) || DEFAULT_SCALE
}

type FieldKey = 'geometry_code' | 'geometry_name'

const errors = reactive<Record<FieldKey, string>>({
  geometry_code: '',
  geometry_name: ''
})

function clearErrors(): void {
  errors.geometry_code = ''
  errors.geometry_name = ''
}

// Reset form + lỗi mỗi khi modal được mở lại.
watch(
  () => props.open,
  (isOpen) => {
    if (isOpen) {
      Object.assign(form, newSGGeometryRead(), { scales: DEFAULT_SCALE })
      clearErrors()
    }
  }
)

// Người dùng vừa sửa ô nào thì xóa ngay báo lỗi của ô đó.
;(['geometry_code', 'geometry_name'] as const).forEach((field) => {
  watch(
    () => form[field],
    () => {
      if (errors[field]) errors[field] = ''
    }
  )
})

function validate(): boolean {
  clearErrors()

  const code = form.geometry_code.trim()
  const name = form.geometry_name.trim()

  if (code.length > 50) errors.geometry_code = 'Mã khối hình học tối đa 50 ký tự.'

  if (!name) errors.geometry_name = 'Vui lòng nhập tên khối hình học.'
  else if (name.length > 100) errors.geometry_name = 'Tên khối hình học tối đa 100 ký tự.'

  return !errors.geometry_code && !errors.geometry_name
}

function onClose(): void {
  if (saving.value) return
  emit('close')
}

async function onSave(): Promise<void> {
  // 1. Kiểm tra dữ liệu hợp lệ
  if (!validate()) return
  if (saving.value) return

  const payload: SGGeometryCreate = {
    geometry_code: form.geometry_code.trim(),
    geometry_name: form.geometry_name.trim(),
    project_id: props.projectId,
    leng: roundDecimal(form.leng),
    width: roundDecimal(form.width),
    height: roundDecimal(form.height),
    // cad_file_path: form.cad_file_path.trim() || null,
    // obj_file_path: form.obj_file_path.trim() || null,
    geometry_type: form.geometry_type,
    geometry_status: form.geometry_status,
    delta_x: form.delta_x,
    delta_y: form.delta_y,
    delta_z: form.delta_z,
    grading_x: 1,
    grading_y: 1,
    grading_z: 1,
    scales: form.scales
  }

  saving.value = true
  try {
    // 2. Gọi API lưu vào DB
    const created = await createGeometry(payload)

    // 3. Thành công: Toast + đóng modal
    toast.success('Thêm mới khối hình học thành công.')
    emit('saved', created)
    emit('close')
  } catch (error) {
    // 4. Có lỗi: hiển thị MessageBox
    const message =
      error instanceof Error ? error.message : 'Không thể lưu khối hình học. Vui lòng thử lại.'
    showError(message)
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <div v-if="open" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
    <div class="flex max-h-full w-full max-w-lg flex-col rounded-xl bg-white shadow-xl">
      <!-- ============================================================ -->
      <!-- Header -->
      <!-- ============================================================ -->
      <header
        class="flex shrink-0 items-center justify-between gap-4 border-b border-gray-200 px-5 py-4"
      >
        <h1 class="sg-title-page">Thêm khối hình học</h1>

        <button type="button" class="sg-button-only-icon" title="Đóng" @click="onClose">
          <X class="h-5 w-5" />
        </button>
      </header>

      <!-- ============================================================ -->
      <!-- Nội dung -->
      <!-- ============================================================ -->
      <section class="min-h-0 flex-1 overflow-auto px-5 py-4">
        <div class="flex flex-col gap-6">
          <sg_input_text
            v-model="form.geometry_code"
            label="Mã khối hình học"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-2 sg-input w-full"
            placeholder="VD: GEO-001"
            :error="errors.geometry_code"
          />

          <sg_input_text
            v-model="form.geometry_name"
            label="Tên khối hình học"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-2 sg-input w-full"
            :required-input="true"
            placeholder="Nhập tên khối hình học"
            :error="errors.geometry_name"
          />

          <sg_select
            :model-value="form.scales"
            label="Hệ số nhân tỉ lệ (Scale)"
            label-c-s-s="sg-label-input"
            :items="SCALE_OPTIONS"
            :show-add="false"
            :show-edit="false"
            :show-delete="false"
            @update:model-value="onScaleChange"
          />

          <div class="grid grid-cols-3 gap-4">
            <sg_input_number
              v-model="form.leng"
              label="Chiều dài (L)"
              input-c-s-s="py-2 sg-input p-2 w-full"
              :decimal="2"
              :min="0"
            />
            <sg_input_number
              v-model="form.width"
              label="Chiều rộng (W)"
              input-c-s-s="py-2 sg-input p-2 w-full"
              :decimal="2"
              :min="0"
            />
            <sg_input_number
              v-model="form.height"
              label="Chiều cao (H)"
              input-c-s-s="py-2 sg-input p-2 w-full"
              :decimal="2"
              :min="0"
            />
          </div>

          <div>
            Kích thước ô lưới
            <div class="grid grid-cols-3 gap-4">
              <sg_input_number
                v-model="form.delta_x"
                label="Chiều dài (L)"
                input-c-s-s="py-2 sg-input p-2 w-full"
                :decimal="2"
                :min="0"
              />
              <sg_input_number
                v-model="form.delta_y"
                label="Chiều rộng (W)"
                input-c-s-s="py-2 sg-input p-2 w-full"
                :decimal="2"
                :min="0"
              />
              <sg_input_number
                v-model="form.delta_z"
                label="Chiều cao (H)"
                input-c-s-s="py-2 sg-input p-2 w-full"
                :decimal="2"
                :min="0"
              />
            </div>
          </div>

          <div class="flex gap-4">
            <sg_radio
              v-model="form.geometry_status"
              :value="GEOMETRY_STATUS.DRAFT"
              label="Draft"
              name="status"
            />
            <sg_radio
              v-model="form.geometry_status"
              :value="GEOMETRY_STATUS.ACTIVE"
              label="Active"
              name="status"
            />
            <sg_radio
              v-model="form.geometry_status"
              :value="GEOMETRY_STATUS.INACTIVE"
              label="Inactive"
              name="status"
            />
          </div>
        </div>
      </section>

      <!-- ============================================================ -->
      <!-- Footer -->
      <!-- ============================================================ -->
      <footer
        class="flex shrink-0 items-center justify-end gap-3 border-t border-gray-200 px-5 py-4"
      >
        <button type="button" class="sg-button-secondary" :disabled="saving" @click="onClose">
          <Ban class="w-5 h-5" stroke-width="1" />Hủy
        </button>
        <button type="button" class="sg-button-primary" :disabled="saving" @click="onSave">
          <Save class="w-5 h-5" stroke-width="1" />{{ saving ? 'Đang lưu...' : 'Lưu' }}
        </button>
      </footer>
    </div>
  </div>

  <!-- Hộp thoại báo lỗi khi gọi API thất bại -->
  <sg_message_box
    :show="msgBox.show"
    :type="msgBox.type"
    :title="msgBox.title"
    :message="msgBox.message"
    :show_ok="msgBox.show_ok"
    :show_cancel="msgBox.show_cancel"
    @ok="msgBox.show = false"
    @cancel="msgBox.show = false"
  />
</template>

<style scoped></style>
