<script setup lang="ts">
import { computed, reactive, ref, watch } from 'vue'
import { X, Save, Ban } from 'lucide-vue-next'
import sg_input_text from '@/components/base/sg_input_text.vue'
import sg_input_number from '@/components/base/sg_input_number.vue'
import sg_radio from '@/components/base/sg_radio.vue'
import sg_select from '@/components/base/sg_select.vue'
import sg_check_box from '@/components/base/sg_check_box.vue'
import sg_message_box from '@/components/base/sg_message_box.vue'
import type { SGSelectItem } from '@/types/sg_site_type'
import type { MsgBoxOptions } from '@/types/sg_msg_box.types'
import {
  CONTROL_MODE,
  DEFAULT_INLET_FLOW_RATE_FIX,
  DEFAULT_INLET_VELOCITY,
  HYDRAULIC_DIAMETER,
  INLET_DIRECTION
} from '@/constants/sg_engr_inlet_const'
import { createInlet, newSGInletCreate } from '@/services/sg_inlet_srv'
import { getUnits } from '@/services/sg_unit_srv'
import { roundDecimal } from '@/utils/sg_formatters'
import { useToast } from '@/utils/sg_use_toast'
import type { SGInletCreate, SGInletRead } from '@/types/sg_inlet'
import type { SGGeometryRead } from '@/types/sg_geometry'
import type { ObjFaceSelection } from '@/types/sg_face_type'

// ======================================================================
// Modal "Miệng cấp gió" (INLET) — thêm mới điều kiện biên.
//   Header : tiêu đề bên trái, nút icon "Đóng" bên phải
//   Body   : Bề mặt được chọn
//            [1] Phương thức điều khiển (control_mode)
//            [2] Thông số vật lý — flow_rate mang ý nghĩa lưu lượng / vận tốc /
//                áp suất tổng tùy theo control_mode đã chọn ở [1]
//            [3] Đặc tính xáo động
//   Footer : nút "Đóng" và "Lưu" căn phải
// Nút "Lưu": validate -> gọi API createInlet -> Toast + emit bản ghi SGInletRead
// + đóng modal khi thành công, hiển thị MessageBox khi có lỗi.
// ======================================================================

interface Props {
  /** Điều khiển đóng mở modal */
  open?: boolean
  /** Tên bề mặt (patch) được chọn làm miệng cấp */
  surfaceName?: string
  /** Khối hình học chứa miệng cấp (lấy geometry_id) */
  geometry?: SGGeometryRead | null
  /** Mặt được chọn làm miệng cấp — lấy tâm (pos_x/y/z) và kích thước (size_w/h) */
  face?: ObjFaceSelection | null
}

const props = withDefaults(defineProps<Props>(), {
  open: false,
  surfaceName: '',
  geometry: null,
  face: null
})

// Kích thước (rộng, cao) của mặt theo 2 trục nằm trong mặt phẳng của nó. Mặt ⊥ X giữ
// quy ước của viewer: rộng theo Y, cao theo Z. Mặt nghiêng ('—') lấy theo mặt ⊥ X.
function faceSize(face: ObjFaceSelection): { w: number; h: number } {
  const dx = face.max.x - face.min.x
  const dy = face.max.y - face.min.y
  const dz = face.max.z - face.min.z
  if (face.axis === 'Y') return { w: dx, h: dz }
  if (face.axis === 'Z') return { w: dx, h: dy }
  return { w: dy, h: dz }
}

const emit = defineEmits<{
  (event: 'close'): void
  // Phát ra sau khi tạo inlet thành công — trang cha dùng để cập nhật danh sách.
  (event: 'saved', inlet: SGInletRead): void
}>()

const toast = useToast()

// Trạng thái gọi API lưu inlet.
const saving = ref(false)

// Hộp thoại báo lỗi (lỗi nạp đơn vị / thiếu khối hình học / lỗi lưu).
const msgBox = reactive<MsgBoxOptions>({
  show: false,
  type: 'error',
  title: 'Lỗi',
  message: '',
  show_ok: true,
  show_cancel: false
})

function showError(message: string): void {
  msgBox.message = message
  msgBox.show = true
}

// Hiển thị số theo định dạng '0.90' như bản thiết kế.
const NUMBER_LOCALE = 'en-US'

const SECTION_TITLE_CSS = 'text-sm font-semibold uppercase tracking-wide text-pmis-lightlabel'
const ROW_CSS = 'grid grid-cols-1 items-start gap-1 sm:grid-cols-[minmax(0,240px)_1fr] sm:gap-4'
const ROW_LABEL_CSS = 'text-[15px] text-pmis-label sm:pt-1.5'
const NUMBER_INPUT_CSS = 'py-1 sg-input w-32 text-right'
const UNIT_CSS = 'pt-1.5 text-sm text-slate-600'

const CONTROL_MODE_OPTIONS = [
  { value: CONTROL_MODE.FLOW_RATE, label: 'Lưu lượng' },
  { value: CONTROL_MODE.VELOCITY, label: 'Vận tốc trực tiếp' },
  { value: CONTROL_MODE.TOTAL_PRESSURE, label: 'Áp suất tổng' }
]

// Giá trị mặc định của flow_rate theo từng control_mode (đặt lại khi đổi chế độ).
const FLOW_RATE_DEFAULT_BY_MODE: Record<number, number> = {
  [CONTROL_MODE.FLOW_RATE]: DEFAULT_INLET_FLOW_RATE_FIX,
  [CONTROL_MODE.VELOCITY]: DEFAULT_INLET_VELOCITY,
  [CONTROL_MODE.TOTAL_PRESSURE]: 0
}

// --- Danh sách đơn vị lưu lượng (flow_unit_id) — nạp từ API getUnits ---
const unitOptions = ref<SGSelectItem[]>([])

async function loadUnits(): Promise<void> {
  try {
    const units = await getUnits()
    unitOptions.value = units.map((unit) => ({ label: unit.unit_name, value: unit.unit_id }))
  } catch (error) {
    showError(error instanceof Error ? error.message : 'Không tải được danh sách đơn vị.')
  }
}

// --- Trạng thái form ---
function defaultForm(): SGInletCreate {
  return {
    ...newSGInletCreate(),
    inlet_code: null,
    inlet_name: props.surfaceName,
    geometry_id: props.geometry?.geometry_id ?? 0,
    control_mode: CONTROL_MODE.FLOW_RATE,
    flow_rate: FLOW_RATE_DEFAULT_BY_MODE[CONTROL_MODE.FLOW_RATE],
    direction: INLET_DIRECTION.NORMAL,
    u_x: 0,
    u_y: 0,
    u_z: -1,
    turbulence: 5,
    hyd_diameter: 0.2,
    hyd_diameter_auto: HYDRAULIC_DIAMETER.AUTO
  }
}

const form = reactive<SGInletCreate>(defaultForm())

type FieldKey = 'inlet_code' | 'flow_rate' | 'direction' | 'turbulence' | 'hyd_diameter'

const errors = reactive<Record<FieldKey, string>>({
  inlet_code: '',
  flow_rate: '',
  direction: '',
  turbulence: '',
  hyd_diameter: ''
})

function clearErrors(): void {
  errors.inlet_code = ''
  errors.flow_rate = ''
  errors.direction = ''
  errors.turbulence = ''
  errors.hyd_diameter = ''
}

// Nạp lại giá trị mặc định mỗi khi modal được mở lại; nạp đơn vị lần đầu mở.
watch(
  () => props.open,
  (isOpen) => {
    if (!isOpen) return
    Object.assign(form, defaultForm())
    clearErrors()
    if (unitOptions.value.length === 0) void loadUnits()
  },
  { immediate: true }
)

// Đổi chế độ cấp gió -> flow_rate mang ý nghĩa khác, đặt lại giá trị mặc định.
watch(
  () => form.control_mode,
  (mode) => {
    form.flow_rate = FLOW_RATE_DEFAULT_BY_MODE[mode] ?? 0
  }
)

// Người dùng vừa sửa ô nào thì xóa ngay báo lỗi của ô đó.
;(['inlet_code', 'flow_rate', 'turbulence', 'hyd_diameter'] as const).forEach((field) => {
  watch(
    () => form[field],
    () => {
      if (errors[field]) errors[field] = ''
    }
  )
})
watch(
  () => [form.u_x, form.u_y, form.u_z, form.direction],
  () => {
    if (errors.direction) errors.direction = ''
  }
)
watch(
  () => form.hyd_diameter_auto,
  () => {
    if (errors.hyd_diameter) errors.hyd_diameter = ''
  }
)

const isFlowRate = computed(() => form.control_mode === CONTROL_MODE.FLOW_RATE)
const isVelocity = computed(() => form.control_mode === CONTROL_MODE.VELOCITY)
const isTotalPressure = computed(() => form.control_mode === CONTROL_MODE.TOTAL_PRESSURE)
const isDirectionVector = computed(() => form.direction === INLET_DIRECTION.VECTOR)
const isHydDiameterAuto = computed(() => form.hyd_diameter_auto === HYDRAULIC_DIAMETER.AUTO)

function validate(): boolean {
  clearErrors()

  if ((form.inlet_code?.trim().length ?? 0) > 30)
    errors.inlet_code = 'Mã miệng cấp tối đa 30 ký tự.'

  if (isFlowRate.value && !(form.flow_rate > 0))
    errors.flow_rate = 'Lưu lượng cấp gió phải lớn hơn 0.'

  if (isVelocity.value && !(form.flow_rate > 0))
    errors.flow_rate = 'Vận tốc cấp gió phải lớn hơn 0.'

  if (isDirectionVector.value && form.u_x === 0 && form.u_y === 0 && form.u_z === 0)
    errors.direction = 'Vector hướng không được bằng (0, 0, 0).'

  if (!(form.turbulence > 0) || form.turbulence > 100)
    errors.turbulence = 'Cường độ xáo động phải nằm trong khoảng (0 -> 100] %.'

  if (!isHydDiameterAuto.value && !(form.hyd_diameter > 0))
    errors.hyd_diameter = 'Đường kính thủy lực phải lớn hơn 0.'

  return !Object.values(errors).some(Boolean)
}

function onClose(): void {
  if (saving.value) return
  emit('close')
}

async function onSave(): Promise<void> {
  if (saving.value) return
  if (!props.geometry) {
    showError('Chưa chọn khối hình học cho miệng cấp gió.')
    return
  }
  if (!props.face) {
    showError('Chưa chọn mặt cho miệng cấp gió.')
    return
  }
  // 1. Kiểm tra dữ liệu hợp lệ
  if (!validate()) return

  // Miệng cấp phủ toàn bộ mặt được chọn: tâm = tâm mặt, kích thước = kích thước mặt.
  const center = props.face.planeCenter
  const size = faceSize(props.face)

  // Backend lưu Decimal(…, 2) -> làm tròn các trường số thực trước khi gửi.
  const payload: SGInletCreate = {
    ...form,
    // Bỏ trống mã -> gửi null để backend tự sinh.
    inlet_code: form.inlet_code?.trim() || null,
    inlet_name: form.inlet_name?.trim() || null,
    geometry_id: props.geometry.geometry_id,
    flow_rate: roundDecimal(form.flow_rate),
    temperature: roundDecimal(form.temperature),
    pos_x: roundDecimal(center.x),
    pos_y: roundDecimal(center.y),
    pos_z: roundDecimal(center.z),
    size_w: roundDecimal(size.w),
    size_h: roundDecimal(size.h),
    u_x: roundDecimal(form.u_x),
    u_y: roundDecimal(form.u_y),
    u_z: roundDecimal(form.u_z),
    turbulence: roundDecimal(form.turbulence),
    hyd_diameter: roundDecimal(form.hyd_diameter),
    hyd_diameter_auto: form.hyd_diameter_auto
  }

  saving.value = true
  try {
    // 2. Gọi API lưu vào DB
    const created = await createInlet(payload)

    // 3. Thành công: Toast + đóng modal
    toast.success('Thêm mới miệng cấp gió thành công.')
    emit('saved', created)
    emit('close')
  } catch (error) {
    // 4. Có lỗi: hiển thị MessageBox
    const message =
      error instanceof Error ? error.message : 'Không thể lưu miệng cấp gió. Vui lòng thử lại.'
    showError(message)
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <div v-if="open" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
    <div class="flex max-h-full w-full max-w-2xl flex-col rounded-xl bg-white shadow-xl">
      <!-- ============================================================ -->
      <!-- Header -->
      <!-- ============================================================ -->
      <header
        class="flex shrink-0 items-center justify-between gap-4 border-b border-gray-200 px-5 py-4"
      >
        <h1 class="sg-title-page">Miệng cấp gió</h1>

        <button type="button" class="sg-button-only-icon" title="Đóng" @click="onClose">
          <X class="h-5 w-5" />
        </button>
      </header>

      <!-- ============================================================ -->
      <!-- Nội dung -->
      <!-- ============================================================ -->
      <section class="inlet-add-scroll min-h-0 flex-1 overflow-auto px-5 py-4">
        <div class="flex flex-col gap-3">
          <div :class="ROW_CSS">
            <span :class="ROW_LABEL_CSS">Mã miệng cấp</span>
            <sg_input_text
              v-model="form.inlet_code"
              input-c-s-s="py-1 sg-input w-full"
              placeholder="Bỏ trống để hệ thống tự sinh"
              :error="errors.inlet_code"
            />
          </div>

          <div :class="ROW_CSS">
            <span :class="ROW_LABEL_CSS">Tên miệng cấp</span>
            <sg_input_text v-model="form.inlet_name" input-c-s-s="py-1 sg-input w-full" />
          </div>

          <!-- [1] Phương thức điều khiển -->
          <fieldset class="flex flex-col gap-3">
            <legend :class="SECTION_TITLE_CSS" class="mb-3 flex w-full items-center gap-3">
              <span class="shrink-0">Phương thức điều khiển</span>
              <span class="h-px flex-1 bg-pmis-bordertab" />
            </legend>

            <div :class="ROW_CSS">
              <span :class="ROW_LABEL_CSS">Chế độ cấp gió</span>
              <div class="flex flex-col gap-2 sm:pt-1.5">
                <sg_radio
                  v-for="option in CONTROL_MODE_OPTIONS"
                  :key="option.value"
                  v-model="form.control_mode"
                  :value="option.value"
                  :label="option.label"
                  name="inlet_add_flow_mode"
                />
              </div>
            </div>
          </fieldset>

          <!-- [2] Thông số vật lý — ô đầu tiên thay đổi theo chế độ đã chọn ở [1] -->
          <fieldset class="flex flex-col gap-3">
            <legend :class="SECTION_TITLE_CSS" class="mb-3 flex w-full items-center gap-3">
              <span class="shrink-0">Thông số vật lý</span>
              <span class="h-px flex-1 bg-pmis-bordertab" />
            </legend>

            <div v-if="isFlowRate" :class="ROW_CSS">
              <span :class="ROW_LABEL_CSS">Lưu lượng cấp gió</span>
              <div class="flex items-start gap-2">
                <sg_input_number
                  v-model="form.flow_rate"
                  :input-c-s-s="NUMBER_INPUT_CSS"
                  :decimal="1"
                  :min="0"
                  :locale="NUMBER_LOCALE"
                  :error="errors.flow_rate"
                />
                <div class="w-28">
                  <sg_select
                    v-model="form.flow_unit_id"
                    selectcss="py-1 sg-select"
                    :items="unitOptions"
                    :show-add="false"
                    :show-edit="false"
                    :show-delete="false"
                  />
                </div>
              </div>
            </div>

            <div v-else-if="isVelocity" :class="ROW_CSS">
              <span :class="ROW_LABEL_CSS">Vận tốc cấp gió</span>
              <div class="flex items-start gap-2">
                <sg_input_number
                  v-model="form.flow_rate"
                  :input-c-s-s="NUMBER_INPUT_CSS"
                  :decimal="2"
                  :min="0"
                  :locale="NUMBER_LOCALE"
                  :error="errors.flow_rate"
                />
                <span :class="UNIT_CSS">m/s</span>
              </div>
            </div>

            <div v-else-if="isTotalPressure" :class="ROW_CSS">
              <span :class="ROW_LABEL_CSS">Áp suất tổng</span>
              <div class="flex items-start gap-2">
                <sg_input_number
                  v-model="form.flow_rate"
                  :input-c-s-s="NUMBER_INPUT_CSS"
                  :decimal="1"
                  :locale="NUMBER_LOCALE"
                />
                <span :class="UNIT_CSS">Pa</span>
              </div>
            </div>

            <div :class="ROW_CSS">
              <span :class="ROW_LABEL_CSS">Hướng thổi</span>
              <div class="flex flex-col gap-2 sm:pt-1.5">
                <sg_radio
                  v-model="form.direction"
                  :value="INLET_DIRECTION.NORMAL"
                  label="Vuông góc bề mặt"
                  name="inlet_add_direction_mode"
                />
                <sg_radio
                  v-model="form.direction"
                  :value="INLET_DIRECTION.VECTOR"
                  label="Định hướng Vector [Ux, Uy, Uz]"
                  name="inlet_add_direction_mode"
                />

                <!-- Thành phần vector hướng thổi -->
                <div v-if="isDirectionVector" class="ml-7 flex flex-col gap-1">
                  <div class="flex flex-wrap items-start gap-3">
                    <div
                      v-for="axis in ['x', 'y', 'z'] as const"
                      :key="axis"
                      class="flex items-start gap-1.5"
                    >
                      <span :class="UNIT_CSS">U{{ axis }}</span>
                      <sg_input_number
                        v-model="form[`u_${axis}`]"
                        input-c-s-s="py-1 sg-input w-20 text-right"
                        :decimal="2"
                        :locale="NUMBER_LOCALE"
                      />
                    </div>
                  </div>
                  <span v-if="errors.direction" class="text-sm text-red-500">
                    {{ errors.direction }}
                  </span>
                </div>
              </div>
            </div>

            <div :class="ROW_CSS">
              <span :class="ROW_LABEL_CSS">Nhiệt độ gió cấp</span>
              <div class="flex items-start gap-2">
                <sg_input_number
                  v-model="form.temperature"
                  :input-c-s-s="NUMBER_INPUT_CSS"
                  :decimal="1"
                  :locale="NUMBER_LOCALE"
                />
                <span :class="UNIT_CSS">°C</span>
              </div>
            </div>
          </fieldset>

          <!-- [3] Đặc tính xáo động -->
          <fieldset class="flex flex-col gap-3">
            <legend :class="SECTION_TITLE_CSS" class="mb-3 flex w-full items-center gap-3">
              <span class="shrink-0">Đặc tính xáo động</span>
              <span class="h-px flex-1 bg-pmis-bordertab" />
            </legend>

            <div :class="ROW_CSS">
              <span :class="ROW_LABEL_CSS">Cường độ xáo động</span>
              <div class="flex items-start gap-2">
                <sg_input_number
                  v-model="form.turbulence"
                  :input-c-s-s="NUMBER_INPUT_CSS"
                  :decimal="1"
                  :min="0"
                  :max="100"
                  :locale="NUMBER_LOCALE"
                  :error="errors.turbulence"
                />
                <span :class="UNIT_CSS">%</span>
              </div>
            </div>

            <div :class="ROW_CSS">
              <span :class="ROW_LABEL_CSS">Đường kính thủy lực (D_h)</span>
              <div class="flex flex-wrap items-start gap-2">
                <sg_input_number
                  v-model="form.hyd_diameter"
                  :input-c-s-s="NUMBER_INPUT_CSS"
                  :decimal="2"
                  :min="0"
                  :locale="NUMBER_LOCALE"
                  :disabled="isHydDiameterAuto"
                  :error="errors.hyd_diameter"
                />
                <span :class="UNIT_CSS">m</span>
                <div class="ml-3 pt-1.5">
                  <sg_check_box
                    v-model="form.hyd_diameter_auto"
                    :true-value="HYDRAULIC_DIAMETER.AUTO"
                    :false-value="HYDRAULIC_DIAMETER.MANUAL"
                    label="Tự động tính"
                  />
                </div>
              </div>
            </div>
          </fieldset>
        </div>
      </section>

      <!-- ============================================================ -->
      <!-- Footer -->
      <!-- ============================================================ -->
      <footer
        class="flex shrink-0 items-center justify-end gap-3 border-t border-gray-200 px-5 py-4"
      >
        <button type="button" class="sg-button-secondary" :disabled="saving" @click="onClose">
          <Ban class="w-5 h-5" stroke-width="1" />Đóng
        </button>
        <button type="button" class="sg-button-primary" :disabled="saving" @click="onSave">
          <Save class="w-5 h-5" stroke-width="1" />{{ saving ? 'Đang lưu...' : 'Lưu' }}
        </button>
      </footer>
    </div>

    <sg_message_box
      :show="msgBox.show"
      :type="msgBox.type"
      :title="msgBox.title"
      :message="msgBox.message"
      :show_ok="msgBox.show_ok"
      :show_cancel="msgBox.show_cancel"
      @ok="msgBox.show = false"
      @cancel="msgBox.show = false"
    />
  </div>
</template>

<style scoped>
/* Thanh cuộn mảnh (~5px, bằng 1/3 mặc định trình duyệt), chỉ hiện khi hover vùng nội dung. */
/* Firefox: không hỗ trợ độ rộng tùy ý, dùng 'thin'. Chỉ áp dụng khi trình duyệt không có
   ::-webkit-scrollbar — Chrome/Edge mới sẽ bỏ qua ::-webkit-scrollbar nếu có scrollbar-width. */
@supports not selector(::-webkit-scrollbar) {
  .inlet-add-scroll {
    scrollbar-width: thin;
    scrollbar-color: transparent transparent;
  }

  .inlet-add-scroll:hover {
    scrollbar-color: rgb(203 213 225) transparent; /* slate-300 */
  }
}

.inlet-add-scroll::-webkit-scrollbar {
  width: 5px;
  height: 5px;
}

.inlet-add-scroll::-webkit-scrollbar-track {
  background: transparent;
}

.inlet-add-scroll::-webkit-scrollbar-thumb {
  background-color: transparent;
  border-radius: 9999px;
}

.inlet-add-scroll:hover::-webkit-scrollbar-thumb {
  background-color: rgb(203 213 225); /* slate-300 */
}

.inlet-add-scroll:hover::-webkit-scrollbar-thumb:hover {
  background-color: rgb(148 163 184); /* slate-400 */
}
</style>
