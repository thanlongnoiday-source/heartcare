<script setup lang="ts">
import { computed, reactive, ref, watch } from 'vue'
import dayjs from 'dayjs'
import { X, Ban, Power, PowerOff } from 'lucide-vue-next'
import sg_input_text from '@/components/base/sg_input_text.vue'
import sg_input_date from '@/components/base/sg_input_date.vue'
import sg_select from '@/components/base/sg_select.vue'
import sg_radio from '@/components/base/sg_radio.vue'
import sg_message_box from '@/components/base/sg_message_box.vue'
import { useToast } from '@/utils/sg_use_toast'
import { updateProject } from '@/services/sg_project_srv'
import { PROJECT_STATUS } from '@/constants/sg_engr_project_const'
import type { SGProjectRead, SGProjectUpdate } from '@/types/sg_project'
import type { SGSelectItem } from '@/types/sg_site_type'
import type { MsgBoxOptions } from '@/types/sg_msg_box.types'

// ======================================================================
// Modal "Xem dự án" — hiển thị thông tin dự án ở chế độ chỉ đọc.
//   Header : tiêu đề "Xem dự án" bên trái, nút icon "Đóng" bên phải
//   Body   : các trường lấy từ SGProjectRead — tất cả đều bị vô hiệu hóa
//   Footer : nút "Close" và một nút đổi trạng thái có 2 dạng:
//              - "Kích hoạt"       khi dự án đang KHÔNG hoạt động (Nháp / Dừng)
//              - "Dừng hoạt động"  khi dự án đang hoạt động (Active)
// Nút đổi trạng thái: xác nhận -> gọi API updateProject -> Toast + emit
// bản ghi SGProjectRead + đóng modal khi thành công, MessageBox khi lỗi.
// ======================================================================

interface Props {
  /** Điều khiển đóng mở modal */
  open?: boolean
  /** Dữ liệu dự án cần xem (SGProjectRead) */
  project?: SGProjectRead | null
  /** Danh sách khách hàng để hiển thị tên theo customer_id */
  customerOptions?: SGSelectItem[]
}

const props = withDefaults(defineProps<Props>(), {
  open: false,
  project: null,
  customerOptions: () => []
})

const emit = defineEmits<{
  (event: 'close'): void
  // Phát ra sau khi đổi trạng thái thành công — trang cha dùng để refresh danh sách.
  (event: 'saved', project: SGProjectRead): void
}>()

const toast = useToast()

// Trạng thái gọi API + hộp thoại (xác nhận đổi trạng thái / báo lỗi).
const saving = ref(false)

// Chế độ hộp thoại: 'confirm' = hỏi xác nhận đổi trạng thái, 'error' = báo lỗi.
const msgBoxMode = ref<'confirm' | 'error'>('confirm')

const msgBox = reactive<MsgBoxOptions>({
  show: false,
  type: 'error',
  title: 'Lỗi',
  message: '',
  text_ok: 'OK',
  text_cancel: 'Hủy',
  show_ok: true,
  show_cancel: false
})

function showError(message: string): void {
  msgBoxMode.value = 'error'
  msgBox.type = 'error'
  msgBox.title = 'Lỗi'
  msgBox.message = message
  msgBox.text_ok = 'OK'
  msgBox.show_ok = true
  msgBox.show_cancel = false
  msgBox.show = true
}

// --- Trạng thái form (chỉ để hiển thị) ---
// project_date giữ ở dạng 'YYYY-MM-DD' cho sg_input_date.
interface ProjectForm {
  project_id: number
  project_code: string
  project_name: string
  project_date: string
  customer_id: number | null
  project_status: number
}

function emptyForm(): ProjectForm {
  return {
    project_id: 0,
    project_code: '',
    project_name: '',
    project_date: dayjs().format('YYYY-MM-DD'),
    customer_id: null,
    project_status: PROJECT_STATUS.DRAFT
  }
}

const form = reactive<ProjectForm>(emptyForm())

// Nạp lại dữ liệu dự án mỗi khi modal được mở lại.
watch(
  () => props.open,
  (isOpen) => {
    if (!isOpen) return

    const source = props.project
    if (source) {
      form.project_id = source.project_id
      form.project_code = source.project_code ?? ''
      form.project_name = source.project_name
      form.project_date =
        source.project_date && dayjs(source.project_date).isValid()
          ? dayjs(source.project_date).format('YYYY-MM-DD')
          : ''
      form.customer_id = source.customer_id
      form.project_status = source.project_status
    } else {
      Object.assign(form, emptyForm())
    }
  },
  { immediate: true }
)

// --- Nút đổi trạng thái ở Footer ---
// Dự án đang "Active" -> nút "Dừng hoạt động" (chuyển sang Inactive).
// Ngược lại (Nháp / Dừng) -> nút "Kích hoạt" (chuyển sang Active).
const isActive = computed<boolean>(() => form.project_status === PROJECT_STATUS.ACTIVE)

const toggleLabel = computed<string>(() => (isActive.value ? 'Dừng hoạt động' : 'Kích hoạt'))

const targetStatus = computed<number>(() =>
  isActive.value ? PROJECT_STATUS.INACTIVE : PROJECT_STATUS.ACTIVE
)

function onClose(): void {
  if (saving.value) return
  emit('close')
}

// Bấm nút đổi trạng thái -> mở hộp thoại xác nhận.
function onToggleStatus(): void {
  if (saving.value || !props.project) return

  msgBoxMode.value = 'confirm'
  msgBox.type = 'confirm'
  msgBox.title = 'Xác nhận'
  msgBox.message = `Bạn có chắc chắn muốn ${toggleLabel.value.toLowerCase()} dự án "${form.project_name}" không?`
  msgBox.text_ok = toggleLabel.value
  msgBox.text_cancel = 'Hủy'
  msgBox.show_ok = true
  msgBox.show_cancel = true
  msgBox.show = true
}

async function onMsgBoxOk(): Promise<void> {
  // Đang báo lỗi -> chỉ đóng hộp thoại.
  if (msgBoxMode.value === 'error') {
    msgBox.show = false
    return
  }

  const source = props.project
  if (!source || saving.value) return

  msgBox.show = false
  saving.value = true
  try {
    const payload: SGProjectUpdate = {
      project_name: source.project_name,
      project_date:
        source.project_date && dayjs(source.project_date).isValid()
          ? dayjs(source.project_date).toISOString()
          : dayjs().toISOString(),
      customer_id: source.customer_id,
      project_status: targetStatus.value
    }

    const updated = await updateProject(source.project_id, payload)

    toast.success('Cập nhật trạng thái dự án thành công.')
    emit('saved', updated)
    emit('close')
  } catch (error) {
    const message =
      error instanceof Error ? error.message : 'Không thể cập nhật trạng thái dự án. Vui lòng thử lại.'
    showError(message)
  } finally {
    saving.value = false
  }
}

function onMsgBoxCancel(): void {
  msgBox.show = false
}
</script>

<template>
  <div v-if="open" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
    <div class="flex max-h-full w-full max-w-lg flex-col rounded-xl bg-white shadow-xl">
      <!-- ============================================================ -->
      <!-- Header -->
      <!-- ============================================================ -->
      <header
        class="flex shrink-0 items-center justify-between gap-4 border-b border-gray-200 px-5 py-4"
      >
        <h1 class="sg-title-page">Xem dự án</h1>

        <button type="button" class="sg-button-only-icon" title="Đóng" @click="onClose">
          <X class="h-5 w-5" />
        </button>
      </header>

      <!-- ============================================================ -->
      <!-- Nội dung — chỉ đọc -->
      <!-- ============================================================ -->
      <section class="min-h-0 flex-1 overflow-auto px-5 py-4">
        <div class="flex flex-col gap-4">
          <sg_input_text
            v-model="form.project_code"
            label="Mã dự án"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-1 sg-input w-full"
            placeholder="Mã dự án"
            :disabled="true"
          />

          <sg_input_text
            v-model="form.project_name"
            label="Tên dự án"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-1 sg-input w-full"
            placeholder="Tên dự án"
            :disabled="true"
          />

          <sg_input_date
            v-model="form.project_date"
            label="Ngày dự án"
            label-c-s-s="sg-label-input"
            placeholder="Ngày dự án"
            :disabled="true"
          />

          <sg_select
            v-model="form.customer_id"
            label="Khách hàng"
            label-c-s-s="sg-label-input"
            :items="customerOptions"
            :show-add="false"
            :show-edit="false"
            :show-delete="false"
            placeholder="Khách hàng"
            :disabled="true"
          />

          <div class="flex gap-4 mt-6">
            <sg_radio
              v-model="form.project_status"
              :value="PROJECT_STATUS.DRAFT"
              :disabled="true"
              label="Draft"
              name="status-view"
            />
            <sg_radio
              v-model="form.project_status"
              :value="PROJECT_STATUS.ACTIVE"
              :disabled="true"
              label="Active"
              name="status-view"
            />
            <sg_radio
              v-model="form.project_status"
              :value="PROJECT_STATUS.INACTIVE"
              :disabled="true"
              label="Inactive"
              name="status-view"
            />
          </div>
        </div>
      </section>

      <!-- ============================================================ -->
      <!-- Footer -->
      <!-- ============================================================ -->
      <footer
        class="flex shrink-0 items-center justify-end gap-3 border-t border-gray-200 px-5 py-4"
      >
        <button type="button" class="sg-button-secondary" :disabled="saving" @click="onClose">
          <Ban class="w-5 h-5" stroke-width="1" />Close
        </button>
        <button
          type="button"
          class="sg-button-primary"
          :disabled="saving || !project"
          @click="onToggleStatus"
        >
          <Power v-if="!isActive" class="w-5 h-5" stroke-width="1" />
          <PowerOff v-else class="w-5 h-5" stroke-width="1" />
          {{ saving ? 'Đang lưu...' : toggleLabel }}
        </button>
      </footer>
    </div>
  </div>

  <!-- Hộp thoại: xác nhận đổi trạng thái / báo lỗi khi gọi API thất bại -->
  <sg_message_box
    :show="msgBox.show"
    :type="msgBox.type"
    :title="msgBox.title"
    :message="msgBox.message"
    :text_ok="msgBox.text_ok"
    :text_cancel="msgBox.text_cancel"
    :show_ok="msgBox.show_ok"
    :show_cancel="msgBox.show_cancel"
    @ok="onMsgBoxOk"
    @cancel="onMsgBoxCancel"
  />
</template>

<style scoped></style>
