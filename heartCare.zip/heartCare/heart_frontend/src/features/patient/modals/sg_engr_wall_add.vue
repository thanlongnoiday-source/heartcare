<script setup lang="ts">
import { computed, reactive, ref, watch } from 'vue'
import { X, Save, Ban } from 'lucide-vue-next'
import sg_input_text from '@/components/base/sg_input_text.vue'
import sg_input_number from '@/components/base/sg_input_number.vue'
import sg_radio from '@/components/base/sg_radio.vue'
import sg_check_box from '@/components/base/sg_check_box.vue'
import sg_message_box from '@/components/base/sg_message_box.vue'
import type { MsgBoxOptions } from '@/types/sg_msg_box.types'
import {
  DEFAULT_WALL_AMBIENT_TEMP,
  DEFAULT_WALL_EMISSIVITY,
  DEFAULT_WALL_FIXED_POWER,
  DEFAULT_WALL_FIXED_POWER_UNIT,
  DEFAULT_WALL_FIXED_TEMP,
  DEFAULT_WALL_HEAT_POWER_0,
  DEFAULT_WALL_HEAT_TRANSFER_COEFFICIENT,
  DEFAULT_WALL_ROUGHNESS,
  DEFAULT_WALL_TRANSMISSIVITY,
  HEAT_FLUX_UNIT,
  SLIP_MODE,
  THERMAL_MODE,
  TRANSMISSIVITY_MODE
} from '@/constants/sg_engr_wall_const'
import { createWall, newSGWallCreate } from '@/services/sg_wall_srv'
import { getUnits } from '@/services/sg_unit_srv'
import { roundDecimal } from '@/utils/sg_formatters'
import { useToast } from '@/utils/sg_use_toast'
import type { SGWallCreate, SGWallRead } from '@/types/sg_wall'
import type { SGGeometryRead } from '@/types/sg_geometry'
import type { ObjFaceSelection } from '@/types/sg_face_type'

// ======================================================================
// Modal "Tường & bề mặt nội thất" (WALL) — thêm mới điều kiện biên.
//   Header : tiêu đề bên trái, nút icon "Đóng" bên phải
//   Body   : Mã / tên tường
//            [1] Đặc tính động lực học (ma sát thành, độ nhám)
//            [2] Chế độ thiết lập nhiệt — chọn 1 trong 4, mỗi chế độ có thông số riêng
//            [3] Thuộc tính bức xạ & mặt trời (độ phát xạ, độ xuyên sáng)
//   Footer : nút "Đóng" và "Lưu" căn phải
// Nút "Lưu": validate -> gọi API createWall -> Toast + emit bản ghi SGWallRead
// + đóng modal khi thành công, hiển thị MessageBox khi có lỗi.
// ======================================================================

interface Props {
  /** Điều khiển đóng mở modal */
  open?: boolean
  /** Tên bề mặt (patch) được chọn làm tường */
  surfaceName?: string
  /** Khối hình học chứa tường (lấy geometry_id) */
  geometry?: SGGeometryRead | null
  /** Mặt được chọn — lấy diện tích để quy đổi công suất W -> W/m² */
  face?: ObjFaceSelection | null
}

const props = withDefaults(defineProps<Props>(), {
  open: false,
  surfaceName: '',
  geometry: null,
  face: null
})

const emit = defineEmits<{
  (event: 'close'): void
  // Phát ra sau khi tạo wall thành công — trang cha dùng để cập nhật danh sách.
  (event: 'saved', wall: SGWallRead): void
}>()

const toast = useToast()

// Trạng thái gọi API lưu wall.
const saving = ref(false)

// Hộp thoại báo lỗi (thiếu khối hình học / lỗi lưu).
const msgBox = reactive<MsgBoxOptions>({
  show: false,
  type: 'error',
  title: 'Lỗi',
  message: '',
  show_ok: true,
  show_cancel: false
})

function showError(message: string): void {
  msgBox.message = message
  msgBox.show = true
}

// Hiển thị số theo định dạng '0.90' như bản thiết kế.
const NUMBER_LOCALE = 'en-US'

const SECTION_TITLE_CSS = 'text-sm font-semibold uppercase tracking-wide text-pmis-lightlabel'
const ROW_CSS = 'grid grid-cols-1 items-start gap-1 sm:grid-cols-[minmax(0,240px)_1fr] sm:gap-4'
const SUB_ROW_CSS = 'grid grid-cols-1 items-start gap-1 sm:grid-cols-[minmax(0,212px)_1fr] sm:gap-4'
const ROW_LABEL_CSS = 'text-[15px] text-pmis-label sm:pt-1.5'
const NUMBER_INPUT_CSS = 'py-1 sg-input w-32 text-right'
const UNIT_CSS = 'pt-1.5 text-sm text-slate-600'
// Khung thông số con của từng chế độ nhiệt (nhánh "└→" trong bản thiết kế).
const SUB_GROUP_CSS = 'ml-7 flex flex-col gap-2 border-l border-pmis-bordertab pl-4'

// --- Trạng thái form ---
interface WallAddForm extends SGWallCreate {
  wall_code: string
}

// --- Đơn vị công suất tỏa nhiệt (unit_id) — nạp nhãn từ API getUnits ---
// Chỉ dùng 2 đơn vị: W (unit_id=6) và W/m² (unit_id=8). Nhãn mặc định dùng khi API chưa trả về.
const HEAT_POWER_UNIT_IDS: number[] = [HEAT_FLUX_UNIT.WATT, HEAT_FLUX_UNIT.WATT_PER_M2]
const heatPowerUnits = ref<{ unit_id: number; unit_name: string }[]>([
  { unit_id: HEAT_FLUX_UNIT.WATT, unit_name: 'Watt (W)' },
  { unit_id: HEAT_FLUX_UNIT.WATT_PER_M2, unit_name: 'W/m²' }
])
const unitsLoaded = ref(false)

async function loadUnits(): Promise<void> {
  try {
    const units = await getUnits()
    const matched = HEAT_POWER_UNIT_IDS.map((id) => units.find((unit) => unit.unit_id === id))
    if (matched.every(Boolean)) {
      heatPowerUnits.value = matched.map((unit) => ({
        unit_id: unit!.unit_id,
        unit_name: unit!.unit_name
      }))
    }
    unitsLoaded.value = true
  } catch (error) {
    showError(error instanceof Error ? error.message : 'Không tải được danh sách đơn vị.')
  }
}

function defaultForm(): WallAddForm {
  return {
    ...newSGWallCreate(),
    wall_code: '',
    wall_name: props.surfaceName,
    geometry_id: props.geometry?.geometry_id ?? 0,
    thermal_mode: THERMAL_MODE.ADIABATIC,
    fixed_temp: DEFAULT_WALL_FIXED_TEMP,
    heat_power: DEFAULT_WALL_FIXED_POWER,
    unit_id: DEFAULT_WALL_FIXED_POWER_UNIT,
    heat_transfer_coefficient: DEFAULT_WALL_HEAT_TRANSFER_COEFFICIENT,
    ambient_temp: DEFAULT_WALL_AMBIENT_TEMP,
    emissivity: DEFAULT_WALL_EMISSIVITY,
    slip_mode: SLIP_MODE.No_SLIP,
    roughness: DEFAULT_WALL_ROUGHNESS,
    transmissivity_mode: TRANSMISSIVITY_MODE.NO_TRANSMISSIVITY,
    transmissivity: DEFAULT_WALL_TRANSMISSIVITY
  }
}

const form = reactive<WallAddForm>(defaultForm())

type FieldKey =
  | 'wall_code'
  | 'roughness'
  | 'heat_power'
  | 'heat_transfer_coefficient'
  | 'emissivity'
  | 'transmissivity'

const FIELD_KEYS: FieldKey[] = [
  'wall_code',
  'roughness',
  'heat_power',
  'heat_transfer_coefficient',
  'emissivity',
  'transmissivity'
]

const errors = reactive<Record<FieldKey, string>>({
  wall_code: '',
  roughness: '',
  heat_power: '',
  heat_transfer_coefficient: '',
  emissivity: '',
  transmissivity: ''
})

function clearErrors(): void {
  FIELD_KEYS.forEach((field) => (errors[field] = ''))
}

// Nạp lại giá trị mặc định mỗi khi modal được mở lại.
watch(
  () => props.open,
  (isOpen) => {
    if (!isOpen) return
    Object.assign(form, defaultForm())
    clearErrors()
    if (!unitsLoaded.value) void loadUnits()
  },
  { immediate: true }
)

// Người dùng vừa sửa ô nào thì xóa ngay báo lỗi của ô đó.
FIELD_KEYS.forEach((field) => {
  watch(
    () => form[field],
    () => {
      if (errors[field]) errors[field] = ''
    }
  )
})

const isAdiabatic = computed(() => form.thermal_mode === THERMAL_MODE.ADIABATIC)
const isFixedTemp = computed(() => form.thermal_mode === THERMAL_MODE.FIXED_TEMP)
const isFixedPower = computed(() => form.thermal_mode === THERMAL_MODE.FIXED_POWER)
const isHeatTrans = computed(() => form.thermal_mode === THERMAL_MODE.HEAT_TRANS)
const hasTransmissivity = computed(
  () => form.transmissivity_mode === TRANSMISSIVITY_MODE.TRANSMISSIVITY
)

function validate(): boolean {
  clearErrors()

  // Mã tường được phép bỏ trống -> backend tự sinh.
  if (form.wall_code.trim().length > 30) errors.wall_code = 'Mã tường tối đa 30 ký tự.'

  if (form.roughness < 0) errors.roughness = 'Độ nhám không được âm.'

  if (isHeatTrans.value && !(form.heat_transfer_coefficient > 0))
    errors.heat_transfer_coefficient = 'Hệ số truyền nhiệt phải lớn hơn 0.'

  if (form.emissivity < 0 || form.emissivity > 1)
    errors.emissivity = 'Độ phát xạ phải nằm trong khoảng 0.0 -> 1.0.'

  if (hasTransmissivity.value && (form.transmissivity < 0 || form.transmissivity > 1))
    errors.transmissivity = 'Độ xuyên sáng phải nằm trong khoảng 0.0 -> 1.0.'

  return !Object.values(errors).some(Boolean)
}

function onClose(): void {
  if (saving.value) return
  emit('close')
}

async function onSave(): Promise<void> {
  if (saving.value) return
  if (!props.geometry) {
    showError('Chưa chọn khối hình học cho tường.')
    return
  }
  // 1. Kiểm tra dữ liệu hợp lệ
  if (!validate()) return

  // Backend lưu Decimal(8, 2) -> làm tròn các trường số thực trước khi gửi.
  const payload: SGWallCreate = {
    // Bỏ trống -> gửi null để backend tự sinh mã.
    wall_code: form.wall_code.trim() || null,
    wall_name: form.wall_name?.trim() || null,
    slip_mode: form.slip_mode,
    roughness: roundDecimal(form.roughness),
    thermal_mode: form.thermal_mode,
    heat_power_0: DEFAULT_WALL_HEAT_POWER_0, // luôn = 0
    fixed_temp: roundDecimal(form.fixed_temp),
    // Cách nhiệt hoàn toàn: q = 0 W/m².
    // Gửi giá trị theo đúng đơn vị đã chọn (unit_id: 6 = W, 8 = W/m²).
    heat_power: isAdiabatic.value ? 0 : roundDecimal(form.heat_power),
    unit_id: form.unit_id,
    heat_transfer_coefficient: roundDecimal(form.heat_transfer_coefficient),
    ambient_temp: roundDecimal(form.ambient_temp),
    emissivity: roundDecimal(form.emissivity),
    transmissivity_mode: form.transmissivity_mode,
    transmissivity: roundDecimal(form.transmissivity),
    geometry_id: props.geometry.geometry_id
  }

  saving.value = true
  try {
    // 2. Gọi API lưu vào DB
    const created = await createWall(payload)

    // 3. Thành công: Toast + đóng modal
    toast.success('Thêm mới tường thành công.')
    emit('saved', created)
    emit('close')
  } catch (error) {
    // 4. Có lỗi: hiển thị MessageBox
    const message =
      error instanceof Error ? error.message : 'Không thể lưu tường. Vui lòng thử lại.'
    showError(message)
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <div v-if="open" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
    <div class="flex max-h-full w-full max-w-2xl flex-col rounded-xl bg-white shadow-xl">
      <!-- ============================================================ -->
      <!-- Header -->
      <!-- ============================================================ -->
      <header
        class="flex shrink-0 items-center justify-between gap-4 border-b border-gray-200 px-5 py-4"
      >
        <h1 class="sg-title-page">Tường &amp; bề mặt nội thất</h1>

        <button type="button" class="sg-button-only-icon" title="Đóng" @click="onClose">
          <X class="h-5 w-5" />
        </button>
      </header>

      <!-- ============================================================ -->
      <!-- Nội dung -->
      <!-- ============================================================ -->
      <section class="sg-scrollbar-thin min-h-0 flex-1 overflow-auto px-5 py-4">
        <div class="flex flex-col gap-3">
          <div :class="ROW_CSS">
            <span :class="ROW_LABEL_CSS">Mã tường</span>
            <sg_input_text
              v-model="form.wall_code"
              input-c-s-s="py-1 sg-input w-full"
              placeholder="Bỏ trống để hệ thống tự sinh"
              :error="errors.wall_code"
            />
          </div>

          <div :class="ROW_CSS">
            <span :class="ROW_LABEL_CSS">Tên tường</span>
            <sg_input_text v-model="form.wall_name" input-c-s-s="py-1 sg-input w-full" />
          </div>

          <!-- [1] Đặc tính động lực học -->
          <fieldset class="flex flex-col gap-3">
            <legend :class="SECTION_TITLE_CSS" class="mb-3 flex w-full items-center gap-3">
              <span class="shrink-0">Đặc tính động lực học</span>
              <span class="h-px flex-1 bg-pmis-bordertab" />
            </legend>

            <div :class="ROW_CSS">
              <span :class="ROW_LABEL_CSS">Chế độ ma sát thành</span>
              <div class="flex flex-col gap-2 sm:pt-1.5">
                <sg_radio
                  v-model="form.slip_mode"
                  :value="SLIP_MODE.No_SLIP"
                  label="Thành cứng không trượt"
                  name="wall_add_slip_mode"
                />
                <sg_radio
                  v-model="form.slip_mode"
                  :value="SLIP_MODE.SLIP"
                  label="Trượt tự do"
                  name="wall_add_slip_mode"
                />
              </div>
            </div>

            <div :class="ROW_CSS">
              <span :class="ROW_LABEL_CSS">Độ nhám bề mặt</span>
              <div class="flex items-start gap-2">
                <sg_input_number
                  v-model="form.roughness"
                  :input-c-s-s="NUMBER_INPUT_CSS"
                  :decimal="1"
                  :min="0"
                  :locale="NUMBER_LOCALE"
                  :error="errors.roughness"
                />
                <span :class="UNIT_CSS">mm</span>
              </div>
            </div>
          </fieldset>

          <!-- [2] Chế độ thiết lập nhiệt — chọn 1 trong 4 -->
          <fieldset class="flex flex-col gap-4">
            <legend :class="SECTION_TITLE_CSS" class="mb-3 flex w-full items-center gap-3">
              <span class="shrink-0">Chế độ thiết lập nhiệt</span>
              <span class="h-px flex-1 bg-pmis-bordertab" />
            </legend>

            <!-- Cách nhiệt hoàn toàn -->
            <div class="flex gap-2">
              <sg_radio
                v-model="form.thermal_mode"
                :value="THERMAL_MODE.ADIABATIC"
                label="Cách nhiệt hoàn toàn"
                name="wall_add_thermal_mode"
              />
              <div :class="SUB_GROUP_CSS">
                <span class="text-sm italic text-slate-500">Dòng nhiệt q = 0 W/m² </span>
              </div>
            </div>

            <!-- Nhiệt độ bề mặt cố định -->
            <div class="flex flex-col gap-2">
              <sg_radio
                v-model="form.thermal_mode"
                :value="THERMAL_MODE.FIXED_TEMP"
                label="Nhiệt độ bề mặt cố định"
                name="wall_add_thermal_mode"
              />
              <div :class="SUB_GROUP_CSS">
                <div :class="SUB_ROW_CSS">
                  <span :class="ROW_LABEL_CSS">Nhiệt độ bề mặt</span>
                  <div class="flex items-start gap-2">
                    <sg_input_number
                      v-model="form.fixed_temp"
                      :input-c-s-s="NUMBER_INPUT_CSS"
                      :decimal="1"
                      :locale="NUMBER_LOCALE"
                      :disabled="!isFixedTemp"
                    />
                    <span :class="UNIT_CSS">°C</span>
                  </div>
                </div>
              </div>
            </div>

            <!-- Tỏa nhiệt hằng số -->
            <div class="flex flex-col gap-2">
              <sg_radio
                v-model="form.thermal_mode"
                :value="THERMAL_MODE.FIXED_POWER"
                label="Tỏa nhiệt hằng số"
                name="wall_add_thermal_mode"
              />
              <div :class="SUB_GROUP_CSS">
                <!-- Công suất + chọn đơn vị (W / W/m²) trên cùng 1 dòng -->
                <div :class="SUB_ROW_CSS">
                  <span :class="ROW_LABEL_CSS">Công suất tỏa nhiệt</span>
                  <div class="flex flex-wrap items-start gap-x-6 gap-y-2">
                    <sg_input_number
                      v-model="form.heat_power"
                      :input-c-s-s="NUMBER_INPUT_CSS"
                      :decimal="1"
                      :locale="NUMBER_LOCALE"
                      :disabled="!isFixedPower"
                      :error="errors.heat_power"
                    />
                    <div class="flex items-center gap-6 pt-1.5">
                      <sg_radio
                        v-for="unit in heatPowerUnits"
                        :key="unit.unit_id"
                        v-model="form.unit_id"
                        :value="unit.unit_id"
                        :label="unit.unit_name"
                        name="wall_add_heat_power_unit"
                        :disabled="!isFixedPower"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Truyền nhiệt đối lưu ngoài -->
            <div class="flex flex-col gap-2">
              <sg_radio
                v-model="form.thermal_mode"
                :value="THERMAL_MODE.HEAT_TRANS"
                label="Truyền nhiệt đối lưu ngoài"
                name="wall_add_thermal_mode"
              />
              <div :class="SUB_GROUP_CSS">
                <div :class="SUB_ROW_CSS">
                  <span :class="ROW_LABEL_CSS">Hệ số truyền nhiệt đối lưu</span>
                  <div class="flex items-start gap-2">
                    <sg_input_number
                      v-model="form.heat_transfer_coefficient"
                      :input-c-s-s="NUMBER_INPUT_CSS"
                      :decimal="1"
                      :min="0"
                      :locale="NUMBER_LOCALE"
                      :disabled="!isHeatTrans"
                      :error="errors.heat_transfer_coefficient"
                    />
                    <span :class="UNIT_CSS">W/(m²·K)</span>
                  </div>
                </div>

                <div :class="SUB_ROW_CSS">
                  <span :class="ROW_LABEL_CSS">Nhiệt độ môi trường ngoài</span>
                  <div class="flex items-start gap-2">
                    <sg_input_number
                      v-model="form.ambient_temp"
                      :input-c-s-s="NUMBER_INPUT_CSS"
                      :decimal="1"
                      :locale="NUMBER_LOCALE"
                      :disabled="!isHeatTrans"
                    />
                    <span :class="UNIT_CSS">°C</span>
                  </div>
                </div>
              </div>
            </div>
          </fieldset>

          <!-- [3] Thuộc tính bức xạ & mặt trời -->
          <fieldset class="flex flex-col gap-3">
            <legend :class="SECTION_TITLE_CSS" class="mb-3 flex w-full items-center gap-3">
              <span class="shrink-0">Thuộc tính bức xạ</span>
              <span class="h-px flex-1 bg-pmis-bordertab" />
            </legend>

            <div :class="ROW_CSS">
              <span :class="ROW_LABEL_CSS">Độ phát xạ bề mặt</span>
              <div class="flex items-start gap-2">
                <sg_input_number
                  v-model="form.emissivity"
                  :input-c-s-s="NUMBER_INPUT_CSS"
                  :decimal="2"
                  :min="0"
                  :max="1"
                  :locale="NUMBER_LOCALE"
                  :error="errors.emissivity"
                />
                <span :class="UNIT_CSS">(0.0 -> 1.0)</span>
              </div>
            </div>

            <div :class="ROW_CSS">
              <div class="sm:pt-1.5">
                <sg_check_box
                  v-model="form.transmissivity_mode"
                  :true-value="TRANSMISSIVITY_MODE.TRANSMISSIVITY"
                  :false-value="TRANSMISSIVITY_MODE.NO_TRANSMISSIVITY"
                  label="Độ xuyên sáng"
                />
              </div>
              <div class="flex items-start gap-2">
                <sg_input_number
                  v-model="form.transmissivity"
                  :input-c-s-s="NUMBER_INPUT_CSS"
                  :decimal="2"
                  :min="0"
                  :max="1"
                  :locale="NUMBER_LOCALE"
                  :disabled="!hasTransmissivity"
                  :error="errors.transmissivity"
                />
                <span :class="UNIT_CSS">(0.0 -> 1.0)</span>
              </div>
            </div>
          </fieldset>
        </div>
      </section>

      <!-- ============================================================ -->
      <!-- Footer -->
      <!-- ============================================================ -->
      <footer
        class="flex shrink-0 items-center justify-end gap-3 border-t border-gray-200 px-5 py-4"
      >
        <button type="button" class="sg-button-secondary" :disabled="saving" @click="onClose">
          <Ban class="w-5 h-5" stroke-width="1" />Đóng
        </button>
        <button type="button" class="sg-button-primary" :disabled="saving" @click="onSave">
          <Save class="w-5 h-5" stroke-width="1" />{{ saving ? 'Đang lưu...' : 'Lưu' }}
        </button>
      </footer>
    </div>

    <sg_message_box
      :show="msgBox.show"
      :type="msgBox.type"
      :title="msgBox.title"
      :message="msgBox.message"
      :show_ok="msgBox.show_ok"
      :show_cancel="msgBox.show_cancel"
      @ok="msgBox.show = false"
      @cancel="msgBox.show = false"
    />
  </div>
</template>

<style scoped></style>
