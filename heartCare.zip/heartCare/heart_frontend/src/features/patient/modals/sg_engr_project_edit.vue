<script setup lang="ts">
import { computed, reactive, ref, watch } from 'vue'
import dayjs from 'dayjs'
import { X, Save, Ban } from 'lucide-vue-next'
import sg_input_text from '@/components/base/sg_input_text.vue'
import sg_input_date from '@/components/base/sg_input_date.vue'
import sg_select from '@/components/base/sg_select.vue'
import sg_radio from '@/components/base/sg_radio.vue'
import sg_message_box from '@/components/base/sg_message_box.vue'
import { useToast } from '@/utils/sg_use_toast'
import { updateProject } from '@/services/sg_project_srv'
import { PROJECT_STATUS } from '@/constants/sg_engr_project_const'
import type { SGProjectRead, SGProjectUpdate } from '@/types/sg_project'
import type { SGSelectItem } from '@/types/sg_site_type'
import type { MsgBoxOptions } from '@/types/sg_msg_box.types'

// ======================================================================
// Modal "Sửa dự án" — form chỉnh sửa thông tin dự án.
//   Header : tiêu đề "Sửa dự án" bên trái, nút icon "Đóng" bên phải
//   Body   : các trường lấy từ SGProjectRead (@/types/sg_project.ts)
//   Footer : nút "Close" và "Lưu" căn phải
// Nút "Lưu": validate -> gọi API updateProject -> Toast + emit bản ghi
// SGProjectRead + đóng modal khi thành công, hiển thị MessageBox khi lỗi.
// ======================================================================

interface Props {
  /** Điều khiển đóng mở modal */
  open?: boolean
  /** Dữ liệu dự án cần sửa (SGProjectRead) */
  project?: SGProjectRead | null
  /** Danh sách khách hàng để chọn (customer_id) */
  customerOptions?: SGSelectItem[]
}

const props = withDefaults(defineProps<Props>(), {
  open: false,
  project: null,
  customerOptions: () => []
})

const emit = defineEmits<{
  (event: 'close'): void
  // Phát ra sau khi cập nhật thành công — trang cha dùng để refresh danh sách.
  (event: 'saved', project: SGProjectRead): void
}>()

const toast = useToast()

// Trạng thái gọi API + hộp thoại báo lỗi.
const saving = ref(false)

const msgBox = reactive<MsgBoxOptions>({
  show: false,
  type: 'error',
  title: 'Lỗi',
  message: '',
  show_ok: true,
  show_cancel: false
})

function showError(message: string): void {
  msgBox.message = message
  msgBox.show = true
}

// --- Trạng thái form ---
// project_date giữ ở dạng 'YYYY-MM-DD' cho sg_input_date, khi lưu mới đổi sang ISO datetime.
interface ProjectForm {
  project_id: number
  project_code: string
  project_name: string
  project_date: string
  customer_id: number | null
  project_status: number
}

function emptyForm(): ProjectForm {
  return {
    project_id: 0,
    project_code: '',
    project_name: '',
    project_date: dayjs().format('YYYY-MM-DD'),
    customer_id: null,
    project_status: PROJECT_STATUS.DRAFT
  }
}

const form = reactive<ProjectForm>(emptyForm())

// Không cho phép chuyển trạng thái dự án về "Nháp".
// Chỉ giữ được "Nháp" nếu dự án vốn đã ở trạng thái này.
const canSelectDraft = computed<boolean>(
  () => props.project?.project_status === PROJECT_STATUS.DRAFT
)

type FieldKey = 'project_code' | 'project_name' | 'project_date' | 'customer_id'

const errors = reactive<Record<FieldKey, string>>({
  project_code: '',
  project_name: '',
  project_date: '',
  customer_id: ''
})

function clearErrors(): void {
  errors.project_code = ''
  errors.project_name = ''
  errors.project_date = ''
  errors.customer_id = ''
}

// Nạp lại dữ liệu dự án mỗi khi modal được mở lại.
watch(
  () => props.open,
  (isOpen) => {
    if (!isOpen) return

    const source = props.project
    if (source) {
      form.project_id = source.project_id
      form.project_code = source.project_code ?? ''
      form.project_name = source.project_name
      form.project_date =
        source.project_date && dayjs(source.project_date).isValid()
          ? dayjs(source.project_date).format('YYYY-MM-DD')
          : ''
      form.customer_id = source.customer_id
      form.project_status = source.project_status
    } else {
      Object.assign(form, emptyForm())
    }

    clearErrors()
  },
  { immediate: true }
)

// Người dùng vừa sửa ô nào thì xóa ngay báo lỗi của ô đó.
;(['project_code', 'project_name', 'project_date', 'customer_id'] as const).forEach((field) => {
  watch(
    () => form[field],
    () => {
      if (errors[field]) errors[field] = ''
    }
  )
})

function validate(): boolean {
  clearErrors()

  const code = form.project_code.trim()
  const name = form.project_name.trim()

  if (code.length > 50) errors.project_code = 'Mã dự án tối đa 50 ký tự.'

  if (!name) errors.project_name = 'Vui lòng nhập tên dự án.'
  else if (name.length > 100) errors.project_name = 'Tên dự án tối đa 100 ký tự.'

  if (!form.project_date || !dayjs(form.project_date).isValid())
    errors.project_date = 'Vui lòng chọn ngày dự án.'

  if (!form.customer_id) errors.customer_id = 'Vui lòng chọn khách hàng.'

  return !errors.project_code && !errors.project_name && !errors.project_date && !errors.customer_id
}

function onClose(): void {
  if (saving.value) return
  emit('close')
}

async function onSave(): Promise<void> {
  // 1. Kiểm tra dữ liệu hợp lệ
  if (!validate()) return
  if (saving.value) return

  // Chặn việc đưa trạng thái dự án về "Nháp".
  if (!canSelectDraft.value && form.project_status === PROJECT_STATUS.DRAFT) {
    showError('Không thể chuyển trạng thái dự án về "Nháp".')
    return
  }

  // SGProjectUpdate không cho phép sửa project_code (không có trong schema update).
  const payload: SGProjectUpdate = {
    project_name: form.project_name.trim(),
    project_date: dayjs(form.project_date).toISOString(),
    customer_id: form.customer_id as number,
    project_status: form.project_status
  }

  saving.value = true
  try {
    // 2. Gọi API sửa thông tin dự án
    const updated = await updateProject(form.project_id, payload)

    // 3. Thành công: Toast + emit bản ghi SGProjectRead + quay về "Danh sách dự án"
    toast.success('Cập nhật dự án thành công.')
    emit('saved', updated)
    emit('close')
  } catch (error) {
    // 4. Có lỗi: hiển thị MessageBox
    const message =
      error instanceof Error ? error.message : 'Không thể cập nhật dự án. Vui lòng thử lại.'
    showError(message)
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <div v-if="open" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
    <div class="flex max-h-full w-full max-w-lg flex-col rounded-xl bg-white shadow-xl">
      <!-- ============================================================ -->
      <!-- Header -->
      <!-- ============================================================ -->
      <header
        class="flex shrink-0 items-center justify-between gap-4 border-b border-gray-200 px-5 py-4"
      >
        <h1 class="sg-title-page">Sửa dự án</h1>

        <button type="button" class="sg-button-only-icon" title="Đóng" @click="onClose">
          <X class="h-5 w-5" />
        </button>
      </header>

      <!-- ============================================================ -->
      <!-- Nội dung -->
      <!-- ============================================================ -->
      <section class="min-h-0 flex-1 overflow-auto px-5 py-4">
        <div class="flex flex-col gap-4">
          <sg_input_text
            v-model="form.project_code"
            label="Mã dự án"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-1 sg-input w-full"
            placeholder="Mã dự án"
            :disabled="true"
            :error="errors.project_code"
          />

          <sg_input_text
            v-model="form.project_name"
            label="Tên dự án"
            label-c-s-s="sg-label-input"
            input-c-s-s="py-1 sg-input w-full"
            :required-input="true"
            placeholder="Nhập tên dự án"
            :error="errors.project_name"
          />

          <sg_input_date
            v-model="form.project_date"
            label="Ngày dự án"
            label-c-s-s="sg-label-input"
            :required-input="true"
            placeholder="Chọn ngày dự án"
            :error="errors.project_date"
          />

          <sg_select
            v-model="form.customer_id"
            label="Khách hàng"
            label-c-s-s="sg-label-input"
            :required-input="true"
            :items="customerOptions"
            :show-add="false"
            :show-edit="false"
            :show-delete="false"
            placeholder="Chọn khách hàng"
            :error="errors.customer_id"
          />

          <div class="flex gap-4 mt-6">
            <sg_radio
              v-model="form.project_status"
              :value="PROJECT_STATUS.DRAFT"
              :disabled="!canSelectDraft"
              label="Draft"
              name="status"
            />
            <sg_radio
              v-model="form.project_status"
              :value="PROJECT_STATUS.ACTIVE"
              :disabled="false"
              label="Active"
              name="status"
            />
            <sg_radio
              v-model="form.project_status"
              :value="PROJECT_STATUS.INACTIVE"
              :disabled="false"
              label="Inactive"
              name="status"
            />
          </div>

          <!-- <sg_select
            v-model="form.project_status"
            label="Trạng thái"
            label-c-s-s="sg-label-input"
            :items="PROJECT_STATUS_OPTIONS"
            :show-add="false"
            :show-edit="false"
            :show-delete="false"
            placeholder="Chọn trạng thái"
          /> -->
        </div>
      </section>

      <!-- ============================================================ -->
      <!-- Footer -->
      <!-- ============================================================ -->
      <footer
        class="flex shrink-0 items-center justify-end gap-3 border-t border-gray-200 px-5 py-4"
      >
        <button type="button" class="sg-button-secondary" :disabled="saving" @click="onClose">
          <Ban class="w-5 h-5" stroke-width="1" />Close
        </button>
        <button type="button" class="sg-button-primary" :disabled="saving" @click="onSave">
          <Save class="w-5 h-5" stroke-width="1" />{{ saving ? 'Đang lưu...' : 'Lưu' }}
        </button>
      </footer>
    </div>
  </div>

  <!-- Hộp thoại báo lỗi khi gọi API thất bại -->
  <sg_message_box
    :show="msgBox.show"
    :type="msgBox.type"
    :title="msgBox.title"
    :message="msgBox.message"
    :show_ok="msgBox.show_ok"
    :show_cancel="msgBox.show_cancel"
    @ok="msgBox.show = false"
    @cancel="msgBox.show = false"
  />
</template>

<style scoped></style>
