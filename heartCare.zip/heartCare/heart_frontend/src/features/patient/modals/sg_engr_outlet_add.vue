<script setup lang="ts">
import { computed, reactive, ref, watch } from 'vue'
import { X, Save, Ban } from 'lucide-vue-next'
import sg_input_text from '@/components/base/sg_input_text.vue'
import sg_input_number from '@/components/base/sg_input_number.vue'
import sg_radio from '@/components/base/sg_radio.vue'
import sg_message_box from '@/components/base/sg_message_box.vue'
import type { MsgBoxOptions } from '@/types/sg_msg_box.types'
import {
  DEFAULT_OUTLET_BACK_TEMP,
  DEFAULT_OUTLET_FLOW_RATE,
  DEFAULT_OUTLET_PRESSURE,
  OUTLET_CONTROL_MODE
} from '@/constants/sg_engr_outlet_const'
import { createOutlet, newSGOutletCreate } from '@/services/sg_outlet_srv'
import { roundDecimal } from '@/utils/sg_formatters'
import { useToast } from '@/utils/sg_use_toast'
import type { SGOutletCreate, SGOutletRead } from '@/types/sg_outlet'
import type { SGGeometryRead } from '@/types/sg_geometry'
import type { ObjFaceSelection } from '@/types/sg_face_type'

// ======================================================================
// Modal "Miệng xả" (OUTLET) — thêm mới điều kiện biên.
//   Header : tiêu đề bên trái, nút icon "Đóng" bên phải
//   Body   : Mã / Tên miệng xả, Chế độ vận hành (control_mode)
//            [1] Thông số áp suất & điều kiện nhiệt (pressure, back_temp)
//            [2] Lưu lượng hút cưỡng bức (flow_rate) — chỉ nhập khi chế độ Lưu lượng hút
//            [3] Xáo động dòng chạy ngược (turbulence)
//   Footer : nút "Đóng" và "Lưu" căn phải
// Nút "Lưu": validate -> gọi API createOutlet -> Toast + emit bản ghi SGOutletRead
// + đóng modal khi thành công, hiển thị MessageBox khi có lỗi.
// ======================================================================

interface Props {
  /** Điều khiển đóng mở modal */
  open?: boolean
  /** Tên bề mặt (patch) được chọn làm miệng xả */
  surfaceName?: string
  /** Khối hình học chứa miệng xả (lấy geometry_id) */
  geometry?: SGGeometryRead | null
  /** Mặt được chọn làm miệng xả — lấy tâm (pos_x/y/z) và kích thước (size_w/h) */
  face?: ObjFaceSelection | null
}

const props = withDefaults(defineProps<Props>(), {
  open: false,
  surfaceName: '',
  geometry: null,
  face: null
})

// Kích thước (rộng, cao) của mặt theo 2 trục nằm trong mặt phẳng của nó. Mặt ⊥ X giữ
// quy ước của viewer: rộng theo Y, cao theo Z. Mặt nghiêng ('—') lấy theo mặt ⊥ X.
function faceSize(face: ObjFaceSelection): { w: number; h: number } {
  const dx = face.max.x - face.min.x
  const dy = face.max.y - face.min.y
  const dz = face.max.z - face.min.z
  if (face.axis === 'Y') return { w: dx, h: dz }
  if (face.axis === 'Z') return { w: dx, h: dy }
  return { w: dy, h: dz }
}

const emit = defineEmits<{
  (event: 'close'): void
  // Phát ra sau khi tạo outlet thành công — trang cha dùng để cập nhật danh sách.
  (event: 'saved', outlet: SGOutletRead): void
}>()

const toast = useToast()

// Trạng thái gọi API lưu outlet.
const saving = ref(false)

// Hộp thoại báo lỗi (thiếu khối hình học / lỗi lưu).
const msgBox = reactive<MsgBoxOptions>({
  show: false,
  type: 'error',
  title: 'Lỗi',
  message: '',
  show_ok: true,
  show_cancel: false
})

function showError(message: string): void {
  msgBox.message = message
  msgBox.show = true
}

// Hiển thị số theo định dạng '0.0' như bản thiết kế.
const NUMBER_LOCALE = 'en-US'

const SECTION_TITLE_CSS = 'text-sm font-semibold uppercase tracking-wide text-pmis-lightlabel'
const ROW_CSS = 'grid grid-cols-1 items-start gap-1 sm:grid-cols-[minmax(0,240px)_1fr] sm:gap-4'
const ROW_LABEL_CSS = 'text-[15px] text-pmis-label sm:pt-1.5'
const NUMBER_INPUT_CSS = 'py-1 sg-input w-32 text-right'
const UNIT_CSS = 'pt-1.5 text-sm text-slate-600'

const CONTROL_MODE_OPTIONS = [
  { value: OUTLET_CONTROL_MODE.PRESSURE_OUTLET, label: 'Áp suất cố định (Fixed Pressure)' },
  { value: OUTLET_CONTROL_MODE.FLOW_RATE, label: 'Lưu lượng hút (Fixed Flow Rate)' }
]

// --- Trạng thái form ---
function defaultForm(): SGOutletCreate {
  return {
    ...newSGOutletCreate(),
    outlet_code: '',
    outlet_name: props.surfaceName,
    geometry_id: props.geometry?.geometry_id ?? 0,
    control_mode: OUTLET_CONTROL_MODE.PRESSURE_OUTLET,
    pressure: DEFAULT_OUTLET_PRESSURE,
    back_temp: DEFAULT_OUTLET_BACK_TEMP,
    flow_rate: DEFAULT_OUTLET_FLOW_RATE,
    turbulence: 5
  }
}

const form = reactive<SGOutletCreate>(defaultForm())

type FieldKey = 'outlet_code' | 'outlet_name' | 'flow_rate' | 'turbulence'

const errors = reactive<Record<FieldKey, string>>({
  outlet_code: '',
  outlet_name: '',
  flow_rate: '',
  turbulence: ''
})

function clearErrors(): void {
  errors.outlet_code = ''
  errors.outlet_name = ''
  errors.flow_rate = ''
  errors.turbulence = ''
}

// Nạp lại giá trị mặc định mỗi khi modal được mở lại.
watch(
  () => props.open,
  (isOpen) => {
    if (!isOpen) return
    Object.assign(form, defaultForm())
    clearErrors()
  },
  { immediate: true }
)

// Người dùng vừa sửa ô nào thì xóa ngay báo lỗi của ô đó.
;(['outlet_code', 'outlet_name', 'flow_rate', 'turbulence'] as const).forEach((field) => {
  watch(
    () => form[field],
    () => {
      if (errors[field]) errors[field] = ''
    }
  )
})
watch(
  () => form.control_mode,
  () => {
    if (errors.flow_rate) errors.flow_rate = ''
  }
)

const isPressureOutlet = computed(() => form.control_mode === OUTLET_CONTROL_MODE.PRESSURE_OUTLET)
const isFlowRate = computed(() => form.control_mode === OUTLET_CONTROL_MODE.FLOW_RATE)

function validate(): boolean {
  clearErrors()

  if (form.outlet_code.trim().length > 30) errors.outlet_code = 'Mã miệng xả tối đa 30 ký tự.'

  if ((form.outlet_name?.trim().length ?? 0) > 100)
    errors.outlet_name = 'Tên miệng xả tối đa 100 ký tự.'

  if (isFlowRate.value && !(form.flow_rate > 0))
    errors.flow_rate = 'Lưu lượng hút yêu cầu phải lớn hơn 0.'

  if (!(form.turbulence > 0) || form.turbulence > 100)
    errors.turbulence = 'Cường độ xáo động phải nằm trong khoảng (0 -> 100] %.'

  return !Object.values(errors).some(Boolean)
}

function onClose(): void {
  if (saving.value) return
  emit('close')
}

async function onSave(): Promise<void> {
  if (saving.value) return
  if (!props.geometry) {
    showError('Chưa chọn khối hình học cho miệng xả.')
    return
  }
  if (!props.face) {
    showError('Chưa chọn mặt cho miệng xả.')
    return
  }
  // 1. Kiểm tra dữ liệu hợp lệ
  if (!validate()) return

  // Miệng xả phủ toàn bộ mặt được chọn: tâm = tâm mặt, kích thước = kích thước mặt.
  const center = props.face.planeCenter
  const size = faceSize(props.face)

  // Backend lưu Decimal(…, 2) -> làm tròn các trường số thực trước khi gửi.
  const payload: SGOutletCreate = {
    ...form,
    outlet_code: form.outlet_code.trim(),
    outlet_name: form.outlet_name?.trim() || null,
    geometry_id: props.geometry.geometry_id,
    pressure: roundDecimal(form.pressure),
    back_temp: roundDecimal(form.back_temp),
    flow_rate: roundDecimal(form.flow_rate),
    turbulence: roundDecimal(form.turbulence),
    pos_x: roundDecimal(center.x),
    pos_y: roundDecimal(center.y),
    pos_z: roundDecimal(center.z),
    size_w: roundDecimal(size.w),
    size_h: roundDecimal(size.h)
  }

  saving.value = true
  try {
    // 2. Gọi API lưu vào DB
    const created = await createOutlet(payload)

    // 3. Thành công: Toast + đóng modal
    toast.success('Thêm mới miệng xả thành công.')
    emit('saved', created)
    emit('close')
  } catch (error) {
    // 4. Có lỗi: hiển thị MessageBox
    const message =
      error instanceof Error ? error.message : 'Không thể lưu miệng xả. Vui lòng thử lại.'
    showError(message)
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <div v-if="open" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
    <div class="flex max-h-full w-full max-w-2xl flex-col rounded-xl bg-white shadow-xl">
      <!-- ============================================================ -->
      <!-- Header -->
      <!-- ============================================================ -->
      <header
        class="flex shrink-0 items-center justify-between gap-4 border-b border-gray-200 px-5 py-4"
      >
        <h1 class="sg-title-page">Miệng xả</h1>

        <button type="button" class="sg-button-only-icon" title="Đóng" @click="onClose">
          <X class="h-5 w-5" />
        </button>
      </header>

      <!-- ============================================================ -->
      <!-- Nội dung -->
      <!-- ============================================================ -->
      <section class="outlet-add-scroll min-h-0 flex-1 overflow-auto px-5 py-4">
        <div class="flex flex-col gap-3">
          <div :class="ROW_CSS">
            <span :class="ROW_LABEL_CSS">Mã miệng xả</span>
            <sg_input_text
              v-model="form.outlet_code"
              input-c-s-s="py-1 sg-input w-full"
              :error="errors.outlet_code"
            />
          </div>

          <div :class="ROW_CSS">
            <span :class="ROW_LABEL_CSS">Tên miệng xả</span>
            <sg_input_text
              v-model="form.outlet_name"
              input-c-s-s="py-1 sg-input w-full"
              :error="errors.outlet_name"
            />
          </div>

          <div :class="ROW_CSS">
            <span :class="ROW_LABEL_CSS">Chế độ vận hành</span>
            <div class="flex flex-col gap-2 sm:pt-1.5">
              <sg_radio
                v-for="option in CONTROL_MODE_OPTIONS"
                :key="option.value"
                v-model="form.control_mode"
                :value="option.value"
                :label="option.label"
                name="outlet_add_control_mode"
              />
            </div>
          </div>

          <!-- [1] Thông số áp suất & điều kiện nhiệt -->
          <fieldset class="flex flex-col gap-3">
            <legend :class="SECTION_TITLE_CSS" class="mb-3 flex w-full items-center gap-3">
              <span class="shrink-0">Thông số áp suất &amp; điều kiện nhiệt</span>
              <span class="h-px flex-1 bg-pmis-bordertab" />
            </legend>

            <div :class="ROW_CSS">
              <span :class="ROW_LABEL_CSS">Áp suất tĩnh (Gauge Pressure)</span>
              <div class="flex items-start gap-2">
                <sg_input_number
                  v-model="form.pressure"
                  :input-c-s-s="NUMBER_INPUT_CSS"
                  :decimal="1"
                  :locale="NUMBER_LOCALE"
                  :disabled="!isPressureOutlet"
                />
                <span :class="UNIT_CSS">Pa</span>
              </div>
            </div>

            <div :class="ROW_CSS">
              <span :class="ROW_LABEL_CSS">Nhiệt độ dòng ngược (Inflow T)</span>
              <div class="flex items-start gap-2">
                <sg_input_number
                  v-model="form.back_temp"
                  :input-c-s-s="NUMBER_INPUT_CSS"
                  :decimal="1"
                  :locale="NUMBER_LOCALE"
                />
                <span :class="UNIT_CSS">°C</span>
              </div>
            </div>
          </fieldset>

          <!-- [2] Lưu lượng hút cưỡng bức — chỉ nhập khi chế độ "Lưu lượng hút" -->
          <fieldset class="flex flex-col gap-3">
            <legend :class="SECTION_TITLE_CSS" class="mb-3 flex w-full items-center gap-3">
              <span class="shrink-0">Lưu lượng hút cưỡng bức</span>
              <span class="h-px flex-1 bg-pmis-bordertab" />
            </legend>

            <div :class="ROW_CSS">
              <span :class="ROW_LABEL_CSS">Lưu lượng hút yêu cầu</span>
              <div class="flex items-start gap-2">
                <sg_input_number
                  v-model="form.flow_rate"
                  :input-c-s-s="NUMBER_INPUT_CSS"
                  :decimal="1"
                  :min="0"
                  :locale="NUMBER_LOCALE"
                  :disabled="!isFlowRate"
                  :error="errors.flow_rate"
                />
                <span :class="UNIT_CSS">m³/h</span>
              </div>
            </div>
          </fieldset>

          <!-- [3] Xáo động dòng chạy ngược -->
          <fieldset class="flex flex-col gap-3">
            <legend :class="SECTION_TITLE_CSS" class="mb-3 flex w-full items-center gap-3">
              <span class="shrink-0">Xáo động dòng chạy ngược</span>
              <span class="h-px flex-1 bg-pmis-bordertab" />
            </legend>

            <div :class="ROW_CSS">
              <span :class="ROW_LABEL_CSS">Cường độ xáo động (Intensity)</span>
              <div class="flex items-start gap-2">
                <sg_input_number
                  v-model="form.turbulence"
                  :input-c-s-s="NUMBER_INPUT_CSS"
                  :decimal="1"
                  :min="0"
                  :max="100"
                  :locale="NUMBER_LOCALE"
                  :error="errors.turbulence"
                />
                <span :class="UNIT_CSS">%</span>
              </div>
            </div>
          </fieldset>
        </div>
      </section>

      <!-- ============================================================ -->
      <!-- Footer -->
      <!-- ============================================================ -->
      <footer
        class="flex shrink-0 items-center justify-end gap-3 border-t border-gray-200 px-5 py-4"
      >
        <button type="button" class="sg-button-secondary" :disabled="saving" @click="onClose">
          <Ban class="w-5 h-5" stroke-width="1" />Đóng
        </button>
        <button type="button" class="sg-button-primary" :disabled="saving" @click="onSave">
          <Save class="w-5 h-5" stroke-width="1" />{{ saving ? 'Đang lưu...' : 'Lưu' }}
        </button>
      </footer>
    </div>

    <sg_message_box
      :show="msgBox.show"
      :type="msgBox.type"
      :title="msgBox.title"
      :message="msgBox.message"
      :show_ok="msgBox.show_ok"
      :show_cancel="msgBox.show_cancel"
      @ok="msgBox.show = false"
      @cancel="msgBox.show = false"
    />
  </div>
</template>

<style scoped>
/* Thanh cuộn mảnh (~5px), chỉ hiện khi hover vùng nội dung — giống sg_engr_inlet_add.vue. */
@supports not selector(::-webkit-scrollbar) {
  .outlet-add-scroll {
    scrollbar-width: thin;
    scrollbar-color: transparent transparent;
  }

  .outlet-add-scroll:hover {
    scrollbar-color: rgb(203 213 225) transparent; /* slate-300 */
  }
}

.outlet-add-scroll::-webkit-scrollbar {
  width: 5px;
  height: 5px;
}

.outlet-add-scroll::-webkit-scrollbar-track {
  background: transparent;
}

.outlet-add-scroll::-webkit-scrollbar-thumb {
  background-color: transparent;
  border-radius: 9999px;
}

.outlet-add-scroll:hover::-webkit-scrollbar-thumb {
  background-color: rgb(203 213 225); /* slate-300 */
}

.outlet-add-scroll:hover::-webkit-scrollbar-thumb:hover {
  background-color: rgb(148 163 184); /* slate-400 */
}
</style>
