// types/sg_fo_common.ts

export interface KpiStat {
  label: string
  value: string | number
  change?: string
  type: 'info' | 'success' | 'warning' | 'danger'
}

export interface RoomStatusSummary {
  vacant: number
  occupied: number
  dirty: number
  clean: number
  ready: number
  outOfOrder: number
}

export interface ApprovalRequest {
  id: string
  type: 'Cancel' | 'LateCheckOut' | 'EarlyCheckIn' | 'Upgrade' | 'Refund'
  guestName: string
  roomNo?: string
  details: string
  createdAt: string
}

export interface AlertNotification {
  id: string
  level: 'warning' | 'danger' | 'info'
  message: string
  time: string
}
