# CLAUDE.md — Engineer actor

Guidance for Claude Code when working on the **Engineer** actor. This is the actor currently under active development. See the root [CLAUDE.md](../../../CLAUDE.md) for stack-wide conventions (routing pattern, naming conventions, API client, i18n, state) — this file only covers what's specific to Engineer.

## Location

**All pages/components for the Engineer actor live under `src/features/engineer/`**, with subfolders `pages/`, `components/`, `modals/`, `types/`, `constants/` (currently empty), `services/` (currently empty). Its route shell is `pages/sg_engr_main.vue`, mounted at `/engineer` in `src/router/index.ts`.

## Routing

## Pages that exist but aren't routed yet

## Naming inconsistency: `components/` and `modals/` use `fo_` prefix

Unlike `pages/` (consistently `sg_engr_*.vue`), files under `engineer/components/` and `engineer/modals/` still carry the **`sg_engr_*` prefix** (e.g. `components/sg_engr_booking_table.vue`, `modals/sg_engr_checkout.vue`, `modals/sg_engr_cust_form.vue`). This is leftover from Engineer being derived from the Front Office module, not a typo — don't rename them reflexively, but prefer `sg_engr_*` for any _new_ component/modal you add here.

## Data & types

## Simulation result viewing

How the simulation page (`pages/sg_engr_simulation.vue`) displays CFD result models stored on S3 (MinIO) after a simulation job finishes. This is the agreed design across three systems.

Frontend implementation: in the "Kết quả" step, selecting a geometry calls `getJobsByGeometry` → picks the newest `JOB_STATUS.SUCCESS` job (`src/constants/sg_engr_job_const.ts`) → `getJobResults(job_id)` in `src/services/sg_job_srv.ts` → renders `components/sg_engr_result_viewer.vue`. Manifest types are `SGJobResultsRead` / `SGResultManifest` in `src/types/sg_job.ts`, matching `app/postprocessing/sg_web_exporter.py` in `hvac_openfoam_v1_1` (manifest `version: 1`; fields are `T`, `U`, `U_mag`, `p_rgh`, `p`, each with a global `range`; there are no PMV/PPD values in it yet).

### 1. OpenFOAM server — emits a lightweight web bundle as loose files

`post-processing.tar.gz` is kept unchanged (archive/download). After `foamToVTK`, a PyVista step extracts surfaces (what browsers render well) and uploads them as separate files:

```
openfoam/{project}/{geometry}/{job_id}/
├── post-processing.tar.gz          (unchanged, for download)
└── web/
    ├── manifest.json               ← frontend reads this first
    ├── surfaces/walls.vtp          (walls/floor/ceiling, with T and p_rgh)
    ├── slices/slice_z1.5.vtp       (horizontal slice z=1.5m, with T, |U|, U)
    ├── slices/slice_x_mid.vtp      (vertical slice through room centre)
    ├── streamlines/inlets.vtp      (streamlines seeded from supply inlets)
    └── images/slice_z_1.50m_T.png  (existing 2D image — thumbnail or fallback)
```

- Data is float32 with zlib compression (readable by vtk.js), optionally decimated; each file is typically a few hundred KB to a few MB.
- `manifest.json` contains: the layer list, relative paths, fields available per layer, **min/max per field** (so the frontend builds one consistent color scale across layers), room bounds, units, `latestTime`, and PMV/PPD comfort indices.
- Files are uploaded with proper `ContentType` (`application/json`, `image/png`, `application/octet-stream`).

### 2. Gateway (`hvac_fastapi_v1_1`) — presigned URLs

- Endpoint `GET /api/v1/jobs/{job_id}/results`: checks the user's access to the project, reads the manifest, and returns the manifest plus a **presigned GET URL (TTL ~30–60 min) per file**.
- The bucket stays private; the browser never holds S3 keys. Presigned URLs expire, so re-call the endpoint rather than caching URLs long-term.
- MinIO bucket CORS allows the frontend origin for `GET`/`HEAD` and exposes `Content-Length` and `ETag`.

### 3. Frontend — rendering with vtk.js

- **3D**: `@kitware/vtk.js` — `vtkXMLPolyDataReader` to read `.vtp`, `vtkColorTransferFunction` to color by the selected field (`T` / `|U|` / `p_rgh`) using the manifest's min/max. UI provides layer toggles (walls, slices, streamlines) and an opacity slider for walls.
- **2D**: show PNGs with a plain `<img>` pointing at the presigned URL.
- Fetch presigned files directly (not through the shared axios clients — they'd attach the `Authorization` header, which S3 presigned requests must not carry).
