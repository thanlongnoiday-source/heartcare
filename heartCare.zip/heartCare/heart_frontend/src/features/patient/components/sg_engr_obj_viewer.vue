<script setup lang="ts">
import { onBeforeUnmount, onMounted, ref, watch, type Component } from 'vue'
import * as THREE from 'three'
import { OBJLoader } from 'three/examples/jsm/loaders/OBJLoader.js'
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import { Axis3d, Box, BrickWall, Hand, Loader2, LogIn, LogOut, Rotate3d } from 'lucide-vue-next'
import type {
  FaceEditKind,
  InletBlock,
  OutletBlock,
  ObjFaceSelection,
  GeometryPartKind
} from '@/types/sg_face_type'

// Trình xem file hình học .obj bằng three.js — nhận URL tuyệt đối của file OBJ,
// nạp bằng OBJLoader (gộp mọi mesh trong file thành một BufferGeometry duy nhất)
// và render dạng KHUNG DÂY (wireframe) trong <canvas> WebGL
// với OrbitControls (xoay/zoom/pan). Camera tự căn bao trọn bounding box sau mỗi lần nạp.
//
// Hai kiểu chiếu, chuyển bằng nút trên viewport (projectionMode):
//   - Phối cảnh (PerspectiveCamera, mặc định): gần to, xa nhỏ như mắt nhìn thật ->
//     không bị ảo giác "cạnh xa trông to hơn" của khung dây chiếu song song.
//   - Trực giao (OrthographicCamera): mọi cạnh giữ đúng tỉ lệ kích thước dù gần hay
//     xa; khi PAN mô hình chỉ trượt phẳng, không có parallax.
// Thao tác KÉO không dùng pan của OrbitControls (pan đó dời camera -> ở phối cảnh,
// mô hình lộ ra mặt khác như thể bị xoay). Thay vào đó kéo chỉ dịch ẢNH render trên
// màn hình (camera.setViewOffset): vị trí + hướng camera giữ nguyên nên mô hình
// trượt đi mà hình dạng y hệt, ở cả hai kiểu chiếu.
// Muốn đổi góc thì xoay (chuột trái) — tách bạch hoàn toàn với thao tác kéo.
const props = defineProps<{
  src: string
  // Các miệng cấp (inlet) hiển thị dạng khối trên mô hình.
  inlets?: InletBlock[]
  // Id miệng cấp đang được chọn (để tô đậm).
  selectedInletId?: number | null
  // Các Miệng xả (outlet) hiển thị dạng khối trên mô hình.
  outlets?: OutletBlock[]
  // Id Miệng xả đang được chọn (để tô đậm).
  selectedOutletId?: number | null
}>()

const emit = defineEmits<{
  'face-select': [selection: ObjFaceSelection | null]
  // Bấm một lệnh trong menu con nổi cạnh mặt đang chọn (Edit Inlet/Outlet/Wall).
  'face-edit': [selection: ObjFaceSelection, kind: FaceEditKind]
  'inlet-select': [id: number | null]
  'outlet-select': [id: number | null]
}>()

const containerRef = ref<HTMLDivElement | null>(null)
const editIconRef = ref<HTMLDivElement | null>(null)
const isLoading = ref(false)
const errorMessage = ref<string | null>(null)

// Mặt phẳng đang được chọn trên khối — dùng để hiển thị badge tóm tắt trong
// viewport. Payload đầy đủ (toạ độ, pháp tuyến...) được phát ra ngoài qua `face-select`.
const selectedFace = ref<{
  axis: 'X' | 'Y' | 'Z' | '—'
  area: number
  size: { x: number; y: number; z: number }
} | null>(null)

// Chế độ kéo (pan): khi bật, giữ chuột trái để dịch chuyển mô hình trong khung nhìn
// — hữu ích khi mô hình lớn hơn khung, cần xem phần đang bị tràn ra ngoài.
// Khi tắt, chuột trái xoay như bình thường (chuột phải luôn kéo được).
const panMode = ref(false)

// Kiểu chiếu đang dùng (xem chú thích đầu file).
const projectionMode = ref<'perspective' | 'orthographic'>('perspective')

// Kích thước bounding box của hình học vừa nạp theo từng trục (đơn vị file OBJ, m).
// Dùng để đối chiếu Dài/Rộng/Cao đã nhập với trục X/Y/Z thực tế backend sinh ra.
const dimensions = ref<{ x: number; y: number; z: number } | null>(null)

// Giữ ngoài reactivity của Vue: các đối tượng three.js đồ sộ, không cần theo dõi sâu.
let renderer: THREE.WebGLRenderer | null = null
let scene: THREE.Scene | null = null
// Tạo sẵn cả hai camera; `camera` trỏ tới camera đang dùng theo projectionMode.
let orthoCamera: THREE.OrthographicCamera | null = null
let perspCamera: THREE.PerspectiveCamera | null = null
let camera: THREE.OrthographicCamera | THREE.PerspectiveCamera | null = null
let controls: OrbitControls | null = null

// Khối miệng cấp / miệng xả: mỗi khối là 1 hộp mờ + viền + nhãn tên. Map id -> bản ghi.
interface PartEntry {
  box: THREE.Mesh
  boxMat: THREE.MeshBasicMaterial
  edges: THREE.LineSegments
  edgeMat: THREE.LineBasicMaterial
  label: THREE.Mesh
  labelMat: THREE.MeshBasicMaterial
  labelTexture: THREE.CanvasTexture
  labelText: string
  labelAspect: number
  sizeSig: string
}

// Khối miệng cấp (inlet): khoá Map là inlet_id (number).
const inletObjects = new Map<number, PartEntry>()

// Bề dày (m) khối miệng cấp hiển thị theo trục X — chỉ phục vụ dựng khối/bắt chọn
// trên mô hình 3D, không phải trường dữ liệu của inlet (inlet chỉ có size_w/size_h).
const INLET_VIEW_DEPTH = 0.1

// Khối Miệng xả (outlet): cùng cơ chế với inletObjects, chỉ khác nguồn dữ liệu
// (props.outlets thay vì props.inlets) và khoá Map là outlet_id (number).
const outletObjects = new Map<number, PartEntry>()

// Bề dày (m) khối Miệng xả hiển thị theo trục X — chỉ phục vụ dựng khối/bắt chọn
// trên mô hình 3D, không phải trường dữ liệu của outlet (outlet chỉ có size_w/size_h).
const OUTLET_VIEW_DEPTH = 0.1

// Hộp bao mô hình vừa nạp (tâm + kích thước, m) — cha dùng để đặt miệng cấp/xả mặc định.
let modelBounds: { center: THREE.Vector3; size: THREE.Vector3 } | null = null

const PART_COLOR: Record<GeometryPartKind, number> = {
  supply: 0x2563eb,
  return: 0xf59e0b,
  obstacle: 0x64748b
}

// Chiều cao (đơn vị thế giới, m) mà khung nhìn ortho bao phủ ở zoom = 1.
// frameGeometry() đặt lại theo bounding sphere; handleResize() dựa vào nó để
// tính lại left/right/top/bottom khi khung đổi tỉ lệ.
let viewSize = 10
// Góc nhìn dọc (độ) của camera phối cảnh.
const PERSP_FOV = 45
// Khoảng cách camera ortho tới tâm quay — chỉ ảnh hưởng near/far, không đổi tỉ lệ.
let orthoDist = 24
let wireframe: THREE.LineSegments | null = null
let grid: THREE.GridHelper | null = null

// Hệ trục tọa độ theo quy ước OpenFOAM: hệ Descartes THUẬN TAY PHẢI, gốc O tại
// góc phòng (0,0,0), phòng nằm trong khối (0..L, 0..W, 0..H):
//   X — dọc chiều DÀI phòng      (0 → L), hướng sang phải nàm hình
//   Y — ngang chiều RỘNG phòng   (0 → W), hướng ra sau nàm hình
//   Z — chiều CAO, thẳng đứng    (0 → H), hướng lên nàm hình
// three.js cũng là hệ thuận tay phải nên toạ độ file OBJ giữ nguyên, không lật trục.
const AXIS_COLOR = { x: 0xef4444, y: 0x22c55e, z: 0x2563eb } // red-500 / green-500 / blue-600
let axesGroup: THREE.Group | null = null
let axisArrows: { x: THREE.ArrowHelper; y: THREE.ArrowHelper; z: THREE.ArrowHelper } | null = null
let axisLabels: { x: THREE.Sprite; y: THREE.Sprite; z: THREE.Sprite } | null = null
const axisLabelTextures: THREE.CanvasTexture[] = []
let frameId = 0
let resizeObserver: ResizeObserver | null = null

let modelGeometry: THREE.BufferGeometry | null = null
let solid: THREE.Mesh | null = null

// Lớp phủ mặt đang chọn: mảng tam giác tô mờ + đường viền cạnh.
let faceFill: THREE.Mesh | null = null
let faceEdges: THREE.LineSegments | null = null

// 8 đỉnh hộp bao (toạ độ thế giới) của mặt đang chọn — mỗi khung hình chiếu xuống
// màn hình để đặt nút "Sửa" ở góc trên-phải của mặt (bám theo khi xoay/zoom/kéo).
let faceCorners: THREE.Vector3[] | null = null
// Payload `face-select` gần nhất — phát lại kèm sự kiện `face-edit` khi bấm nút "Sửa".
let lastFaceSelection: ObjFaceSelection | null = null
const projected = new THREE.Vector3()

// Kích thước (px) mỗi icon trong menu con nổi cạnh mặt đang chọn + khoảng cách tới góc mặt.
const EDIT_ICON_SIZE = 28
const EDIT_ICON_GAP = 4

// Các lệnh trong menu con nổi cạnh mặt đang chọn.
const FACE_EDIT_COMMANDS: { kind: FaceEditKind; title: string; icon: Component }[] = [
  { kind: 'inlet', title: 'Edit Inlet', icon: LogIn },
  { kind: 'outlet', title: 'Edit Outlet', icon: LogOut },
  { kind: 'wall', title: 'Edit Wall', icon: BrickWall }
]

// Material dùng lại giữa các lần nạp — chỉ dispose khi hủy component.
let wireMat: THREE.LineBasicMaterial | null = null
let solidMat: THREE.MeshBasicMaterial | null = null
let faceFillMat: THREE.MeshBasicMaterial | null = null
let faceEdgeMat: THREE.LineBasicMaterial | null = null

const raycaster = new THREE.Raycaster()
const pointerNdc = new THREE.Vector2()
let pointerDownX = 0
let pointerDownY = 0

// Độ dịch (px) của ảnh render so với khung nhìn — do thao tác kéo tạo ra.
const panOffset = { x: 0, y: 0 }
let isPanning = false
let panLastX = 0
let panLastY = 0

let isDisposed = false
// Mỗi lần loadObj tăng token -> bỏ qua kết quả của lần nạp cũ về muộn (vd: URL hết
// hạn lỗi 403 về sau khi URL mới đã nạp xong, làm hiện nhầm thông báo lỗi).
let loadToken = 0

function makeAxisSprite(text: string, hex: number): THREE.Sprite {
  const s = 128
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = s
  const ctx = canvas.getContext('2d') as CanvasRenderingContext2D
  ctx.font = '700 88px system-ui, -apple-system, "Segoe UI", sans-serif'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillStyle = `#${hex.toString(16).padStart(6, '0')}`
  ctx.fillText(text, s / 2, s / 2 + 4)

  const texture = new THREE.CanvasTexture(canvas)
  texture.colorSpace = THREE.SRGBColorSpace
  axisLabelTextures.push(texture)
  const sprite = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: texture,
      transparent: true,
      depthTest: false,
      depthWrite: false
    })
  )
  sprite.renderOrder = 6
  return sprite
}

function initScene(): void {
  const container = containerRef.value
  if (!container) return

  const width = container.clientWidth || 1
  const height = container.clientHeight || 1

  scene = new THREE.Scene()
  // scene.background = new THREE.Color(0xf1f5f9) // slate-100
  scene.background = new THREE.Color(0xffffff) // white

  const aspect = width / height
  orthoCamera = new THREE.OrthographicCamera(
    (-viewSize * aspect) / 2,
    (viewSize * aspect) / 2,
    viewSize / 2,
    -viewSize / 2,
    0.01,
    5000
  )
  perspCamera = new THREE.PerspectiveCamera(PERSP_FOV, aspect, 0.01, 5000)
  // Quy ước OpenFOAM: trục Z thẳng đứng hướng lên (đối dấu véc-tơ trọng lực). Đặt
  // "up" của camera thành +Z để lần hiển thị đầu tiên (và cả khi orbit) Z luôn là
  // phương đứng.
  for (const cam of [orthoCamera, perspCamera]) {
    cam.up.set(0, 0, 1)
    cam.position.set(6, -6, 4)
  }
  camera = projectionMode.value === 'perspective' ? perspCamera : orthoCamera

  renderer = new THREE.WebGLRenderer({ antialias: true })
  renderer.setPixelRatio(window.devicePixelRatio)
  renderer.setSize(width, height)
  container.appendChild(renderer.domElement)

  renderer.domElement.addEventListener('pointerdown', onPointerDown)
  renderer.domElement.addEventListener('pointermove', onPointerMove)
  renderer.domElement.addEventListener('pointerup', onPointerUp)
  renderer.domElement.addEventListener('pointercancel', onPointerCancel)

  wireMat = new THREE.LineBasicMaterial({ color: 0x1e3a8a })
  // Vô hình nhưng vẫn raycast được; DoubleSide để bắt cả khi camera nằm trong khối.
  solidMat = new THREE.MeshBasicMaterial({ visible: false, side: THREE.DoubleSide })
  faceFillMat = new THREE.MeshBasicMaterial({
    color: 0x2563eb,
    transparent: true,
    opacity: 0.28,
    side: THREE.DoubleSide,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1
  })
  faceEdgeMat = new THREE.LineBasicMaterial({ color: 0x1d4ed8 })

  controls = new OrbitControls(camera, renderer.domElement)
  controls.enableDamping = true

  // Tắt pan của OrbitControls — kéo do onPointerMove xử lý (xem chú thích đầu file).
  controls.enablePan = false
  controls.mouseButtons = {
    LEFT: THREE.MOUSE.ROTATE,
    MIDDLE: THREE.MOUSE.DOLLY,
    RIGHT: THREE.MOUSE.PAN
  }
  controls.touches = {
    ONE: THREE.TOUCH.ROTATE,
    TWO: THREE.TOUCH.DOLLY_PAN
  }
  applyPanMode()

  // Khung dây không cần chiếu sáng (LineBasicMaterial không phản ứng với đèn).
  // GridHelper mặc định nằm trong mặt XZ (Y-up) -> xoay về mặt sàn XY để khớp Z-up.
  grid = new THREE.GridHelper(10, 10, 0xcbd5e1, 0xe2e8f0)
  grid.rotation.x = Math.PI / 2
  scene.add(grid)

  // Hệ trục OpenFOAM (thuận tay phải) tại gốc O: X = đỏ, Y = xanh lá, Z = xanh dương.
  // Mỗi trục là một mũi tên + nhãn chữ ở đầu mút; độ dài scale theo bounding box
  // của hình học trong frameGeometry() để trục luôn nhô nhẹ khỏi khối.
  axesGroup = new THREE.Group()
  const origin = new THREE.Vector3(0, 0, 0)
  axisArrows = {
    x: new THREE.ArrowHelper(new THREE.Vector3(1, 0, 0), origin, 1, AXIS_COLOR.x),
    y: new THREE.ArrowHelper(new THREE.Vector3(0, 1, 0), origin, 1, AXIS_COLOR.y),
    z: new THREE.ArrowHelper(new THREE.Vector3(0, 0, 1), origin, 1, AXIS_COLOR.z)
  }
  axisLabels = {
    x: makeAxisSprite('X', AXIS_COLOR.x),
    y: makeAxisSprite('Y', AXIS_COLOR.y),
    z: makeAxisSprite('Z', AXIS_COLOR.z)
  }
  axesGroup.add(axisArrows.x, axisArrows.y, axisArrows.z, axisLabels.x, axisLabels.y, axisLabels.z)
  scene.add(axesGroup)

  resizeObserver = new ResizeObserver(handleResize)
  resizeObserver.observe(container)

  animate()
}

// Gán nút chuột trái / chạm một ngón theo panMode: kéo hoặc xoay. Với enablePan =
// false, trạng thái PAN của OrbitControls không làm gì — chỉ để chuột trái không xoay.
function applyPanMode(): void {
  if (!controls) return
  controls.mouseButtons.LEFT = panMode.value ? THREE.MOUSE.PAN : THREE.MOUSE.ROTATE
  controls.touches.ONE = panMode.value ? THREE.TOUCH.PAN : THREE.TOUCH.ROTATE
}

function togglePanMode(): void {
  panMode.value = !panMode.value
  applyPanMode()
}

// Chuyển phối cảnh <-> trực giao, giữ nguyên tâm quay, hướng nhìn và độ lớn mô hình
// tại tâm quay (chiều cao thế giới mà khung nhìn bao phủ ở khoảng cách target).
function toggleProjection(): void {
  if (!camera || !controls || !orthoCamera || !perspCamera) return
  const target = controls.target
  const dir = new THREE.Vector3().subVectors(camera.position, target).normalize()
  const halfTan = Math.tan(THREE.MathUtils.degToRad(PERSP_FOV / 2))

  if (projectionMode.value === 'perspective') {
    const visibleHeight = 2 * perspCamera.position.distanceTo(target) * halfTan
    orthoCamera.zoom = viewSize / visibleHeight
    orthoCamera.position.copy(target).addScaledVector(dir, orthoDist)
    camera = orthoCamera
    projectionMode.value = 'orthographic'
  } else {
    const visibleHeight = viewSize / orthoCamera.zoom
    perspCamera.position.copy(target).addScaledVector(dir, visibleHeight / 2 / halfTan)
    camera = perspCamera
    projectionMode.value = 'perspective'
  }

  camera.updateProjectionMatrix()
  controls.object = camera
  controls.update()
}

// Áp panOffset lên cả hai camera (giữ đồng bộ khi chuyển kiểu chiếu). setViewOffset
// chỉ dời vùng ảnh được render, không động tới vị trí/hướng camera.
function applyViewOffset(): void {
  const container = containerRef.value
  if (!container) return
  const width = container.clientWidth || 1
  const height = container.clientHeight || 1
  for (const cam of [orthoCamera, perspCamera]) {
    if (!cam) continue
    if (panOffset.x === 0 && panOffset.y === 0) cam.clearViewOffset()
    else cam.setViewOffset(width, height, -panOffset.x, -panOffset.y, width, height)
  }
}

// Nút nào là kéo: chuột phải, chuột trái khi bật chế độ kéo, hoặc chuột trái kèm
// Shift/Ctrl/Meta (khớp quy ước OrbitControls).
function isPanPointer(e: PointerEvent): boolean {
  if (!e.isPrimary) return false
  if (e.button === 2) return true
  return e.button === 0 && (panMode.value || e.shiftKey || e.ctrlKey || e.metaKey)
}

function animate(): void {
  frameId = requestAnimationFrame(animate)
  controls?.update()
  if (renderer && scene && camera) renderer.render(scene, camera)
  updateEditIconPosition()
}

// Chiếu hộp bao của mặt đang chọn xuống màn hình, lấy góc trên-phải của hình chữ
// nhật bao trên màn hình rồi đặt nút "Sửa" ngay cạnh góc đó (kẹp trong khung nhìn).
// Ghi thẳng vào style của phần tử thay vì qua ref reactive để không render lại Vue
// mỗi khung hình.
function updateEditIconPosition(): void {
  const el = editIconRef.value
  const container = containerRef.value
  if (!el || !container || !camera || !faceCorners) return

  const width = container.clientWidth
  const height = container.clientHeight
  let maxX = -Infinity
  let minY = Infinity
  for (const corner of faceCorners) {
    projected.copy(corner).project(camera)
    maxX = Math.max(maxX, ((projected.x + 1) / 2) * width)
    minY = Math.min(minY, ((1 - projected.y) / 2) * height)
  }

  // Kẹp theo kích thước thật của menu con (rộng hơn 1 icon).
  const menuW = el.offsetWidth || EDIT_ICON_SIZE
  const menuH = el.offsetHeight || EDIT_ICON_SIZE
  const left = Math.min(Math.max(maxX + EDIT_ICON_GAP, 0), width - menuW)
  const top = Math.min(Math.max(minY - menuH - EDIT_ICON_GAP, 0), height - menuH)
  el.style.transform = `translate(${left}px, ${top}px)`
}

function onEditFaceClick(kind: FaceEditKind): void {
  if (lastFaceSelection) emit('face-edit', lastFaceSelection, kind)
}

function handleResize(): void {
  const container = containerRef.value
  if (!container || !renderer || !orthoCamera || !perspCamera) return

  const width = container.clientWidth || 1
  const height = container.clientHeight || 1
  const aspect = width / height

  orthoCamera.left = (-viewSize * aspect) / 2
  orthoCamera.right = (viewSize * aspect) / 2
  orthoCamera.top = viewSize / 2
  orthoCamera.bottom = -viewSize / 2
  orthoCamera.updateProjectionMatrix()
  perspCamera.aspect = aspect
  perspCamera.updateProjectionMatrix()
  applyViewOffset()
  renderer.setSize(width, height)
}

// Vẽ chữ lên một canvas -> texture, kèm tỉ lệ khung để dựng PlaneGeometry đúng dạng.
function makeLabelTexture(text: string): { texture: THREE.CanvasTexture; aspect: number } {
  const fontSize = 64
  const padX = 28
  const padY = 18
  const font = `700 ${fontSize}px system-ui, -apple-system, "Segoe UI", sans-serif`

  const canvas = document.createElement('canvas')
  const measureCtx = canvas.getContext('2d') as CanvasRenderingContext2D
  measureCtx.font = font
  const textWidth = Math.max(1, measureCtx.measureText(text).width)

  canvas.width = Math.ceil(textWidth + padX * 2)
  canvas.height = Math.ceil(fontSize + padY * 2)

  const ctx = canvas.getContext('2d') as CanvasRenderingContext2D
  const r = 16
  ctx.beginPath()
  ctx.moveTo(r, 0)
  ctx.arcTo(canvas.width, 0, canvas.width, canvas.height, r)
  ctx.arcTo(canvas.width, canvas.height, 0, canvas.height, r)
  ctx.arcTo(0, canvas.height, 0, 0, r)
  ctx.arcTo(0, 0, canvas.width, 0, r)
  ctx.closePath()
  ctx.fillStyle = 'rgba(255,255,255,0.94)'
  ctx.fill()
  ctx.lineWidth = 4
  ctx.strokeStyle = '#93c5fd'
  ctx.stroke()

  ctx.font = font
  ctx.fillStyle = '#1e3a8a'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(text, canvas.width / 2, canvas.height / 2 + 2)

  const texture = new THREE.CanvasTexture(canvas)
  texture.colorSpace = THREE.SRGBColorSpace
  texture.anisotropy = renderer?.capabilities.getMaxAnisotropy() ?? 1
  texture.needsUpdate = true
  return { texture, aspect: canvas.width / canvas.height }
}

const _labelN = new THREE.Vector3()
const _labelUp = new THREE.Vector3()
const _labelRight = new THREE.Vector3()
const _labelTrueUp = new THREE.Vector3()
const _labelBasis = new THREE.Matrix4()

// Xoay tấm chữ để mặt phẳng tấm trùng mặt phẳng có pháp tuyến `normal`; trả về
// pháp tuyến đã chuẩn hóa (_labelN) để đẩy tấm ra khỏi mặt một chút.
function orientLabelOnPlane(
  mesh: THREE.Mesh,
  normal: { x: number; y: number; z: number }
): THREE.Vector3 {
  _labelN.set(normal.x, normal.y, normal.z)
  if (_labelN.lengthSq() === 0) _labelN.set(0, 0, 1)
  _labelN.normalize()
  // "Lên" của chữ: +Z, trừ khi mặt gần như nằm ngang (sàn/trần) thì dùng +Y.
  _labelUp.set(0, 0, 1)
  if (Math.abs(_labelN.z) > 0.9) _labelUp.set(0, 1, 0)
  _labelRight.crossVectors(_labelUp, _labelN).normalize()
  _labelTrueUp.crossVectors(_labelN, _labelRight).normalize()
  _labelBasis.makeBasis(_labelRight, _labelTrueUp, _labelN)
  mesh.quaternion.setFromRotationMatrix(_labelBasis)
  return _labelN
}

// Giải phóng toàn bộ tài nguyên của một khối miệng cấp / miệng xả.
function disposePartEntry(entry: PartEntry): void {
  scene?.remove(entry.box)
  entry.box.geometry.dispose()
  entry.boxMat.dispose()
  entry.edges.geometry.dispose()
  entry.edgeMat.dispose()
  entry.label.geometry.dispose()
  entry.labelMat.dispose()
  entry.labelTexture.dispose()
}

// Đồng bộ các khối miệng cấp (inlet) theo prop `inlets`: dựng/cập nhật hộp mờ +
// viền + nhãn tên; kích thước chỉ có 2 chiều (size_w/size_h) -> khối luôn mỏng theo
// trục X (INLET_VIEW_DEPTH), tô đậm khối có id = `selectedInletId`.
function syncInlets(): void {
  if (!scene) return

  const items = props.inlets ?? []
  const seen = new Set<number>()
  const color = PART_COLOR.supply

  for (const inlet of items) {
    seen.add(inlet.id)
    const sizeSig = `${inlet.size.w}|${inlet.size.h}`
    const selected = inlet.id === props.selectedInletId

    let entry = inletObjects.get(inlet.id)
    if (!entry) {
      const boxGeo = new THREE.BoxGeometry(1, 1, 1)
      const boxMat = new THREE.MeshBasicMaterial({
        color,
        transparent: true,
        opacity: 0.18,
        depthWrite: false
      })
      const box = new THREE.Mesh(boxGeo, boxMat)
      box.renderOrder = 2
      box.userData.inletId = inlet.id

      const edgeMat = new THREE.LineBasicMaterial({ color })
      const edges = new THREE.LineSegments(new THREE.EdgesGeometry(boxGeo), edgeMat)
      box.add(edges)

      const { texture, aspect } = makeLabelTexture(inlet.name || ' ')
      const labelMat = new THREE.MeshBasicMaterial({
        map: texture,
        transparent: true,
        side: THREE.DoubleSide,
        depthWrite: false
      })
      const label = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), labelMat)
      label.renderOrder = 4

      entry = {
        box,
        boxMat,
        edges,
        edgeMat,
        label,
        labelMat,
        labelTexture: texture,
        labelText: inlet.name,
        labelAspect: aspect,
        sizeSig: ''
      }
      inletObjects.set(inlet.id, entry)
      scene.add(box)
      scene.add(label)
    }

    // Dựng lại hình hộp khi kích thước đổi (X luôn mỏng — chỉ để bắt raycast).
    if (entry.sizeSig !== sizeSig) {
      const geo = new THREE.BoxGeometry(
        INLET_VIEW_DEPTH,
        Math.max(inlet.size.w, 1e-3),
        Math.max(inlet.size.h, 1e-3)
      )
      entry.box.geometry.dispose()
      entry.box.geometry = geo
      entry.edges.geometry.dispose()
      entry.edges.geometry = new THREE.EdgesGeometry(geo)
      entry.sizeSig = sizeSig
    }

    // Cập nhật chữ nhãn khi tên đổi.
    if (entry.labelText !== inlet.name) {
      const { texture, aspect } = makeLabelTexture(inlet.name || ' ')
      entry.labelTexture.dispose()
      entry.labelMat.map = texture
      entry.labelMat.needsUpdate = true
      entry.labelTexture = texture
      entry.labelText = inlet.name
      entry.labelAspect = aspect
    }

    // Độ đậm theo trạng thái chọn.
    entry.boxMat.opacity = selected ? 0.34 : 0.16
    entry.edgeMat.linewidth = selected ? 2 : 1
    entry.box.renderOrder = selected ? 5 : 2

    entry.box.position.set(inlet.center.x, inlet.center.y, inlet.center.z)

    // Nhãn nằm TRÊN mặt phẳng của mặt chứa inlet (mặt ⊥ X, x = center.x), giữa miệng
    // cấp. Cỡ chữ: cao ~28% cạnh nhỏ, rộng không tràn quá 92% bề rộng (Y) của miệng.
    const fit = Math.max(Math.min(inlet.size.w, inlet.size.h), 1e-3)
    let h = Math.max(fit * 0.28, 1e-3)
    let w = h * entry.labelAspect
    const maxW = Math.max(inlet.size.w, 1e-3) * 0.92
    if (w > maxW && w > 0) {
      const k = maxW / w
      w *= k
      h *= k
    }
    entry.label.scale.set(w, h, 1)
    // Pháp tuyến hướng RA ngoài mô hình -> chữ đọc xuôi khi nhìn mặt từ bên ngoài.
    const outward = modelBounds && inlet.center.x < modelBounds.center.x ? -1 : 1
    orientLabelOnPlane(entry.label, { x: outward, y: 0, z: 0 })
    entry.label.position.set(inlet.center.x, inlet.center.y, inlet.center.z)
  }

  for (const [id, entry] of inletObjects) {
    if (seen.has(id)) continue
    disposePartEntry(entry)
    inletObjects.delete(id)
  }
}

// Đồng bộ các khối Miệng xả (outlet) theo prop `outlets`: cùng cơ chế syncInlets(),
// tô đậm theo `selectedOutletId` thay vì `selectedInletId`, màu theo PART_COLOR.return.
function syncOutlets(): void {
  if (!scene) return

  const items = props.outlets ?? []
  const seen = new Set<number>()
  const color = PART_COLOR.return

  for (const outlet of items) {
    seen.add(outlet.id)
    const sizeSig = `${outlet.size.w}|${outlet.size.h}`
    const selected = outlet.id === props.selectedOutletId

    let entry = outletObjects.get(outlet.id)
    if (!entry) {
      const boxGeo = new THREE.BoxGeometry(1, 1, 1)
      const boxMat = new THREE.MeshBasicMaterial({
        color,
        transparent: true,
        opacity: 0.18,
        depthWrite: false
      })
      const box = new THREE.Mesh(boxGeo, boxMat)
      box.renderOrder = 2
      box.userData.outletId = outlet.id

      const edgeMat = new THREE.LineBasicMaterial({ color })
      const edges = new THREE.LineSegments(new THREE.EdgesGeometry(boxGeo), edgeMat)
      box.add(edges)

      const { texture, aspect } = makeLabelTexture(outlet.name || ' ')
      const labelMat = new THREE.MeshBasicMaterial({
        map: texture,
        transparent: true,
        side: THREE.DoubleSide,
        depthWrite: false
      })
      const label = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), labelMat)
      label.renderOrder = 4

      entry = {
        box,
        boxMat,
        edges,
        edgeMat,
        label,
        labelMat,
        labelTexture: texture,
        labelText: outlet.name,
        labelAspect: aspect,
        sizeSig: ''
      }
      outletObjects.set(outlet.id, entry)
      scene.add(box)
      scene.add(label)
    }

    // Dựng lại hình hộp khi kích thước đổi (X luôn mỏng — chỉ để bắt raycast).
    if (entry.sizeSig !== sizeSig) {
      const geo = new THREE.BoxGeometry(
        OUTLET_VIEW_DEPTH,
        Math.max(outlet.size.w, 1e-3),
        Math.max(outlet.size.h, 1e-3)
      )
      entry.box.geometry.dispose()
      entry.box.geometry = geo
      entry.edges.geometry.dispose()
      entry.edges.geometry = new THREE.EdgesGeometry(geo)
      entry.sizeSig = sizeSig
    }

    // Cập nhật chữ nhãn khi tên đổi.
    if (entry.labelText !== outlet.name) {
      const { texture, aspect } = makeLabelTexture(outlet.name || ' ')
      entry.labelTexture.dispose()
      entry.labelMat.map = texture
      entry.labelMat.needsUpdate = true
      entry.labelTexture = texture
      entry.labelText = outlet.name
      entry.labelAspect = aspect
    }

    // Độ đậm theo trạng thái chọn.
    entry.boxMat.opacity = selected ? 0.34 : 0.16
    entry.edgeMat.linewidth = selected ? 2 : 1
    entry.box.renderOrder = selected ? 5 : 2

    entry.box.position.set(outlet.center.x, outlet.center.y, outlet.center.z)

    // Nhãn nằm TRÊN mặt phẳng của mặt chứa outlet (mặt ⊥ X, x = center.x), giữa miệng
    // xả — giống syncInlets(). Cỡ chữ: cao ~28% cạnh nhỏ, rộng không tràn quá 92% bề
    // rộng (Y) của miệng.
    const fit = Math.max(Math.min(outlet.size.w, outlet.size.h), 1e-3)
    let h = Math.max(fit * 0.28, 1e-3)
    let w = h * entry.labelAspect
    const maxW = Math.max(outlet.size.w, 1e-3) * 0.92
    if (w > maxW && w > 0) {
      const k = maxW / w
      w *= k
      h *= k
    }
    entry.label.scale.set(w, h, 1)
    // Pháp tuyến hướng RA ngoài mô hình -> chữ đọc xuôi khi nhìn mặt từ bên ngoài.
    const outward = modelBounds && outlet.center.x < modelBounds.center.x ? -1 : 1
    orientLabelOnPlane(entry.label, { x: outward, y: 0, z: 0 })
    entry.label.position.set(outlet.center.x, outlet.center.y, outlet.center.z)
  }

  for (const [id, entry] of outletObjects) {
    if (seen.has(id)) continue
    disposePartEntry(entry)
    outletObjects.delete(id)
  }
}

// Gỡ + giải phóng geometry của mô hình hiện tại (khung dây + mesh đặc + hình học gốc).
// Material dùng chung -> không dispose ở đây.
function disposeModel(): void {
  clearFaceSelection()
  dimensions.value = null

  if (wireframe) {
    scene?.remove(wireframe)
    wireframe.geometry.dispose()
    wireframe = null
  }
  if (solid) {
    scene?.remove(solid)
    solid = null
  }
  if (modelGeometry) {
    modelGeometry.dispose()
    modelGeometry = null
  }
}

// Xoá lớp phủ mặt đang chọn (không phát sự kiện — người gọi tự quyết định).
function clearFaceSelection(): void {
  if (faceFill) {
    scene?.remove(faceFill)
    faceFill.geometry.dispose()
    faceFill = null
  }
  if (faceEdges) {
    scene?.remove(faceEdges)
    faceEdges.geometry.dispose()
    faceEdges = null
  }
  faceCorners = null
  lastFaceSelection = null
  selectedFace.value = null
}

// Bỏ chọn do người dùng bấm nút "Bỏ chọn" -> có phát sự kiện ra ngoài.
function deselectFace(): void {
  clearFaceSelection()
  emit('face-select', null)
}

function onPointerDown(e: PointerEvent): void {
  pointerDownX = e.clientX
  pointerDownY = e.clientY
  // Ngón thứ hai chạm vào -> đang pinch-zoom, dừng kéo.
  isPanning = isPanPointer(e)
  panLastX = e.clientX
  panLastY = e.clientY
}

function onPointerMove(e: PointerEvent): void {
  if (!isPanning || !e.isPrimary) return
  panOffset.x += e.clientX - panLastX
  panOffset.y += e.clientY - panLastY
  panLastX = e.clientX
  panLastY = e.clientY
  applyViewOffset()
}

function onPointerCancel(): void {
  isPanning = false
}

// Chỉ coi là "bấm chọn" khi nhả chuột trái gần như đúng chỗ nhấn (di chuyển < 4px)
// -> phân biệt với thao tác xoay/kéo của OrbitControls.
function onPointerUp(e: PointerEvent): void {
  if (e.isPrimary) isPanning = false
  if (e.button !== 0 || isLoading.value) return
  if (Math.hypot(e.clientX - pointerDownX, e.clientY - pointerDownY) > 4) return
  pickFace(e)
}

function pickFace(e: PointerEvent): void {
  if (!renderer || !camera) return

  const rect = renderer.domElement.getBoundingClientRect()
  pointerNdc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1
  pointerNdc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1
  raycaster.setFromCamera(pointerNdc, camera)

  // 1) Ưu tiên các khối miệng cấp (inlet).
  if (inletObjects.size > 0) {
    const boxes = Array.from(inletObjects.values(), (p) => p.box)
    const inletHit = raycaster.intersectObjects(boxes, false)[0]
    if (inletHit) {
      const id = inletHit.object.userData.inletId as number | undefined
      if (id !== undefined) {
        if (selectedFace.value) deselectFace()
        emit('outlet-select', null)
        emit('inlet-select', id)
        return
      }
    }
  }

  // 2) Các khối Miệng xả (outlet).
  if (outletObjects.size > 0) {
    const boxes = Array.from(outletObjects.values(), (p) => p.box)
    const outletHit = raycaster.intersectObjects(boxes, false)[0]
    if (outletHit) {
      const id = outletHit.object.userData.outletId as number | undefined
      if (id !== undefined) {
        if (selectedFace.value) deselectFace()
        emit('inlet-select', null)
        emit('outlet-select', id)
        return
      }
    }
  }

  // 3) Chọn mặt trên mô hình OBJ.
  if (!solid || !modelGeometry) {
    if (selectedFace.value) deselectFace()
    emit('inlet-select', null)
    emit('outlet-select', null)
    return
  }

  const hit = raycaster.intersectObject(solid, false)[0]
  if (!hit || hit.faceIndex == null) {
    if (selectedFace.value) deselectFace()
    emit('inlet-select', null)
    emit('outlet-select', null)
    return
  }

  emit('inlet-select', null)
  emit('outlet-select', null)

  const face = extractCoplanarFace(modelGeometry, hit.faceIndex)
  if (!face) return

  applyFaceSelection(face)
  emitFaceSelection(face)
}

// Phát payload `face-select` cho một mặt vừa trích (badge `axis` đọc từ selectedFace
// mà applyFaceSelection() vừa đặt).
function emitFaceSelection(face: CoplanarFace): void {
  lastFaceSelection = {
    normal: { x: face.normal.x, y: face.normal.y, z: face.normal.z },
    center: { x: face.center.x, y: face.center.y, z: face.center.z },
    planeCenter: { x: face.planeCenter.x, y: face.planeCenter.y, z: face.planeCenter.z },
    min: { x: face.min.x, y: face.min.y, z: face.min.z },
    max: { x: face.max.x, y: face.max.y, z: face.max.z },
    area: face.area,
    axis: selectedFace.value?.axis ?? '—',
    triangleCount: face.triangleCount
  }
  emit('face-select', lastFaceSelection)
}

interface CoplanarFace {
  positions: Float32Array
  normal: THREE.Vector3
  center: THREE.Vector3
  planeCenter: THREE.Vector3
  min: THREE.Vector3
  max: THREE.Vector3
  area: number
  triangleCount: number
}

// Từ 1 tam giác vừa bấm trúng -> gộp mọi tam giác ĐỒNG PHẲNG (cùng pháp tuyến và
// cùng nằm trên một mặt phẳng) thành "một mặt". Đủ tốt cho khối phòng dạng hộp và
// các mặt phẳng nội bộ; không gộp mặt cong.
function extractCoplanarFace(geo: THREE.BufferGeometry, triIndex: number): CoplanarFace | null {
  const pos = geo.getAttribute('position') as THREE.BufferAttribute
  const idx = geo.getIndex()
  const triCount = (idx ? idx.count : pos.count) / 3

  const vAt = (tri: number, corner: number, target: THREE.Vector3): THREE.Vector3 => {
    const slot = tri * 3 + corner
    return target.fromBufferAttribute(pos, idx ? idx.getX(slot) : slot)
  }

  const a = new THREE.Vector3()
  const b = new THREE.Vector3()
  const c = new THREE.Vector3()
  const ab = new THREE.Vector3()
  const ac = new THREE.Vector3()
  const n = new THREE.Vector3()
  const n0 = new THREE.Vector3()

  vAt(triIndex, 0, a)
  vAt(triIndex, 1, b)
  vAt(triIndex, 2, c)
  n0.crossVectors(ab.subVectors(b, a), ac.subVectors(c, a))
  if (n0.lengthSq() === 0) return null
  n0.normalize()
  const d0 = n0.dot(a)

  if (!geo.boundingBox) geo.computeBoundingBox()
  const diag = geo.boundingBox ? geo.boundingBox.getSize(new THREE.Vector3()).length() : 1
  const planeEps = Math.max(diag * 1e-3, 1e-6)
  const NORMAL_DOT_MIN = 0.999 // ~2.5°: đủ chặt để tách mặt, đủ lỏng cho sai số lưới tam giác

  const out: number[] = []
  const center = new THREE.Vector3()
  const triC = new THREE.Vector3()
  const min = new THREE.Vector3(Infinity, Infinity, Infinity)
  const max = new THREE.Vector3(-Infinity, -Infinity, -Infinity)
  let area = 0
  let triangleCount = 0

  for (let t = 0; t < triCount; t++) {
    vAt(t, 0, a)
    vAt(t, 1, b)
    vAt(t, 2, c)
    n.crossVectors(ab.subVectors(b, a), ac.subVectors(c, a))
    const twiceArea = n.length()
    if (twiceArea === 0) continue
    n.divideScalar(twiceArea)
    if (n.dot(n0) < NORMAL_DOT_MIN) continue
    if (
      Math.abs(n0.dot(a) - d0) > planeEps ||
      Math.abs(n0.dot(b) - d0) > planeEps ||
      Math.abs(n0.dot(c) - d0) > planeEps
    ) {
      continue
    }

    out.push(a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z)
    const triArea = twiceArea / 2
    area += triArea
    center.add(triC.copy(a).add(b).add(c).divideScalar(3).multiplyScalar(triArea))
    min.min(a).min(b).min(c)
    max.max(a).max(b).max(c)
    triangleCount++
  }

  if (triangleCount === 0) return null
  center.divideScalar(area || 1)

  // Tâm hộp bao của mặt, chiếu bỏ thành phần lệch theo pháp tuyến -> nằm ĐÚNG trên
  // mặt phẳng của mặt và ngay chính giữa (khớp với mặt chữ nhật của khối phòng).
  const planeCenter = new THREE.Vector3().addVectors(min, max).multiplyScalar(0.5)
  planeCenter.addScaledVector(n0, d0 - n0.dot(planeCenter))

  return {
    positions: new Float32Array(out),
    normal: n0.clone(),
    center,
    planeCenter,
    min,
    max,
    area,
    triangleCount
  }
}

// Dựng lớp phủ (tam giác mờ + viền cạnh) cho mặt vừa trích và cập nhật badge.
function applyFaceSelection(face: CoplanarFace): void {
  if (!scene || !faceFillMat || !faceEdgeMat) return
  clearFaceSelection()

  const geometry = new THREE.BufferGeometry()
  geometry.setAttribute('position', new THREE.BufferAttribute(face.positions, 3))

  faceFill = new THREE.Mesh(geometry, faceFillMat)
  faceFill.renderOrder = 1
  scene.add(faceFill)

  faceEdges = new THREE.LineSegments(new THREE.EdgesGeometry(geometry, 1), faceEdgeMat)
  faceEdges.renderOrder = 2
  scene.add(faceEdges)

  const { min, max } = face
  faceCorners = []
  for (const x of [min.x, max.x]) {
    for (const y of [min.y, max.y]) {
      for (const z of [min.z, max.z]) faceCorners.push(new THREE.Vector3(x, y, z))
    }
  }

  const ax = Math.abs(face.normal.x)
  const ay = Math.abs(face.normal.y)
  const az = Math.abs(face.normal.z)
  let axis: 'X' | 'Y' | 'Z' | '—' = '—'
  if (ax > 0.9 && ax >= ay && ax >= az) axis = 'X'
  else if (ay > 0.9 && ay >= az) axis = 'Y'
  else if (az > 0.9) axis = 'Z'

  selectedFace.value = {
    axis,
    area: face.area,
    size: {
      x: face.max.x - face.min.x,
      y: face.max.y - face.min.y,
      z: face.max.z - face.min.z
    }
  }
}

// Đưa camera + tâm quay về vị trí bao trọn bounding box của geometry vừa nạp.
function frameGeometry(geometry: THREE.BufferGeometry): void {
  if (!camera || !controls || !orthoCamera || !perspCamera) return

  geometry.computeBoundingBox()
  geometry.computeBoundingSphere()
  const box = geometry.boundingBox
  if (!box) return

  const size = box.getSize(new THREE.Vector3())
  const center = box.getCenter(new THREE.Vector3())
  dimensions.value = { x: size.x, y: size.y, z: size.z }
  modelBounds = { center: center.clone(), size: size.clone() }
  const maxDim = Math.max(size.x, size.y, size.z) || 1
  const radius = geometry.boundingSphere?.radius || maxDim / 2

  // Trục xuất phát từ gốc O, dài hơn kích thước khối theo từng phương 2 đơn vị (m)
  // -> luôn nhô khỏi mô hình. Với phòng OpenFOAM (min ≈ 0) đây chính là
  // L + 2 / W + 2 / H + 2.
  const head = (maxDim * 0.1) / 3
  const axisLen = {
    x: Math.max(box.max.x, size.x) + 2,
    y: Math.max(box.max.y, size.y) + 2,
    z: Math.max(box.max.z, size.z) + 2
  }
  axisArrows?.x.setLength(axisLen.x, head, head * 0.5)
  axisArrows?.y.setLength(axisLen.y, head, head * 0.5)
  axisArrows?.z.setLength(axisLen.z, head, head * 0.5)
  const labelScale = Math.max(maxDim * 0.03, 0.1)
  axisLabels?.x.scale.setScalar(labelScale)
  axisLabels?.y.scale.setScalar(labelScale)
  axisLabels?.z.scale.setScalar(labelScale)
  axisLabels?.x.position.set(axisLen.x + labelScale * 0.7, 0, 0)
  axisLabels?.y.position.set(0, axisLen.y + labelScale * 0.7, 0)
  axisLabels?.z.position.set(0, 0, axisLen.z + labelScale * 0.7)

  // Căn khung nhìn ortho bao trọn bounding sphere (đường kính + lề ~20%), có bù
  // theo tỉ lệ khung để cạnh ngắn hơn vẫn chứa đủ mô hình.
  const container = containerRef.value
  const aspect = (container?.clientWidth || 1) / (container?.clientHeight || 1)
  const fit = radius * 2 * 1.2
  viewSize = aspect >= 1 ? fit : fit / aspect
  // Mô hình mới -> bỏ độ dịch kéo cũ, đưa mô hình về giữa khung.
  panOffset.x = 0
  panOffset.y = 0
  applyViewOffset()
  orthoCamera.left = (-viewSize * aspect) / 2
  orthoCamera.right = (viewSize * aspect) / 2
  orthoCamera.top = viewSize / 2
  orthoCamera.bottom = -viewSize / 2
  orthoCamera.zoom = 1

  // Nhìn chếch từ +X / -Y, hơi cao theo +Z (Z là phương đứng). Với ortho, khoảng
  // cách camera chỉ ảnh hưởng near/far chứ không đổi tỉ lệ hiển thị.
  const viewDir = new THREE.Vector3(1, -1, 0.7).normalize()
  orthoDist = maxDim * 4
  controls.target.copy(center)
  orthoCamera.position.copy(center).addScaledVector(viewDir, orthoDist)
  orthoCamera.near = 0.01
  orthoCamera.far = orthoDist * 4 + radius * 4
  orthoCamera.updateProjectionMatrix()

  // Phối cảnh: lùi camera vừa đủ để bounding sphere (kèm lề ~20%) lọt cả theo
  // góc nhìn dọc lẫn ngang (cạnh khung ngắn hơn quyết định).
  const vHalf = THREE.MathUtils.degToRad(PERSP_FOV / 2)
  const hHalf = Math.atan(Math.tan(vHalf) * aspect)
  const perspDist = (radius * 1.2) / Math.sin(Math.min(vHalf, hHalf))
  perspCamera.position.copy(center).addScaledVector(viewDir, perspDist)
  perspCamera.near = 0.01
  perspCamera.far = perspDist * 4 + radius * 4
  perspCamera.updateProjectionMatrix()
  controls.update()
}

// OBJLoader trả về một Group (mỗi object/group trong file .obj là một Mesh riêng,
// kèm material mặc định). Gộp mọi Mesh thành MỘT BufferGeometry chỉ có `position`
// (đã áp ma trận thế giới của từng mesh) để raycast + trích mặt đồng phẳng chạy
// trên một hình học duy nhất như trước. Line/Points trong file bị bỏ qua.
// Giải phóng toàn bộ geometry/material của Group gốc sau khi gộp.
function objGroupToGeometry(root: THREE.Group): THREE.BufferGeometry | null {
  root.updateMatrixWorld(true)
  const pieces: THREE.BufferGeometry[] = []

  root.traverse((obj) => {
    const mesh = obj as THREE.Mesh
    if (!mesh.isMesh) return
    const position = mesh.geometry.getAttribute('position')
    if (position && position.count >= 3) {
      const src = mesh.geometry.index ? mesh.geometry.toNonIndexed() : mesh.geometry
      const piece = new THREE.BufferGeometry()
      piece.setAttribute('position', src.getAttribute('position').clone())
      piece.applyMatrix4(mesh.matrixWorld)
      pieces.push(piece)
      if (src !== mesh.geometry) src.dispose()
    }
    mesh.geometry.dispose()
    const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material]
    materials.forEach((m) => m.dispose())
  })

  if (pieces.length === 0) return null
  if (pieces.length === 1) return pieces[0]

  const merged = mergeGeometries(pieces, false)
  pieces.forEach((p) => p.dispose())
  return merged
}

function loadObj(url: string): void {
  if (!scene) return

  if (!url) {
    disposeModel()
    return
  }

  isLoading.value = true
  errorMessage.value = null
  const token = ++loadToken

  new OBJLoader().load(
    url,
    (group) => {
      const geometry = objGroupToGeometry(group)

      // Component đã hủy hoặc đã có lần nạp mới hơn -> giải phóng ngay, không dựng gì thêm.
      if (token !== loadToken || isDisposed || !scene || !wireMat || !solidMat) {
        geometry?.dispose()
        return
      }

      // File .obj không có mặt tam giác nào (rỗng / chỉ có line, point).
      if (!geometry) {
        disposeModel()
        isLoading.value = false
        errorMessage.value = 'File hình học (.obj) không chứa bề mặt nào'
        return
      }

      disposeModel()
      // Giữ lại hình học gốc để raycast + trích mặt khi người dùng bấm chọn.
      modelGeometry = geometry

      // EdgesGeometry gộp các tam giác đồng phẳng, chỉ giữ cạnh đặc trưng
      // (góc lệch > 1°) -> khung dây gọn theo cạnh hình học, không lộ đường
      // chéo chia tam giác trên các mặt phẳng.
      wireframe = new THREE.LineSegments(new THREE.EdgesGeometry(geometry, 1), wireMat)
      scene.add(wireframe)

      // Mesh đặc vô hình bọc đúng hình học gốc -> mục tiêu cho raycast chọn mặt.
      solid = new THREE.Mesh(geometry, solidMat)
      scene.add(solid)

      frameGeometry(geometry)
      // Đã có modelBounds -> dựng lại nhãn inlet/outlet để chữ quay đúng phía ngoài mặt.
      syncInlets()
      syncOutlets()
      isLoading.value = false
    },
    undefined,
    (error) => {
      // eslint-disable-next-line no-console
      console.error('[sg_engr_obj_viewer] Không thể tải OBJ:', url, error)
      if (token !== loadToken || isDisposed) return
      isLoading.value = false
      dimensions.value = null
      errorMessage.value = 'Không thể tải file hình học (.obj)'
    }
  )
}

onMounted(() => {
  initScene()
  syncInlets()
  syncOutlets()
  if (props.src) loadObj(props.src)
})

watch(
  () => props.src,
  (url) => loadObj(url)
)

watch([() => props.inlets, () => props.selectedInletId], syncInlets, { deep: true })
watch([() => props.outlets, () => props.selectedOutletId], syncOutlets, { deep: true })

// API cho component cha:
//  - clearFaceSelection: chủ động bỏ chọn mặt (vẫn phát `face-select` null).
//  - getModelBounds: tâm + kích thước hộp bao mô hình (m) để đặt miệng cấp/xả mặc định.
defineExpose({
  clearFaceSelection: deselectFace,
  getModelBounds: (): {
    center: { x: number; y: number; z: number }
    size: { x: number; y: number; z: number }
  } | null =>
    modelBounds
      ? {
          center: { x: modelBounds.center.x, y: modelBounds.center.y, z: modelBounds.center.z },
          size: { x: modelBounds.size.x, y: modelBounds.size.y, z: modelBounds.size.z }
        }
      : null
})

onBeforeUnmount(() => {
  isDisposed = true

  // 1) Dừng vòng lặp render + observer -> không còn tham chiếu giữ đối tượng sống.
  cancelAnimationFrame(frameId)
  frameId = 0
  resizeObserver?.disconnect()
  resizeObserver = null

  if (renderer) {
    renderer.domElement.removeEventListener('pointerdown', onPointerDown)
    renderer.domElement.removeEventListener('pointermove', onPointerMove)
    renderer.domElement.removeEventListener('pointerup', onPointerUp)
    renderer.domElement.removeEventListener('pointercancel', onPointerCancel)
  }

  // Khối miệng cấp (inlet).
  for (const entry of inletObjects.values()) disposePartEntry(entry)
  inletObjects.clear()

  // Khối Miệng xả (outlet).
  for (const entry of outletObjects.values()) disposePartEntry(entry)
  outletObjects.clear()
  modelBounds = null

  // 2) Giải phóng geometry/material của mọi đối tượng trong scene (khung dây, mesh
  //    đặc, lớp phủ mặt chọn, lưới, trục tọa độ...) rồi bóc khỏi scene.
  disposeModel()

  grid?.dispose()
  grid = null

  if (axisArrows) {
    for (const arrow of [axisArrows.x, axisArrows.y, axisArrows.z]) arrow.dispose()
  }
  if (axisLabels) {
    for (const sprite of [axisLabels.x, axisLabels.y, axisLabels.z]) sprite.material.dispose()
  }
  for (const texture of axisLabelTextures) texture.dispose()
  axisLabelTextures.length = 0
  if (axesGroup) scene?.remove(axesGroup)
  axesGroup = null
  axisArrows = null
  axisLabels = null

  wireMat?.dispose()
  solidMat?.dispose()
  faceFillMat?.dispose()
  faceEdgeMat?.dispose()
  wireMat = solidMat = faceFillMat = faceEdgeMat = null

  scene?.traverse((obj) => {
    const mesh = obj as Partial<THREE.Mesh>
    mesh.geometry?.dispose?.()
    const material = mesh.material
    if (Array.isArray(material)) material.forEach((m) => m.dispose())
    else material?.dispose?.()
  })
  scene?.clear()

  // 3) OrbitControls: gỡ toàn bộ event listener trên canvas.
  controls?.dispose()

  // 4) WebGLRenderer: xóa cache chương trình/texture rồi ép mất WebGL context để
  //    trả lại bộ nhớ GPU ngay thay vì chờ GC.
  if (renderer) {
    renderer.renderLists.dispose()
    renderer.dispose()
    renderer.forceContextLoss()
    renderer.domElement.parentNode?.removeChild(renderer.domElement)
  }

  renderer = null
  scene = null
  camera = null
  orthoCamera = null
  perspCamera = null
  controls = null
})
</script>

<template>
  <div class="relative h-full w-full">
    <div
      ref="containerRef"
      class="h-full w-full"
      :class="panMode ? 'cursor-grab active:cursor-grabbing' : ''"
    ></div>

    <!-- Nút "Sửa" nổi cạnh góc trên-phải của mặt đang chọn. Vị trí (transform) được
         cập nhật mỗi khung hình trong updateEditIconPosition(). -->
    <div class="p-2 flex items-center justify-center border border-pmis-bordernormal">
      <div
        v-if="selectedFace"
        ref="editIconRef"
        class="absolute left-0 top-0 flex items-center gap-1 rounded-md border border-pmis-bordernormal bg-white p-1 shadow"
      >
        <button
          v-for="cmd in FACE_EDIT_COMMANDS"
          :key="cmd.kind"
          type="button"
          class="flex items-center justify-center rounded border border-pmis-primary bg-white text-pmis-primary transition-colors hover:bg-pmis-primary hover:text-white"
          :style="{ width: `${EDIT_ICON_SIZE}px`, height: `${EDIT_ICON_SIZE}px` }"
          :title="cmd.title"
          @click="onEditFaceClick(cmd.kind)"
        >
          <component :is="cmd.icon" class="h-4 w-4" />
        </button>
      </div>
    </div>

    <!-- Chuyển chế độ chuột trái: xoay <-> kéo. Chuột phải luôn kéo được.
         Kéo (ở cả hai chế độ) không làm đổi góc nhìn. -->
    <div class="absolute right-3 top-3 flex items-center gap-2">
      <!-- Chuyển kiểu chiếu: phối cảnh (gần to, xa nhỏ) <-> trực giao (đúng tỉ lệ). -->
      <button
        type="button"
        class="flex items-center gap-1.5 rounded-md bg-white/90 px-2.5 py-1.5 text-xs font-medium text-pmis-text shadow transition hover:bg-white"
        :title="
          projectionMode === 'perspective'
            ? 'Đang chiếu phối cảnh (gần to, xa nhỏ) — bấm để chuyển sang trực giao'
            : 'Đang chiếu trực giao (giữ đúng tỉ lệ kích thước) — bấm để chuyển sang phối cảnh'
        "
        @click="toggleProjection"
      >
        <component :is="projectionMode === 'perspective' ? Axis3d : Box" class="h-4 w-4" />
        {{ projectionMode === 'perspective' ? 'Phối cảnh' : 'Trực giao' }}
      </button>

      <button
        type="button"
        class="flex items-center gap-1.5 rounded-md bg-white/90 px-2.5 py-1.5 text-xs font-medium shadow transition hover:bg-white"
        :class="panMode ? 'text-pmis-primary' : 'text-pmis-text'"
        :title="
          panMode
            ? 'Đang bật chế độ kéo — giữ chuột trái để dịch chuyển mô hình (không đổi góc nhìn)'
            : 'Bật chế độ kéo mô hình'
        "
        @click="togglePanMode"
      >
        <component :is="panMode ? Hand : Rotate3d" class="h-4 w-4" />
        {{ panMode ? 'Chế độ kéo' : 'Chế độ xoay' }}
      </button>
    </div>

    <!-- Gợi ý thao tác khi đã có mô hình mà chưa chọn mặt nào. -->
    <!-- <div
      v-else-if="dimensions && !isLoading && !errorMessage"
      class="pointer-events-none absolute bottom-3 left-3 rounded-md bg-white/80 px-2.5 py-1.5 text-xs text-pmis-placeholder shadow"
    >
      Bấm vào một mặt của khối để chọn
    </div> -->

    <div
      v-if="isLoading"
      class="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-white/60"
    >
      <Loader2 class="h-8 w-8 animate-spin text-pmis-primary" />
      <p class="text-sm text-pmis-placeholder">Đang tải mô hình hình học...</p>
    </div>

    <div
      v-else-if="errorMessage"
      class="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-white/60 p-6 text-center"
    >
      <p class="text-sm text-pmis-danger">{{ errorMessage }}</p>
    </div>
  </div>
</template>

<style scoped></style>
