<script setup lang="ts">
// ======================================================================
// Trình xem kết quả mô phỏng CFD (bước "Kết quả" trên trang mô phỏng).
// Dữ liệu vào là manifest.json lấy từ GET /api/v1/jobs/{job_id}/results — mỗi
// layer/ảnh đã có `url` presigned S3/MinIO, trình duyệt tải thẳng từ S3 bằng fetch
// (KHÔNG qua apiClient: header Authorization làm S3 từ chối chữ ký).
//   - 3D: vtk.js đọc .vtp (float32, nén zlib), tô màu theo field đang chọn với
//         thang màu chung lấy từ manifest.fields[field].range.
//   - 2D: ảnh PNG mặt cắt hiển thị bằng <img>.
// Layer chỉ được tải khi bật lần đầu (lazy), sau đó giữ lại để bật/tắt tức thì.
// ======================================================================
import { computed, onBeforeUnmount, onMounted, reactive, ref, watch } from 'vue'
import { Box, Hand, Image as ImageIcon, Loader2, Rotate3d } from 'lucide-vue-next'
import '@kitware/vtk.js/Rendering/Profiles/Geometry'
import vtkGenericRenderWindow, {
  type vtkGenericRenderWindow as GenericRenderWindow
} from '@kitware/vtk.js/Rendering/Misc/GenericRenderWindow'
import vtkXMLPolyDataReader from '@kitware/vtk.js/IO/XML/XMLPolyDataReader'
import vtkActor, { type vtkActor as Actor } from '@kitware/vtk.js/Rendering/Core/Actor'
import vtkMapper, { type vtkMapper as Mapper } from '@kitware/vtk.js/Rendering/Core/Mapper'
import vtkColorTransferFunction from '@kitware/vtk.js/Rendering/Core/ColorTransferFunction'
import vtkColorMaps from '@kitware/vtk.js/Rendering/Core/ColorTransferFunction/ColorMaps'
import { ColorMode, ScalarMode } from '@kitware/vtk.js/Rendering/Core/Mapper/Constants'
import vtkInteractorStyleManipulator, {
  type vtkInteractorStyleManipulator as InteractorStyleManipulator
} from '@kitware/vtk.js/Interaction/Style/InteractorStyleManipulator'
import vtkMouseCameraTrackballRotateManipulator from '@kitware/vtk.js/Interaction/Manipulators/MouseCameraTrackballRotateManipulator'
import vtkMouseCameraTrackballPanManipulator from '@kitware/vtk.js/Interaction/Manipulators/MouseCameraTrackballPanManipulator'
import vtkMouseCameraTrackballZoomManipulator from '@kitware/vtk.js/Interaction/Manipulators/MouseCameraTrackballZoomManipulator'
import type { SGResultLayer, SGResultLayerType, SGResultManifest } from '@/types/sg_job'
import { isPresignedUrlExpired } from '@/utils/sg_presigned_url'

const props = defineProps<{
  manifest: SGResultManifest
}>()

const emit = defineEmits<{
  // Presigned URL đã hết hạn -> trang cha gọi lại API results để lấy URL mới.
  expired: []
}>()

const LAYER_GROUP_LABEL: Record<SGResultLayerType, string> = {
  surface: 'Bề mặt (tường / sàn / trần / miệng gió)',
  slice: 'Mặt cắt',
  streamlines: 'Đường dòng'
}
const LAYER_GROUP_ORDER: SGResultLayerType[] = ['surface', 'slice', 'streamlines']

// Màu các layer không có field đang chọn (vẽ trơn, không tô theo giá trị).
const NO_FIELD_COLOR: [number, number, number] = [0.75, 0.75, 0.75]
const COLOR_MAP_PRESET = 'Cool to Warm'
const LEGEND_STEPS = 16

// ----------------------------------------------------------------------
// Trạng thái giao diện
// ----------------------------------------------------------------------
const viewMode = ref<'3d' | '2d'>('3d')

// Danh sách field cho ô chọn. U là vector -> dùng U_mag (|U|) nếu có để tô màu.
const fieldOptions = computed(() =>
  Object.entries(props.manifest.fields)
    .filter(([name]) => !(name === 'U' && 'U_mag' in props.manifest.fields))
    .map(([name, info]) => ({ name, label: `${info.label} (${name === 'U_mag' ? '|U|' : name})` }))
)

const selectedField = ref<string>('')
const selectedFieldInfo = computed(() => props.manifest.fields[selectedField.value])

const layerVisible = reactive<Record<string, boolean>>({})
const layerLoading = reactive<Record<string, boolean>>({})
const layerError = reactive<Record<string, string>>({})
const surfaceOpacity = ref(0.35)

const layerGroups = computed(() =>
  LAYER_GROUP_ORDER.map((type) => ({
    type,
    label: LAYER_GROUP_LABEL[type],
    layers: props.manifest.layers.filter((layer) => layer.type === type)
  })).filter((group) => group.layers.length > 0)
)

const isAnyLayerLoading = computed(() => Object.values(layerLoading).some(Boolean))

// Field mặc định: T nếu có, không thì field đầu tiên.
function defaultField(manifest: SGResultManifest): string {
  if ('T' in manifest.fields) return 'T'
  return fieldOptions.value[0]?.name ?? ''
}

// Mặc định bật toàn bộ bề mặt (bán trong suốt) + mặt cắt đầu tiên; tắt đường dòng.
function resetUiState(manifest: SGResultManifest): void {
  for (const key of Object.keys(layerVisible)) delete layerVisible[key]
  for (const key of Object.keys(layerError)) delete layerError[key]
  const firstSlice = manifest.layers.find((layer) => layer.type === 'slice')
  for (const layer of manifest.layers) {
    layerVisible[layer.id] = layer.type === 'surface' || layer.id === firstSlice?.id
  }
  selectedField.value = defaultField(manifest)
  viewMode.value = manifest.layers.length > 0 || manifest.images.length === 0 ? '3d' : '2d'
}

// ----------------------------------------------------------------------
// vtk.js
// ----------------------------------------------------------------------
const containerRef = ref<HTMLDivElement | null>(null)
let renderWindow: GenericRenderWindow | null = null
let resizeObserver: ResizeObserver | null = null
let isDisposed = false
let hasResetCamera = false

const lookupTable = vtkColorTransferFunction.newInstance()
lookupTable.applyColorMap(vtkColorMaps.getPresetByName(COLOR_MAP_PRESET))

interface LoadedLayer {
  actor: Actor
  mapper: Mapper
  fields: string[]
}
const loaded = new Map<string, LoadedLayer>()
// Map trên không reactive -> đếm riêng để template biết đã có layer nào hiển thị chưa.
const loadedCount = ref(0)

function render(): void {
  renderWindow?.getRenderWindow().render()
}

// Cập nhật thang màu theo field đang chọn (range chung trên toàn miền từ manifest).
function applyLookupTable(): void {
  const info = selectedFieldInfo.value
  if (!info) return
  const [min, max] = info.range
  lookupTable.applyColorMap(vtkColorMaps.getPresetByName(COLOR_MAP_PRESET))
  lookupTable.setMappingRange(min, max === min ? min + 1e-6 : max)
  lookupTable.updateRange()
  if (info.components > 1) lookupTable.setVectorModeToMagnitude()
  else lookupTable.setVectorModeToComponent()
}

function styleLayer(layer: SGResultLayer, entry: LoadedLayer): void {
  const field = selectedField.value
  const hasField = !!field && entry.fields.includes(field)
  entry.mapper.setScalarVisibility(hasField)
  if (hasField) entry.mapper.setColorByArrayName(field)

  const property = entry.actor.getProperty()
  property.setColor(...NO_FIELD_COLOR)
  if (layer.type === 'surface') property.setOpacity(surfaceOpacity.value)
  if (layer.type === 'streamlines') property.setLineWidth(2)

  entry.actor.setVisibility(!!layerVisible[layer.id])
}

function restyleAll(): void {
  applyLookupTable()
  for (const layer of props.manifest.layers) {
    const entry = loaded.get(layer.id)
    if (entry) styleLayer(layer, entry)
  }
  render()
}

// Góc nhìn mặc định: nhìn chéo từ trên xuống, trục Z (chiều cao phòng) hướng lên.
function resetCamera(): void {
  if (!renderWindow) return
  const [xmin, xmax, ymin, ymax, zmin, zmax] = props.manifest.bounds
  const center: [number, number, number] = [(xmin + xmax) / 2, (ymin + ymax) / 2, (zmin + zmax) / 2]
  // Xoay quanh tâm phòng (kể cả sau khi đã kéo mô hình lệch khỏi giữa màn hình).
  interactorStyle?.setCenterOfRotation(center)
  const camera = renderWindow.getRenderer().getActiveCamera()
  camera.setFocalPoint(center[0], center[1], center[2])
  camera.setPosition(center[0] + 1, center[1] - 1.4, center[2] + 0.9)
  camera.setViewUp(0, 0, 1)
  renderWindow.getRenderer().resetCamera()
  render()
}

// ----------------------------------------------------------------------
// Thao tác chuột (giống sg_engr_obj_viewer):
//   - Chuột trái : xoay (mặc định) hoặc kéo/pan khi bật "Chế độ kéo"
//   - Shift + chuột trái, chuột giữa, chuột phải: luôn kéo/pan
//   - Con lăn    : phóng to / thu nhỏ
// Kéo dịch camera song song mặt phẳng màn hình -> không đổi góc nhìn.
// ----------------------------------------------------------------------
const MOUSE_BUTTON = { LEFT: 1, MIDDLE: 2, RIGHT: 3 } as const

const panMode = ref(false)
let interactorStyle: InteractorStyleManipulator | null = null

function makePan(button: number, shift = false) {
  const manipulator = vtkMouseCameraTrackballPanManipulator.newInstance()
  manipulator.setButton(button)
  manipulator.setShift(shift)
  return manipulator
}

function applyManipulators(): void {
  if (!interactorStyle) return
  interactorStyle.removeAllMouseManipulators()

  if (panMode.value) {
    interactorStyle.addMouseManipulator(makePan(MOUSE_BUTTON.LEFT))
  } else {
    const rotate = vtkMouseCameraTrackballRotateManipulator.newInstance()
    rotate.setButton(MOUSE_BUTTON.LEFT)
    interactorStyle.addMouseManipulator(rotate)
    interactorStyle.addMouseManipulator(makePan(MOUSE_BUTTON.LEFT, true))
  }
  interactorStyle.addMouseManipulator(makePan(MOUSE_BUTTON.MIDDLE))
  interactorStyle.addMouseManipulator(makePan(MOUSE_BUTTON.RIGHT))

  const zoom = vtkMouseCameraTrackballZoomManipulator.newInstance()
  zoom.setDragEnabled(false)
  zoom.setScrollEnabled(true)
  interactorStyle.addMouseManipulator(zoom)
}

function togglePanMode(): void {
  panMode.value = !panMode.value
  applyManipulators()
}

async function loadLayer(layer: SGResultLayer): Promise<void> {
  if (!renderWindow || loaded.has(layer.id) || layerLoading[layer.id]) return
  if (!layer.url) {
    layerError[layer.id] = 'Không có đường dẫn tải layer.'
    return
  }
  if (isPresignedUrlExpired(layer.url)) {
    emit('expired')
    return
  }

  const jobCode = props.manifest.job_code
  layerLoading[layer.id] = true
  delete layerError[layer.id]
  try {
    const res = await fetch(layer.url)
    if (!res.ok) {
      // 403 thường là URL hết hạn / sai chữ ký -> xin URL mới.
      if (res.status === 403) emit('expired')
      throw new Error(`HTTP ${res.status}`)
    }
    const buffer = await res.arrayBuffer()
    // Đã đổi job / huỷ component trong lúc chờ tải -> bỏ kết quả.
    if (isDisposed || !renderWindow || props.manifest.job_code !== jobCode) return

    const reader = vtkXMLPolyDataReader.newInstance()
    reader.parseAsArrayBuffer(buffer)
    const polyData = reader.getOutputData(0)

    const mapper = vtkMapper.newInstance({
      interpolateScalarsBeforeMapping: true,
      colorMode: ColorMode.MAP_SCALARS,
      scalarMode: ScalarMode.USE_POINT_FIELD_DATA,
      useLookupTableScalarRange: true
    })
    mapper.setLookupTable(lookupTable)
    mapper.setInputData(polyData)
    const actor = vtkActor.newInstance()
    actor.setMapper(mapper)

    const entry: LoadedLayer = { actor, mapper, fields: layer.fields }
    loaded.set(layer.id, entry)
    loadedCount.value = loaded.size
    styleLayer(layer, entry)
    renderWindow.getRenderer().addActor(actor)

    if (!hasResetCamera) {
      hasResetCamera = true
      resetCamera()
    } else {
      render()
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    layerError[layer.id] = `Không tải được layer: ${message}`
  } finally {
    delete layerLoading[layer.id]
  }
}

// Tải các layer đang bật mà chưa có dữ liệu.
function syncVisibleLayers(): void {
  for (const layer of props.manifest.layers) {
    if (layerVisible[layer.id]) loadLayer(layer)
  }
}

function clearLayers(): void {
  const renderer = renderWindow?.getRenderer()
  for (const entry of loaded.values()) {
    renderer?.removeActor(entry.actor)
    entry.actor.delete()
    entry.mapper.delete()
  }
  loaded.clear()
  loadedCount.value = 0
  hasResetCamera = false
  render()
}

function toggleLayer(layer: SGResultLayer): void {
  layerVisible[layer.id] = !layerVisible[layer.id]
  const entry = loaded.get(layer.id)
  if (entry) {
    entry.actor.setVisibility(layerVisible[layer.id])
    render()
  } else if (layerVisible[layer.id]) {
    loadLayer(layer)
  }
}

watch(selectedField, restyleAll)

watch(surfaceOpacity, (opacity) => {
  for (const layer of props.manifest.layers) {
    if (layer.type === 'surface') loaded.get(layer.id)?.actor.getProperty().setOpacity(opacity)
  }
  render()
})

// Manifest đổi: khác job -> dựng lại từ đầu; cùng job (chỉ làm mới presigned URL)
// -> giữ nguyên layer đã tải, chỉ tải tiếp các layer đang bật còn thiếu.
watch(
  () => props.manifest,
  (manifest, previous) => {
    if (!previous || manifest.job_code !== previous.job_code) {
      clearLayers()
      resetUiState(manifest)
    }
    if (viewMode.value === '3d') syncVisibleLayers()
  }
)

// Canvas vtk.js chỉ có kích thước thật khi tab 3D đang hiển thị.
watch(viewMode, (mode) => {
  if (mode !== '3d') return
  requestAnimationFrame(() => {
    renderWindow?.resize()
    syncVisibleLayers()
  })
})

// Dải màu chú giải: lấy mẫu chính lookupTable để khớp đúng màu trên mô hình.
const legendGradient = computed(() => {
  const info = selectedFieldInfo.value
  if (!info) return ''
  const [min, max] = info.range
  const stops: string[] = []
  const rgb: number[] = [0, 0, 0]
  for (let i = 0; i < LEGEND_STEPS; i++) {
    const t = i / (LEGEND_STEPS - 1)
    lookupTable.getColor(min + (max - min) * t, rgb)
    stops.push(
      `rgb(${Math.round(rgb[0] * 255)}, ${Math.round(rgb[1] * 255)}, ${Math.round(rgb[2] * 255)}) ${(t * 100).toFixed(1)}%`
    )
  }
  return `linear-gradient(to right, ${stops.join(', ')})`
})

function formatValue(value: number): string {
  const abs = Math.abs(value)
  if (abs !== 0 && (abs < 0.01 || abs >= 1e5)) return value.toExponential(2)
  return value.toFixed(2)
}

function imageName(file: string): string {
  return file.split('/').pop() ?? file
}

onMounted(() => {
  resetUiState(props.manifest)
  applyLookupTable()

  const container = containerRef.value
  if (!container) return
  renderWindow = vtkGenericRenderWindow.newInstance({
    background: [1, 1, 1],
    listenWindowResize: false
  })
  renderWindow.setContainer(container)
  renderWindow.resize()

  interactorStyle = vtkInteractorStyleManipulator.newInstance()
  applyManipulators()
  renderWindow.getInteractor().setInteractorStyle(interactorStyle)

  resizeObserver = new ResizeObserver(() => {
    renderWindow?.resize()
    render()
  })
  resizeObserver.observe(container)

  if (viewMode.value === '3d') syncVisibleLayers()
})

onBeforeUnmount(() => {
  isDisposed = true
  resizeObserver?.disconnect()
  resizeObserver = null
  // Lỗi khi dọn vtk.js không được lọt ra ngoài: ở chế độ dev Vue ném lại lỗi của
  // hook unmount, làm hỏng lần patch -> component thay thế (trình xem STL ở bước
  // "Khối hình học") không được mount.
  try {
    clearLayers()
    // Gỡ style khỏi interactor trước; GenericRenderWindow.delete() không huỷ
    // interactor nên huỷ riêng sau cùng (nó vẫn giữ listener visibilitychange).
    const interactor = renderWindow?.getInteractor()
    interactor?.setInteractorStyle(null as never)
    interactorStyle?.delete()
    renderWindow?.delete()
    interactor?.delete()
    lookupTable.delete()
  } catch (error) {
    // eslint-disable-next-line no-console
    console.error('[sg_engr_result_viewer] Lỗi khi giải phóng vtk.js:', error)
  }
  renderWindow = null
  interactorStyle = null
})
</script>

<template>
  <div class="relative h-full w-full">
    <!-- 3D: canvas vtk.js (giữ lại khi chuyển tab 2D để không phải tải lại layer) -->
    <!-- Chặn menu chuột phải để chuột phải dùng được cho thao tác kéo. -->
    <div
      v-show="viewMode === '3d'"
      ref="containerRef"
      class="h-full w-full"
      :class="panMode ? 'cursor-grab active:cursor-grabbing' : ''"
      @contextmenu.prevent
    ></div>

    <!-- 2D: ảnh mặt cắt -->
    <div v-if="viewMode === '2d'" class="h-full w-full overflow-y-auto p-4">
      <div
        v-if="manifest.images.length === 0"
        class="flex h-full items-center justify-center text-sm text-pmis-placeholder"
      >
        Không có ảnh 2D cho kết quả này
      </div>
      <div v-else class="grid gap-4">
        <figure
          v-for="image in manifest.images"
          :key="image.file"
          class="rounded-md border border-pmis-bordertab p-2"
        >
          <img
            v-if="image.url"
            :src="image.url"
            :alt="imageName(image.file)"
            class="mx-auto max-h-[70vh] object-contain"
          />
          <figcaption class="mt-1 text-center text-xs text-pmis-placeholder">
            {{ imageName(image.file) }}
          </figcaption>
        </figure>
      </div>
    </div>

    <div class="absolute right-3 top-3 flex items-center gap-2">
      <!-- Chuyển chế độ chuột trái: xoay <-> kéo. Chuột phải / giữa luôn kéo được. -->
      <button
        v-if="viewMode === '3d'"
        type="button"
        class="flex items-center gap-1.5 rounded-md bg-white/90 px-2.5 py-1.5 text-xs font-medium shadow transition hover:bg-white"
        :class="panMode ? 'text-pmis-primary' : 'text-pmis-text'"
        :title="
          panMode
            ? 'Đang bật chế độ kéo — giữ chuột trái để dịch chuyển mô hình (không đổi góc nhìn)'
            : 'Bật chế độ kéo mô hình (hoặc giữ Shift / chuột phải để kéo)'
        "
        @click="togglePanMode"
      >
        <component :is="panMode ? Hand : Rotate3d" class="h-4 w-4" />
        {{ panMode ? 'Chế độ kéo' : 'Chế độ xoay' }}
      </button>

      <!-- Chuyển 3D / 2D -->
      <div class="flex overflow-hidden rounded-md bg-white/90 text-xs shadow">
        <button
          type="button"
          class="flex items-center gap-1.5 px-2.5 py-1.5 font-medium transition"
          :class="viewMode === '3d' ? 'bg-pmis-primary-100 text-pmis-primary' : 'text-pmis-text'"
          :disabled="manifest.layers.length === 0"
          @click="viewMode = '3d'"
        >
          <Box class="h-4 w-4" />
          3D
        </button>
        <button
          type="button"
          class="flex items-center gap-1.5 px-2.5 py-1.5 font-medium transition"
          :class="viewMode === '2d' ? 'bg-pmis-primary-100 text-pmis-primary' : 'text-pmis-text'"
          @click="viewMode = '2d'"
        >
          <ImageIcon class="h-4 w-4" />
          2D
        </button>
      </div>
    </div>

    <!-- Bảng điều khiển 3D: field, layer, độ trong suốt bề mặt -->
    <div
      v-if="viewMode === '3d'"
      class="absolute left-3 top-3 flex max-h-[calc(100%-6rem)] w-64 flex-col gap-3 overflow-y-auto rounded-md bg-white/90 p-3 text-xs shadow"
    >
      <label class="flex flex-col gap-1">
        <span class="font-semibold text-pmis-text">Trường hiển thị</span>
        <select v-model="selectedField" class="sg-select text-xs">
          <option v-for="option in fieldOptions" :key="option.name" :value="option.name">
            {{ option.label }}
          </option>
        </select>
      </label>

      <div v-for="group in layerGroups" :key="group.type" class="flex flex-col gap-1">
        <span class="font-semibold text-pmis-text">{{ group.label }}</span>
        <label
          v-for="layer in group.layers"
          :key="layer.id"
          class="flex cursor-pointer items-center gap-2 text-pmis-label"
          :title="layerError[layer.id] || layer.name"
        >
          <input type="checkbox" :checked="!!layerVisible[layer.id]" @change="toggleLayer(layer)" />
          <span class="flex-1 truncate" :class="{ 'text-pmis-danger': layerError[layer.id] }">
            {{ layer.name }}
          </span>
          <Loader2
            v-if="layerLoading[layer.id]"
            class="h-3.5 w-3.5 shrink-0 animate-spin text-pmis-primary"
          />
        </label>

        <label v-if="group.type === 'surface'" class="mt-1 flex items-center gap-2">
          <span class="shrink-0 text-pmis-label">Độ đục</span>
          <input
            v-model.number="surfaceOpacity"
            type="range"
            min="0"
            max="1"
            step="0.05"
            class="flex-1"
          />
          <span class="w-8 text-right text-pmis-label"
            >{{ Math.round(surfaceOpacity * 100) }}%</span
          >
        </label>
      </div>

      <button type="button" class="sg-button-secondary justify-center text-xs" @click="resetCamera">
        Đặt lại góc nhìn
      </button>
    </div>

    <!-- Chú giải thang màu -->
    <div
      v-if="viewMode === '3d' && selectedFieldInfo"
      class="pointer-events-none absolute bottom-3 left-1/2 w-80 -translate-x-1/2 rounded-md bg-white/90 px-3 py-2 text-xs shadow"
    >
      <div class="mb-1 text-center font-semibold text-pmis-text">
        {{ selectedFieldInfo.label }} ({{ selectedFieldInfo.unit }})
      </div>
      <div class="h-3 w-full rounded-sm" :style="{ background: legendGradient }"></div>
      <div class="mt-0.5 flex justify-between text-pmis-label">
        <span>{{ formatValue(selectedFieldInfo.range[0]) }}</span>
        <span>{{ formatValue(selectedFieldInfo.range[1]) }}</span>
      </div>
    </div>

    <div
      v-if="viewMode === '3d' && isAnyLayerLoading && loadedCount === 0"
      class="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-white/60"
    >
      <Loader2 class="h-8 w-8 animate-spin text-pmis-primary" />
      <p class="text-sm text-pmis-placeholder">Đang tải kết quả mô phỏng...</p>
    </div>
  </div>
</template>

<style scoped></style>
