<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import {
  Search,
  FunnelPlus,
  FunnelX,
  Plus,
  Eye,
  Pencil,
  Trash2,
  LoaderCircle
} from 'lucide-vue-next'
import sg_input_text from '@/components/base/sg_input_text.vue'
import sg_select from '@/components/base/sg_select.vue'
import sg_pagination from '@/components/base/sg_pagination.vue'
import sg_message_box from '@/components/base/sg_message_box.vue'
import sg_engr_cust_add from '@/features/patient/modals/sg_engr_cust_add.vue'
import sg_engr_cust_edit from '@/features/patient/modals/sg_engr_cust_edit.vue'
import { getCustomerPaged, deleteCustomer } from '@/services/sg_customer_srv'
import { useToast } from '@/utils/sg_use_toast'
import { PAGE_SIZE_OPTIONS } from '@/options/sg_site_option'
import type { SGCustomerRead, SGCustomerPagedParams } from '@/types/sg_customer'
import type { MsgBoxOptions, MsgType } from '@/types/sg_msg_box.types'

// ======================================================================
// Trang "Danh sách khách hàng" — layout chia 4 vùng theo chiều dọc:
//   Vùng 1 (Header)   — tiêu đề + nút "Thêm mới"
//   Vùng 2 (Bộ lọc)   — 2 dòng điều kiện lọc
//   Vùng 3 (Danh sách)— bảng khách hàng
//   Vùng 4 (Phân trang)
// Danh sách được tải từ backend qua getCustomerPaged() — lọc & phân trang phía server.
// ======================================================================

interface Customer {
  id: string
  name: string
  address: string
  phone: string
  email: string
}

const toast = useToast()

const customers = ref<Customer[]>([])

// Bản ghi gốc trả về từ backend — dùng để mở modal "Sửa khách hàng" (SGCustomerRead).
const customerRecords = ref<SGCustomerRead[]>([])

// Ánh xạ bản ghi trả về từ backend (SGCustomerRead) sang model hiển thị của bảng.
function toCustomer(record: SGCustomerRead): Customer {
  return {
    id: `KH${String(record.customer_id).padStart(3, '0')}`,
    name: record.customer_name,
    address: record.addr,
    phone: record.phone ?? '',
    email: record.email ?? ''
  }
}

// --- Vùng 2: điều kiện lọc + tham số phân trang ---
// Giá trị đang gõ trong các ô nhập liệu + trang / số dòng gửi lên backend.
// Dùng thẳng kiểu tham số của backend (SGCustomerPagedParams).
const filterForm = reactive<SGCustomerPagedParams>({
  page: 1,
  page_size: 10,
  customer_name: '',
  addr: '',
  phone: '',
  email: ''
})

// Tổng số bản ghi / tổng số trang do backend trả về.
const totalItems = ref(0)
const totalPages = ref(1)

// Bật sẵn khi mới vào trang để không lóe lên "Không có khách hàng phù hợp."
// trong khoảng chờ tải danh sách lần đầu.
const loading = ref(true)

// Tải danh sách khách hàng có phân trang từ backend theo filterForm.
async function loadCustomers(): Promise<void> {
  loading.value = true
  try {
    const res = await getCustomerPaged({
      page: filterForm.page,
      page_size: filterForm.page_size,
      customer_name: filterForm.customer_name?.trim() || null,
      addr: filterForm.addr?.trim() || null,
      phone: filterForm.phone?.trim() || null,
      email: filterForm.email?.trim() || null
    })

    customerRecords.value = res.items
    customers.value = res.items.map(toCustomer)
    totalItems.value = res.total
    totalPages.value = Math.max(1, res.total_pages)

    // Trang hiện tại vượt quá tổng số trang (vd sau khi xóa dòng cuối) -> lùi lại và tải lại.
    if (filterForm.page > totalPages.value) {
      filterForm.page = totalPages.value
      await loadCustomers()
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể tải danh sách khách hàng.'
    toast.error(message)
  } finally {
    loading.value = false
  }
}

onMounted(loadCustomers)

// Nút "Filter" bật/tắt hiển thị các ô lọc ở Dòng 2 (Địa chỉ / Điện thoại / Email).
//   showAdvancedFilter = true  -> hiện Dòng 2, icon FunnelX  (bấm để ẩn)
//   showAdvancedFilter = false -> ẩn Dòng 2, icon FunnelPlus (bấm để hiện)
const showAdvancedFilter = ref(true)

function toggleAdvancedFilter(): void {
  showAdvancedFilter.value = !showAdvancedFilter.value

  // Khi ẩn Dòng 2, xóa điều kiện lọc rồi tải lại từ trang 1.
  if (!showAdvancedFilter.value) {
    filterForm.addr = ''
    filterForm.phone = ''
    filterForm.email = ''
    filterForm.page = 1
    void loadCustomers()
  }
}

// Áp dụng điều kiện lọc — gọi khi nhấn "Enter" trong ô nhập liệu bất kỳ,
// bấm icon tìm kiếm hoặc bấm nút Filter. Luôn quay về trang 1.
function applyFilter(): void {
  filterForm.page = 1
  void loadCustomers()
}

function changePageSize(): void {
  filterForm.page = 1
  void loadCustomers()
}

function changePage(page: number): void {
  filterForm.page = page
  void loadCustomers()
}

// --- Vùng 1 / Vùng 3: thao tác (mock) ---
// Trạng thái hiển thị modal "Thêm mới khách hàng".
const showAddModal = ref(false)

function onCreate(): void {
  showAddModal.value = true
}

function onCloseAddModal(): void {
  showAddModal.value = false
}

async function onCustomerSaved(): Promise<void> {
  // Modal đã gọi API thành công — giữ nguyên trang hiện hành và tải lại danh sách.
  // loadCustomers() tự chuyển về trang cuối nếu trang hiện hành vượt quá tổng số trang.
  await loadCustomers()
  showAddModal.value = false
}

function onView(customer: Customer): void {
  // TODO: xem chi tiết khách hàng
  void customer
}

// Trạng thái + dữ liệu cho modal "Sửa khách hàng".
const showEditModal = ref(false)
const editingCustomer = ref<SGCustomerRead | null>(null)

function onEdit(customer: Customer): void {
  // customer.id có dạng "KH003" -> tách lấy số để tìm bản ghi gốc.
  const customerId = Number(customer.id.replace(/\D/g, ''))
  const record = customerRecords.value.find((r) => r.customer_id === customerId)
  if (!record) {
    toast.error('Không tìm thấy thông tin khách hàng.')
    return
  }

  editingCustomer.value = { ...record }
  showEditModal.value = true
}

function onCloseEditModal(): void {
  showEditModal.value = false
  editingCustomer.value = null
}

// Modal "Sửa khách hàng" đã gọi API updateCustomer thành công và phát bản ghi
// SGCustomerRead mới — cập nhật lại danh sách rồi đóng modal.
async function onEditModalSaved(updated: SGCustomerRead): Promise<void> {
  void updated
  onCloseEditModal()
  await loadCustomers()
}

// --- Xóa khách hàng ---
// Một hộp thoại dùng chung: hỏi xác nhận trước khi xóa, và báo lỗi nếu API thất bại.
const msgBox = reactive<MsgBoxOptions>({
  show: false,
  type: 'confirm',
  title: '',
  message: '',
  text_ok: 'Xóa',
  text_cancel: 'Hủy',
  show_ok: true,
  show_cancel: true
})

// Chế độ hiện tại của hộp thoại: 'confirm' = đang hỏi xóa, 'error' = đang báo lỗi / thông báo.
const msgBoxMode = ref<'confirm' | 'error'>('confirm')

// Khách hàng đang chờ xác nhận xóa.
const deletingCustomer = ref<SGCustomerRead | null>(null)
const deleting = ref(false)

// Mở hộp thoại ở chế độ "thông báo": chỉ 1 nút OK.
// Luôn set đủ cả 3 cờ nút để không bị dính giá trị cũ từ lần mở trước (msgBox dùng chung).
function openInfoBox(title: string, message: string, type: MsgType = 'info'): void {
  deletingCustomer.value = null
  msgBoxMode.value = 'error' // onMsgBoxOk / onMsgBoxCancel chỉ đóng hộp thoại
  msgBox.type = type
  msgBox.title = title
  msgBox.message = message
  msgBox.text_ok = 'OK'
  msgBox.show_ok = true
  msgBox.show_danger = false
  msgBox.show_cancel = false
  msgBox.show = true
}

function onDelete(customer: Customer): void {
  // customer.id có dạng "KH003" -> tách lấy số để tìm bản ghi gốc.
  const customerId = Number(customer.id.replace(/\D/g, ''))
  const record = customerRecords.value.find((r) => r.customer_id === customerId)
  if (!record) {
    toast.error('Không tìm thấy thông tin khách hàng.')
    return
  }

  // 1. Hỏi xác nhận trước khi xóa — set đủ cả 3 cờ nút.
  deletingCustomer.value = record
  msgBoxMode.value = 'confirm'
  msgBox.type = 'confirm'
  msgBox.title = 'Xác nhận xóa'
  msgBox.message = `Bạn có chắc chắn muốn xóa khách hàng "${record.customer_name}" không?`
  msgBox.text_ok = 'Xóa'
  msgBox.text_cancel = 'Hủy'
  msgBox.show_ok = true
  msgBox.show_danger = false
  msgBox.show_cancel = true
  msgBox.show = true
}

function onMsgBoxCancel(): void {
  msgBox.show = false
  if (msgBoxMode.value === 'confirm') deletingCustomer.value = null
}

async function onMsgBoxOk(): Promise<void> {
  // Đang ở chế độ báo lỗi -> chỉ đóng hộp thoại.
  if (msgBoxMode.value === 'error') {
    msgBox.show = false
    return
  }

  // Chế độ xác nhận -> tiến hành xóa.
  const record = deletingCustomer.value
  if (!record || deleting.value) return

  deleting.value = true
  try {
    // 2. Gọi API xóa khách hàng.
    await deleteCustomer(record.customer_id)

    // 3. Thành công: đóng hộp thoại, thông báo và tải lại danh sách.
    msgBox.show = false
    deletingCustomer.value = null
    toast.success('Xóa khách hàng thành công.')
    // loadCustomers() tự lùi trang nếu trang hiện tại vượt quá tổng số trang sau khi xóa.
    await loadCustomers()
  } catch (error) {
    // 4. Lỗi: chuyển hộp thoại sang chế độ báo lỗi (chỉ 1 nút OK).
    const message = error instanceof Error ? error.message : 'Không thể xóa khách hàng.'
    openInfoBox('Lỗi', message, 'error')
  } finally {
    deleting.value = false
  }
}
</script>

<template>
  <div class="flex h-full w-full flex-col gap-4">
    <!-- ============================================================ -->
    <!-- Vùng 1: Header -->
    <!-- ============================================================ -->
    <header class="flex shrink-0 items-center justify-between gap-4">
      <h1 class="sg-title-page uppercase text-lg">Danh sách khách hàng</h1>

      <button type="button" class="sg-button-primary" @click="onCreate">
        <Plus class="h-4 w-4" />
        <span>Thêm mới</span>
      </button>
    </header>

    <!-- ============================================================ -->
    <!-- Vùng 2: Điều kiện lọc -->
    <!-- ============================================================ -->
    <section class="flex shrink-0 flex-col gap-3">
      <!-- Dòng 1 -->
      <div class="flex items-center justify-between gap-3">
        <div class="flex items-center gap-2">
          <div class="w-72">
            <sg_input_text
              v-model="filterForm.customer_name"
              placeholder="Tìm kiếm theo tên khách hàng"
              input-c-s-s="py-1 sg-input w-full"
              :iconright="Search"
              @enter="applyFilter"
              @icon-right-click="applyFilter"
            />
          </div>

          <button
            type="button"
            class="sg-button-filter"
            :title="showAdvancedFilter ? 'Ẩn bộ lọc' : 'Hiện bộ lọc'"
            @click="toggleAdvancedFilter"
          >
            <FunnelX v-if="showAdvancedFilter" class="h-5 w-5" />
            <FunnelPlus v-else class="h-5 w-5" />
          </button>
        </div>

        <div class="w-48 shrink-0">
          <sg_select
            v-model="filterForm.page_size"
            :items="PAGE_SIZE_OPTIONS"
            :show-add="false"
            :show-edit="false"
            :show-delete="false"
            placeholder="Số dòng / trang"
            @on-change="changePageSize"
          />
        </div>
      </div>

      <!-- Dòng 2 -->
      <div v-if="showAdvancedFilter" class="flex items-center gap-3">
        <sg_input_text
          v-model="filterForm.addr"
          placeholder="Địa chỉ"
          input-c-s-s="py-1 sg-input w-full"
          @enter="applyFilter"
        />
        <sg_input_text
          v-model="filterForm.phone"
          placeholder="Điện thoại"
          input-c-s-s="py-1 sg-input w-full"
          @enter="applyFilter"
        />
        <sg_input_text
          v-model="filterForm.email"
          placeholder="Email"
          input-c-s-s="py-1 sg-input w-full"
          @enter="applyFilter"
        />
      </div>
    </section>

    <!-- ============================================================ -->
    <!-- Vùng 3: Danh sách khách hàng -->
    <!-- ============================================================ -->
    <section class="min-h-0 flex-1 overflow-auto sg-table-wrapper">
      <table class="w-full border-collapse text-sm">
        <thead class="sticky top-0 z-10 bg-slate-50 text-left text-pmis-label">
          <tr>
            <th class="py-3 px-4 border-b border-gray-200 font-semibold" style="min-width: 200px">
              Tên khách hàng
            </th>
            <th class="py-3 px-4 border-b border-gray-200 font-semibold" style="min-width: 200px">
              Địa chỉ
            </th>
            <th class="py-3 px-4 border-b border-gray-200 font-semibold" style="width: 120px">
              Điện thoại
            </th>
            <th class="py-3 px-4 border-b border-gray-200 font-semibold" style="width: 120px">
              Email
            </th>
            <th class="py-3 px-4 border-b border-gray-200 font-semibold" style="width: 120px">
              Thao tác
            </th>
          </tr>
        </thead>

        <tbody>
          <!-- Đang tải dữ liệu từ backend -->
          <tr v-if="loading">
            <td colspan="5" class="py-8 text-center text-pmis-placeholder">
              <span class="inline-flex items-center gap-2">
                <LoaderCircle class="h-6 w-6 animate-spin" />
                Đang tải dữ liệu...
              </span>
            </td>
          </tr>

          <tr
            v-for="customer in customers"
            v-show="!loading"
            :key="customer.id"
            class="hover:bg-pmis-primary-50/50"
          >
            <td class="py-3 px-4 border-b border-gray-200" style="min-width: 200px">
              {{ customer.name }}
            </td>
            <td class="py-3 px-4 border-b border-gray-200" style="min-width: 200px">
              {{ customer.address }}
            </td>
            <td class="py-3 px-4 border-b border-gray-200" style="width: 120px">
              {{ customer.phone }}
            </td>
            <td class="py-3 px-4 border-b border-gray-200 truncate" style="width: 120px">
              {{ customer.email }}
            </td>
            <td class="py-3 px-4 border-b border-gray-200" style="width: 120px">
              <div class="flex items-center gap-3">
                <button
                  type="button"
                  class="sg-button-only-icon"
                  title="Xem"
                  @click="onView(customer)"
                >
                  <Eye class="h-4 w-4" />
                </button>
                <button
                  type="button"
                  class="sg-button-only-icon"
                  title="Sửa"
                  @click="onEdit(customer)"
                >
                  <Pencil class="h-4 w-4" />
                </button>
                <button
                  type="button"
                  class="sg-button-only-icon-del"
                  title="Xóa"
                  @click="onDelete(customer)"
                >
                  <Trash2 class="h-4 w-4" />
                </button>
              </div>
            </td>
          </tr>

          <tr v-if="!loading && customers.length === 0">
            <td colspan="5" class="py-8 text-center text-pmis-placeholder">
              Không có khách hàng phù hợp.
            </td>
          </tr>
        </tbody>
      </table>
    </section>

    <!-- ============================================================ -->
    <!-- Vùng 4: Phân trang (nằm bên trái) -->
    <!-- ============================================================ -->
    <footer class="flex shrink-0 items-center justify-start">
      <sg_pagination
        :curr-page="filterForm.page"
        :total-pages="totalPages"
        :total-items="totalItems"
        :page-size="filterForm.page_size"
        item-name="khách hàng"
        @update:page="changePage"
      />
    </footer>

    <!-- ============================================================ -->
    <!-- Modal: Thêm mới khách hàng -->
    <!-- ============================================================ -->
    <sg_engr_cust_add :open="showAddModal" @close="onCloseAddModal" @saved="onCustomerSaved" />

    <!-- ============================================================ -->
    <!-- Modal: Sửa khách hàng -->
    <!-- ============================================================ -->
    <sg_engr_cust_edit
      :open="showEditModal"
      :customer="editingCustomer"
      @close="onCloseEditModal"
      @saved="onEditModalSaved"
    />

    <!-- ============================================================ -->
    <!-- Hộp thoại: xác nhận xóa / báo lỗi khi xóa -->
    <!-- ============================================================ -->
    <sg_message_box
      :show="msgBox.show"
      :type="msgBox.type"
      :title="msgBox.title"
      :message="msgBox.message"
      :text_ok="msgBox.text_ok"
      :text_cancel="msgBox.text_cancel"
      :show_ok="msgBox.show_ok"
      :show_cancel="msgBox.show_cancel"
      @ok="onMsgBoxOk"
      @cancel="onMsgBoxCancel"
    />
  </div>
</template>

<style scoped></style>
