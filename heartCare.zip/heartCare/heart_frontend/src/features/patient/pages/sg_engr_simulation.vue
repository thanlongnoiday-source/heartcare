<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, reactive, ref, watch } from 'vue'
import {
  ChevronDown,
  ChevronRight,
  Download,
  LoaderCircle,
  Cuboid,
  Play,
  Plus,
  Square,
  Trash2,
  Wind
} from 'lucide-vue-next'
import sg_message_box from '@/components/base/sg_message_box.vue'
import sg_engr_geometry_add from '@/features/patient/modals/sg_engr_geometry_add.vue'
import sg_engr_geometry_edit from '@/features/patient/layouts/sg_engr_geometry_edit.vue'
import sg_engr_obj_viewer from '@/features/patient/components/sg_engr_obj_viewer.vue'
import {
  GEOMETRY_PART_KIND_LABEL,
  type GeometryPartKind,
  type FaceEditKind,
  type InletBlock,
  type OutletBlock,
  type ObjFaceSelection
} from '@/types/sg_face_type'
import sg_engr_inlet_edit from '@/features/patient/layouts/sg_engr_inlet_edit.vue'
import sg_engr_outlet_edit from '@/features/patient/layouts/sg_engr_outlet_edit.vue'
import sg_engr_wall_edit from '@/features/patient/layouts/sg_engr_wall_edit.vue'
import sg_engr_inlet_modal from '@/features/patient/modals/sg_engr_inlet_add.vue'
import sg_engr_outlet_modal from '@/features/patient/modals/sg_engr_outlet_add.vue'
import sg_engr_wall_modal from '@/features/patient/modals/sg_engr_wall_add.vue'
import sg_engr_result_viewer from '@/features/patient/components/sg_engr_result_viewer.vue'
import type { SGProjectRead } from '@/types/sg_project'
import type { SGJobProgressMessage, SGJobRead, SGJobResultsRead } from '@/types/sg_job'
import type { SGGeometryRead, SGGeometryUpdate } from '@/types/sg_geometry'
import type { SGInletCreate, SGInletRead, SGInletUpdate } from '@/types/sg_inlet'
import type { SGOutletCreate, SGOutletRead, SGOutletUpdate } from '@/types/sg_outlet'
import type { SGWallCreate, SGWallRead, SGWallUpdate } from '@/types/sg_wall'
import type { MsgBoxOptions } from '@/types/sg_msg_box.types'
import {
  buildBlockMeshDictWithOpenings,
  // checkMesh,
  deleteGeometry,
  getGeometryByproject,
  getGeometryStl,
  runSimulation,
  stopSimulation,
  updateGeometry
} from '@/services/sg_geometry_srv'
import {
  createInlet,
  deleteInlet,
  getInletsByGeometry,
  newSGInletCreate,
  updateInlet
} from '@/services/sg_inlet_srv'
import {
  createOutlet,
  deleteOutlet,
  getOutletsByGeometry,
  newSGOutletCreate,
  updateOutlet
} from '@/services/sg_outlet_srv'
import {
  createWall,
  deleteWall,
  getWallsByGeometry,
  newSGWallCreate,
  updateWall
} from '@/services/sg_wall_srv'
import { getJob, getJobResults, getJobsByGeometry } from '@/services/sg_job_srv'
import {
  connectJobProgress,
  isProgressFailed,
  isProgressSuccess,
  type JobProgressSocket
} from '@/services/sg_job_ws_srv'
import { useToast } from '@/utils/sg_use_toast'
import { formatNumber, roundDecimal } from '@/utils/sg_formatters'
import { isPresignedUrlExpired } from '@/utils/sg_presigned_url'
import { GEOMETRY_STATUS } from '@/constants/sg_engr_geometry_const'
import { JOB_STATUS, getJobStageLabel, getJobStatusLabel } from '@/constants/sg_engr_job_const'
import { ENV } from '@/config/env'

// ======================================================================
// Trang "Khối hình học" (mô phỏng CFD) — layout chia 2 vùng theo chiều dọc:
//   Vùng 1 (Header) — tiêu đề + nút "Chạy mô phỏng"
//   Vùng 2 (Body)   — chia 3 vùng con theo chiều ngang:
//     - Trái  : form nhập liệu cho thiết bị tương ứng
//     - Giữa  : hiển thị mô hình 3D (rộng full, flex-1)
//     - Phải  : menu Sidebar, rộng cố định 400px
// Đây là khung cấu trúc — nội dung chi tiết từng vùng sẽ được bổ sung sau.
// ======================================================================

// Dự án đang mô phỏng — truyền vào khi bấm icon "Mô phỏng" trên danh sách dự án
// (sg_engr_project_list.vue -> sg_engr_main.vue).
const props = defineProps<{
  project: SGProjectRead
}>()

// Danh sách geometry thuộc dự án đang mô phỏng.
const geometryList = ref<SGGeometryRead[]>([])
const isLoadingGeometry = ref(false)

// Menu Sidebar (2 cấp): cấp 1 "Khối hình học" (menu tĩnh, đóng/mở được),
// cấp 2 là danh sách geometry_code lấy từ geometryList (tương tác được).
const isGeometryGroupExpanded = ref(true)
const selectedGeometryId = ref<number | null>(null)

// Ba menu cấp 1, mỗi loại một menu riêng: Miệng cấp / Miệng xả / Tường.
const partGroupExpanded = reactive<Record<GeometryPartKind, boolean>>({
  supply: true,
  return: true,
  obstacle: true
})

function toggleGeometryGroup(): void {
  isGeometryGroupExpanded.value = !isGeometryGroupExpanded.value
}

function selectGeometry(geometryId: number): void {
  selectedGeometryId.value = geometryId
  refreshGeometryStlIfExpired()
  // Đang ở bước "Kết quả" -> nạp kết quả mô phỏng của geometry vừa bấm.
  if (isResultStepActive.value) loadResults(geometryId)
  // Rời khỏi luồng "chọn mặt": bỏ chọn để vùng bên phải nạp lại
  // sg_engr_geometry_edit của geometry vừa bấm.
  if (selectedFace.value) {
    objViewerRef.value?.clearFaceSelection()
    selectedFace.value = null
  }
  selectedInletId.value = null
  selectedOutletId.value = null
  selectedWallId.value = null
}

// Geometry đang được chọn trên Sidebar — truyền sang panel "Các thuộc tính" bên phải.
const selectedGeometry = computed<SGGeometryRead | undefined>(() =>
  geometryList.value.find((geometry) => geometry.geometry_id === selectedGeometryId.value)
)

// URL tuyệt đối tới file hình học geometry.stl của geometry đang chọn — trình xem 3D
// (sg_engr_obj_viewer) dựa vào đây để render mô hình lên viewport.
// STL nằm theo job ({project}/{geometry}/{job_code}/geometry.stl) nên lấy qua
// GET /geometrys/get-geometry-stl với job mới nhất của geometry (job tạo sẵn trong
// create_geometry, cũng là job mà run_simulation dùng). Backend trả presigned URL
// S3/MinIO (ngắn hạn) -> trình duyệt tải thẳng từ S3, không đi qua FastAPI.
const geometryObjUrl = ref<string | null>(null)
// geometry_id ứng với geometryObjUrl hiện tại.
let stlGeometryId: number | null = null
// Mỗi lần nạp tăng token -> bỏ qua response của lần chọn trước nếu về muộn.
let stlRequestToken = 0

async function loadGeometryStl(geometryId: number | null): Promise<void> {
  const token = ++stlRequestToken
  // Đổi geometry -> xoá mô hình cũ ngay; cùng geometry (ký lại URL) -> giữ viewer.
  if (geometryId !== stlGeometryId) {
    geometryObjUrl.value = null
    stlGeometryId = geometryId
  }
  if (geometryId === null) return

  try {
    const jobs = await getJobsByGeometry(geometryId)
    if (token !== stlRequestToken) return
    const latestJob = jobs.reduce<SGJobRead | undefined>(
      (latest, job) => (!latest || job.job_id > latest.job_id ? job : latest),
      undefined
    )
    if (!latestJob) {
      geometryObjUrl.value = null
      return
    }

    const stlUrl = await getGeometryStl(geometryId, latestJob.job_id)
    if (token !== stlRequestToken) return
    geometryObjUrl.value = stlUrl ? buildStaticFileUrl(stlUrl) : null
  } catch (error) {
    if (token !== stlRequestToken) return
    geometryObjUrl.value = null
    const message = error instanceof Error ? error.message : 'Không thể tải file hình học (.stl).'
    showError(message)
  }
}

watch(selectedGeometryId, (id) => loadGeometryStl(id), { immediate: true })

// Presigned URL hết hạn (user mở trang lâu) -> gọi lại API để backend ký URL mới.
async function refreshGeometryStlIfExpired(): Promise<void> {
  const geometryId = selectedGeometryId.value
  // Geometry vừa đổi -> watch ở trên đang nạp URL mới, không cần làm mới.
  if (geometryId === null || geometryId !== stlGeometryId) return
  if (geometryObjUrl.value && !isPresignedUrlExpired(geometryObjUrl.value)) return
  await loadGeometryStl(geometryId)
}

// Thay bản ghi geometry trong danh sách.
function replaceGeometry(updated: SGGeometryRead): void {
  const index = geometryList.value.findIndex((g) => g.geometry_id === updated.geometry_id)
  if (index !== -1) geometryList.value[index] = updated
}

// Modal "Thêm khối hình học".
const showGeometryAdd = ref(false)

function onAddGeometry(): void {
  showGeometryAdd.value = true
}

// Ghép URL tuyệt đối tới file tĩnh (STL/ảnh...) từ đường dẫn tương đối backend trả về.
function buildStaticFileUrl(relativePath: string): string {
  if (/^https?:\/\//i.test(relativePath)) return relativePath

  const base = String(ENV.API_URL ?? '').replace(/\/+$/, '')
  const path = relativePath.replace(/^\/+/, '')

  return base ? `${base}/${path}` : `/${path}`
}

function onGeometryAdded(geometry: SGGeometryRead): void {
  geometryList.value.push(geometry)
  // Chọn geometry vừa thêm -> watch(selectedGeometryId) gọi getGeometryStl lấy
  // presigned URL của STL, viewport tự render.
  selectedGeometryId.value = geometry.geometry_id
}

const toast = useToast()

// Lưu thay đổi thuộc tính geometry từ panel bên phải.
async function onSaveGeometry(payload: SGGeometryUpdate): Promise<void> {
  if (selectedGeometryId.value === null) return
  try {
    const updated = await updateGeometry(selectedGeometryId.value, payload)
    replaceGeometry(updated)
    toast.success('Cập nhật thuộc tính khối hình học thành công.')
  } catch (error) {
    const message =
      error instanceof Error ? error.message : 'Không thể cập nhật thuộc tính khối hình học.'
    showError(message)
  }
}

// Hộp thoại dùng chung cho báo lỗi và xác nhận xóa.
const msgBox = reactive<MsgBoxOptions>({
  show: false,
  type: 'error',
  title: 'Lỗi',
  message: '',
  text_ok: 'OK',
  text_cancel: 'Hủy',
  show_ok: true,
  show_cancel: false
})

// geometry_id đang chờ xác nhận xóa (null = hộp thoại không phải luồng xóa).
const pendingDeleteId = ref<number | null>(null)

function showError(message: string): void {
  pendingDeleteId.value = null
  msgBox.type = 'error'
  msgBox.title = 'Lỗi'
  msgBox.message = message
  msgBox.text_ok = 'OK'
  msgBox.show_ok = true
  msgBox.show_cancel = false
  msgBox.show = true
}

// Nhấn "Xóa" trên panel thuộc tính -> mở hộp thoại xác nhận.
function confirmDeleteGeometry(geometryId: number): void {
  const geometry = geometryList.value.find((g) => g.geometry_id === geometryId)
  if (!geometry) return
  if (geometry.geometry_status !== GEOMETRY_STATUS.DRAFT) {
    showError('Chỉ có thể xóa khối hình học ở trạng thái "Nháp".')
    return
  }

  pendingDeleteId.value = geometryId
  msgBox.type = 'confirm'
  msgBox.title = 'Xác nhận xóa'
  msgBox.message = `Xóa khối hình học "${geometry.geometry_code}"? Hành động này không thể hoàn tác.`
  msgBox.text_ok = 'Xóa'
  msgBox.show_ok = true
  msgBox.show_cancel = true
  msgBox.show = true
}

async function performDeleteGeometry(geometryId: number): Promise<void> {
  const geometry = geometryList.value.find((g) => g.geometry_id === geometryId)
  if (!geometry) return
  if (geometry.geometry_status !== GEOMETRY_STATUS.DRAFT) {
    showError('Chỉ có thể xóa khối hình học ở trạng thái "Nháp".')
    return
  }

  try {
    await deleteGeometry(geometryId)
    geometryList.value = geometryList.value.filter((g) => g.geometry_id !== geometryId)
    if (selectedGeometryId.value === geometryId) selectedGeometryId.value = null
    toast.success('Xóa khối hình học thành công.')
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể xóa khối hình học.'
    showError(message)
  }
}

function onMsgBoxOk(): void {
  const id = pendingDeleteId.value
  pendingDeleteId.value = null
  msgBox.show = false
  if (id !== null) performDeleteGeometry(id)
}

function onMsgBoxCancel(): void {
  pendingDeleteId.value = null
  msgBox.show = false
}

async function loadGeometryList(): Promise<void> {
  isLoadingGeometry.value = true
  try {
    geometryList.value = await getGeometryByproject(props.project.project_id)
  } catch (error) {
    const message =
      error instanceof Error ? error.message : 'Không thể tải danh sách geometry của dự án.'
    showError(message)
  } finally {
    isLoadingGeometry.value = false
  }
}

onMounted(() => {
  loadGeometryList()
})

// ====================================================================
// Log trạng thái từ Gateway (vùng dưới viewport 3D)
// Ghi lại phản hồi của /block-mesh-dict, /run-simulation, rồi theo dõi job:
//   - Chính: WebSocket ws /api/v1/jobs/{job_id}/ws (sg_job_ws_srv) — gateway phát
//     progress %, iteration, residuals theo thời gian thực.
//   - Dự phòng (WS không kết nối được): polling GET /jobs/by-id/{job_id} —
//     job_status/job_stage/job_pct do sg_job_monitor_srv cập nhật (~5s/lần).
// ====================================================================
type LogLevel = 'info' | 'success' | 'error'

interface StatusLogEntry {
  id: number
  time: string
  level: LogLevel
  message: string
}

const LOG_LEVEL_CLASS: Record<LogLevel, string> = {
  info: 'text-slate-300',
  success: 'text-emerald-400',
  error: 'text-red-400'
}

// Giữ tối đa chừng này dòng để vùng log không phình vô hạn khi polling lâu.
const MAX_LOG_ENTRIES = 500
const JOB_POLL_INTERVAL_MS = 5000

const statusLogs = ref<StatusLogEntry[]>([])
const logContainerRef = ref<HTMLElement | null>(null)
let logSeq = 0

function appendLog(level: LogLevel, message: string): void {
  statusLogs.value.push({
    id: ++logSeq,
    time: new Date().toLocaleTimeString('vi-VN'),
    level,
    message
  })
  if (statusLogs.value.length > MAX_LOG_ENTRIES) {
    statusLogs.value.splice(0, statusLogs.value.length - MAX_LOG_ENTRIES)
  }
  // Tự cuộn xuống dòng mới nhất.
  nextTick(() => {
    const el = logContainerRef.value
    if (el) el.scrollTop = el.scrollHeight
  })
}

function clearLogs(): void {
  statusLogs.value = []
}

// Job mô phỏng đang được theo dõi (null = không theo dõi).
const watchingJobId = ref<number | null>(null)
// Kênh đang dùng để theo dõi job — hiển thị trên tiêu đề vùng log.
const watchMode = ref<'ws' | 'poll' | null>(null)
// Thông điệp tiến độ mới nhất từ WebSocket (giữ lại sau khi job kết thúc).
const liveProgress = ref<SGJobProgressMessage | null>(null)
let jobSocket: JobProgressSocket | null = null
let jobPollTimer: ReturnType<typeof setTimeout> | null = null
// Tăng mỗi lần bắt đầu/dừng theo dõi -> bỏ qua response/thông điệp của lần cũ.
let jobWatchToken = 0

function stopJobWatch(): void {
  jobWatchToken++
  jobSocket?.close()
  jobSocket = null
  if (jobPollTimer) clearTimeout(jobPollTimer)
  jobPollTimer = null
  watchingJobId.value = null
  watchMode.value = null
}

function formatResidual(value: number): string {
  return typeof value === 'number' && Number.isFinite(value)
    ? formatNumber(value, undefined, {
        notation: 'scientific',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      })
    : String(value)
}

// Theo dõi job qua WebSocket ws /api/v1/jobs/{job_id}/ws. `actionLabel` = tên thao
// tác đã khởi chạy job ("Chia khối" / "Mô phỏng") để ghi log cho dễ đọc.
function startJobWatch(jobId: number, geometry: SGGeometryRead, actionLabel: string): void {
  stopJobWatch()
  const token = jobWatchToken
  const geometryCode = geometry.geometry_code
  watchingJobId.value = jobId
  watchMode.value = 'ws'
  liveProgress.value = null
  // Tiến độ (status / bước / %) đã hiển thị trên tiêu đề vùng log -> log chỉ ghi
  // residuals, và chỉ khi giá trị thay đổi (gateway có thể gửi lại cùng một ảnh chụp).
  let lastResiduals = ''

  jobSocket = connectJobProgress(jobId, {
    onOpen: () => {
      if (token !== jobWatchToken) return
      appendLog('info', `[${geometryCode}] Đã kết nối WebSocket, theo dõi job #${jobId}.`)
    },
    onMessage: (msg) => {
      if (token !== jobWatchToken) return
      liveProgress.value = msg

      const residuals = Object.entries(msg.residuals ?? {})
        .map(([name, value]) => `${name}=${formatResidual(value)}`)
        .join('  ')
      if (residuals && residuals !== lastResiduals) {
        lastResiduals = residuals
        // Ghi kèm iteration để biết residuals thuộc vòng lặp nào.
        const iteration = msg.iteration != null ? `iter ${formatNumber(msg.iteration)}: ` : ''
        appendLog('info', `[${geometryCode}] ${iteration}${residuals}`)
      }

      if (isProgressSuccess(msg.status) || isProgressFailed(msg.status)) {
        releaseSimulationJob(jobId)
      }
      if (isProgressSuccess(msg.status)) {
        appendLog('success', `[${geometryCode}] ${actionLabel} hoàn tất. Chọn "Kết quả" để xem.`)
        // Đang mở bước "Kết quả" của đúng geometry này -> nạp kết quả mới. Dùng
        // GET /jobs/{job_id}/results thay vì result_url vì viewer cần presigned URL
        // của từng file layer, còn result_url chỉ ký riêng manifest.json.
        if (isResultStepActive.value && selectedGeometryId.value === geometry.geometry_id) {
          loadResults(geometry.geometry_id)
        }
      } else if (isProgressFailed(msg.status)) {
        appendLog(
          'error',
          `[${geometryCode}] ${actionLabel} thất bại${msg.error_message ? `: ${msg.error_message}` : '.'}`
        )
      }
    },
    onServerError: (message, status) => {
      if (token !== jobWatchToken) return
      appendLog('error', `[${geometryCode}] WebSocket${status ? ` ${status}` : ''}: ${message}`)
    },
    // Gateway đóng 1000 sau thông điệp COMPLETED/FAILED, 4xxx sau envelope lỗi.
    onClosed: () => {
      if (token !== jobWatchToken) return
      jobSocket = null
      watchingJobId.value = null
      watchMode.value = null
    },
    onReconnecting: (attempt, retryIn) => {
      if (token !== jobWatchToken) return
      appendLog(
        'error',
        `[${geometryCode}] Mất kết nối WebSocket, thử lại lần ${formatNumber(attempt)} sau ${formatNumber(Math.round(retryIn / 1000))}s...`
      )
    },
    onGiveUp: () => {
      if (token !== jobWatchToken) return
      jobSocket = null
      appendLog(
        'error',
        `[${geometryCode}] Không kết nối được WebSocket, chuyển sang polling trạng thái job.`
      )
      startJobPolling(jobId, geometryCode, actionLabel, token)
    }
  })
}

// Dự phòng khi WebSocket không dùng được: polling trạng thái job qua REST.
function startJobPolling(
  jobId: number,
  geometryCode: string,
  actionLabel: string,
  token: number
): void {
  watchMode.value = 'poll'
  // Chỉ ghi log khi trạng thái thay đổi so với lần polling trước.
  let lastSnapshot = ''
  let consecutiveErrors = 0

  const poll = async (): Promise<void> => {
    try {
      const job = await getJob(jobId)
      if (token !== jobWatchToken) return
      consecutiveErrors = 0

      const snapshot = `${job.job_status}|${job.job_stage}|${job.job_pct}`
      if (snapshot !== lastSnapshot) {
        lastSnapshot = snapshot
        const level: LogLevel =
          job.job_status === JOB_STATUS.FAILED
            ? 'error'
            : job.job_status === JOB_STATUS.SUCCESS
              ? 'success'
              : 'info'
        appendLog(
          level,
          `[${geometryCode}] Job #${job.job_id}: ${getJobStatusLabel(job.job_status)} — ${getJobStageLabel(job.job_stage)} (${formatNumber(job.job_pct)}%)`
        )
      }

      if (job.job_status === JOB_STATUS.SUCCESS || job.job_status === JOB_STATUS.FAILED) {
        appendLog(
          job.job_status === JOB_STATUS.SUCCESS ? 'success' : 'error',
          job.job_status === JOB_STATUS.SUCCESS
            ? `[${geometryCode}] ${actionLabel} hoàn tất. Chọn "Kết quả" để xem.`
            : `[${geometryCode}] ${actionLabel} thất bại.`
        )
        releaseSimulationJob(jobId)
        stopJobWatch()
        return
      }
    } catch (error) {
      if (token !== jobWatchToken) return
      consecutiveErrors++
      const message = error instanceof Error ? error.message : 'Không thể lấy trạng thái job.'
      appendLog('error', `[${geometryCode}] ${message}`)
      if (consecutiveErrors >= 5) {
        appendLog('error', `[${geometryCode}] Dừng theo dõi job #${jobId} sau nhiều lần lỗi.`)
        stopJobWatch()
        return
      }
    }
    jobPollTimer = setTimeout(poll, JOB_POLL_INTERVAL_MS)
  }

  poll()
}

onBeforeUnmount(() => {
  stopJobWatch()
})

// Nút "Chia khối" -> gọi API buildBlockMeshDictWithOpenings với geometry đang chọn
// trên Sidebar để sinh blockMeshDict kèm các miệng cấp/xả/tường đã khai báo.
async function onBlockMeshClick(): Promise<void> {
  activeHeaderStep.value = 'blockMesh'
  const geometry = selectedGeometry.value
  if (!geometry) {
    showError('Chọn một khối hình học trước khi chia khối.')
    return
  }

  appendLog('info', `[${geometry.geometry_code}] Gửi yêu cầu chia khối (POST /block-mesh-dict)...`)
  try {
    const blockMeshPath = await buildBlockMeshDictWithOpenings(geometry)
    appendLog(
      'success',
      `[${geometry.geometry_code}] Đã gửi yêu cầu chia khối${blockMeshPath ? `: ${blockMeshPath}` : '.'}`
    )
    toast.success('Đã gửi yêu cầu chia khối.')

    // /block-mesh-dict chỉ trả đường dẫn, không trả job_id. Gateway gửi job mới nhất
    // của geometry cho worker -> lấy job_id đó để theo dõi tiến độ qua WebSocket.
    const jobs = await getJobsByGeometry(geometry.geometry_id)
    const latestJob = jobs.reduce<SGJobRead | undefined>(
      (latest, job) => (!latest || job.job_id > latest.job_id ? job : latest),
      undefined
    )
    if (latestJob) startJobWatch(latestJob.job_id, geometry, 'Chia khối')
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể chia khối.'
    appendLog('error', `[${geometry.geometry_code}] ${message}`)
    showError(message)
  }
}

// Job mô phỏng đang chạy (đã kích hoạt bộ giải) -> nút chuyển sang "Dừng mô phỏng".
const runningSimJobId = ref<number | null>(null)
// Đang chờ phản hồi /run-simulation hoặc /stop-simulation -> khóa nút, tránh bấm lần 2.
const isSimRequestPending = ref(false)

// Job mô phỏng kết thúc (hoàn tất / thất bại) -> nút trở lại "Chạy mô phỏng".
function releaseSimulationJob(jobId: number): void {
  if (runningSimJobId.value === jobId) runningSimJobId.value = null
}

function onSimulationButtonClick(): void {
  if (isSimRequestPending.value) return
  if (runningSimJobId.value !== null) onStopSimulation()
  else onRunSimulation()
}

// Nút "Chạy mô phỏng" -> gọi API runSimulation với geometry đang chọn trên Sidebar
// để khởi chạy job mô phỏng CFD, sau đó theo dõi trạng thái job trên vùng log.
async function onRunSimulation(): Promise<void> {
  activeHeaderStep.value = 'simulation'
  const geometry = selectedGeometry.value
  if (!geometry) {
    showError('Chọn một khối hình học trước khi chạy mô phỏng.')
    return
  }

  appendLog(
    'info',
    `[${geometry.geometry_code}] Gửi yêu cầu chạy mô phỏng (POST /run-simulation)...`
  )
  isSimRequestPending.value = true
  try {
    const jobId = await runSimulation(geometry)
    appendLog('success', `[${geometry.geometry_code}] Đã khởi chạy mô phỏng, job #${jobId}.`)
    toast.success('Đã khởi chạy mô phỏng.')
    if (jobId) {
      runningSimJobId.value = jobId
      startJobWatch(jobId, geometry, 'Mô phỏng')
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể chạy mô phỏng.'
    appendLog('error', `[${geometry.geometry_code}] ${message}`)
    showError(message)
  } finally {
    isSimRequestPending.value = false
  }
}

// Nút "Dừng mô phỏng" -> gọi API stopSimulation với job mô phỏng đang chạy.
async function onStopSimulation(): Promise<void> {
  activeHeaderStep.value = 'simulation'
  const jobId = runningSimJobId.value
  if (jobId === null) return

  appendLog('info', `Gửi yêu cầu dừng mô phỏng job #${jobId} (POST /stop-simulation)...`)
  isSimRequestPending.value = true
  try {
    await stopSimulation(jobId)
    appendLog('success', `Đã dừng mô phỏng, job #${jobId}.`)
    toast.success('Đã dừng mô phỏng.')
    if (watchingJobId.value === jobId) stopJobWatch()
    releaseSimulationJob(jobId)
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể dừng mô phỏng.'
    appendLog('error', `Job #${jobId}: ${message}`)
    showError(message)
  } finally {
    isSimRequestPending.value = false
  }
}

// Bước "Khối hình học" trên Header — chỉ khi đã bấm nút này thì viewport mới
// render mô hình của geometry đang chọn trên Sidebar.
const isGeometryStepActive = ref(true)

// Bước "Kết quả" trên Header — loại trừ với bước "Khối hình học".
const isResultStepActive = ref(false)

// Nút vừa bấm trên Header -> tô màu (kích hoạt). Chỉ ảnh hưởng hiển thị nút; nội
// dung viewport vẫn theo isGeometryStepActive / isResultStepActive ở trên.
type HeaderStep = 'geometry' | 'blockMesh' | 'simulation' | 'result'
const activeHeaderStep = ref<HeaderStep>('geometry')
const HEADER_STEP_ACTIVE_CLASS = 'border-pmis-primary bg-pmis-primary-100 text-pmis-primary'

// Quay lại từ bước "Kết quả": presigned URL của file STL có thể đã hết hạn trong lúc
// xem kết quả -> ký lại URL trước khi mount viewer, tránh S3 trả 403.
async function onGeometryClick(): Promise<void> {
  activeHeaderStep.value = 'geometry'
  await refreshGeometryStlIfExpired()
  isResultStepActive.value = false
  isGeometryStepActive.value = true
}

// Nút "Kiểm tra lưới" -> gọi API checkMesh với geometry đang chọn trên Sidebar
// để kiểm tra file system/blockMeshDict đã sinh từ bước "Chia khối".
// async function onCheckMeshClick(): Promise<void> {
//   const geometry = selectedGeometry.value
//   if (!geometry) {
//     showError('Chọn một khối hình học trước khi kiểm tra lưới.')
//     return
//   }

//   try {
//     await checkMesh(geometry)
//     toast.success('Kiểm tra lưới thành công.')
//   } catch (error) {
//     const message = error instanceof Error ? error.message : 'Không thể kiểm tra lưới.'
//     showError(message)
//   }
// }

function onResultClick(): void {
  activeHeaderStep.value = 'result'
  isGeometryStepActive.value = false
  isResultStepActive.value = true
  if (selectedGeometryId.value !== null) loadResults(selectedGeometryId.value)
}

// ====================================================================
// Kết quả mô phỏng (bước "Kết quả")
// geometry -> job SUCCESS mới nhất (GET /jobs/by-geometry/{id}) -> manifest kèm
// presigned URL (GET /jobs/{job_id}/results) -> sg_engr_result_viewer hiển thị.
// ====================================================================
const resultJob = ref<SGJobRead | null>(null)
const jobResults = ref<SGJobResultsRead | null>(null)
const isLoadingResults = ref(false)
// Thông báo trạng thái (không phải lỗi) hiển thị giữa viewport, vd: chưa chạy mô phỏng.
const resultNotice = ref('')

// Mỗi lần nạp tăng token -> bỏ qua response của lần bấm trước nếu về muộn.
let resultsRequestToken = 0

function clearResults(): void {
  resultsRequestToken++
  resultJob.value = null
  jobResults.value = null
  resultNotice.value = ''
  isLoadingResults.value = false
}

// Thông báo khi geometry chưa có job SUCCESS, dựa trên job gần nhất.
function noResultNotice(latest: SGJobRead | undefined): string {
  if (!latest) return 'Khối hình học này chưa được chạy mô phỏng.'
  if (latest.job_status === JOB_STATUS.FAILED) {
    return `Lần mô phỏng gần nhất (${latest.job_version ?? latest.job_code}) thất bại, chưa có kết quả để hiển thị.`
  }
  return `Mô phỏng ${latest.job_version ?? latest.job_code} đang ở trạng thái "${getJobStatusLabel(latest.job_status)}" (${latest.job_pct}%). Vui lòng quay lại khi hoàn tất.`
}

async function loadResults(geometryId: number): Promise<void> {
  const token = ++resultsRequestToken
  const sameGeometry = resultJob.value?.geometry_id === geometryId
  // Đổi geometry -> xoá kết quả cũ ngay; cùng geometry -> giữ viewer trong lúc làm mới URL.
  if (!sameGeometry) {
    resultJob.value = null
    jobResults.value = null
  }
  resultNotice.value = ''
  isLoadingResults.value = true
  try {
    const jobs = await getJobsByGeometry(geometryId)
    if (token !== resultsRequestToken) return

    const byNewest = [...jobs].sort((a, b) => b.job_id - a.job_id)
    const job = byNewest.find((j) => j.job_status === JOB_STATUS.SUCCESS)
    if (!job) {
      resultJob.value = null
      jobResults.value = null
      resultNotice.value = noResultNotice(byNewest[0])
      return
    }

    const results = await getJobResults(job.job_id)
    if (token !== resultsRequestToken) return

    resultJob.value = job
    jobResults.value = results
    if (!results.available || !results.manifest) {
      resultNotice.value =
        'Kết quả mô phỏng không có dữ liệu hiển thị trên web. Bạn vẫn có thể tải gói kết quả về máy.'
    }
  } catch (error) {
    if (token !== resultsRequestToken) return
    const message = error instanceof Error ? error.message : 'Không thể tải kết quả mô phỏng.'
    showError(message)
  } finally {
    if (token === resultsRequestToken) isLoadingResults.value = false
  }
}

// Viewer báo presigned URL hết hạn -> gọi lại API để backend ký URL mới. Giới hạn
// 30s/lần để không lặp vô hạn khi đồng hồ máy người dùng lệch so với server.
let lastResultsRefreshAt = 0

function onResultsExpired(): void {
  if (selectedGeometryId.value === null || isLoadingResults.value) return
  if (Date.now() - lastResultsRefreshAt < 30_000) return
  lastResultsRefreshAt = Date.now()
  loadResults(selectedGeometryId.value)
}

// Geometry đang chọn bị xoá / bỏ chọn -> không còn kết quả để hiển thị.
watch(selectedGeometryId, (id) => {
  if (id === null) clearResults()
})

function formatDateTime(value: string | null | undefined): string {
  if (!value) return ''
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString('vi-VN')
}

// Tham chiếu tới trình xem 3D — dùng để chủ động bỏ chọn mặt từ panel bên phải.
const objViewerRef = ref<InstanceType<typeof sg_engr_obj_viewer> | null>(null)

// Mặt phẳng người dùng chọn trên mô hình 3D (null = chưa chọn / vừa bỏ chọn).
const selectedFace = ref<ObjFaceSelection | null>(null)

// Danh sách miệng cấp (inlet) của geometry đang xem — nạp từ API theo geometry_id
// mỗi khi đổi geometry, và cập nhật khi thêm / sửa / xoá.
const inlets = ref<SGInletRead[]>([])
const isLoadingInlets = ref(false)
const selectedInletId = ref<number | null>(null)
const selectedInlet = computed<SGInletRead | undefined>(() =>
  inlets.value.find((inlet) => inlet.inlet_id === selectedInletId.value)
)

// Nạp danh sách miệng cấp của một geometry từ backend.
async function loadInlets(geometryId: number): Promise<void> {
  isLoadingInlets.value = true
  try {
    inlets.value = await getInletsByGeometry(geometryId)
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể tải danh sách miệng cấp.'
    showError(message)
  } finally {
    isLoadingInlets.value = false
  }
}

// Danh sách miệng xả (outlet) của geometry đang xem — nạp từ API theo geometry_id
// mỗi khi đổi geometry, và cập nhật khi thêm / sửa / xoá.
const outlets = ref<SGOutletRead[]>([])
const isLoadingOutlets = ref(false)
const selectedOutletId = ref<number | null>(null)
const selectedOutlet = computed<SGOutletRead | undefined>(() =>
  outlets.value.find((outlet) => outlet.outlet_id === selectedOutletId.value)
)

// Nạp danh sách miệng xả của một geometry từ backend.
async function loadOutlets(geometryId: number): Promise<void> {
  isLoadingOutlets.value = true
  try {
    outlets.value = await getOutletsByGeometry(geometryId)
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể tải danh sách miệng xả.'
    showError(message)
  } finally {
    isLoadingOutlets.value = false
  }
}

// Danh sách tường (wall) của geometry đang xem — nạp từ API theo geometry_id
// mỗi khi đổi geometry, và cập nhật khi thêm / sửa / xoá.
const walls = ref<SGWallRead[]>([])
const isLoadingWalls = ref(false)
const selectedWallId = ref<number | null>(null)
const selectedWall = computed<SGWallRead | undefined>(() =>
  walls.value.find((wall) => wall.wall_id === selectedWallId.value)
)

// Nạp danh sách tường của một geometry từ backend.
async function loadWalls(geometryId: number): Promise<void> {
  isLoadingWalls.value = true
  try {
    walls.value = await getWallsByGeometry(geometryId)
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể tải danh sách tường.'
    showError(message)
  } finally {
    isLoadingWalls.value = false
  }
}

// Đổi geometry -> nạp lại danh sách miệng cấp / miệng xả / tường từ API.
watch(
  selectedGeometry,
  (geometry) => {
    selectedInletId.value = null
    selectedOutletId.value = null
    selectedWallId.value = null
    inlets.value = []
    outlets.value = []
    walls.value = []
    if (geometry) {
      loadInlets(geometry.geometry_id)
      loadOutlets(geometry.geometry_id)
      loadWalls(geometry.geometry_id)
    }
  },
  { immediate: true }
)

function onFaceSelect(face: ObjFaceSelection | null): void {
  selectedFace.value = face
  if (face) {
    selectedInletId.value = null
    selectedOutletId.value = null
    selectedWallId.value = null
  }
}

// --- Modal "Miệng cấp" — mở bằng lệnh Edit Inlet trên menu con cạnh mặt đang chọn ---
const showInletModal = ref(false)
// Mặt đang mở modal Miệng cấp — modal lấy tâm + kích thước mặt làm vị trí inlet.
const inletFace = ref<ObjFaceSelection | null>(null)

// Modal đã lưu inlet xuống DB -> đưa bản ghi vào danh sách và mở panel của nó.
function onInletModalSaved(inlet: SGInletRead): void {
  inlets.value.push(inlet)
  selectInlet(inlet.inlet_id)
}

// --- Modal "Miệng xả" — mở bằng lệnh Edit Outlet trên menu con cạnh mặt đang chọn ---
const showOutletModal = ref(false)
// Mặt đang mở modal Miệng xả — modal lấy tâm + kích thước mặt làm vị trí outlet.
const outletFace = ref<ObjFaceSelection | null>(null)

// Modal đã lưu outlet xuống DB -> đưa bản ghi vào danh sách và mở panel của nó.
function onOutletModalSaved(outlet: SGOutletRead): void {
  outlets.value.push(outlet)
  selectOutlet(outlet.outlet_id)
}

// --- Modal "Tường & bề mặt nội thất" — mở bằng lệnh Edit Wall trên menu con cạnh mặt đang chọn ---
const showWallModal = ref(false)
// Mặt đang mở modal Tường — modal lấy tên bề mặt + diện tích mặt (quy đổi W -> W/m²).
const wallFace = ref<ObjFaceSelection | null>(null)

// Tên bề mặt hiển thị trên modal Tường — đặt theo trục vuông góc của mặt.
const wallSurfaceName = computed<string>(() => {
  const face = wallFace.value
  if (!face) return ''
  return face.axis === '—' ? 'Mặt nghiêng' : `Mặt ⊥ ${face.axis}`
})

// Modal đã lưu wall xuống DB -> đưa bản ghi vào danh sách và mở panel của nó.
function onWallModalSaved(wall: SGWallRead): void {
  walls.value.push(wall)
  selectWall(wall.wall_id)
}

// Menu con nổi cạnh mặt đang chọn: Edit Inlet / Edit Outlet / Edit Wall.
function onFaceEdit(face: ObjFaceSelection, kind: FaceEditKind): void {
  if (kind === 'inlet') {
    inletFace.value = face
    showInletModal.value = true
  } else if (kind === 'outlet') {
    outletFace.value = face
    showOutletModal.value = true
  } else if (kind === 'wall') {
    wallFace.value = face
    showWallModal.value = true
  }
}

// Vị trí (tâm, m) + kích thước (rộng theo Y, cao theo Z) để tạo một miệng cấp/xả.
interface OpeningPlacement {
  center: { x: number; y: number; z: number }
  sizeW: number
  sizeH: number
}

// ====================================================================
// Miệng cấp / miệng xả / tường
// ====================================================================

// Danh sách miệng cấp hiển thị dạng khối trên mô hình 3D — ánh xạ từ SGInletRead
// (pos_x/y/z = tâm khối, size_w/size_h = kích thước). Bấm trúng khối này trên
// viewer -> emit `inlet-select` -> mở panel sg_engr_inlet_edit bên phải.
const inletBlocks = computed<InletBlock[]>(() =>
  inlets.value.map((inlet) => ({
    id: inlet.inlet_id,
    name: inlet.inlet_name || inlet.inlet_code,
    center: { x: inlet.pos_x, y: inlet.pos_y, z: inlet.pos_z },
    size: { w: inlet.size_w, h: inlet.size_h }
  }))
)

// Danh sách miệng xả hiển thị dạng khối trên mô hình 3D — ánh xạ từ SGOutletRead
// (pos_x/y/z = tâm khối, size_w/size_h = kích thước). Bấm trúng khối này trên
// viewer -> emit `outlet-select` -> mở panel sg_engr_outlet_edit bên phải.
const outletBlocks = computed<OutletBlock[]>(() =>
  outlets.value.map((outlet) => ({
    id: outlet.outlet_id,
    name: outlet.outlet_name || outlet.outlet_code,
    center: { x: outlet.pos_x, y: outlet.pos_y, z: outlet.pos_z },
    size: { w: outlet.size_w, h: outlet.size_h }
  }))
)

// "+ Thêm" trên menu "Miệng xả" -> tạo một outlet thật ở backend tại tâm mô hình.
// Miệng xả (return) là một outlet thật -> dựng payload SGOutletCreate và gọi API
// createOutlet (giống cách onAddInlet làm cho miệng cấp).
async function onAddOutlet(): Promise<void> {
  const geometry = selectedGeometry.value
  if (!geometry) return

  const bounds = objViewerRef.value?.getModelBounds()
  // Vị trí mặc định: tâm trên mặt phẳng X=L (Dài) — tức mặt xa nhất của hộp bao
  // theo trục X (center.x + size.x/2), căn giữa theo Y/Z. Kích thước mặc định:
  // chiều rộng = Y (chiều rộng hình hộp) / 3, chiều cao = Z (chiều cao hình hộp) / 3.
  const center = bounds
    ? {
        x: roundDecimal(bounds.center.x + bounds.size.x / 2),
        y: roundDecimal(bounds.center.y),
        z: roundDecimal(bounds.center.z)
      }
    : { x: 0, y: 0, z: 0 }
  const sizeW = bounds ? roundDecimal(bounds.size.y / 3) : 0
  const sizeH = bounds ? roundDecimal(bounds.size.z / 3) : 0
  await createOutletAt({ center, sizeW, sizeH })
}

// Tạo một outlet thật ở backend tại vị trí/kích thước cho trước rồi mở panel của nó
// — dùng chung cho "+ Thêm" (Sidebar) và "Edit Outlet" (menu con trên mặt đang chọn).
async function createOutletAt({ center, sizeW, sizeH }: OpeningPlacement): Promise<void> {
  const geometry = selectedGeometry.value
  if (!geometry) return

  const nextNo = outlets.value.length + 1

  const payload: SGOutletCreate = {
    ...newSGOutletCreate(),
    outlet_code: `OUT-${String(nextNo).padStart(3, '0')}`,
    outlet_name: `${GEOMETRY_PART_KIND_LABEL.return} ${String(nextNo).padStart(2, '0')}`,
    pos_x: center.x,
    pos_y: center.y,
    pos_z: center.z,
    size_w: sizeW,
    size_h: sizeH,
    geometry_id: geometry.geometry_id
  }

  try {
    const created = await createOutlet(payload)
    outlets.value.push(created)
    selectOutlet(created.outlet_id)
    toast.success(
      `Đã thêm ${GEOMETRY_PART_KIND_LABEL.return.toLowerCase()} "${created.outlet_code}".`
    )
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể thêm miệng xả.'
    showError(message)
  }
}

// "+ Thêm" trên menu "Tường" -> tạo một wall thật ở backend cho geometry đang xem.
// Tường (obstacle) là một wall thật -> dựng payload SGWallCreate và gọi API
// createWall (giống cách onAddOutlet làm cho miệng xả). Khác với miệng cấp/xả,
// wall không có vị trí/kích thước (SGWallBase không có pos_x/y/z, size_w/size_h).
async function onAddWall(): Promise<void> {
  const geometry = selectedGeometry.value
  if (!geometry) return

  const nextNo = walls.value.length + 1

  const payload: SGWallCreate = {
    ...newSGWallCreate(),
    wall_code: `WALL-${String(nextNo).padStart(3, '0')}`,
    wall_name: `${GEOMETRY_PART_KIND_LABEL.obstacle} ${String(nextNo).padStart(2, '0')}`,
    geometry_id: geometry.geometry_id
  }

  try {
    const created = await createWall(payload)
    walls.value.push(created)
    selectWall(created.wall_id)
    toast.success(
      `Đã thêm ${GEOMETRY_PART_KIND_LABEL.obstacle.toLowerCase()} "${created.wall_code}".`
    )
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể thêm tường.'
    showError(message)
  }
}

// "+ Thêm" trên menu "Miệng cấp" -> tạo một miệng cấp (inlet) tại tâm mô hình và
// gọi API createInlet. Bản ghi trả về được đưa vào danh sách `inlets` của geometry.
async function onAddInlet(): Promise<void> {
  const geometry = selectedGeometry.value
  if (!geometry) return

  const bounds = objViewerRef.value?.getModelBounds()
  // Vị trí mặc định: tâm trên mặt phẳng X=0 — tức mặt gần nhất của hộp bao theo
  // trục X (center.x - size.x/2), căn giữa theo Y/Z. Kích thước mặc định: chiều
  // rộng = Y (chiều rộng hình hộp) / 3, chiều cao = Z (chiều cao hình hộp) / 3.
  const center = bounds
    ? {
        x: roundDecimal(bounds.center.x - bounds.size.x / 2),
        y: roundDecimal(bounds.center.y),
        z: roundDecimal(bounds.center.z)
      }
    : { x: 0, y: 0, z: 0 }
  const sizeW = bounds ? roundDecimal(bounds.size.y / 3) : 0
  const sizeH = bounds ? roundDecimal(bounds.size.z / 3) : 0
  await createInletAt({ center, sizeW, sizeH })
}

// Tạo một inlet thật ở backend tại vị trí/kích thước cho trước rồi mở panel của nó
// — dùng chung cho "+ Thêm" (Sidebar) và "Edit Inlet" (menu con trên mặt đang chọn).
async function createInletAt({ center, sizeW, sizeH }: OpeningPlacement): Promise<void> {
  const geometry = selectedGeometry.value
  if (!geometry) return

  const nextNo = inlets.value.length + 1

  const payload: SGInletCreate = {
    ...newSGInletCreate(),
    inlet_code: `INL-${String(nextNo).padStart(3, '0')}`,
    inlet_name: `${GEOMETRY_PART_KIND_LABEL.supply} ${String(nextNo).padStart(2, '0')}`,
    pos_x: center.x,
    pos_y: center.y,
    pos_z: center.z,
    size_w: sizeW,
    size_h: sizeH,
    geometry_id: geometry.geometry_id
  }

  try {
    const created = await createInlet(payload)
    inlets.value.push(created)
    selectInlet(created.inlet_id)
    toast.success(
      `Đã thêm ${GEOMETRY_PART_KIND_LABEL.supply.toLowerCase()} "${created.inlet_code}".`
    )
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể thêm miệng cấp.'
    showError(message)
  }
}

// Chọn 1 miệng cấp trên Sidebar -> mở panel sg_engr_inlet_edit bên phải, rời luồng
// chọn mặt.
function selectInlet(id: number | null): void {
  selectedInletId.value = id
  if (id !== null) {
    selectedOutletId.value = null
    selectedWallId.value = null
    if (selectedFace.value) {
      objViewerRef.value?.clearFaceSelection()
      selectedFace.value = null
    }
  }
}

// Panel phát `save` -> gọi API updateInlet rồi cập nhật bản ghi trong danh sách.
async function onSaveInlet(payload: SGInletUpdate): Promise<void> {
  if (selectedInletId.value === null) return
  try {
    const updated = await updateInlet(selectedInletId.value, payload)
    const index = inlets.value.findIndex((i) => i.inlet_id === updated.inlet_id)
    if (index !== -1) inlets.value[index] = updated
    toast.success(`Đã lưu miệng cấp "${updated.inlet_code}".`)
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể lưu miệng cấp.'
    showError(message)
  }
}

// Panel phát `delete` -> gọi API deleteInlet rồi bỏ khỏi danh sách.
async function onDeleteInlet(inletId: number): Promise<void> {
  try {
    await deleteInlet(inletId)
    inlets.value = inlets.value.filter((i) => i.inlet_id !== inletId)
    if (selectedInletId.value === inletId) selectedInletId.value = null
    toast.success('Đã xoá miệng cấp.')
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể xoá miệng cấp.'
    showError(message)
  }
}

function onCloseInletPanel(): void {
  selectedInletId.value = null
}

// Chọn 1 miệng xả trên Sidebar / mô hình 3D -> mở panel sg_engr_outlet_edit bên
// phải, rời luồng chọn mặt / miệng cấp.
function selectOutlet(id: number | null): void {
  selectedOutletId.value = id
  if (id !== null) {
    selectedInletId.value = null
    selectedWallId.value = null
    if (selectedFace.value) {
      objViewerRef.value?.clearFaceSelection()
      selectedFace.value = null
    }
  }
}

// Panel phát `save` -> gọi API updateOutlet rồi cập nhật bản ghi trong danh sách.
async function onSaveOutlet(payload: SGOutletUpdate): Promise<void> {
  if (selectedOutletId.value === null) return
  try {
    const updated = await updateOutlet(selectedOutletId.value, payload)
    const index = outlets.value.findIndex((o) => o.outlet_id === updated.outlet_id)
    if (index !== -1) outlets.value[index] = updated
    toast.success(`Đã lưu miệng xả "${updated.outlet_code}".`)
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể lưu miệng xả.'
    showError(message)
  }
}

// Panel phát `delete` -> gọi API deleteOutlet rồi bỏ khỏi danh sách.
async function onDeleteOutlet(outletId: number): Promise<void> {
  try {
    await deleteOutlet(outletId)
    outlets.value = outlets.value.filter((o) => o.outlet_id !== outletId)
    if (selectedOutletId.value === outletId) selectedOutletId.value = null
    toast.success('Đã xoá miệng xả.')
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể xoá miệng xả.'
    showError(message)
  }
}

function onCloseOutletPanel(): void {
  selectedOutletId.value = null
}

// Chọn 1 tường trên Sidebar -> mở panel sg_engr_wall_edit bên phải, rời luồng
// chọn mặt / miệng cấp / miệng xả.
function selectWall(id: number | null): void {
  selectedWallId.value = id
  if (id !== null) {
    selectedInletId.value = null
    selectedOutletId.value = null
    if (selectedFace.value) {
      objViewerRef.value?.clearFaceSelection()
      selectedFace.value = null
    }
  }
}

// Panel phát `save` -> gọi API updateWall rồi cập nhật bản ghi trong danh sách.
async function onSaveWall(payload: SGWallUpdate): Promise<void> {
  if (selectedWallId.value === null) return
  try {
    const updated = await updateWall(selectedWallId.value, payload)
    const index = walls.value.findIndex((w) => w.wall_id === updated.wall_id)
    if (index !== -1) walls.value[index] = updated
    toast.success(`Đã lưu tường "${updated.wall_code}".`)
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể lưu tường.'
    showError(message)
  }
}

// Panel phát `delete` -> gọi API deleteWall rồi bỏ khỏi danh sách.
async function onDeleteWall(wallId: number): Promise<void> {
  try {
    await deleteWall(wallId)
    walls.value = walls.value.filter((w) => w.wall_id !== wallId)
    if (selectedWallId.value === wallId) selectedWallId.value = null
    toast.success('Đã xoá tường.')
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể xoá tường.'
    showError(message)
  }
}

function onCloseWallPanel(): void {
  selectedWallId.value = null
}
</script>

<template>
  <div class="flex h-full w-full flex-col gap-4">
    <!-- ============================================================ -->
    <!-- Vùng 1: Header -->
    <!-- ============================================================ -->
    <header class="flex shrink-0 items-center justify-between gap-4">
      <div class="flex items-center space-x-4">
        <div class="w-64">
          <h1 class="sg-title-page uppercase text-lg">Mô phỏng dự án</h1>
          {{ props.project.project_name }}
        </div>

        <div class="flex items-center space-x-2">
          <button
            type="button"
            class="sg-button-secondary"
            :class="{ [HEADER_STEP_ACTIVE_CLASS]: activeHeaderStep === 'geometry' }"
            @click="onGeometryClick"
          >
            <Cuboid class="h-4 w-4" />
            Khối hình học
          </button>
          <span class="uppercase">></span>
          <button
            type="button"
            class="sg-button-secondary"
            :class="{ [HEADER_STEP_ACTIVE_CLASS]: activeHeaderStep === 'blockMesh' }"
            @click="onBlockMeshClick"
          >
            Chia khối
          </button>
          <span class="uppercase">></span>
          <button
            type="button"
            class="sg-button-secondary"
            :class="{ [HEADER_STEP_ACTIVE_CLASS]: activeHeaderStep === 'simulation' }"
            :disabled="isSimRequestPending"
            @click="onSimulationButtonClick"
          >
            <LoaderCircle v-if="isSimRequestPending" class="h-4 w-4 animate-spin" />
            <Square v-else-if="runningSimJobId !== null" class="h-4 w-4" />
            <Play v-else class="h-4 w-4" />
            <span>{{ runningSimJobId !== null ? 'Dừng mô phỏng' : 'Chạy mô phỏng' }}</span>
          </button>
          <span class="uppercase">></span>
          <!-- <button type="button" class="sg-button-secondary" @click="onCheckMeshClick">
            Kiểm tra lưới
          </button> -->
          <button
            type="button"
            class="sg-button-secondary"
            :class="{ [HEADER_STEP_ACTIVE_CLASS]: activeHeaderStep === 'result' }"
            @click="onResultClick"
          >
            <Cuboid class="h-4 w-4" />
            Kết quả
          </button>
        </div>
      </div>

      <!-- <button type="button" class="sg-button-primary" @click="onRunSimulation">
        <Play class="h-4 w-4" />
        <span>Chạy mô phỏng</span>
      </button> -->
    </header>

    <!-- ============================================================ -->
    <!-- Vùng 2: Body -->
    <!-- ============================================================ -->
    <section class="flex min-h-0 flex-1 gap-4">
      <!-- Vùng trái: Menu Sidebar -->
      <aside
        class="flex w-64 border border-pmis-bordertab rounded-lg shrink-0 flex-col overflow-y-auto sg-table-wrapper"
      >
        <nav class="flex-1 overflow-y-auto py-2">
          <!-- Cấp 1: menu tĩnh "Khối hình học" -->
          <div class="flex items-center gap-1 pr-2 transition-colors hover:bg-pmis-primary-50">
            <button
              type="button"
              class="flex flex-1 items-center gap-2 px-3 py-2 text-left"
              @click="toggleGeometryGroup"
            >
              <component
                :is="isGeometryGroupExpanded ? ChevronDown : ChevronRight"
                class="h-4 w-4 shrink-0 text-pmis-placeholder"
              />
              <span class="flex-1 truncate text-sm font-semibold text-pmis-text">
                Khối hình học
              </span>
            </button>

            <button
              type="button"
              class="sg-button-only-icon shrink-0"
              title="Thêm khối hình học"
              @click="onAddGeometry"
            >
              <Plus class="h-4 w-4" />
            </button>
          </div>

          <!-- Cấp 2: danh sách geometry_code, chọn được -->
          <ul v-if="isGeometryGroupExpanded" class="ml-6 border-l border-slate-100">
            <li v-if="isLoadingGeometry" class="px-3 py-1.5 text-sm text-pmis-placeholder">
              <span class="inline-flex items-center gap-2">
                <LoaderCircle class="h-4 w-4 animate-spin" />
                Đang tải dữ liệu...
              </span>
            </li>
            <li
              v-else-if="geometryList.length === 0"
              class="px-3 py-1.5 text-sm text-pmis-placeholder"
            >
              Chưa có khối hình học
            </li>
            <template v-else>
              <li v-for="geometry in geometryList" :key="geometry.geometry_id">
                <button
                  type="button"
                  class="block w-full rounded-md truncate px-3 py-1.5 text-left text-sm transition-colors"
                  :class="
                    selectedGeometryId === geometry.geometry_id
                      ? 'border border-pmis-bordernormal bg-pmis-primary-100 font-semibold text-pmis-primary'
                      : 'text-pmis-label hover:bg-pmis-primary-50 hover:text-pmis-primary'
                  "
                  @click="selectGeometry(geometry.geometry_id)"
                >
                  {{ geometry.geometry_code }}
                </button>
              </li>
            </template>
          </ul>

          <!-- ================================================================ -->
          <!-- Cấp 1: menu "Miệng cấp" (supply) -->
          <!-- ================================================================ -->
          <div
            class="mt-1 flex items-center gap-1 border-t border-slate-100 pr-2 pt-1 transition-colors hover:bg-pmis-primary-50"
          >
            <button
              type="button"
              class="flex flex-1 items-center gap-2 px-3 py-2 text-left"
              @click="partGroupExpanded.supply = !partGroupExpanded.supply"
            >
              <component
                :is="partGroupExpanded.supply ? ChevronDown : ChevronRight"
                class="h-4 w-4 shrink-0 text-pmis-placeholder"
              />
              <span class="flex-1 truncate text-sm font-semibold text-pmis-text">
                {{ GEOMETRY_PART_KIND_LABEL.supply }}
              </span>
            </button>

            <button
              type="button"
              class="sg-button-only-icon shrink-0"
              :disabled="!selectedGeometry"
              :title="
                selectedGeometry
                  ? `Thêm ${GEOMETRY_PART_KIND_LABEL.supply.toLowerCase()} vào mô hình`
                  : 'Chọn một khối hình học trước'
              "
              @click="onAddInlet"
            >
              <Plus class="h-4 w-4" />
            </button>
          </div>

          <ul v-if="partGroupExpanded.supply" class="ml-6 border-l border-slate-100">
            <li v-if="isLoadingInlets" class="px-3 py-1.5 text-sm text-pmis-placeholder">
              <span class="inline-flex items-center gap-2">
                <LoaderCircle class="h-4 w-4 animate-spin" />
                Đang tải dữ liệu...
              </span>
            </li>
            <li v-else-if="inlets.length === 0" class="px-3 py-1.5 text-sm text-pmis-placeholder">
              Chưa có miệng cấp
            </li>
            <template v-else>
              <li v-for="inlet in inlets" :key="inlet.inlet_id">
                <button
                  type="button"
                  class="flex w-full items-center gap-2 rounded-md px-3 py-1.5 text-left text-sm transition-colors"
                  :class="
                    selectedInletId === inlet.inlet_id
                      ? 'border border-pmis-bordernormal bg-pmis-primary-100 font-semibold text-pmis-primary'
                      : 'text-pmis-label hover:bg-pmis-primary-50 hover:text-pmis-primary'
                  "
                  @click="selectInlet(inlet.inlet_id)"
                >
                  <Wind class="h-3.5 w-3.5 shrink-0 text-pmis-placeholder" />
                  <span class="flex-1 truncate">{{ inlet.inlet_name || inlet.inlet_code }}</span>
                </button>
              </li>
            </template>
          </ul>

          <!-- ================================================================ -->
          <!-- Cấp 1: menu "Miệng xả" (return) -->
          <!-- ================================================================ -->
          <div
            class="mt-1 flex items-center gap-1 border-t border-slate-100 pr-2 pt-1 transition-colors hover:bg-pmis-primary-50"
          >
            <button
              type="button"
              class="flex flex-1 items-center gap-2 px-3 py-2 text-left"
              @click="partGroupExpanded.return = !partGroupExpanded.return"
            >
              <component
                :is="partGroupExpanded.return ? ChevronDown : ChevronRight"
                class="h-4 w-4 shrink-0 text-pmis-placeholder"
              />
              <span class="flex-1 truncate text-sm font-semibold text-pmis-text">
                {{ GEOMETRY_PART_KIND_LABEL.return }}
              </span>
            </button>

            <button
              type="button"
              class="sg-button-only-icon shrink-0"
              :disabled="!selectedGeometry"
              :title="
                selectedGeometry
                  ? `Thêm ${GEOMETRY_PART_KIND_LABEL.return.toLowerCase()} vào mô hình`
                  : 'Chọn một khối hình học trước'
              "
              @click="onAddOutlet"
            >
              <Plus class="h-4 w-4" />
            </button>
          </div>

          <ul v-if="partGroupExpanded.return" class="ml-6 border-l border-slate-100">
            <li v-if="isLoadingOutlets" class="px-3 py-1.5 text-sm text-pmis-placeholder">
              <span class="inline-flex items-center gap-2">
                <LoaderCircle class="h-4 w-4 animate-spin" />
                Đang tải dữ liệu...
              </span>
            </li>
            <li v-else-if="outlets.length === 0" class="px-3 py-1.5 text-sm text-pmis-placeholder">
              Chưa có miệng xả
            </li>
            <template v-else>
              <li v-for="outlet in outlets" :key="outlet.outlet_id">
                <button
                  type="button"
                  class="flex w-full items-center gap-2 rounded-md px-3 py-1.5 text-left text-sm transition-colors"
                  :class="
                    selectedOutletId === outlet.outlet_id
                      ? 'border border-pmis-bordernormal bg-pmis-primary-100 font-semibold text-pmis-primary'
                      : 'text-pmis-label hover:bg-pmis-primary-50 hover:text-pmis-primary'
                  "
                  @click="selectOutlet(outlet.outlet_id)"
                >
                  <Wind class="h-3.5 w-3.5 shrink-0 text-pmis-placeholder" />
                  <span class="flex-1 truncate">{{
                    outlet.outlet_name || outlet.outlet_code
                  }}</span>
                </button>
              </li>
            </template>
          </ul>

          <!-- ================================================================ -->
          <!-- Cấp 1: menu "Tường" (obstacle) — kèm các mặt "Tường (Wall)" đã lưu -->
          <!-- ================================================================ -->
          <div
            class="mt-1 flex items-center gap-1 border-t border-slate-100 pr-2 pt-1 transition-colors hover:bg-pmis-primary-50"
          >
            <button
              type="button"
              class="flex flex-1 items-center gap-2 px-3 py-2 text-left"
              @click="partGroupExpanded.obstacle = !partGroupExpanded.obstacle"
            >
              <component
                :is="partGroupExpanded.obstacle ? ChevronDown : ChevronRight"
                class="h-4 w-4 shrink-0 text-pmis-placeholder"
              />
              <span class="flex-1 truncate text-sm font-semibold text-pmis-text">
                {{ GEOMETRY_PART_KIND_LABEL.obstacle }}
              </span>
            </button>

            <button
              type="button"
              class="sg-button-only-icon shrink-0"
              :disabled="!selectedGeometry"
              :title="
                selectedGeometry
                  ? `Thêm ${GEOMETRY_PART_KIND_LABEL.obstacle.toLowerCase()} vào mô hình`
                  : 'Chọn một khối hình học trước'
              "
              @click="onAddWall"
            >
              <Plus class="h-4 w-4" />
            </button>
          </div>

          <ul v-if="partGroupExpanded.obstacle" class="ml-6 border-l border-slate-100">
            <li v-if="isLoadingWalls" class="px-3 py-1.5 text-sm text-pmis-placeholder">
              <span class="inline-flex items-center gap-2">
                <LoaderCircle class="h-4 w-4 animate-spin" />
                Đang tải dữ liệu...
              </span>
            </li>
            <li v-else-if="walls.length === 0" class="px-3 py-1.5 text-sm text-pmis-placeholder">
              Chưa có khối nào
            </li>
            <li v-for="wall in walls" :key="wall.wall_id">
              <button
                type="button"
                class="flex w-full items-center gap-2 rounded-md px-3 py-1.5 text-left text-sm transition-colors"
                :class="
                  selectedWallId === wall.wall_id
                    ? 'border border-pmis-bordernormal bg-pmis-primary-100 font-semibold text-pmis-primary'
                    : 'text-pmis-label hover:bg-pmis-primary-50 hover:text-pmis-primary'
                "
                @click="selectWall(wall.wall_id)"
              >
                <Wind class="h-3.5 w-3.5 shrink-0 text-pmis-placeholder" />
                <span class="flex-1 truncate">{{ wall.wall_name || wall.wall_code }}</span>
              </button>
            </li>
          </ul>
        </nav>
      </aside>

      <!-- Vùng giữa: mô hình 3D (trên) + log trạng thái từ Gateway (dưới) -->
      <div class="flex min-w-0 flex-1 flex-col gap-4">
        <main
          class="min-h-0 flex-1 border border-pmis-bordertab rounded-lg overflow-hidden sg-table-wrapper"
        >
          <sg_engr_obj_viewer
            v-if="isGeometryStepActive && geometryObjUrl"
            ref="objViewerRef"
            :src="geometryObjUrl"
            :inlets="inletBlocks"
            :selected-inlet-id="selectedInletId"
            :outlets="outletBlocks"
            :selected-outlet-id="selectedOutletId"
            @face-select="onFaceSelect"
            @face-edit="onFaceEdit"
            @inlet-select="selectInlet"
            @outlet-select="selectOutlet"
          />

          <!-- Bước "Kết quả": hiển thị manifest từ GET /jobs/{job_id}/results -->
          <template v-else-if="isResultStepActive">
            <sg_engr_result_viewer
              v-if="jobResults?.available && jobResults.manifest"
              :manifest="jobResults.manifest"
              @expired="onResultsExpired"
            />
            <div
              v-else
              class="flex h-full flex-col items-center justify-center gap-2 p-4 text-center text-sm text-pmis-placeholder"
            >
              <template v-if="isLoadingResults">
                <LoaderCircle class="h-8 w-8 animate-spin text-pmis-primary" />
                Đang tải kết quả mô phỏng...
              </template>
              <template v-else-if="!selectedGeometry">
                Chọn một khối hình học để xem kết quả mô phỏng
              </template>
              <template v-else-if="resultNotice">{{ resultNotice }}</template>
            </div>
          </template>

          <div
            v-else
            class="flex h-full items-center justify-center p-4 text-sm text-pmis-placeholder"
          >
            {{
              isGeometryStepActive
                ? 'Chưa có mô hình hình học để hiển thị'
                : 'Chọn "Khối hình học" để hiển thị mô hình'
            }}
          </div>
        </main>

        <!-- Log trạng thái: phản hồi Chia khối / Chạy mô phỏng + tiến độ job -->
        <section
          class="flex h-56 shrink-0 flex-col overflow-hidden rounded-lg border border-pmis-bordertab"
        >
          <div
            class="flex shrink-0 items-center justify-between gap-2 border-b border-pmis-bordertab px-3 py-1.5"
          >
            <span class="flex min-w-0 items-center gap-2 text-sm font-semibold text-pmis-text">
              <span class="shrink-0">Log trạng thái</span>
              <span
                v-if="watchingJobId !== null"
                class="inline-flex shrink-0 items-center gap-1 text-xs font-normal text-pmis-placeholder"
              >
                <LoaderCircle class="h-3.5 w-3.5 animate-spin text-pmis-primary" />
                Đang theo dõi job #{{ watchingJobId }}
                {{ watchMode === 'poll' ? '(polling)' : '' }}
              </span>
              <!-- Tiến độ realtime từ WebSocket: trạng thái, bước hiện tại, iteration, % -->
              <span
                v-if="liveProgress"
                class="flex min-w-0 items-center gap-1 text-xs font-normal"
                :title="liveProgress.current_step"
              >
                <span
                  class="shrink-0 font-semibold"
                  :class="
                    isProgressFailed(liveProgress.status)
                      ? 'text-red-600'
                      : isProgressSuccess(liveProgress.status)
                        ? 'text-emerald-600'
                        : 'text-pmis-primary'
                  "
                >
                  {{ liveProgress.status }}
                </span>
                <span class="truncate text-pmis-text">{{ liveProgress.current_step }}</span>
                <span class="shrink-0 tabular-nums text-pmis-label">
                  ·
                  <template v-if="liveProgress.iteration != null">
                    Iteration {{ liveProgress.iteration }}/{{ liveProgress.max_iterations ?? '?' }}
                    ·
                  </template>
                  {{ liveProgress.progress_percentage }}%
                </span>
              </span>
            </span>
            <button
              type="button"
              class="sg-button-only-icon shrink-0"
              title="Xoá log"
              :disabled="statusLogs.length === 0"
              @click="clearLogs"
            >
              <Trash2 class="h-4 w-4" />
            </button>
          </div>

          <!-- Thanh tiến độ realtime từ WebSocket -->
          <div v-if="liveProgress" class="shrink-0 border-b border-pmis-bordertab px-3 py-2">
            <div class="h-1.5 w-full overflow-hidden rounded-full bg-slate-200">
              <div
                class="h-full rounded-full transition-[width] duration-300"
                :class="isProgressFailed(liveProgress.status) ? 'bg-red-500' : 'bg-pmis-primary'"
                :style="{
                  width: `${Math.min(100, Math.max(0, liveProgress.progress_percentage))}%`
                }"
              />
            </div>
          </div>

          <div
            ref="logContainerRef"
            class="min-h-0 flex-1 overflow-y-auto bg-slate-900 px-3 py-2 font-mono text-xs leading-5"
          >
            <p v-if="statusLogs.length === 0" class="text-slate-500">
              Chưa có log. Bấm "Chia khối" hoặc "Chạy mô phỏng" để bắt đầu.
            </p>
            <p
              v-for="entry in statusLogs"
              :key="entry.id"
              class="whitespace-pre-wrap break-words"
              :class="LOG_LEVEL_CLASS[entry.level]"
            >
              <span class="text-slate-500">[{{ entry.time }}]</span> {{ entry.message }}
            </p>
          </div>
        </section>
      </div>

      <!-- Vùng phải, theo thứ tự ưu tiên:
           1) đang chọn 1 miệng cấp -> panel chỉnh inlet
           2) đang chọn 1 miệng xả   -> panel chỉnh outlet
           3) đang chọn 1 tường      -> panel chỉnh wall
           4) đang chọn 1 geometry   -> panel "Các thuộc tính"
           (Chọn 1 mặt không mở panel riêng — thao tác qua menu nổi Edit Inlet/Outlet/Wall
           trên viewer.)
           Miệng cấp / Miệng xả / Tường / thuộc tính geometry chỉ hiển thị khi đã bật
           bước "Khối hình học". -->
      <aside
        class="flex w-64 border border-pmis-bordertab rounded-lg shrink-0 flex-col overflow-y-auto sg-table-wrapper"
      >
        <!-- Bước "Kết quả": thông tin job đang hiển thị + tải gói post-processing -->
        <div v-if="isResultStepActive && resultJob" class="flex flex-col gap-3 p-4 text-sm">
          <h2 class="font-semibold text-pmis-text">Kết quả mô phỏng</h2>
          <dl class="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1.5">
            <dt class="text-pmis-placeholder">Khối</dt>
            <dd class="truncate text-pmis-text">{{ selectedGeometry?.geometry_code }}</dd>
            <dt class="text-pmis-placeholder">Phiên bản</dt>
            <dd class="text-pmis-text">{{ resultJob.job_version ?? '—' }}</dd>
            <dt class="text-pmis-placeholder">Mã job</dt>
            <dd class="truncate text-pmis-text" :title="resultJob.job_code ?? ''">
              {{ resultJob.job_code }}
            </dd>
            <dt class="text-pmis-placeholder">Chạy lúc</dt>
            <dd class="text-pmis-text">{{ formatDateTime(resultJob.created_at) }}</dd>
            <template v-if="jobResults?.manifest">
              <dt class="text-pmis-placeholder">Thời điểm</dt>
              <dd class="text-pmis-text">Time = {{ jobResults.manifest.time }}</dd>
              <dt class="text-pmis-placeholder">Xuất lúc</dt>
              <dd class="text-pmis-text">
                {{ formatDateTime(jobResults.manifest.generated_at) }}
              </dd>
            </template>
          </dl>
          <a
            v-if="jobResults?.archive_url"
            :href="jobResults.archive_url"
            class="sg-button-secondary justify-center"
            download
          >
            <Download class="h-4 w-4" />
            Tải gói kết quả
          </a>
        </div>
        <div
          v-else-if="
            !isGeometryStepActive &&
            (selectedInlet || selectedOutlet || selectedWall || selectedGeometry)
          "
          class="p-4 text-sm text-pmis-placeholder"
        >
          Chọn "Khối hình học" để xem thông tin
        </div>
        <sg_engr_inlet_edit
          v-else-if="selectedInlet"
          :key="selectedInlet.inlet_id"
          :inlet="selectedInlet"
          @save="onSaveInlet"
          @delete="onDeleteInlet"
          @deselect="onCloseInletPanel"
        />
        <sg_engr_outlet_edit
          v-else-if="selectedOutlet"
          :key="selectedOutlet.outlet_id"
          :outlet="selectedOutlet"
          @save="onSaveOutlet"
          @delete="onDeleteOutlet"
          @deselect="onCloseOutletPanel"
        />
        <sg_engr_wall_edit
          v-else-if="selectedWall"
          :key="selectedWall.wall_id"
          :wall="selectedWall"
          @save="onSaveWall"
          @delete="onDeleteWall"
          @deselect="onCloseWallPanel"
        />
        <sg_engr_geometry_edit
          v-else-if="selectedGeometry"
          :key="selectedGeometry.geometry_id"
          :geometry="selectedGeometry"
          @save="onSaveGeometry"
          @delete="confirmDeleteGeometry"
        />
        <div v-else class="p-4 text-sm text-pmis-placeholder">
          Chọn một khối hình học để xem thuộc tính
        </div>
      </aside>
    </section>

    <sg_message_box
      :show="msgBox.show"
      :type="msgBox.type"
      :title="msgBox.title"
      :message="msgBox.message"
      :text_ok="msgBox.text_ok"
      :text_cancel="msgBox.text_cancel"
      :show_ok="msgBox.show_ok"
      :show_cancel="msgBox.show_cancel"
      @ok="onMsgBoxOk"
      @cancel="onMsgBoxCancel"
    />

    <sg_engr_geometry_add
      :open="showGeometryAdd"
      :project-id="props.project.project_id"
      @close="showGeometryAdd = false"
      @saved="onGeometryAdded"
    />

    <sg_engr_inlet_modal
      :open="showInletModal"
      :geometry="selectedGeometry"
      :face="inletFace"
      @close="showInletModal = false"
      @saved="onInletModalSaved"
    />

    <sg_engr_outlet_modal
      :open="showOutletModal"
      :geometry="selectedGeometry"
      :face="outletFace"
      @close="showOutletModal = false"
      @saved="onOutletModalSaved"
    />

    <sg_engr_wall_modal
      :open="showWallModal"
      :geometry="selectedGeometry"
      :face="wallFace"
      :surface-name="wallSurfaceName"
      @close="showWallModal = false"
      @saved="onWallModalSaved"
    />
  </div>
</template>

<style scoped></style>
