<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import dayjs from 'dayjs'
import {
  Search,
  FunnelPlus,
  FunnelX,
  Plus,
  Boxes,
  Eye,
  Pencil,
  Trash2,
  LoaderCircle
} from 'lucide-vue-next'
import sg_input_text from '@/components/base/sg_input_text.vue'
import sg_select from '@/components/base/sg_select.vue'
import sg_pagination from '@/components/base/sg_pagination.vue'
import sg_message_box from '@/components/base/sg_message_box.vue'
import sg_engr_project_add from '@/features/patient/modals/sg_engr_project_add.vue'
import sg_engr_project_edit from '@/features/patient/modals/sg_engr_project_edit.vue'
import sg_engr_project_view from '@/features/patient/modals/sg_engr_project_view.vue'
import { getProjectPaged, deleteProject } from '@/services/sg_project_srv'
import { getCustomers } from '@/services/sg_customer_srv'
import { useToast } from '@/utils/sg_use_toast'
import { PAGE_SIZE_OPTIONS } from '@/options/sg_site_option'
import {
  PROJECT_STATUS,
  PROJECT_STATUS_OPTIONS,
  getProjectStatusLabel
} from '@/constants/sg_engr_project_const'
import type { SGProjectRead, SGProjectPagedParams } from '@/types/sg_project'
import type { SGSelectItem } from '@/types/sg_site_type'
import type { MsgBoxOptions, MsgType } from '@/types/sg_msg_box.types'

// ======================================================================
// Trang "Danh sách dự án" — layout chia 4 vùng theo chiều dọc:
//   Vùng 1 (Header)   — tiêu đề + nút "Thêm mới"
//   Vùng 2 (Bộ lọc)   — 2 dòng điều kiện lọc
//   Vùng 3 (Danh sách)— bảng dự án
//   Vùng 4 (Phân trang)
// Danh sách được tải từ backend qua getProjectPaged() — lọc & phân trang phía server.
// Tên khách hàng hiển thị được suy ra từ customer_id (SGProjectRead không trả customer_name).
// ======================================================================

interface Project {
  id: string
  code: string
  name: string
  date: string
  customerId: number
  customerName: string
  status: number
  statusLabel: string
}

const toast = useToast()

// Phát ra khi bấm icon "Mô phỏng" trên 1 dòng dự án — sg_engr_main.vue lắng nghe
// để chuyển vùng Nội dung (Vùng 3) sang hiển thị trang sg_engr_simulation.vue,
// truyền theo bản ghi gốc (SGProjectRead) làm thuộc tính "project" của trang đó.
const emit = defineEmits<{
  simulate: [project: SGProjectRead]
}>()

const projects = ref<Project[]>([])

// Bản ghi gốc trả về từ backend — dùng để mở modal "Sửa dự án" (SGProjectRead).
const projectRecords = ref<SGProjectRead[]>([])

// Map customer_id -> customer_name + danh sách chọn khách hàng cho modal.
const customerNameById = ref<Map<number, string>>(new Map())
const customerOptions = ref<SGSelectItem[]>([])

// Ánh xạ bản ghi trả về từ backend (SGProjectRead) sang model hiển thị của bảng.
function toProject(record: SGProjectRead): Project {
  return {
    id: `DA${String(record.project_id).padStart(3, '0')}`,
    code: record.project_code ?? '',
    name: record.project_name,
    date: record.project_date ? dayjs(record.project_date).format('DD/MM/YYYY') : '',
    customerId: record.customer_id,
    customerName: customerNameById.value.get(record.customer_id) ?? `#${record.customer_id}`,
    status: record.project_status,
    statusLabel: getProjectStatusLabel(record.project_status)
  }
}

// --- Vùng 2: điều kiện lọc + tham số phân trang ---
// Giá trị đang gõ trong các ô nhập liệu + trang / số dòng gửi lên backend.
// Dùng thẳng kiểu tham số của backend (SGProjectPagedParams).
const filterForm = reactive<SGProjectPagedParams>({
  page: 1,
  page_size: 10,
  project_code: '',
  project_name: '',
  customer_name: '',
  project_status: null
})

// Giá trị của ô select trạng thái ('' = tất cả).
const statusFilter = ref<number | ''>('')

const statusFilterOptions: SGSelectItem[] = [
  { label: 'Tất cả trạng thái', value: '' },
  ...PROJECT_STATUS_OPTIONS
]

// Tổng số bản ghi / tổng số trang do backend trả về.
const totalItems = ref(0)
const totalPages = ref(1)

// Bật sẵn khi mới vào trang để không lóe lên "Không có dự án phù hợp."
// trong khoảng chờ tải danh sách khách hàng + dự án lần đầu.
const loading = ref(true)

// Tải danh sách khách hàng (1 lần) để hiển thị tên khách hàng theo customer_id.
async function loadCustomers(): Promise<void> {
  try {
    const list = await getCustomers()
    customerNameById.value = new Map(list.map((c) => [c.customer_id, c.customer_name]))
    customerOptions.value = list.map((c) => ({ label: c.customer_name, value: c.customer_id }))
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể tải danh sách khách hàng.'
    toast.error(message)
  }
}

// Tải danh sách dự án có phân trang từ backend theo filterForm.
async function loadProjects(): Promise<void> {
  loading.value = true
  try {
    const res = await getProjectPaged({
      page: filterForm.page,
      page_size: filterForm.page_size,
      project_code: filterForm.project_code?.trim() || null,
      project_name: filterForm.project_name?.trim() || null,
      customer_name: filterForm.customer_name?.trim() || null,
      project_status: statusFilter.value === '' ? null : Number(statusFilter.value)
    })

    projectRecords.value = res.items
    projects.value = res.items.map(toProject)
    totalItems.value = res.total
    totalPages.value = Math.max(1, res.total_pages)

    // Trang hiện tại vượt quá tổng số trang (vd sau khi xóa dòng cuối) -> lùi lại và tải lại.
    if (filterForm.page > totalPages.value) {
      filterForm.page = totalPages.value
      await loadProjects()
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Không thể tải danh sách dự án.'
    toast.error(message)
  } finally {
    loading.value = false
  }
}

onMounted(async () => {
  await loadCustomers()
  // Ánh xạ lại tên khách hàng cho các dòng đã tải (nếu có).
  projects.value = projectRecords.value.map(toProject)
  await loadProjects()
})

// Nút "Filter" bật/tắt hiển thị các ô lọc ở Dòng 2 (Mã dự án / Khách hàng / Trạng thái).
//   showAdvancedFilter = true  -> hiện Dòng 2, icon FunnelX  (bấm để ẩn)
//   showAdvancedFilter = false -> ẩn Dòng 2, icon FunnelPlus (bấm để hiện)
const showAdvancedFilter = ref(true)

function toggleAdvancedFilter(): void {
  showAdvancedFilter.value = !showAdvancedFilter.value

  // Khi ẩn Dòng 2, xóa điều kiện lọc rồi tải lại từ trang 1.
  if (!showAdvancedFilter.value) {
    filterForm.project_code = ''
    filterForm.customer_name = ''
    statusFilter.value = ''
    filterForm.page = 1
    void loadProjects()
  }
}

// Áp dụng điều kiện lọc — gọi khi nhấn "Enter" trong ô nhập liệu bất kỳ,
// bấm icon tìm kiếm hoặc đổi trạng thái. Luôn quay về trang 1.
function applyFilter(): void {
  filterForm.page = 1
  void loadProjects()
}

function changePageSize(): void {
  filterForm.page = 1
  void loadProjects()
}

function changePage(page: number): void {
  filterForm.page = page
  void loadProjects()
}

// --- Vùng 1: thao tác thêm mới ---
const showAddModal = ref(false)

function onCreate(): void {
  showAddModal.value = true
}

function onCloseAddModal(): void {
  showAddModal.value = false
}

async function onProjectSaved(): Promise<void> {
  // Modal đã gọi API thành công — giữ nguyên trang hiện hành và tải lại danh sách.
  await loadProjects()
  showAddModal.value = false
}

// Trạng thái + dữ liệu cho modal "Xem dự án".
const showViewModal = ref(false)
const viewingProject = ref<SGProjectRead | null>(null)

function onSimulate(project: Project): void {
  const record = findRecord(project)
  if (!record) {
    toast.error('Không tìm thấy thông tin dự án.')
    return
  }

  emit('simulate', record)
}

function onView(project: Project): void {
  const record = findRecord(project)
  if (!record) {
    toast.error('Không tìm thấy thông tin dự án.')
    return
  }

  viewingProject.value = { ...record }
  showViewModal.value = true
}

function onCloseViewModal(): void {
  showViewModal.value = false
  viewingProject.value = null
}

// Modal "Xem dự án" đã đổi trạng thái thành công — tải lại danh sách rồi đóng modal.
async function onViewModalSaved(updated: SGProjectRead): Promise<void> {
  void updated
  onCloseViewModal()
  await loadProjects()
}

// Trạng thái + dữ liệu cho modal "Sửa dự án".
const showEditModal = ref(false)
const editingProject = ref<SGProjectRead | null>(null)

function findRecord(project: Project): SGProjectRead | undefined {
  // project.id có dạng "DA003" -> tách lấy số để tìm bản ghi gốc.
  const projectId = Number(project.id.replace(/\D/g, ''))
  return projectRecords.value.find((r) => r.project_id === projectId)
}

function onEdit(project: Project): void {
  const record = findRecord(project)
  if (!record) {
    toast.error('Không tìm thấy thông tin dự án.')
    return
  }

  editingProject.value = { ...record }
  showEditModal.value = true
}

function onCloseEditModal(): void {
  showEditModal.value = false
  editingProject.value = null
}

// Modal "Sửa dự án" đã gọi API updateProject thành công — cập nhật lại danh sách rồi đóng modal.
async function onEditModalSaved(updated: SGProjectRead): Promise<void> {
  void updated
  onCloseEditModal()
  await loadProjects()
}

// --- Xóa dự án ---
// Một hộp thoại dùng chung: hỏi xác nhận trước khi xóa, và báo lỗi nếu API thất bại.
const msgBox = reactive<MsgBoxOptions>({
  show: false,
  type: 'confirm',
  title: '',
  message: '',
  text_ok: 'Xóa',
  text_cancel: 'Hủy',
  show_ok: true,
  show_cancel: true
})

// Chế độ hiện tại của hộp thoại: 'confirm' = đang hỏi xóa, 'error' = đang báo lỗi / thông báo.
const msgBoxMode = ref<'confirm' | 'error'>('confirm')

// Dự án đang chờ xác nhận xóa.
const deletingProject = ref<SGProjectRead | null>(null)
const deleting = ref(false)

// Mở hộp thoại ở chế độ "thông báo": chỉ 1 nút OK.
// Luôn set đủ cả 3 cờ nút để không bị dính giá trị cũ từ lần mở trước (msgBox dùng chung).
function openInfoBox(title: string, message: string, type: MsgType = 'info'): void {
  deletingProject.value = null
  msgBoxMode.value = 'error' // onMsgBoxOk / onMsgBoxCancel chỉ đóng hộp thoại
  msgBox.type = type
  msgBox.title = title
  msgBox.message = message
  msgBox.text_ok = 'OK'
  msgBox.show_ok = true
  msgBox.show_danger = false
  msgBox.show_cancel = false
  msgBox.show = true
}

function onDelete(project: Project): void {
  const record = findRecord(project)
  if (!record) {
    toast.error('Không tìm thấy thông tin dự án.')
    return
  }

  // Chỉ cho phép xóa dự án ở trạng thái "Nháp" — thông báo qua MessageBox nếu khác.
  if (record.project_status !== PROJECT_STATUS.DRAFT) {
    openInfoBox('Không thể xóa', 'Chỉ có thể xóa dự án ở trạng thái "Nháp".', 'warning')
    return
  }

  // 1. Hỏi xác nhận trước khi xóa — set đủ cả 3 cờ nút.
  deletingProject.value = record
  msgBoxMode.value = 'confirm'
  msgBox.type = 'confirm'
  msgBox.title = 'Xác nhận xóa'
  msgBox.message = `Bạn có chắc chắn muốn xóa dự án "${record.project_name}" không?`
  msgBox.text_ok = 'Xóa'
  msgBox.text_cancel = 'Hủy'
  msgBox.show_ok = true
  msgBox.show_danger = false
  msgBox.show_cancel = true
  msgBox.show = true
}

function onMsgBoxCancel(): void {
  msgBox.show = false
  if (msgBoxMode.value === 'confirm') deletingProject.value = null
}

async function onMsgBoxOk(): Promise<void> {
  // Đang ở chế độ báo lỗi -> chỉ đóng hộp thoại.
  if (msgBoxMode.value === 'error') {
    msgBox.show = false
    return
  }

  // Chế độ xác nhận -> tiến hành xóa.
  const record = deletingProject.value
  if (!record || deleting.value) return

  deleting.value = true
  try {
    // 2. Gọi API xóa dự án.
    await deleteProject(record.project_id)

    // 3. Thành công: đóng hộp thoại, thông báo và tải lại danh sách.
    msgBox.show = false
    deletingProject.value = null
    toast.success('Xóa dự án thành công.')
    await loadProjects()
  } catch (error) {
    // 4. Lỗi: chuyển hộp thoại sang chế độ báo lỗi (chỉ 1 nút OK).
    const message = error instanceof Error ? error.message : 'Không thể xóa dự án.'
    openInfoBox('Lỗi', message, 'error')
  } finally {
    deleting.value = false
  }
}
</script>

<template>
  <div class="flex h-full w-full flex-col gap-4">
    <!-- ============================================================ -->
    <!-- Vùng 1: Header -->
    <!-- ============================================================ -->
    <header class="flex shrink-0 items-center justify-between gap-4">
      <h1 class="sg-title-page uppercase text-lg">Danh sách dự án</h1>

      <button type="button" class="sg-button-primary" @click="onCreate">
        <Plus class="h-4 w-4" />
        <span>Thêm mới</span>
      </button>
    </header>

    <!-- ============================================================ -->
    <!-- Vùng 2: Điều kiện lọc -->
    <!-- ============================================================ -->
    <section class="flex shrink-0 flex-col gap-3">
      <!-- Dòng 1 -->
      <div class="flex items-center justify-between gap-3">
        <div class="flex items-center gap-2">
          <div class="w-72">
            <sg_input_text
              v-model="filterForm.project_name"
              placeholder="Tìm kiếm theo tên dự án"
              input-c-s-s="py-1 sg-input w-full"
              :iconright="Search"
              @enter="applyFilter"
              @icon-right-click="applyFilter"
            />
          </div>

          <button
            type="button"
            class="sg-button-filter"
            :title="showAdvancedFilter ? 'Ẩn bộ lọc' : 'Hiện bộ lọc'"
            @click="toggleAdvancedFilter"
          >
            <FunnelX v-if="showAdvancedFilter" class="h-5 w-5" />
            <FunnelPlus v-else class="h-5 w-5" />
          </button>
        </div>

        <div class="w-48 shrink-0">
          <sg_select
            v-model="filterForm.page_size"
            :items="PAGE_SIZE_OPTIONS"
            :show-add="false"
            :show-edit="false"
            :show-delete="false"
            placeholder="Số dòng / trang"
            @on-change="changePageSize"
          />
        </div>
      </div>

      <!-- Dòng 2 -->
      <div v-if="showAdvancedFilter" class="flex items-center gap-3">
        <sg_input_text
          v-model="filterForm.project_code"
          placeholder="Mã dự án"
          input-c-s-s="py-1 sg-input w-full"
          @enter="applyFilter"
        />
        <sg_input_text
          v-model="filterForm.customer_name"
          placeholder="Tên khách hàng"
          input-c-s-s="py-1 sg-input w-full"
          @enter="applyFilter"
        />
        <div class="w-56 shrink-0">
          <sg_select
            v-model="statusFilter"
            :items="statusFilterOptions"
            :show-add="false"
            :show-edit="false"
            :show-delete="false"
            placeholder="Trạng thái"
            @on-change="applyFilter"
          />
        </div>
      </div>
    </section>

    <!-- ============================================================ -->
    <!-- Vùng 3: Danh sách dự án -->
    <!-- ============================================================ -->
    <section class="min-h-0 flex-1 overflow-auto sg-table-wrapper">
      <table class="w-full border-collapse text-sm">
        <thead class="sticky top-0 z-10 bg-slate-50 text-left text-pmis-label">
          <tr>
            <th class="py-3 px-4 border-b border-gray-200 font-semibold" style="width: 120px">
              Mã dự án
            </th>
            <th class="py-3 px-4 border-b border-gray-200 font-semibold" style="min-width: 220px">
              Tên dự án
            </th>
            <th class="py-3 px-4 border-b border-gray-200 font-semibold" style="width: 120px">
              Ngày dự án
            </th>
            <th class="py-3 px-4 border-b border-gray-200 font-semibold" style="min-width: 180px">
              Khách hàng
            </th>
            <th class="py-3 px-4 border-b border-gray-200 font-semibold" style="width: 140px">
              Trạng thái
            </th>
            <th class="py-3 px-4 border-b border-gray-200 font-semibold" style="width: 120px">
              Thao tác
            </th>
          </tr>
        </thead>

        <tbody>
          <!-- Đang tải dữ liệu từ backend -->
          <tr v-if="loading">
            <td colspan="6" class="py-8 text-center text-pmis-placeholder">
              <span class="inline-flex items-center gap-2">
                <LoaderCircle class="h-6 w-6 animate-spin" />
                Đang tải dữ liệu...
              </span>
            </td>
          </tr>

          <tr
            v-for="project in projects"
            v-show="!loading"
            :key="project.id"
            class="hover:bg-pmis-primary-50/50"
          >
            <td class="py-3 px-4 border-b border-gray-200" style="width: 120px">
              {{ project.code }}
            </td>
            <td class="py-3 px-4 border-b border-gray-200" style="min-width: 220px">
              {{ project.name }}
            </td>
            <td class="py-3 px-4 border-b border-gray-200" style="width: 120px">
              {{ project.date }}
            </td>
            <td class="py-3 px-4 border-b border-gray-200" style="min-width: 180px">
              {{ project.customerName }}
            </td>
            <td class="py-3 px-4 border-b border-gray-200" style="width: 140px">
              <span
                class="px-2 py-1 text-xs font-semibold rounded-full bg-transparent border"
                :class="[
                  'px-2 py-1 rounded text-xs font-semibold',
                  project.status === PROJECT_STATUS.DRAFT && 'border-status-draft',
                  project.status === PROJECT_STATUS.ACTIVE && 'border-status-active',
                  project.status === PROJECT_STATUS.INACTIVE && 'border-status-inactive'
                ]"
              >
                {{ project.statusLabel }}
              </span>
              <!-- {{ project.statusLabel }} -->
            </td>
            <td class="py-3 px-4 border-b border-gray-200" style="width: 120px">
              <div class="flex items-center gap-3">
                <button
                  type="button"
                  class="sg-button-only-icon"
                  title="Mô phỏng"
                  @click="onSimulate(project)"
                >
                  <Boxes class="h-4 w-4" />
                </button>
                <button
                  type="button"
                  class="sg-button-only-icon"
                  title="Xem"
                  @click="onView(project)"
                >
                  <Eye class="h-4 w-4" />
                </button>
                <button
                  type="button"
                  class="sg-button-only-icon"
                  title="Sửa"
                  @click="onEdit(project)"
                >
                  <Pencil class="h-4 w-4" />
                </button>
                <button
                  type="button"
                  class="sg-button-only-icon-del"
                  title="Xóa"
                  @click="onDelete(project)"
                >
                  <Trash2 class="h-4 w-4" />
                </button>
              </div>
            </td>
          </tr>

          <tr v-if="!loading && projects.length === 0">
            <td colspan="6" class="py-8 text-center text-pmis-placeholder">
              Không có dự án phù hợp.
            </td>
          </tr>
        </tbody>
      </table>
    </section>

    <!-- ============================================================ -->
    <!-- Vùng 4: Phân trang (nằm bên trái) -->
    <!-- ============================================================ -->
    <footer class="flex shrink-0 items-center justify-start">
      <sg_pagination
        :curr-page="filterForm.page"
        :total-pages="totalPages"
        :total-items="totalItems"
        :page-size="filterForm.page_size"
        item-name="dự án"
        @update:page="changePage"
      />
    </footer>

    <!-- ============================================================ -->
    <!-- Modal: Thêm mới dự án -->
    <!-- ============================================================ -->
    <sg_engr_project_add
      :open="showAddModal"
      :customer-options="customerOptions"
      @close="onCloseAddModal"
      @saved="onProjectSaved"
    />

    <!-- ============================================================ -->
    <!-- Modal: Sửa dự án -->
    <!-- ============================================================ -->
    <sg_engr_project_edit
      :open="showEditModal"
      :project="editingProject"
      :customer-options="customerOptions"
      @close="onCloseEditModal"
      @saved="onEditModalSaved"
    />

    <!-- ============================================================ -->
    <!-- Modal: Xem dự án -->
    <!-- ============================================================ -->
    <sg_engr_project_view
      :open="showViewModal"
      :project="viewingProject"
      :customer-options="customerOptions"
      @close="onCloseViewModal"
      @saved="onViewModalSaved"
    />

    <!-- ============================================================ -->
    <!-- Hộp thoại: xác nhận xóa / báo lỗi khi xóa -->
    <!-- ============================================================ -->
    <sg_message_box
      :show="msgBox.show"
      :type="msgBox.type"
      :title="msgBox.title"
      :message="msgBox.message"
      :text_ok="msgBox.text_ok"
      :text_cancel="msgBox.text_cancel"
      :show_ok="msgBox.show_ok"
      :show_cancel="msgBox.show_cancel"
      @ok="onMsgBoxOk"
      @cancel="onMsgBoxCancel"
    />
  </div>
</template>

<style scoped></style>
