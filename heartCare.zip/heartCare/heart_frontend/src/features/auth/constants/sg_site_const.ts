// Định nghĩa các Role (Actor) trong hệ thống như đã thống nhất
export const HEARTRole = {
  PATIENT: 1,
  SYSTEM_ADMIN: 2
} as const

export type HEARTRoleType = (typeof HEARTRole)[keyof typeof HEARTRole]
