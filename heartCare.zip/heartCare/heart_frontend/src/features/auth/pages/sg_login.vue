<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { Eye, EyeOff, Lock, User2, ArrowRight, Hotel } from 'lucide-vue-next'
import sg_check_box from '@/components/base/sg_check_box.vue'
import { HEARTRole, type HEARTRoleType } from '@/features/auth/constants/sg_site_const'
import { useAuthStore } from '@/stores/sg_auth_store'
import { loginUser } from '@/services/pt_user_srv'

const router = useRouter()
const authStore = useAuthStore()

// State quản lý form
const username = ref<string>('')
const password = ref<string>('')
const rememberMe = ref<boolean>(false)
const showPassword = ref<boolean>(false)
const isLoading = ref<boolean>(false)

// const isAgreed = ref(false)

const errorMessage = ref<string>('')

// Hàm xử lý đăng nhập: gọi API /users/login, lưu user vào store rồi điều hướng theo role
const handleLogin = async (e: Event) => {
  e.preventDefault()
  if (!username.value || !password.value) return

  isLoading.value = true
  errorMessage.value = ''

  try {
    // loginUser tự lưu access_token vào localStorage("token")
    const token = await loginUser({ username: username.value, password: password.value })

    // Role lấy từ backend (1: patient, 2: admin) — trùng giá trị với HEARTRole
    const role = token.user.roles as HEARTRoleType
    authStore.setUser({ username: token.user.username, role })

    // Điều hướng bằng chuỗi path
    if (role === HEARTRole.SYSTEM_ADMIN) {
      router.push('/sysadmin')
    } else if (role === HEARTRole.PATIENT) {
      router.push('/patient')
    }
  } catch (error) {
    errorMessage.value =
      error instanceof Error ? error.message : 'Đăng nhập thất bại, vui lòng thử lại.'
  } finally {
    isLoading.value = false
  }
}
</script>

<template>
  <div class="min-h-screen w-full flex">
    <div
      class="hidden lg:flex lg:w-[60%] bg-gradient-to-br from-indigo-700 via-blue-600 to-cyan-500 p-12 flex-col justify-between relative overflow-hidden"
    >
      <div
        class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff10_1px,transparent_1px),linear-gradient(to_bottom,#ffffff10_1px,transparent_1px)] bg-[size:32px_32px]"
      ></div>

      <div class="flex items-center gap-3 relative z-10 text-white">
        <div class="p-2 bg-white/10 backdrop-blur-md rounded-xl border border-white/20">
          <Hotel class="w-8 h-8 text-white" />
        </div>
        <div>
          <span class="text-2xl font-bold italic tracking-wider block">iHEART</span>
          <span class="text-xs text-blue-200 uppercase tracking-widest">
            Đề tài: Phân tích dữ liệu y tế & xây dựng ứng dụng hỗ trợ dự đoán nguy cơ mắc bệnh tim
            mạch
          </span>
        </div>
      </div>

      <div class="relative z-10 max-w-xl text-white mb-12">
        <div class="grid grid-cols-[20px_1fr] gap-y-2">
          <!-- <div>-</div>
          <div class="text-blue-100 text-lg font-light leading-relaxed">
            Giám sát, kiểm soát hoạt động khách sạn theo thời gian thực.
          </div>

          <div>-</div>
          <div class="text-blue-100 text-lg font-light leading-relaxed">
            Cùng AI phân tích và định hướng khách sạn trong tương lai.
          </div> -->
        </div>
      </div>

      <div class="relative z-10 text-sm text-blue-200/60">
        &copy; 2026 iHeart. All rights reserved.
      </div>
    </div>

    <div
      class="w-full lg:w-[40%] flex items-center justify-center p-6 sm:p-12 bg-white shadow-2xl z-10"
    >
      <div class="w-full max-w-md space-y-8">
        <div class="text-center lg:text-left">
          <div class="flex lg:hidden items-center justify-center gap-2 mb-6">
            <div class="p-2 bg-pmis-bg backdrop-blur-md rounded-xl border border-pmis-primary-300">
              <Hotel class="w-8 h-8 text-pmis-primary" />
            </div>
            <!-- <Hotel class="w-10 h-10 text-pmis-primary" /> -->
            <span class="text-2xl font-bold italic text-pmis-primary tracking-tight"> iHeart </span>
          </div>

          <h2 class="text-3xl font-bold uppercase tracking-tight text-pmis-primary">Đăng nhập</h2>
          <p class="">Nhập thông tin tài khoản của bạn.</p>
        </div>

        <form class="space-y-6" @submit="handleLogin">
          <div>
            <label for="username" class="sg-label-input"> Tài khoản</label>
            <div class="relative rounded-lg shadow-sm">
              <div
                class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-pmis-placeholder"
              >
                <User2 class="h-5 w-5" stroke-width="1" />
              </div>
              <input
                id="username"
                v-model="username"
                type="text"
                required
                placeholder="nhập tài khoản"
                class="w-full py-2 pl-10 pr-4 sg-input"
              />
            </div>
          </div>

          <div>
            <div class="flex items-center justify-between">
              <label for="password" class="sg-label-input"> Mật khẩu </label>
              <a href="#" class="sg-link"> Quên mật khẩu? </a>
            </div>
            <div class="relative rounded-lg shadow-sm">
              <div
                class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-pmis-placeholder"
              >
                <Lock class="h-5 w-5" stroke-width="1" />
              </div>
              <input
                id="password"
                v-model="password"
                :type="showPassword ? 'text' : 'password'"
                required
                placeholder="••••••••"
                class="w-full py-2 pl-10 pr-12 sg-input"
              />
              <button
                type="button"
                class="absolute inset-y-0 right-0 pr-3 sg-button-only-icon"
                @click="showPassword = !showPassword"
              >
                <EyeOff v-if="showPassword" class="h-5 w-5" stroke-width="1" />
                <Eye v-else class="h-5 w-5" stroke-width="1" />
              </button>
            </div>
          </div>

          <div class="flex items-center">
            <sg_check_box
              id="terms"
              v-model="rememberMe"
              label="Ghi nhớ đăng nhập trên thiết bị này"
            />
          </div>

          <p v-if="errorMessage" class="text-sm text-red-600">{{ errorMessage }}</p>

          <button type="submit" :disabled="isLoading" class="w-full sg-button-primary">
            <span
              v-if="isLoading"
              class="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"
            ></span>
            <span v-else class="flex items-center gap-1">
              Đăng nhập hệ thống
              <ArrowRight class="w-5 h-5" />
            </span>
          </button>
        </form>
      </div>
    </div>
  </div>
</template>
