<template>
  <RouterView />
  <sg_toast />
</template>

<script setup lang="ts">
import { RouterView } from 'vue-router'
import sg_toast from '@/components/base/sg_toast.vue'
</script>

<style scoped></style>
