// src/stores/toast.store.ts
import { defineStore } from "pinia"
// import type { ToastItem, ToastOptions, ToastPosition } from "@/components/toast/toast.types"
import type { ToastItem, ToastOptions, ToastPosition } from "@/types/sg_toast.types"

let seed = 0

export const useToastStore = defineStore("toast", {
  state: () => ({
    toasts: [] as ToastItem[],
    position: "top-right" as ToastPosition,
    max: 5
  }),

  actions: {
    push(options: ToastOptions) {
      if (this.toasts.length >= this.max) {
        this.toasts.shift()
      }

      const toast: ToastItem = {
        id: ++seed,
        type: options.type ?? "info",
        message: options.message,
        duration: options.duration ?? 3000,
        closable: options.closable ?? true,
        position: this.position
      }

      this.toasts.push(toast)

      setTimeout(() => this.remove(toast.id), toast.duration)
    },

    remove(id: number) {
      this.toasts = this.toasts.filter(t => t.id !== id)
    }
  }
})

