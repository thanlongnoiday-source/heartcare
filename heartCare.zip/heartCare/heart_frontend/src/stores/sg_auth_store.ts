// src/stores/sg_auth_store.ts

import { defineStore } from 'pinia'
import { HEARTRole, type HEARTRoleType } from '@/features/auth/constants/sg_site_const'

export interface SGAuthUser {
  username: string
  role: HEARTRoleType
}

export const ROLE_LABELS: Record<HEARTRoleType, string> = {
  [HEARTRole.PATIENT]: 'Bệnh nhân',
  [HEARTRole.SYSTEM_ADMIN]: 'Quản trị hệ thống'
}

// TODO: chưa nối API đăng nhập thật — tạm lưu username + role chọn ở form đăng nhập.
// Lưu vào localStorage để F5 không mất thông tin user.
const STORAGE_KEY = 'sg_auth_user'

function loadUser(): SGAuthUser | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? (JSON.parse(raw) as SGAuthUser) : null
  } catch {
    return null
  }
}

export const useAuthStore = defineStore('auth', {
  state: () => ({
    user: loadUser()
  }),

  getters: {
    displayName: (state): string => state.user?.username ?? '',
    roleLabel: (state): string => (state.user ? ROLE_LABELS[state.user.role] : '')
  },

  actions: {
    setUser(user: SGAuthUser) {
      this.user = user
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(user))
      } catch {
        // Bỏ qua — trình duyệt chặn storage thì chỉ giữ trong phiên hiện tại
      }
    },

    logout() {
      this.user = null
      try {
        localStorage.removeItem(STORAGE_KEY)
      } catch {
        // Bỏ qua
      }
    }
  }
})
