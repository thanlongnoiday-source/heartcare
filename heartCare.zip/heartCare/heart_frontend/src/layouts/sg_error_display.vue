<template>
  <div
    v-if="show && message"
    class="mt-2 p-4 bg-red-50 text-red-700 rounded-lg border border-red-200 flex items-start gap-3 shadow-sm"
  >
    <!-- Error Icon -->
    <div class="flex-shrink-0 mt-0.5">
      <AlertCircle class="w-5 h-5 text-red-600" />
    </div>

    <!-- Error Message -->
    <div class="flex-1">
      <p class="font-semibold text-red-800">{{ title }}</p>
      <p class="text-sm text-red-700 mt-1">{{ message }}</p>
      <p v-if="code" class="text-xs text-red-600 mt-2 opacity-70">Mã lỗi: {{ code }}</p>
    </div>

    <!-- Close Button -->
    <button
      v-if="showbtnClose"
      class="text-red-600 hover:text-red-800 transition-colors flex-shrink-0"
      aria-label="Đóng thông báo"
      @click="emit('close')"
    >
      <Ban class="w-5 h-5" />
    </button>
  </div>
</template>

<script setup lang="ts">
import { AlertCircle, Ban } from 'lucide-vue-next'
// import { defineEmits, defineProps } from "vue";

defineProps<{
  show: boolean
  message: string
  title?: string
  code?: number | string
  showbtnClose?: boolean
}>()

const emit = defineEmits<{
  close: []
}>()
</script>

<style scoped>
/* Add any additional styles if needed */
</style>
