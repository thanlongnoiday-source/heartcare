<script setup lang="ts">
import { computed } from 'vue'

type RadioValue = string | number | boolean
type RadioSize = 'sm' | 'md' | 'lg'

interface Props {
  modelValue: RadioValue
  value: RadioValue
  label?: string
  name?: string
  disabled?: boolean
  size?: RadioSize
}

const props = withDefaults(defineProps<Props>(), {
  label: '',
  name: '',
  disabled: false,
  size: 'md'
})

const emit = defineEmits<{
  (e: 'update:modelValue', value: RadioValue): void
}>()

const isChecked = computed<boolean>(() => {
  return props.modelValue === props.value
})

function onChange(): void {
  if (props.disabled) return

  emit('update:modelValue', props.value)
}

const radioSizeClass = computed<string>(() => {
  switch (props.size) {
    case 'sm':
      return 'h-4 w-4'

    case 'lg':
      return 'h-6 w-6'

    case 'md':
    default:
      return 'h-5 w-5'
  }
})

const dotSizeClass = computed<string>(() => {
  switch (props.size) {
    case 'sm':
      return 'h-1.5 w-1.5'

    case 'lg':
      return 'h-3 w-3'

    case 'md':
    default:
      return 'h-2.5 w-2.5'
  }
})

const borderWidthClass = computed<string>(() => {
  switch (props.size) {
    case 'lg':
      return 'border-[2px]'

    case 'sm':
    case 'md':
    default:
      return 'border-1'
  }
})

const labelSizeClass = computed<string>(() => {
  switch (props.size) {
    case 'sm':
      return 'text-sm'

    case 'lg':
      return 'text-base'

    case 'md':
    default:
      return 'text-[15px]'
  }
})
</script>

<template>
  <label
    class="group inline-flex items-center gap-[6px] select-none transition-all duration-200"
    :class="[disabled ? 'cursor-not-allowed' : 'cursor-pointer hover:-translate-y-[1px]']"
  >
    <!-- Hidden Native Input -->
    <input
      type="radio"
      class="hidden"
      :checked="isChecked"
      :disabled="disabled"
      :name="name"
      @change="onChange"
    />

    <!-- Radio Box -->
    <div
      class="relative flex shrink-0 items-center justify-center rounded-full transition-all duration-200 ease-out"
      :class="[
        radioSizeClass,
        borderWidthClass,

        // Checked
        isChecked
          ? disabled
            ? `
              border-slate-400
              bg-slate-400
              shadow-none
            `
            : `
              border-pmis-primary
              bg-pmis-primary
              shadow-[0_0_0_2px_rgba(37,99,235,0.12)]
            `
          : // Unchecked
            disabled
            ? `
              border-slate-300 border
              bg-slate-200
              shadow-none
            `
            : `
              border-slate-400 border
              bg-white
              group-hover:border-pmis-primary
              group-hover:shadow-[0_0_0_2px_rgba(37,99,235,0.08)]
            `
      ]"
    >
      <!-- Inner White Dot -->
      <div
        class="rounded-full bg-white transition-all duration-200 ease-out"
        :class="[dotSizeClass, isChecked ? 'scale-100 opacity-100' : 'scale-0 opacity-0']"
      />
    </div>

    <!-- Label -->
    <span
      v-if="label"
      class="font-medium leading-none transition-colors duration-200"
      :class="[labelSizeClass, disabled ? 'text-slate-400' : 'text-slate-800']"
    >
      {{ label }}
    </span>
  </label>
</template>
