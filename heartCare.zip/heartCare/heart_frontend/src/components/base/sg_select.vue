<template>
  <div ref="rootRef" class="relative w-full">
    <!-- Label -->
    <label v-if="label" class="block" :class="labelCSS">
      {{ label }}
      <span v-if="requiredInput" class="text-pmis-danger">*</span>
    </label>

    <!-- Trigger -->
    <div
      tabindex="0"
      class="flex items-center gap-2 justify-between"
      :class="[
        error ? 'border-pmis-danger focus:ring-pmis-danger' : '',
        selectcss,
        props.disabled ? '' : 'cursor-pointer'
      ]"
      @click="onSelectClick()"
    >
      <span
        class="truncate block flex-1 min-w-0"
        :class="[
          selectedLabel ? 'text-pmis-text' : 'text-pmis-placeholder',
          props.disabled ? 'text-pmis-disabled' : 'text-pmis-placeholder'
        ]"
        :title="String(selectedLabel || placeholder)"
      >
        {{ selectedLabel || placeholder }}
      </span>

      <!-- Action buttons -->
      <div class="flex items-center gap-3 flex-shrink-0 ml-2">
        <!-- Add Icon -->
        <div v-if="showAdd" class="relative group">
          <Plus :class="addColor" class="h-4 w-4" @click.stop="onAdd" />
          <!-- Tooltip -->
          <div
            v-if="!props.disabled"
            class="absolute top-8 left-1/2 -translate-x-1/2 whitespace-nowrap rounded bg-white border border-pmis-primary px-2 py-1 opacity-0 group-hover:opacity-100 transition pointer-events-none"
          >
            Thêm
          </div>
        </div>

        <!-- Edit Icon -->
        <div v-if="showEdit" class="relative group">
          <Pencil :class="editColor" class="h-4 w-4" @click.stop="onEdit" />
          <!-- Tooltip -->
          <div
            v-if="!props.disabled"
            class="absolute top-8 left-1/2 -translate-x-1/2 whitespace-nowrap rounded bg-white border border-pmis-primary px-2 py-1 opacity-0 group-hover:opacity-100 transition pointer-events-none"
          >
            Sửa
          </div>
        </div>

        <!-- Delete Icon -->
        <div v-if="showDelete" class="relative group">
          <X :class="deleteColor" class="h-4 w-4" @click.stop="onDelete" />
          <!-- Tooltip -->
          <div
            v-if="!props.disabled"
            class="absolute top-8 left-1/2 -translate-x-1/2 whitespace-nowrap rounded bg-white border border-pmis-primary px-2 py-1 opacity-0 group-hover:opacity-100 transition pointer-events-none"
          >
            Xóa
          </div>
        </div>

        <!-- Dropdown icon -->
        <ChevronDown class="h-4 w-4 text-gray-600" />
      </div>
    </div>

    <!-- Dropdown -->
    <ul
      v-if="open && !disabled && !teleportDropdown"
      class="absolute z-[9999] mt-1 rounded-lg border bg-white shadow-lg overflow-y-auto left-0 right-0"
      :style="{
        maxHeight: maxHeight
      }"
    >
      <li
        v-for="opt in items"
        :key="getValue(opt)"
        class="cursor-pointer px-3 py-2 text-sm hover:bg-pmis-primary-50 truncate"
        :title="String(getLabel(opt))"
        @click="choose(opt)"
      >
        {{ getLabel(opt) }}
      </li>
    </ul>

    <!-- Error Message -->
    <p v-if="error" class="text-sm text-pmis-danger mt-0.5">
      {{ error }}
    </p>

    <teleport to="body">
      <ul
        v-if="open && !disabled && teleportDropdown"
        class="fixed z-[9999] rounded-lg border bg-white shadow-lg overflow-y-auto"
        :style="dropdownStyle"
      >
        <li
          v-for="opt in items"
          :key="getValue(opt)"
          class="cursor-pointer px-3 py-2 text-sm hover:bg-primary/50 truncate"
          :title="String(getLabel(opt))"
          @click="choose(opt)"
        >
          {{ getLabel(opt) }}
        </li>
      </ul>
    </teleport>
  </div>
</template>

<script setup lang="ts">
import type { SGSelectItem } from '@/types/sg_site_type'
import { ChevronDown, Pencil, Plus, X } from 'lucide-vue-next'
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'

type SelectValue = string | number | null
type DropDownWidth = 'auto' | 'full' | 'min-content'

interface Props {
  modelValue?: SelectValue
  label?: string
  labelCSS?: string
  requiredInput?: boolean
  items?: SGSelectItem[]
  placeholder?: string
  disabled?: boolean
  error?: string
  dropdownWidth?: DropDownWidth
  maxHeight?: string
  selectcss?: string
  addColor?: string
  editColor?: string
  deleteColor?: string
  autoReset?: boolean
  showAdd?: boolean
  showEdit?: boolean
  showDelete?: boolean
  teleportDropdown?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  modelValue: null,
  label: '',
  labelCSS: 'font-medium text-sm font-cambria text-lighttext',
  requiredInput: false,
  items: () => [],
  placeholder: 'Chọn mục',
  disabled: false,
  error: '',
  dropdownWidth: 'auto',
  maxHeight: '200px',
  selectcss:
    'w-full rounded-lg border bg-white px-3 py-2.5 text-sm shadow-sm hover:border-primary focus-within:border-primary focus-within:ring-1 focus-within:ring-primary',
  addColor: 'text-green-600 hover:text-green-700',
  editColor: 'text-blue-600 hover:text-blue-700',
  deleteColor: 'text-red-600 hover:text-red-700',
  autoReset: false,
  showAdd: true,
  showEdit: true,
  showDelete: true,
  teleportDropdown: false
})

const emit = defineEmits<{
  (e: 'update:modelValue', value: string | number | null): void
  (e: 'on-add'): void
  (e: 'on-edit', value: string | number): void
  (e: 'on-delete', value: string | number): void
  (e: 'on-change', value: string | number): void
  (e: 'on-selected', value: string | number): void
}>()

const open = ref(false)
const selected = ref<SelectValue>(props.modelValue)
const selectedLabel = ref<string | number | ''>('')
const rootRef = ref<HTMLElement | null>(null)
const dropdownPosition = ref({ top: 0, left: 0, width: 0 })
// const label = ref<string>("Đơn vị cơ bản");

const getLabel = (opt: string | { label: string; value: string | number }): string | number => {
  return typeof opt === 'string' ? opt : opt.label
}

const getValue = (opt: string | { label: string; value: string | number }): string | number => {
  return typeof opt === 'string' ? opt : opt.value
}

const findLabelByValue = (value: SelectValue): string => {
  if (value === '' || value === null || value === undefined) {
    return ''
  }
  // if (!value) return "";

  const match = props.items.find((opt) => getValue(opt) == value)

  return match ? String(getLabel(match)) : ''
}

const dropdownStyle = computed(() => ({
  top: `${dropdownPosition.value.top}px`,
  left: `${dropdownPosition.value.left}px`,
  width: `${dropdownPosition.value.width}px`,
  maxHeight: props.maxHeight
}))

function updateDropdownPosition() {
  if (!rootRef.value) return

  const rect = rootRef.value.getBoundingClientRect()
  dropdownPosition.value = {
    top: rect.bottom + 4,
    left: rect.left,
    width: rect.width
  }
}

// Sync giá trị cha
watch(
  [() => props.modelValue],
  ([value]) => {
    selected.value = value
    selectedLabel.value = findLabelByValue(value)
  },
  { immediate: true }
)

watch(
  () => props.items,
  () => {
    selectedLabel.value = findLabelByValue(selected.value)
  },
  { deep: true }
)

const choose = (opt: string | { label: string; value: string | number }): void => {
  const value = getValue(opt)

  selected.value = value
  selectedLabel.value = getLabel(opt)

  emit('update:modelValue', value)
  emit('on-change', value)
  emit('on-selected', value)

  open.value = false

  if (props.autoReset) {
    selected.value = ''
    selectedLabel.value = ''
    emit('update:modelValue', '')
  }
}

const onAdd = (): void => {
  if (props.disabled) return

  emit('on-add')
}

const onEdit = (): void => {
  if (props.disabled) return

  emit('on-edit', selected.value || '')
}

const onDelete = (): void => {
  if (props.disabled) return

  // selected.value = "";
  // selectedLabel.value = "";
  // emit("update:modelValue", "");
  emit('on-delete', selected.value || '')

  open.value = false
}

const onSelectClick = (): void => {
  if (props.disabled) return

  open.value = !open.value

  if (open.value && props.teleportDropdown) {
    updateDropdownPosition()
  }
}

watch(
  () => open.value,
  (isOpen) => {
    if (isOpen && props.teleportDropdown) {
      updateDropdownPosition()
    }
  }
)

onMounted(() => {
  if (!props.teleportDropdown) return

  window.addEventListener('resize', updateDropdownPosition)
  window.addEventListener('scroll', updateDropdownPosition, true)
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', updateDropdownPosition)
  window.removeEventListener('scroll', updateDropdownPosition, true)
})
</script>

<style scoped></style>
