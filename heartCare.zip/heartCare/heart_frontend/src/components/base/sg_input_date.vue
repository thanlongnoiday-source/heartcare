<template>
  <div ref="rootRef" class="relative w-full">
    <!-- Label -->
    <label v-if="label" class="block" :class="labelCSS">
      {{ label }}
      <span v-if="requiredInput" class="text-pmis-danger">*</span>
    </label>

    <!-- Trigger -->
    <div
      :id="id || undefined"
      role="button"
      tabindex="0"
      aria-haspopup="dialog"
      :aria-expanded="open"
      class="flex items-center gap-2"
      :class="[
        inputCSS,
        error ? 'border-pmis-danger focus:border-pmis-danger' : '',
        disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'
      ]"
      @click="onTriggerClick"
      @keydown.enter.prevent="onTriggerClick"
      @keydown.space.prevent="onTriggerClick"
      @keydown.esc="close"
    >
      <span
        class="truncate flex-1 min-w-0"
        :class="displayText ? 'text-pmis-text' : 'text-pmis-placeholder'"
      >
        {{ displayText || placeholder }}
      </span>

      <button
        v-if="clearable && displayText && !disabled"
        type="button"
        aria-label="Xóa ngày"
        class="text-gray-400 hover:text-gray-600 shrink-0"
        @click.stop="clear"
      >
        <X class="w-4 h-4" />
      </button>

      <CalendarDays class="w-4 h-4 text-gray-500 shrink-0" />
    </div>

    <!-- Error Message -->
    <p v-if="error" class="text-sm text-pmis-danger mt-0.5">
      {{ error }}
    </p>

    <teleport to="body">
      <div
        v-if="open"
        data-sg-date-dropdown
        class="fixed z-[9999] w-[280px] rounded-lg border border-pmis-bordernormal bg-white p-3 shadow-lg"
        :style="dropdownStyle"
      >
        <!-- Month header -->
        <div class="mb-2 flex items-center justify-between">
          <button
            type="button"
            class="rounded p-1 hover:bg-pmis-primary-50"
            aria-label="Tháng trước"
            @click="prevMonth"
          >
            <ChevronLeft class="w-4 h-4" />
          </button>
          <div v-if="yearSelect" class="flex items-center gap-1">
            <span class="text-sm font-semibold capitalize">{{ monthLabel }}</span>
            <select
              :value="viewMonth.year()"
              aria-label="Chọn năm"
              class="cursor-pointer rounded border border-pmis-bordernormal px-1 py-0.5 text-sm font-semibold outline-none hover:bg-pmis-primary-50"
              @change="onYearChange"
            >
              <option v-for="y in yearOptions" :key="y" :value="y">{{ y }}</option>
            </select>
          </div>
          <span v-else class="text-sm font-semibold capitalize">{{ monthYearLabel }}</span>
          <button
            type="button"
            class="rounded p-1 hover:bg-pmis-primary-50"
            aria-label="Tháng sau"
            @click="nextMonth"
          >
            <ChevronRight class="w-4 h-4" />
          </button>
        </div>

        <!-- Weekday header -->
        <div class="grid grid-cols-7 text-center text-xs text-gray-500">
          <div
            v-for="(w, idx) in weekdayLabels"
            :key="idx"
            class="flex h-7 items-center justify-center capitalize"
          >
            {{ w }}
          </div>
        </div>

        <!-- Days grid -->
        <div class="grid grid-cols-7 gap-y-1">
          <button
            v-for="cell in dayCells"
            :key="cell.iso"
            type="button"
            :disabled="cell.disabled"
            class="mx-auto flex h-8 w-8 items-center justify-center rounded-md text-sm transition-colors"
            :class="[
              cell.inCurrentMonth ? 'text-pmis-text' : 'text-gray-300',
              cell.disabled
                ? 'cursor-not-allowed opacity-40'
                : 'cursor-pointer hover:bg-pmis-primary-50',
              cell.isSelected ? '!bg-pmis-primary !text-white' : '',
              cell.isToday && !cell.isSelected ? 'border border-pmis-primary' : ''
            ]"
            @click="selectDay(cell)"
          >
            {{ cell.day }}
          </button>
        </div>

        <!-- Footer -->
        <div class="mt-2 flex justify-between border-t pt-2">
          <button type="button" class="text-xs text-pmis-primary hover:underline" @click="goToday">
            Hôm nay
          </button>
          <button
            v-if="clearable && displayText"
            type="button"
            class="text-xs text-gray-500 hover:underline"
            @click="clear"
          >
            Xóa
          </button>
        </div>
      </div>
    </teleport>
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import dayjs, { type Dayjs } from 'dayjs'
import { CalendarDays, ChevronLeft, ChevronRight, X } from 'lucide-vue-next'

interface Props {
  modelValue?: string // ISO 'YYYY-MM-DD'
  id?: string
  label?: string
  labelCSS?: string
  requiredInput?: boolean
  inputCSS?: string
  placeholder?: string
  disabled?: boolean
  error?: string
  min?: string // ISO 'YYYY-MM-DD'
  max?: string // ISO 'YYYY-MM-DD'
  locale?: string
  clearable?: boolean
  yearSelect?: boolean // Hiện dropdown chọn năm trên header lịch
}

const props = withDefaults(defineProps<Props>(), {
  modelValue: '',
  id: '',
  label: '',
  labelCSS: 'font-medium text-sm font-cambria text-pmis-text',
  requiredInput: false,
  inputCSS: 'sg-date',
  placeholder: 'Chọn ngày',
  disabled: false,
  error: '',
  min: undefined,
  max: undefined,
  locale: 'vi-VN',
  clearable: true,
  yearSelect: false
})

const emit = defineEmits<{
  (e: 'update:modelValue', value: string): void
  (e: 'change', value: string): void
}>()

const rootRef = ref<HTMLElement | null>(null)
const open = ref(false)
const viewMonth = ref<Dayjs>(
  props.modelValue && dayjs(props.modelValue).isValid() ? dayjs(props.modelValue) : dayjs()
)
const dropdownPosition = ref({ top: 0, left: 0 })

const selectedDate = computed<Dayjs | null>(() =>
  props.modelValue && dayjs(props.modelValue).isValid() ? dayjs(props.modelValue) : null
)
const minDate = computed<Dayjs | null>(() =>
  props.min && dayjs(props.min).isValid() ? dayjs(props.min) : null
)
const maxDate = computed<Dayjs | null>(() =>
  props.max && dayjs(props.max).isValid() ? dayjs(props.max) : null
)

// Text hiển thị trên trigger: format theo đúng thứ tự ngày/tháng/năm của locale khách sạn
// (Intl.DateTimeFormat), thay vì luôn theo locale của trình duyệt/OS như input type="date" gốc.
const displayText = computed(() => {
  if (!selectedDate.value) return ''

  return new Intl.DateTimeFormat(props.locale, {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(selectedDate.value.toDate())
})

const monthYearLabel = computed(() =>
  new Intl.DateTimeFormat(props.locale, { month: 'long', year: 'numeric' }).format(
    viewMonth.value.toDate()
  )
)

const monthLabel = computed(() =>
  new Intl.DateTimeFormat(props.locale, { month: 'long' }).format(viewMonth.value.toDate())
)

// Danh sách năm cho dropdown: giới hạn theo min/max nếu có, mặc định 100 năm trước -> 10 năm sau.
// Luôn bao gồm năm đang xem để <select> không bị trống khi điều hướng tháng vượt khoảng.
const yearOptions = computed<number[]>(() => {
  const currentYear = dayjs().year()
  const viewYear = viewMonth.value.year()
  const from = Math.min(minDate.value?.year() ?? currentYear - 100, viewYear)
  const to = Math.max(maxDate.value?.year() ?? currentYear + 10, viewYear)

  return Array.from({ length: to - from + 1 }, (_, i) => to - i)
})

// Ngày bắt đầu tuần (0=CN...6=T7) theo locale — dùng Intl weekInfo nếu trình duyệt hỗ trợ
// (Chrome/Edge mới), fallback: en-US/en-CA bắt đầu Chủ nhật, còn lại (kể cả vi-VN) Thứ hai.
const firstDayOfWeek = computed<number>(() => {
  try {
    const locale = new Intl.Locale(props.locale) as Intl.Locale & {
      getWeekInfo?: () => { firstDay: number }
      weekInfo?: { firstDay: number }
    }
    const info = locale.getWeekInfo?.() ?? locale.weekInfo

    if (info?.firstDay) return info.firstDay % 7 // API trả 1-7 (7=CN) -> quy về 0-6 (0=CN)
  } catch {
    // Intl.Locale/weekInfo không được hỗ trợ trên trình duyệt này -> dùng fallback bên dưới
  }

  return /^en-(US|CA)/i.test(props.locale) ? 0 : 1
})

const weekdayLabels = computed(() => {
  const base = dayjs().day(firstDayOfWeek.value)
  const fmt = new Intl.DateTimeFormat(props.locale, { weekday: 'short' })

  return Array.from({ length: 7 }, (_, i) => fmt.format(base.add(i, 'day').toDate()))
})

interface DayCell {
  iso: string
  day: number
  inCurrentMonth: boolean
  isToday: boolean
  isSelected: boolean
  disabled: boolean
}

const dayCells = computed<DayCell[]>(() => {
  const startOfMonth = viewMonth.value.startOf('month')
  const diffToFirst = (startOfMonth.day() - firstDayOfWeek.value + 7) % 7
  const gridStart = startOfMonth.subtract(diffToFirst, 'day')
  const today = dayjs()

  return Array.from({ length: 42 }, (_, i) => {
    const date = gridStart.add(i, 'day')

    return {
      iso: date.format('YYYY-MM-DD'),
      day: date.date(),
      inCurrentMonth: date.month() === viewMonth.value.month(),
      isToday: date.isSame(today, 'day'),
      isSelected: !!selectedDate.value && date.isSame(selectedDate.value, 'day'),
      disabled:
        (!!minDate.value && date.isBefore(minDate.value, 'day')) ||
        (!!maxDate.value && date.isAfter(maxDate.value, 'day'))
    }
  })
})

const dropdownStyle = computed(() => ({
  top: `${dropdownPosition.value.top}px`,
  left: `${dropdownPosition.value.left}px`
}))

function updateDropdownPosition() {
  if (!rootRef.value) return

  const rect = rootRef.value.getBoundingClientRect()
  dropdownPosition.value = { top: rect.bottom + 4, left: rect.left }
}

function onTriggerClick() {
  if (props.disabled) return

  open.value = !open.value

  if (open.value) {
    viewMonth.value = selectedDate.value ?? dayjs()
    updateDropdownPosition()
  }
}

function close() {
  open.value = false
}

function prevMonth() {
  viewMonth.value = viewMonth.value.subtract(1, 'month')
}

function nextMonth() {
  viewMonth.value = viewMonth.value.add(1, 'month')
}

function onYearChange(e: Event) {
  const year = Number((e.target as HTMLSelectElement).value)
  viewMonth.value = viewMonth.value.year(year)
}

function goToday() {
  viewMonth.value = dayjs()
}

function selectDay(cell: DayCell) {
  if (cell.disabled) return

  emit('update:modelValue', cell.iso)
  emit('change', cell.iso)
  open.value = false
}

function clear() {
  emit('update:modelValue', '')
  emit('change', '')
  open.value = false
}

function onDocMouseDown(e: MouseEvent) {
  if (!open.value) return

  const target = e.target as Node
  if (rootRef.value?.contains(target)) return
  // Dropdown được teleport ra <body> nên nằm ngoài rootRef -> kiểm tra riêng qua data attribute.
  if ((target as HTMLElement).closest?.('[data-sg-date-dropdown]')) return

  close()
}

watch(
  () => props.modelValue,
  (v) => {
    if (v && dayjs(v).isValid()) viewMonth.value = dayjs(v)
  }
)

onMounted(() => {
  document.addEventListener('mousedown', onDocMouseDown)
  window.addEventListener('resize', updateDropdownPosition)
  window.addEventListener('scroll', updateDropdownPosition, true)
})

onBeforeUnmount(() => {
  document.removeEventListener('mousedown', onDocMouseDown)
  window.removeEventListener('resize', updateDropdownPosition)
  window.removeEventListener('scroll', updateDropdownPosition, true)
})
</script>

<style scoped></style>
