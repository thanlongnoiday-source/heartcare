<template>
  <div class="">
    <!-- Label -->
    <label v-if="label" class="block" :class="[labelCSS]">
      {{ label }}
      <span v-if="requiredInput" class="text-pmis-danger">*</span>
    </label>

    <div
      class="relative flex items-center"
      :class="{
        'opacity-50 cursor-not-allowed': disabled
      }"
    >
      <!-- Input -->
      <input
        ref="inputRef"
        type="text"
        :placeholder="placeholder"
        :disabled="disabled"
        :class="[
          'flex-1 min-w-0',
          iconRight ? 'pr-10' : 'pr-3',
          inputCSS,
          error ? 'border-pmis-danger focus:border-pmis-danger text-pmis-danger' : ''
        ]"
        @focus="onFocus"
        @keydown="onKeydown"
        @keyup="onKeyup"
        @input="onInput"
        @blur="onBlur"
      />

      <!-- Icon Right -->
      <component
        :is="iconRight"
        v-if="iconRight"
        class="absolute right-3 w-5 h-5 text-gray-400 cursor-pointer"
        @click.stop="rightClick"
      />
    </div>

    <!-- Error Message -->
    <p v-if="error" class="text-sm text-pmis-danger mt-0.5" :class="[errorCSS]">
      {{ error }}
    </p>
  </div>
</template>

<script lang="ts" setup>
import { SGError } from '@/types/sg_site_type'
import { computed, nextTick, onMounted, onUnmounted, ref, watch, type Component } from 'vue'

interface RangeErrorInfo {
  isError: boolean
  type: '' | 'min' | 'max'
}

interface Props {
  modelValue: string | number | undefined
  label?: string
  labelCSS?: string
  requiredInput?: boolean
  inputCSS?: string
  errorCSS?: string
  placeholder?: string
  disabled?: boolean
  error?: string
  decimal?: number
  min?: number
  max?: number
  locale?: string
  iconRight?: Component
  debounce?: number // thời gian debounce ms
}

const props = withDefaults(defineProps<Props>(), {
  label: '',
  errorCSS: '',
  placeholder: '',
  error: '',
  min: undefined,
  max: undefined,
  iconRight: undefined,
  labelCSS: 'font-medium text-sm font-cambria text-pmis-text',
  inputCSS: `w-full border rounded-lg py-2 px-2
              focus:outline-none focus:ring-0.5
              transition-all
              text-lg bg-white text-right
              dark:bg-gray-800 dark:text-white
              border-gray-300 focus:ring-pmis-primary-500`,
  decimal: 0,
  locale: 'vi-VN',
  debounce: 300,
  requiredInput: false
})

const emits = defineEmits<{
  (e: 'update:modelValue', value: string | number): void
  (e: 'input', value: Event): void
  (e: 'keydown', value: KeyboardEvent): void
  (e: 'keyup', value: KeyboardEvent): void
  (e: 'range-error', value: RangeErrorInfo): void
  (e: 'component-error', value: Error): void
  (e: 'icon-right-click', value: string | number): void
}>()

const DEBOUNCE_MS = props.debounce ?? 300
const inputRef = ref<HTMLInputElement | null>(null)
let debounceTimer: ReturnType<typeof setTimeout> | undefined
const rangeError = ref<RangeErrorInfo>({
  isError: false,
  type: ''
})

// Kiểu gốc của modelValue do component cha truyền vào (number hay string) -> dùng để
// emit lại update:modelValue đúng kiểu đó, tránh biến "number" bị âm thầm đổi thành
// "string" sau khi người dùng tương tác (gõ/blur/Enter).
const isNumberModel = ref(typeof props.modelValue === 'number')

onMounted(() => {
  syncFromModelValue(props.modelValue)
})

onUnmounted(() => {
  clearTimeout(debounceTimer)
})

// ======================================================================
// WATCH - đồng bộ modelValue bên ngoài vào input
// Khả năng hàm watch có thể chạy khi chưa có DOM
// Do vậy, cần có thêm hàm onMounted để chạy lại khi DOM đã được khởi tạo xong
// ======================================================================
watch(
  () => props.modelValue,
  (v) => {
    if (typeof v === 'number') {
      isNumberModel.value = true
    } else if (typeof v === 'string') {
      isNumberModel.value = false
    }

    syncFromModelValue(v)
  },
  {
    immediate: true,
    flush: 'post'
  }
)

const separators = computed(() => {
  return getNumberSeparators(props.locale || 'vi-VN')
})

const allowed = computed(() => {
  const { group, decimal } = separators.value
  return new RegExp(`[0-9\\${group}\\${decimal}-]`)
})

// ======================================================================
// KEYDOWN — xử lý Enter NGAY LẬP TỨC, bỏ debounce
// ======================================================================
const onKeydown = (e: KeyboardEvent): void => {
  try {
    const el = inputRef.value
    if (!el) return

    emits('keydown', e)

    const key = e.key

    // ENTER → format + clamp ngay
    if (key === 'Enter') {
      e.preventDefault()

      let num = parseLocaleNumber(el.value)
      if (!isNaN(num)) {
        if (props.min !== undefined && num < props.min) num = props.min
        if (props.max !== undefined && num > props.max) num = props.max
      }

      el.value = formatNumber(num.toString())
      emitModelValue(num, el.value)
      rangeError.value.isError = false
      rangeError.value.type = ''
      emits('range-error', rangeError.value)

      el.setSelectionRange(el.value.length, el.value.length)
      return
    }

    // Allow control keys
    const ctrl = [
      'Backspace',
      'Delete',
      'ArrowLeft',
      'ArrowRight',
      'ArrowUp',
      'ArrowDown',
      'Home',
      'End',
      'Tab'
    ]
    if (ctrl.includes(key)) return

    // Cấm "." nếu decimal = 0
    if ((props.decimal ?? 0) === 0 && key === separators.value.decimal) {
      e.preventDefault()

      return
    }

    if (!allowed.value.test(key)) {
      // console.error("SGInputNumberVue allowed.value: ", allowed.value);
      e.preventDefault()
    }
  } catch (err) {
    // console.error('SGInputNumberVue/onKeydown error: ', err)
    emits('component-error', new SGError('SGInputNumberVue/onKeydown error:' + err, err as Error))
  }
}

const onKeyup = (e: KeyboardEvent): void => {
  try {
    emits('keyup', e)
  } catch (err) {
    // console.error('SGInputNumberVue/onKeyup error: ', err)
    emits('component-error', new SGError('SGInputNumberVue/onKeyup error:' + err, err as Error))
  }
}

// ======================================================================
// INPUT — DEBOUNCE TOÀN BỘ XỬ LÝ
// ======================================================================
const onInput = (e: Event): void => {
  try {
    clearTimeout(debounceTimer)
    debounceTimer = setTimeout(processInput, DEBOUNCE_MS)

    emits('input', e)
  } catch (err) {
    // console.error('SGInputNumberVue/onInput error: ', err)
    emits('component-error', new SGError('SGInputNumberVue/onInput error:' + err, err as Error))
  }
}

// ======================================================================
// BLUR — xử lý ngay lập tức, không debounce
// ======================================================================
const onBlur = () => {
  try {
    const el = inputRef.value
    if (!el) return

    let num = parseLocaleNumber(el.value)

    if (!isNaN(num)) {
      if (props.min !== undefined && num < props.min) num = props.min
      if (props.max !== undefined && num > props.max) num = props.max
    }

    el.value = formatNumber(num.toString())
    emitModelValue(num, el.value)
    rangeError.value.isError = false
    rangeError.value.type = ''
    emits('range-error', rangeError.value)
  } catch (err) {
    // console.error('SGInputNumberVue/onBlur error: ', err)
    emits('component-error', new SGError('SGInputNumberVue/onBlur error:' + err, err as Error))
  }
}

// ======================================================================
// FOCUS — select all
// ======================================================================
const onFocus = () => {
  try {
    const el = inputRef.value
    if (!el) return
    nextTick(() => el.select())
  } catch (err) {
    // console.error('SGInputNumberVue/onFocus error: ', err)
    emits('component-error', new SGError('SGInputNumberVue/onFocus error:' + err, err as Error))
  }
}

const rightClick = (): void => {
  try {
    emits('icon-right-click', props.modelValue ?? '')
  } catch (err) {
    // console.error('SGInputNumberVue/rightClick error: ', err)
    emits('component-error', new SGError('SGInputNumberVue/rightClick error:' + err, err as Error))
  }
}

// Emit update:modelValue đúng kiểu gốc (number/string) đã ghi nhận ở isNumberModel.
// - numValue: giá trị số đã parse (dùng khi ở number-mode)
// - textValue: chuỗi đã format theo locale (dùng khi ở string-mode, giữ nguyên hành vi cũ)
function emitModelValue(numValue: number, textValue: string): void {
  if (isNumberModel.value) {
    if (Number.isNaN(numValue)) return
    emits('update:modelValue', numValue)
  } else {
    emits('update:modelValue', textValue)
  }
}

function syncFromModelValue(v: string | number | undefined): void {
  const el = inputRef.value
  if (!el) return

  if (el === document.activeElement) return

  if (v == null || v === '') {
    el.value = ''
    return
  }

  // number.toString() luôn dùng '.' làm dấu thập phân (bất kể locale) và không có dấu phân
  // cách hàng nghìn -> đã là dạng canonical, KHÔNG được đưa qua parseByLocale() (hàm đó chỉ
  // dành cho chuỗi do người dùng gõ theo định dạng locale, vd '1.234,5' ở vi-VN), nếu không
  // dấu thập phân '.' sẽ bị hiểu nhầm thành dấu phân cách hàng nghìn của locale và bị xóa.
  const raw = typeof v === 'number' ? v.toString() : parseByLocale(v)
  const formatted = formatNumber(raw)

  el.value = formatted
}

// ======================================================================
// SANITIZE
// ======================================================================
const sanitize = (value: string): string => {
  let v = value

  const { group, decimal } = separators.value

  // Remove all except number, minus, decimal, group
  const reg = new RegExp(`[^0-9\\${group}\\${decimal}-]`, 'g')
  v = v.replace(reg, '')

  // Only one minus
  v = v.replace(/(?!^)-/g, '')

  // Remove group separators
  const groupReg = new RegExp(`\\${group}`, 'g')
  v = v.replace(groupReg, '')

  // Replace locale decimal -> .
  if (decimal !== '.') {
    const decReg = new RegExp(`\\${decimal}`, 'g')
    v = v.replace(decReg, '.')
  }

  // Multiple dots
  const parts = v.split('.')
  if (parts.length > 2) {
    v = parts[0] + '.' + parts.slice(1).join('')
  }

  // Decimal limit
  const dec = props.decimal ?? 0

  if (dec === 0) {
    v = v.replace(/\./g, '')
  }

  if (dec > 0 && v.includes('.')) {
    const [i, d] = v.split('.')
    v = i + '.' + d.slice(0, dec)
  }

  return v
}

// ======================================================================
// FORMAT
// ======================================================================
const getNumberSeparators = (locale: string) => {
  const parts = new Intl.NumberFormat(locale).formatToParts(12345.6)

  let group = ','
  let decimal = '.'

  for (const p of parts) {
    if (p.type === 'group') group = p.value
    if (p.type === 'decimal') decimal = p.value
  }

  return { group, decimal }
}

const formatNumber = (value: string): string => {
  if (!value) return ''

  const num = Number(value)

  if (isNaN(num)) return ''

  return num.toLocaleString(props.locale, {
    minimumFractionDigits: props.decimal,
    maximumFractionDigits: props.decimal
  })
}

// ======================================================================
// ERROR STATE
// ======================================================================
const checkErrorState = (raw: string) => {
  if (!raw || raw === '-' || raw === '-.') {
    rangeError.value.isError = false
    rangeError.value.type = ''
    emits('range-error', rangeError.value)

    return
  }

  const num = Number(raw)
  if (isNaN(num)) {
    rangeError.value.isError = false
    rangeError.value.type = ''
    emits('range-error', rangeError.value)

    return
  }

  if (props.min !== undefined && num < props.min) {
    rangeError.value.isError = true
    rangeError.value.type = 'min'
    emits('range-error', rangeError.value)

    return
  }

  if (props.max !== undefined && num > props.max) {
    rangeError.value.isError = true
    rangeError.value.type = 'max'
    emits('range-error', rangeError.value)

    return
  }

  rangeError.value.isError = false
  rangeError.value.type = ''
  emits('range-error', rangeError.value)
}

// ======================================================================
// LIVE PROCESS (sanitize + error + format)
// ======================================================================
const processInput = async () => {
  const el = inputRef.value
  if (!el) return

  const oldText = el.value
  const caretPos = el.selectionStart ?? oldText.length

  // Đếm số digit trước caret
  const digitCount = countDigitsBefore(oldText, caretPos)

  const clean = sanitize(oldText)

  checkErrorState(clean)

  // Trường hợp đặc biệt: số đang gõ dở (vd '-', '1.') -> chưa phải số hợp lệ.
  // Ở number-mode không có cách nào biểu diễn trạng thái dở dang này bằng number nên
  // bỏ qua emit, giữ nguyên giá trị number hợp lệ gần nhất bên ngoài; input vẫn hiển thị
  // đúng những gì người dùng đang gõ.
  if (clean === '-' || clean === '-.' || clean.endsWith('.')) {
    el.value = clean

    if (!isNumberModel.value) {
      emits('update:modelValue', clean)
    }

    await nextTick()
    el.setSelectionRange(clean.length, clean.length)
    return
  }

  const formatted = formatNumber(clean)

  el.value = formatted
  emitModelValue(Number(clean), formatted)

  await nextTick()

  // Tìm lại vị trí caret mới
  const newPos = findPosByDigitCount(formatted, digitCount)

  el.setSelectionRange(newPos, newPos)
}

const parseLocaleNumber = (text: string): number => {
  const clean = sanitize(text)
  return Number(clean)
}

const parseByLocale = (text: string): string => {
  const { group, decimal } = separators.value

  let v = text

  // Remove group separator
  const groupReg = new RegExp(`\\${group}`, 'g')
  v = v.replace(groupReg, '')

  // Replace decimal -> .
  if (decimal !== '.') {
    const decReg = new RegExp(`\\${decimal}`, 'g')
    v = v.replace(decReg, '.')
  }

  return v
}

// Đếm bao nhiêu chữ số (0-9) trước vị trí caret
const countDigitsBefore = (text: string, pos: number) => {
  let count = 0

  for (let i = 0; i < pos; i++) {
    if (/\d/.test(text[i])) count++
  }

  return count
}

// Tìm vị trí caret mới dựa theo số chữ số
const findPosByDigitCount = (text: string, digitCount: number) => {
  let count = 0

  for (let i = 0; i < text.length; i++) {
    if (/\d/.test(text[i])) {
      count++
    }

    if (count >= digitCount) {
      return i + 1
    }
  }

  return text.length
}
</script>

<style scoped></style>
