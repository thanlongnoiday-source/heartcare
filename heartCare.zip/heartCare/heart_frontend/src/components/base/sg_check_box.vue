<script setup lang="ts">
import { computed } from 'vue'
import { Check } from 'lucide-vue-next'

type CheckboxValue = boolean | number | string

interface Props {
  label?: string
  disabled?: boolean
  trueValue?: CheckboxValue
  falseValue?: CheckboxValue
  size?: 'sm' | 'md' | 'lg'
  invalid?: boolean
  name?: string
  id?: string
}

// 1. Sử dụng defineModel (Vue 3.4+) giúp code ngắn gọn hơn rất nhiều
const model = defineModel<CheckboxValue>({ default: false })

const props = withDefaults(defineProps<Props>(), {
  disabled: false,
  trueValue: true,
  falseValue: false,
  size: 'md',
  invalid: false,
  label: '',
  name: '',
  id: ''
})

const emit = defineEmits<{
  (e: 'change', value: CheckboxValue): void
}>()

// Kiểm tra xem có đang check không
const isChecked = computed<boolean>(() => model.value === props.trueValue)

// Định nghĩa size dạng Mapping Object (Gọn hơn switch-case)
// const sizeClasses = {
//   sm: { input: 'h-4 w-4', label: 'text-sm', svg: 'h-3 w-3' },
//   md: { input: 'h-5 w-5', label: 'text-sm', svg: 'h-3.5 w-3.5' },
//   lg: { input: 'h-6 w-6', label: 'text-base', svg: 'h-4 w-4' }
// }

const sizeClasses = {
  sm: { input: 'h-4 w-4', label: 'text-sm', iconSize: 12 },
  md: { input: 'h-5 w-5', label: 'text-sm', iconSize: 14 },
  lg: { input: 'h-6 w-6', label: 'text-base', iconSize: 16 }
}

const currentSize = computed(() => sizeClasses[props.size] || sizeClasses.md)

const onChange = (event: Event): void => {
  const target = event.target as HTMLInputElement
  const value = target.checked ? props.trueValue : props.falseValue

  model.value = value // Tự động emit update:modelValue
  emit('change', value)
}
</script>

<template>
  <label
    :for="id || undefined"
    class="inline-flex items-center gap-2 select-none"
    :class="[disabled ? 'cursor-not-allowed opacity-60 pointer-events-none' : 'cursor-pointer']"
  >
    <div class="relative flex items-center justify-center">
      <input
        :id="id"
        :name="name"
        type="checkbox"
        :checked="isChecked"
        :disabled="disabled"
        class="peer appearance-none rounded border transition-colors duration-200 bg-white dark:bg-pmis-text border-slate-400 dark:border-pmis-bg checked:bg-pmis-bg checked:border-pmis-primary focus:outline-none focus:ring-1 focus:ring-sky-500 focus:ring-offset-1 disabled:bg-pmis-disabled dark:disabled:bg-slate-700 disabled:checked:bg-pmis-disabled"
        :class="[currentSize.input, invalid ? 'border-red-500' : '']"
        @change="onChange"
      />

      <!-- Icon SVG Check -->
      <!-- <svg
        v-if="isChecked"
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 20 20"
        fill="none"
        stroke="currentColor"
        stroke-width="3"
        class="absolute pointer-events-none text-pmis-text"
        :class="currentSize.svg"
      >
        <path stroke-linecap="round" stroke-linejoin="round" d="M5 10L8 13L15 6" />
      </svg> -->

      <Check
        v-if="isChecked"
        :size="currentSize.iconSize"
        :stroke-width="3"
        class="absolute pointer-events-none text-pmis-text"
      />
    </div>

    <!-- Phần nhãn hiển thị -->
    <span
      v-if="label"
      class="font-medium transition-colors"
      :class="[
        currentSize.label,
        disabled ? 'text-pmis-label dark:text-pmis-bg' : 'text-pmis-text dark:text-pmis-bg'
      ]"
    >
      {{ label }}
    </span>
  </label>
</template>
