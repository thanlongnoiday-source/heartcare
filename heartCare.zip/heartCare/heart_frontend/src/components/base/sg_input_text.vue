<template>
  <div class="w-full">
    <!-- Label -->
    <label v-if="label" class="block" :class="labelCSS" :for="id || undefined">
      {{ label }}
      <span v-if="requiredInput" class="text-pmis-danger">*</span>
    </label>

    <div
      class="relative w-full flex items-center"
      :class="{ 'opacity-50 cursor-not-allowed': disabled }"
    >
      <!-- Icon Left -->
      <component :is="iconleft" v-if="iconleft" class="absolute left-3 w-5 h-5 text-gray-400" />

      <input
        :id="id || undefined"
        v-model="model"
        type="text"
        :placeholder="placeholder"
        :disabled="disabled"
        :style="{
          paddingLeft: iconleft ? '2.5rem' : undefined,
          paddingRight: iconright ? '2.5rem' : undefined
        }"
        :class="[
          'w-full',
          inputCSS,
          error ? 'border-pmis-danger focus:border-pmis-danger text-pmis-danger' : '',
          !iconleft && 'pl-2',
          !iconright && 'pr-2'
        ]"
        @keydown="onKeydown"
        @keyup="onKeyup"
      />

      <!-- Icon Right -->
      <component
        :is="iconright"
        v-if="iconright"
        class="absolute right-3 w-5 h-5 text-gray-400 cursor-pointer"
        @click.stop="rightClick"
      />
    </div>

    <!-- Error Message -->
    <p v-if="error" class="text-sm text-pmis-danger mt-0.5">
      {{ error }}
    </p>
  </div>
</template>

<script lang="ts" setup>
import { SGError } from '@/types/sg_site_type'
import { computed, type Component } from 'vue'

interface Props {
  modelValue: string | number | null | undefined
  id?: string
  label?: string
  labelCSS?: string
  requiredInput?: boolean
  placeholder?: string
  inputCSS?: string
  disabled?: boolean
  error?: string
  iconleft?: Component
  iconright?: Component
}

const props = withDefaults(defineProps<Props>(), {
  id: '',
  label: '',
  placeholder: '',
  labelCSS: `font-medium text-sm font-cambria text-lighttext`,
  inputCSS: `border rounded-lg py-2 px-2
              focus:outline-none focus:ring-1
              transition-all placeholder-placeholder
              text-xl font-cambria text-lighttext bg-white text-left
              dark:bg-darkttext dark:text-white
              border-gray-300 focus:ring-primary`,

  requiredInput: false,
  error: '',
  iconleft: undefined,
  iconright: undefined
})

const emits = defineEmits<{
  (event: 'update:modelValue', value: string | number | null | undefined): void
  (event: 'icon-right-click', value: string | number): void
  (event: 'component-error', err: SGError): void
  (event: 'keydown', keyEvent: KeyboardEvent): void
  (event: 'keyup', keyEvent: KeyboardEvent): void
  (event: 'enter', value: string, keyEvent: KeyboardEvent): void
}>()

const model = computed({
  get: () => props.modelValue,
  set: (val) => emits('update:modelValue', val)
})

// ======================================================================
// KEYUP — xử lý NGAY LẬP TỨC, bỏ debounce
// ======================================================================
const onKeydown = (e: KeyboardEvent): void => {
  try {
    emits('keydown', e)
    if (e.key === 'Enter') {
      const target = e.target as HTMLInputElement

      emits('enter', target.value, e)
    }
  } catch (err) {
    // console.error('sg_input_textVue/onKeydown error: ', err)
    emits('component-error', new SGError('sg_input_textVue/onKeydown error:' + err, err as Error))
  }
}

const onKeyup = (e: KeyboardEvent): void => {
  try {
    emits('keyup', e)
  } catch (err) {
    // console.error('sg_input_textVue/onKeyup error: ', err)
    emits('component-error', new SGError('sg_input_textVue/onKeyup error:' + err, err as Error))
  }
}

const rightClick = (): void => {
  try {
    if (props.disabled) return

    emits('icon-right-click', props.modelValue ?? '')
  } catch (err) {
    // console.error('sg_input_textVue/rightClick error: ', err)
    emits('component-error', new SGError('sg_input_textVue/rightClick error:' + err, err as Error))
  }
}
</script>
