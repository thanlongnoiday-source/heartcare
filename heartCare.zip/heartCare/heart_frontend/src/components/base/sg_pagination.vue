<template>
  <div class="flex items-center gap-4">
    <!-- Pagination buttons -->
    <div class="flex items-center gap-2">
      <!-- First -->
      <button
        class="p-0.5 rounded-md border border-pmis-primary-200 bg-white hover:border-pmis-primary-500"
        :disabled="props.currPage === 1"
        @click="goToPage(1)"
      >
        <ChevronFirst class="w-6 h-6" stroke-width="1" />
      </button>

      <!-- Prev -->
      <button
        class="p-0.5 rounded-md border border-pmis-primary-200 bg-white hover:border-pmis-primary-500"
        :disabled="props.currPage === 1"
        @click="goToPage(props.currPage - 1)"
      >
        <ChevronLeft class="w-6 h-6" stroke-width="1" />
      </button>

      <!-- Page Numbers -->
      <button
        v-for="p in pages"
        :key="p"
        class="px-3 p-0.5 rounded-md border border-pmis-primary-200 bg-white hover:border-pmis-primary-500"
        :class="
          p === props.currPage
            ? 'border-pmis-primary-500 text-pmis-text'
            : 'border-pmis-primary-200'
        "
        @click="goToPage(p)"
      >
        {{ p }}
      </button>

      <!-- Next -->
      <button
        class="p-0.5 rounded-md border border-pmis-primary-200 bg-white hover:border-pmis-primary-500"
        :disabled="props.currPage === totalPages"
        @click="goToPage(props.currPage + 1)"
      >
        <ChevronRight class="w-6 h-6" stroke-width="1" />
      </button>

      <!-- Last -->
      <button
        class="p-0.5 rounded-md border border-pmis-primary-200 bg-white hover:border-pmis-primary-500"
        :disabled="props.currPage === totalPages"
        @click="goToPage(props.totalPages)"
      >
        <ChevronLast class="w-6 h-6" stroke-width="1" />
      </button>
    </div>

    <!-- Display text -->
    <div class="text-sm text-gray-600">
      {{ startRecord }} - {{ endRecord }} / {{ totalItems }} {{ itemName }}
    </div>
  </div>
</template>

<script setup lang="ts">
import { ChevronFirst, ChevronLast, ChevronLeft, ChevronRight } from 'lucide-vue-next'
import { computed } from 'vue'

interface PageItem {
  currPage?: number
  totalPages?: number
  totalItems?: number
  pageSize?: number
  itemName?: string
}

const props = withDefaults(defineProps<PageItem>(), {
  currPage: 1, // Trang hiện tại
  totalPages: 0, // Tổng số trang
  totalItems: 0, // Tổng số dòng
  pageSize: 20, // Số dòng của 1 trang
  itemName: 'bản ghi'
})

// Calculate start and end record numbers
const startRecord = computed(() => {
  if (props.totalItems === 0) return 0
  return (props.currPage - 1) * props.pageSize + 1
})

const endRecord = computed(() => {
  const end = props.currPage * props.pageSize
  return Math.min(end, props.totalItems)
})

const emit = defineEmits<{
  (e: 'update:page', page: number): void
}>()

// Hiển thị trang ±2 (ví dụ: 3 4 [5] 6 7)
const pages = computed(() => {
  const arr: number[] = []
  const start = Math.max(1, props.currPage - 2)
  const end = Math.min(props.totalPages, props.currPage + 2)

  for (let i = start; i <= end; i++) arr.push(i)

  return arr
})

const goToPage = (page: number): void => {
  if (page < 1 || page > props.totalPages) return // bỏ qua

  emit('update:page', page)
  // console.log("update:page", page)
}
</script>

<style scoped></style>
