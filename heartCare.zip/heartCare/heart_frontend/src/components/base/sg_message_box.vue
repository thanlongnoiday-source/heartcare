<template>
  <transition name="fade">
    <div v-if="props.show" class="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div
        role="alertdialog"
        aria-modal="true"
        :aria-label="props.title"
        :class="['w-full max-w-sm rounded-xl border p-4', variantClasses[props.type].container]"
      >
        <div class="flex items-start gap-3">
          <div :class="['-mt-0.5', variantClasses[props.type].icon]">
            <component :is="icons[props.type]" class="h-5 w-5 flex-shrink-0" />
          </div>

          <div class="w-full">
            <h4 class="mb-1 text-sm font-semibold text-gray-800 dark:text-white/90">
              {{ props.title }}
            </h4>

            <p
              class="text-sm text-gray-500 dark:text-gray-400 leading-relaxed whitespace-pre-line break-words"
            >
              {{ props.message }}
            </p>

            <router-link
              v-if="props.show_link"
              :to="props.link_href"
              class="inline-block mt-3 text-sm font-medium text-gray-500 underline dark:text-gray-400"
            >
              {{ props.link_text }}
            </router-link>

            <div class="flex justify-end gap-3 pt-6">
              <button
                v-if="props.show_cancel"
                class="min-w-20 px-4 py-2 rounded-md text-gray-700 bg-white border border-gray-300 hover:bg-gray-100 font-medium"
                @click="onCancel_Click"
              >
                {{ props.text_cancel }}
              </button>

              <button
                v-if="props.show_danger"
                class="min-w-20 px-4 py-2 rounded-md text-white bg-red-600 border border-red-700 hover:bg-red-700 font-medium"
                @click="onDanger_Click"
              >
                {{ props.text_danger }}
              </button>

              <button
                v-if="props.show_ok"
                class="min-w-20 px-4 py-2 rounded-md text-white bg-blue-600 border border-blue-700 hover:bg-blue-700 font-medium"
                @click="onOK_Click"
              >
                {{ props.text_ok }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script lang="ts">
import type { MsgType } from '@/types/sg_msg_box.types'
import { CircleCheckBig, CircleQuestionMark, CircleX, Info, TriangleAlert } from 'lucide-vue-next'

// Static lookup tables — kept in a plain (non-setup) block so they're built
// once per module instead of being re-allocated on every component instance.
const variantClasses: Record<MsgType, { container: string; icon: string }> = {
  success: {
    container: 'border-msgbox-success !bg-white shadow-lg',
    icon: 'text-msgbox-success'
  },
  error: {
    container: 'border-msgbox-error !bg-white shadow-lg',
    icon: 'text-msgbox-error'
  },
  warning: {
    container: 'border-msgbox-warning !bg-white shadow-lg',
    icon: 'text-msgbox-warning'
  },
  info: {
    container: 'border-msgbox-info !bg-white shadow-lg',
    icon: 'text-msgbox-info'
  },
  confirm: {
    container: 'border-msgbox-confirm !bg-white shadow-lg',
    icon: 'text-msgbox-confirm'
  }
}

const icons: Record<MsgType, typeof CircleCheckBig> = {
  success: CircleCheckBig,
  error: CircleX,
  warning: TriangleAlert,
  info: Info,
  confirm: CircleQuestionMark
}
</script>

<script lang="ts" setup>
import type { MsgBoxOptions } from '@/types/sg_msg_box.types'

const props = withDefaults(defineProps<MsgBoxOptions>(), {
  type: 'info',
  show_link: false,
  link_href: '#',
  link_text: 'Learn more',
  text_ok: 'OK',
  text_cancel: 'Cancel',
  text_danger: 'Danger',
  show_ok: true,
  show_cancel: true,
  show_danger: false
})

const emit = defineEmits<{
  (e: 'ok'): void
  (e: 'cancel'): void
  (e: 'danger'): void
  // (e: 'cancel', value: number): void
  // (e: 'close', payload: { id: number; name: string }): void
}>()

function onOK_Click(): void {
  emit('ok')
}

function onCancel_Click(): void {
  emit('cancel')
}

function onDanger_Click(): void {
  emit('danger')
}
</script>

<style scoped>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.25s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
