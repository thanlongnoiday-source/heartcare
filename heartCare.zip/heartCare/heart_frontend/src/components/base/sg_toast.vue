<template>
  <!-- Mount 1 lần ở App.vue. Teleport ra body để nổi trên mọi layout/route. -->
  <teleport to="body">
    <div
      class="fixed top-4 right-4 z-[10000] flex w-full max-w-sm flex-col gap-2 pointer-events-none"
    >
      <transition-group name="sg-toast">
        <div
          v-for="toast in store.toasts"
          :key="toast.id"
          class="pointer-events-auto flex items-start gap-3 rounded-lg border-l-4 bg-white px-4 py-3 shadow-md"
          :class="styleMap[toast.type].wrap"
          role="alert"
        >
          <component :is="styleMap[toast.type].icon" class="mt-0.5 h-5 w-5 shrink-0" />
          <p class="flex-1 whitespace-pre-line text-sm">{{ toast.message }}</p>
          <button
            v-if="toast.closable"
            class="shrink-0 text-slate-400 hover:text-slate-600"
            aria-label="Đóng"
            @click="store.remove(toast.id)"
          >
            <X class="h-4 w-4" />
          </button>
        </div>
      </transition-group>
    </div>
  </teleport>
</template>

<script setup lang="ts">
import { useToastStore } from '@/stores/sg_toast.store'
import type { ToastType } from '@/types/sg_toast.types'
import { CheckCircle2, XCircle, AlertTriangle, Info, X } from 'lucide-vue-next'
import type { Component } from 'vue'

const store = useToastStore()

// Màu viền + chữ + icon theo từng loại toast. Nền trắng, dùng viền trái đổi màu.
const styleMap: Record<ToastType, { wrap: string; icon: Component }> = {
  success: { wrap: 'border-green-500 text-green-700', icon: CheckCircle2 },
  error: { wrap: 'border-red-500 text-red-700', icon: XCircle },
  warning: { wrap: 'border-yellow-500 text-yellow-700', icon: AlertTriangle },
  info: { wrap: 'border-blue-500 text-blue-700', icon: Info }
}
</script>

<style scoped>
.sg-toast-enter-active,
.sg-toast-leave-active {
  transition: all 0.25s ease;
}
.sg-toast-enter-from,
.sg-toast-leave-to {
  opacity: 0;
  transform: translateX(1rem);
}
</style>
