import {
  LayoutDashboard,
  //   FileText
  //   Handshake,
  //   Target,
  //   Network,
  //   CalendarClock,
  //   ListTodo,
  Users,
  ShieldCheck,
  CircleCheckBig,
  FileSpreadsheet,
  FileChartColumn,
  Settings
} from 'lucide-vue-next'
import type { RouteRecordRaw } from 'vue-router'

export const adminRoutes: RouteRecordRaw[] = [
  {
    path: '/admin/sys-dashboard',
    name: 'sys-dashboard',
    component: () => import('@/features/system_admin/pages/pt_sys_dashboard.vue'),
    meta: {
      label: 'Dashboard',
      module: 'System Admin',
      permission: '',
      filter: 'sysadmin',
      icon: LayoutDashboard
    }
  },
  {
    path: '/sysadmin/id-user',
    name: 'id-user',
    component: () => import('@/features/system_admin/pages/pt_sys_dashboard.vue'),
    meta: {
      label: 'User Management',
      module: 'Identity Admin',
      permission: '',
      filter: 'sysadmin',
      icon: Users
    }
  },
  {
    path: '/sysadmin/id-roles',
    name: 'id-roles',
    component: () => import('@/features/system_admin/pages/pt_sys_dashboard.vue'),
    meta: {
      label: 'Roles & Permissions',
      module: 'Identity Admin',
      permission: '',
      filter: 'sysadmin',
      icon: ShieldCheck
    }
  },
  {
    path: '/sysadmin/id-approval',
    name: 'id-approval',
    component: () => import('@/features/system_admin/pages/pt_sys_dashboard.vue'),
    meta: {
      label: 'Approval Requests',
      module: 'Identity Admin',
      permission: '',
      filter: 'sysadmin',
      icon: CircleCheckBig
    }
  },
  {
    path: '/sysadmin/id-audit-logs',
    name: 'id-audit-logs',
    component: () => import('@/features/system_admin/pages/pt_sys_dashboard.vue'),
    meta: {
      label: 'Audit Logs',
      module: 'Identity Admin',
      permission: '',
      filter: 'sysadmin',
      icon: FileSpreadsheet
    }
  },
  {
    path: '/sysadmin/id-reports',
    name: 'id-reports',
    component: () => import('@/features/system_admin/pages/pt_sys_dashboard.vue'),
    meta: {
      label: 'Reports',
      module: 'Identity Admin',
      permission: '',
      filter: 'sysadmin',
      icon: FileChartColumn
    }
  },
  {
    path: '/sysadmin/id-setting',
    name: 'id-setting',
    component: () => import('@/features/system_admin/pages/pt_sys_dashboard.vue'),
    meta: {
      label: 'System Settings',
      module: 'Identity Admin',
      permission: '',
      filter: 'sysadmin',
      icon: Settings
    }
  }
]
