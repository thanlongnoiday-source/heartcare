import {
  LayoutDashboard,
  //   FileText
  //   Handshake,
  //   Target,
  //   Network,
  //   CalendarClock,
  //   ListTodo,
  Users,
  ShieldCheck,
  CircleCheckBig,
  FileSpreadsheet,
  FileChartColumn,
  Settings
  //   ReceiptText,
  //   ShieldAlert,
  //   TriangleAlert,
  //   CircleCheckBig,
  //   FilePen,
  //   RotateCcw,
  //   ShoppingCart,
  //   FileChartColumn
} from 'lucide-vue-next'
import type { RouteRecordRaw } from 'vue-router'

export const idAdminRoutes: RouteRecordRaw[] = [
  {
    path: '/engineer/id-dashboard',
    name: 'id-dashboard',
    component: () => import('@/features/identity_admin/pages/sg_id_dashboard.vue'),
    meta: {
      label: 'Dashboard',
      module: 'Identity Admin',
      permission: '',
      filter: 'idadmin',
      icon: LayoutDashboard
    }
  },
  {
    path: '/idadmin/id-user',
    name: 'id-user',
    component: () => import('@/features/identity_admin/pages/sg_id_user_list.vue'),
    meta: {
      label: 'User Management',
      module: 'Identity Admin',
      permission: '',
      filter: 'idadmin',
      icon: Users
    }
  },
  {
    path: '/idadmin/id-roles',
    name: 'id-roles',
    component: () => import('@/features/identity_admin/pages/sg_id_roles.vue'),
    meta: {
      label: 'Roles & Permissions',
      module: 'Identity Admin',
      permission: '',
      filter: 'idadmin',
      icon: ShieldCheck
    }
  },
  {
    path: '/idadmin/id-approval',
    name: 'id-approval',
    component: () => import('@/features/identity_admin/pages/sg_id_approval.vue'),
    meta: {
      label: 'Approval Requests',
      module: 'Identity Admin',
      permission: '',
      filter: 'idadmin',
      icon: CircleCheckBig
    }
  },
  {
    path: '/idadmin/id-audit-logs',
    name: 'id-audit-logs',
    component: () => import('@/features/identity_admin/pages/sg_id_audit_logs.vue'),
    meta: {
      label: 'Audit Logs',
      module: 'Identity Admin',
      permission: '',
      filter: 'idadmin',
      icon: FileSpreadsheet
    }
  },
  {
    path: '/idadmin/id-reports',
    name: 'id-reports',
    component: () => import('@/features/identity_admin/pages/sg_id_reports.vue'),
    meta: {
      label: 'Reports',
      module: 'Identity Admin',
      permission: '',
      filter: 'idadmin',
      icon: FileChartColumn
    }
  },
  {
    path: '/idadmin/id-setting',
    name: 'id-setting',
    component: () => import('@/features/identity_admin/pages/sg_id_system_settings.vue'),
    meta: {
      label: 'System Settings',
      module: 'Identity Admin',
      permission: '',
      filter: 'idadmin',
      icon: Settings
    }
  }
]
