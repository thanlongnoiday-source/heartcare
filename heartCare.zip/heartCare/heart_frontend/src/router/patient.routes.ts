import { LayoutDashboard } from 'lucide-vue-next'
import type { RouteRecordRaw } from 'vue-router'

export const patientRoutes: RouteRecordRaw[] = [
  {
    path: '/patient/customer',
    name: 'engr-customer',
    component: () => import('@/features/patient/pages/sg_engr_cust_list.vue'),
    meta: {
      label: 'Customer',
      module: 'Patient',
      permission: '',
      filter: 'patient',
      icon: LayoutDashboard
    }
  },
  {
    path: '/patient/project',
    name: 'engr-project',
    component: () => import('@/features/patient/pages/sg_engr_project_list.vue'),
    meta: {
      label: 'Project',
      module: 'Patient',
      permission: '',
      filter: 'patient',
      icon: LayoutDashboard
    }
  }
]
