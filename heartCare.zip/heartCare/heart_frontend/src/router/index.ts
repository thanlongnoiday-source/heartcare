import { createRouter, createWebHistory } from 'vue-router'
import { patientRoutes } from './patient.routes'
import { adminRoutes } from './sysadmin.routes'
// import { recp_journeyRoutes } from './recp_journey.routes'

const routes = [
  {
    path: '/',
    name: 'sg-login',
    component: () => import('@/features/auth/pages/sg_login.vue')
  },
  {
    path: '/sysadmin',
    name: 'sysadmin',
    component: () => import('@/features/system_admin/pages/pt_sys_main.vue'),
    // redirect: '/sysadmin/sys-dashboard',
    meta: {
      label: 'Admin',
      module: 'sysadmin',
      permission: 'admin.list',
      filter: '',
      icon: null
    },
    children: [...adminRoutes]
  },
  {
    path: '/patient',
    name: 'patient',
    component: () => import('@/features/patient/pages/sg_engr_main.vue'),
    // redirect: '/patient/customer',
    meta: {
      label: 'Patient',
      module: 'patient',
      permission: 'patient.list',
      filter: '',
      icon: null
    },
    children: [...patientRoutes]
  }
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
})

export default router
