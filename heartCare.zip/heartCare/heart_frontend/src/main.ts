import { createApp } from 'vue'
import { createPinia } from 'pinia'
import router from '@/router/index'
import App from './App.vue'

import '@/assets/css/style.css'
// import { useCompanyStore } from '@/stores/sg_company_store'

const app = createApp(App)
const pinia = createPinia()

async function bootstrap() {
  app.use(pinia)

  // await useCompanyStore().fetchcompanyInfo()

  app.use(router)
  //   app.use(CKEditor);
  app.mount('#app')
}

bootstrap()
