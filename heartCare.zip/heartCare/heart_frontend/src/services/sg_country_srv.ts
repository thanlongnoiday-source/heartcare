// src/services/sg_country_srv.ts
//
// Service ánh xạ 1-1 với app/api/sg_country_api.py (router prefix "/countrys").
// Mọi response bọc trong APIResponse -> SGAPIResponse<T>, field dữ liệu là `items`.

import axios, { AxiosError } from 'axios'
import apiClient from '@/utils/api'
import { SGAPIError, type SGAPIResponse } from '@/types/sg_site_type'
import type {
  SGCountryCreate,
  SGCountryPagedParams,
  SGCountryPageRes,
  SGCountryRead,
  SGCountryUpdate
} from '@/types/sg_country'

// ======================================================
// API CONSTANTS
// ======================================================
// Backend router: APIRouter(prefix="/countrys"). Đổi tiền tố cho khớp gateway nếu cần.
const API_URL = '/api/v1/countrys'

// ======================================================
// RESPONSE HELPERS
// ======================================================
function validateBusinessResponse<T>(response: SGAPIResponse<T>): SGAPIResponse<T> {
  if (response.status !== 200) {
    throw new SGAPIError(response.message || 'Business validation error', response.status)
  }

  return response
}

function handleAxiosError(error: unknown, source: string): never {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<SGAPIResponse & { detail?: unknown }>

    const data = axiosError.response?.data
    const detail = data?.detail

    // FastAPI/Pydantic validation error (vd: HTTP 422): detail = [{ loc, msg, type }, ...]
    const message = Array.isArray(detail)
      ? detail
          .map((item: { loc?: unknown[]; msg?: string }) => {
            const field = Array.isArray(item?.loc) ? item.loc.join('.') : item?.loc
            return field ? `${field}: ${item?.msg}` : item?.msg
          })
          .join('; ')
      : data?.message || axiosError.message || 'Unknown axios error'

    const status = data?.status || axiosError.response?.status || 0

    throw new SGAPIError(`${source}: ${message}`, status, detail)
  }

  if (error instanceof Error) {
    throw new SGAPIError(`${source}: ${error.message}`, 0)
  }

  throw new SGAPIError(`${source}: Unknown error`, 0)
}

export function newSGCountryCreate(): SGCountryCreate {
  return {
    country_name: '' // max_length=100
  }
}

// ======================================================
// LIST
// GET /countrys/  -> get_countrys
// ======================================================
export async function getCountrys(): Promise<SGCountryRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGCountryRead[]>>(`${API_URL}/`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_country_srv/getCountrys')
  }
}

// ======================================================
// LIST (PAGED)
// POST /countrys/page  -> get_country_page (payload: SGCountryPagred)
// Response bọc trong APIResponsePage: { items, status, message, page, page_size, total, total_pages }
// ======================================================
export async function getCountryPaged(filter: SGCountryPagedParams): Promise<SGCountryPageRes> {
  try {
    const res = await apiClient.post<SGCountryPageRes>(`${API_URL}/page`, filter)

    const data = res.data

    if (data.status !== 200) {
      throw new SGAPIError(data.message || 'Business validation error', data.status)
    }

    return data
  } catch (error) {
    handleAxiosError(error, 'sg_country_srv/getCountryPaged')
  }
}

// ======================================================
// DETAIL
// GET /countrys/by-id/{country_id}  -> get_country
// ======================================================
export async function getCountry(countryId: number): Promise<SGCountryRead> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGCountryRead>>(`${API_URL}/by-id/${countryId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_country_srv/getCountry')
  }
}

// ======================================================
// CREATE
// POST /countrys/  -> create_country (payload: SGCountryCreate)
// ======================================================
export async function createCountry(payload: SGCountryCreate): Promise<SGCountryRead> {
  try {
    const res = await apiClient.post<SGAPIResponse<SGCountryRead>>(`${API_URL}/`, payload)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_country_srv/createCountry')
  }
}

// ======================================================
// UPDATE
// PUT /countrys/by-id/{country_id}  -> update_country (payload: SGCountryUpdate)
// ======================================================
export async function updateCountry(
  countryId: number,
  payload: SGCountryUpdate
): Promise<SGCountryRead> {
  try {
    const res = await apiClient.put<SGAPIResponse<SGCountryRead>>(
      `${API_URL}/by-id/${countryId}`,
      payload
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_country_srv/updateCountry')
  }
}

// ======================================================
// DELETE
// DELETE /countrys/by-id/{country_id}  -> delete_country (items = null)
// ======================================================
export async function deleteCountry(countryId: number): Promise<null> {
  try {
    const res = await apiClient.delete<SGAPIResponse<null>>(`${API_URL}/by-id/${countryId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_country_srv/deleteCountry')
  }
}
