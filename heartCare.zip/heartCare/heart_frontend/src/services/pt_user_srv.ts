// src/services/pt_user_srv.ts
//
// Service ánh xạ 1-1 với app/api/user_api.py (router prefix "/users").
// Mọi response bọc trong APIResponse -> SGAPIResponse<T>, field dữ liệu là `items`.
// Các API (trừ /login) yêu cầu header Authorization: Bearer <access_token>.

import axios, { AxiosError } from 'axios'
import apiClient from '@/utils/api'
import { SGAPIError, type SGAPIResponse } from '@/types/sg_site_type'
import type {
  PTUserCreate,
  PTUserListParams,
  PTUserLogin,
  PTUserRead,
  PTUserToken,
  PTUserUpdate,
  UserPagedParams,
  UserPagedRes
} from '@/types/pt_user'

// ======================================================
// API CONSTANTS
// ======================================================
// Backend router: APIRouter(prefix="/users"). Đổi tiền tố cho khớp gateway nếu cần.
const API_URL = '/api/users'

// ======================================================
// RESPONSE HELPERS
// ======================================================
function validateBusinessResponse<T>(response: SGAPIResponse<T>): SGAPIResponse<T> {
  if (response.status !== 200) {
    // Gắn chi tiết lỗi từng field (vd: "username: Tên đăng nhập đã tồn tại") vào message
    const fieldErrors = response.errors ?? response.err_items
    const detail = fieldErrors?.length
      ? ` (${fieldErrors.map((e) => `${e.field}: ${e.message}`).join('; ')})`
      : ''

    throw new SGAPIError(
      (response.message || 'Business validation error') + detail,
      response.status,
      fieldErrors
    )
  }

  return response
}

function handleAxiosError(error: unknown, source: string): never {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<SGAPIResponse & { detail?: unknown }>

    const data = axiosError.response?.data
    const detail = data?.detail

    // FastAPI/Pydantic validation error (vd: HTTP 422): detail = [{ loc, msg, type }, ...]
    const message = Array.isArray(detail)
      ? detail
          .map((item: { loc?: unknown[]; msg?: string }) => {
            const field = Array.isArray(item?.loc) ? item.loc.join('.') : item?.loc
            return field ? `${field}: ${item?.msg}` : item?.msg
          })
          .join('; ')
      : data?.message ||
        (typeof detail === 'string' ? detail : null) ||
        axiosError.message ||
        'Unknown axios error'

    const status = data?.status || axiosError.response?.status || 0

    throw new SGAPIError(`${source}: ${message}`, status, detail)
  }

  if (error instanceof Error) {
    throw new SGAPIError(`${source}: ${error.message}`, 0)
  }

  throw new SGAPIError(`${source}: Unknown error`, 0)
}

export function newPTUserCreate(): PTUserCreate {
  return {
    username: '', // max_length=50
    full_name: null, // max_length=100
    dob: '', // ISO datetime
    gender: 1, // 1: Nam, 2: Nữ
    addr: '', // Địa chỉ
    roles: 1, // 1: 'patient', 2: 'admin'
    pw: null // max_length=100
  }
}

// ======================================================
// LIST (admin)
// GET /users/?skip=&limit=  -> list_users
// ======================================================
export async function getUsers(params?: PTUserListParams): Promise<PTUserRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<PTUserRead[]>>(`${API_URL}/`, { params })

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_user_srv/getUsers')
  }
}

// ======================================================
// LIST (PAGED - admin)
// POST /users/page  -> page_users (payload: UserPagedParams, body rỗng -> page=1, page_size=20)
// Backend bọc kết quả trong APIResponse: items = UserPageRes { items, page, page_size, total, total_pages }
// ======================================================
export async function getUserPaged(filter?: UserPagedParams): Promise<UserPagedRes> {
  try {
    const res = await apiClient.post<SGAPIResponse<UserPagedRes>>(`${API_URL}/page`, filter ?? null)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_user_srv/getUserPaged')
  }
}

// ======================================================
// DETAIL (chính chủ hoặc admin)
// GET /users/{users_id}  -> read_user
// ======================================================
export async function getUser(usersId: number): Promise<PTUserRead> {
  try {
    const res = await apiClient.get<SGAPIResponse<PTUserRead>>(`${API_URL}/${usersId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_user_srv/getUser')
  }
}

// ======================================================
// CREATE (admin)
// POST /users/  -> create_user_api (payload: PTUserCreate)
// ======================================================
export async function createUser(payload: PTUserCreate): Promise<PTUserRead> {
  try {
    const res = await apiClient.post<SGAPIResponse<PTUserRead>>(`${API_URL}/`, payload)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_user_srv/createUser')
  }
}

// ======================================================
// UPDATE (chính chủ hoặc admin; chỉ admin được đổi `roles`)
// PUT /users/by_id/{users_id}  -> update_user_api (payload: PTUserUpdate)
// ======================================================
export async function updateUser(usersId: number, payload: PTUserUpdate): Promise<PTUserRead> {
  try {
    const res = await apiClient.put<SGAPIResponse<PTUserRead>>(
      `${API_URL}/by_id/${usersId}`,
      payload
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_user_srv/updateUser')
  }
}

// ======================================================
// DELETE (admin)
// DELETE /users/by_id/{users_id}  -> delete_user_api (items = user đã xóa)
// ======================================================
export async function deleteUser(usersId: number): Promise<PTUserRead> {
  try {
    const res = await apiClient.delete<SGAPIResponse<PTUserRead>>(`${API_URL}/by_id/${usersId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_user_srv/deleteUser')
  }
}

// ======================================================
// LOGIN
// POST /users/login  -> login_user (payload: PTUserLogin)
// Lưu access_token vào localStorage("token") để interceptor trong utils/api.ts gắn vào header.
// ======================================================
export async function loginUser(payload: PTUserLogin): Promise<PTUserToken> {
  try {
    const res = await apiClient.post<SGAPIResponse<PTUserToken>>(`${API_URL}/login`, payload)

    const data = validateBusinessResponse(res.data)

    localStorage.setItem('token', data.items.access_token)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_user_srv/loginUser')
  }
}
