// src/services/sg_project_srv.ts
//
// Service ánh xạ 1-1 với app/api/sg_project_api.py (router prefix "/projects").
// Mọi response bọc trong APIResponse -> SGAPIResponse<T>, field dữ liệu là `items`.

import axios, { AxiosError } from 'axios'
import apiClient from '@/utils/api'
import { SGAPIError, type SGAPIResponse } from '@/types/sg_site_type'
import type {
  SGProjectCreate,
  SGProjectPagedParams,
  SGProjectPagedRes,
  SGProjectRead,
  SGProjectUpdate
} from '@/types/sg_project'

// ======================================================
// API CONSTANTS
// ======================================================
// Backend router: APIRouter(prefix="/projects"). Đổi tiền tố cho khớp gateway nếu cần.
const API_URL = '/api/v1/projects'

// ======================================================
// RESPONSE HELPERS
// ======================================================
function validateBusinessResponse<T>(response: SGAPIResponse<T>): SGAPIResponse<T> {
  if (response.status !== 200) {
    throw new SGAPIError(response.message || 'Business validation error', response.status)
  }

  return response
}

function handleAxiosError(error: unknown, source: string): never {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<SGAPIResponse & { detail?: unknown }>

    const data = axiosError.response?.data
    const detail = data?.detail

    // FastAPI/Pydantic validation error (vd: HTTP 422): detail = [{ loc, msg, type }, ...]
    const message = Array.isArray(detail)
      ? detail
          .map((item: { loc?: unknown[]; msg?: string }) => {
            const field = Array.isArray(item?.loc) ? item.loc.join('.') : item?.loc
            return field ? `${field}: ${item?.msg}` : item?.msg
          })
          .join('; ')
      : data?.message || axiosError.message || 'Unknown axios error'

    const status = data?.status || axiosError.response?.status || 0

    throw new SGAPIError(`${source}: ${message}`, status, detail)
  }

  if (error instanceof Error) {
    throw new SGAPIError(`${source}: ${error.message}`, 0)
  }

  throw new SGAPIError(`${source}: Unknown error`, 0)
}

// ======================================================
// FACTORY
// ======================================================
export function newSGProjectCreate(): SGProjectCreate {
  return {
    project_code: null, // max_length=50, backend tự sinh nếu bỏ trống
    project_name: '', // max_length=100
    project_date: new Date().toISOString(),
    customer_id: 0,
    project_status: 0
  }
}

// ======================================================
// LIST
// GET /projects/  -> get_projects
// ======================================================
export async function getProjects(): Promise<SGProjectRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGProjectRead[]>>(`${API_URL}/`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_project_srv/getProjects')
  }
}

// ======================================================
// LIST (PAGED)
// POST /projects/page  -> get_project_page (payload: SGProjectPagred)
// Response bọc trong APIResponsePage: { items, status, message, page, page_size, total, total_pages }
// ======================================================
export async function getProjectPaged(filter: SGProjectPagedParams): Promise<SGProjectPagedRes> {
  try {
    const res = await apiClient.post<SGProjectPagedRes>(`${API_URL}/page`, filter)

    const data = res.data

    if (data.status !== 200) {
      throw new SGAPIError(data.message || 'Business validation error', data.status)
    }

    return data
  } catch (error) {
    handleAxiosError(error, 'sg_project_srv/getProjectPaged')
  }
}

// ======================================================
// DETAIL
// GET /projects/by-id/{project_id}  -> get_project
// ======================================================
export async function getProject(projectId: number): Promise<SGProjectRead> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGProjectRead>>(`${API_URL}/by-id/${projectId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_project_srv/getProject')
  }
}

// ======================================================
// CREATE
// POST /projects/  -> create_project (payload: SGProjectCreate)
// ======================================================
export async function createProject(payload: SGProjectCreate): Promise<SGProjectRead> {
  try {
    const res = await apiClient.post<SGAPIResponse<SGProjectRead>>(`${API_URL}/`, payload)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_project_srv/createProject')
  }
}

// ======================================================
// UPDATE
// PUT /projects/by-id/{project_id}  -> update_project (payload: SGProjectUpdate)
// ======================================================
export async function updateProject(
  projectId: number,
  payload: SGProjectUpdate
): Promise<SGProjectRead> {
  try {
    const res = await apiClient.put<SGAPIResponse<SGProjectRead>>(
      `${API_URL}/by-id/${projectId}`,
      payload
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_project_srv/updateProject')
  }
}

// ======================================================
// DELETE
// DELETE /projects/by-id/{project_id}  -> delete_project (items = null)
// ======================================================
export async function deleteProject(projectId: number): Promise<null> {
  try {
    const res = await apiClient.delete<SGAPIResponse<null>>(`${API_URL}/by-id/${projectId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_project_srv/deleteProject')
  }
}
