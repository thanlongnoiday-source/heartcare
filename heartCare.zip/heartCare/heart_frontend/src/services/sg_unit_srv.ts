// src/services/sg_runit_srv.ts
//
// Service ánh xạ 1-1 với app/api/sg_unit_api.py (router prefix "/units").
// Mọi response bọc trong APIResponse -> SGAPIResponse<T>, field dữ liệu là `items`.

import axios, { AxiosError } from 'axios'
import apiClient from '@/utils/api'
import { SGAPIError, type SGAPIResponse } from '@/types/sg_site_type'
import type {
  SGUnitCreate,
  SGUnitPagedParams,
  SGUnitPageRes,
  SGUnitRead,
  SGUnitUpdate
} from '@/types/sg_unit'

// ======================================================
// API CONSTANTS
// ======================================================
// Backend router: APIRouter(prefix="/units"). Đổi tiền tố cho khớp gateway nếu cần.
const API_URL = '/api/v1/units'

// ======================================================
// RESPONSE HELPERS
// ======================================================
function validateBusinessResponse<T>(response: SGAPIResponse<T>): SGAPIResponse<T> {
  if (response.status !== 200) {
    throw new SGAPIError(response.message || 'Business validation error', response.status)
  }

  return response
}

function handleAxiosError(error: unknown, source: string): never {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<SGAPIResponse & { detail?: unknown }>

    const data = axiosError.response?.data
    const detail = data?.detail

    // FastAPI/Pydantic validation error (vd: HTTP 422): detail = [{ loc, msg, type }, ...]
    const message = Array.isArray(detail)
      ? detail
          .map((item: { loc?: unknown[]; msg?: string }) => {
            const field = Array.isArray(item?.loc) ? item.loc.join('.') : item?.loc
            return field ? `${field}: ${item?.msg}` : item?.msg
          })
          .join('; ')
      : data?.message || axiosError.message || 'Unknown axios error'

    const status = data?.status || axiosError.response?.status || 0

    throw new SGAPIError(`${source}: ${message}`, status, detail)
  }

  if (error instanceof Error) {
    throw new SGAPIError(`${source}: ${error.message}`, 0)
  }

  throw new SGAPIError(`${source}: Unknown error`, 0)
}

export function newSGUnitCreate(): SGUnitCreate {
  return {
    unit_name: '' // max_length=100
  }
}

// ======================================================
// LIST
// GET /units/  -> get_units
// ======================================================
export async function getUnits(): Promise<SGUnitRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGUnitRead[]>>(`${API_URL}/`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_runit_srv/getUnits')
  }
}

// ======================================================
// LIST (PAGED)
// POST /units/page  -> get_unit_page (payload: SGUnitPagred)
// Response bọc trong APIResponsePage: { items, status, message, page, page_size, total, total_pages }
// ======================================================
export async function getUnitPaged(filter: SGUnitPagedParams): Promise<SGUnitPageRes> {
  try {
    const res = await apiClient.post<SGUnitPageRes>(`${API_URL}/page`, filter)

    const data = res.data

    if (data.status !== 200) {
      throw new SGAPIError(data.message || 'Business validation error', data.status)
    }

    return data
  } catch (error) {
    handleAxiosError(error, 'sg_runit_srv/getUnitPaged')
  }
}

// ======================================================
// DETAIL
// GET /units/by-id/{unit_id}  -> get_unit
// ======================================================
export async function getUnit(unitId: number): Promise<SGUnitRead> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGUnitRead>>(`${API_URL}/by-id/${unitId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_runit_srv/getUnit')
  }
}

// ======================================================
// CREATE
// POST /units/  -> create_unit (payload: SGUnitCreate)
// ======================================================
export async function createUnit(payload: SGUnitCreate): Promise<SGUnitRead> {
  try {
    const res = await apiClient.post<SGAPIResponse<SGUnitRead>>(`${API_URL}/`, payload)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_runit_srv/createUnit')
  }
}

// ======================================================
// UPDATE
// PUT /units/by-id/{unit_id}  -> update_unit (payload: SGUnitUpdate)
// ======================================================
export async function updateUnit(unitId: number, payload: SGUnitUpdate): Promise<SGUnitRead> {
  try {
    const res = await apiClient.put<SGAPIResponse<SGUnitRead>>(
      `${API_URL}/by-id/${unitId}`,
      payload
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_runit_srv/updateUnit')
  }
}

// ======================================================
// DELETE
// DELETE /units/by-id/{unit_id}  -> delete_unit (items = null)
// ======================================================
export async function deleteUnit(unitId: number): Promise<null> {
  try {
    const res = await apiClient.delete<SGAPIResponse<null>>(`${API_URL}/by-id/${unitId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_runit_srv/deleteUnit')
  }
}
