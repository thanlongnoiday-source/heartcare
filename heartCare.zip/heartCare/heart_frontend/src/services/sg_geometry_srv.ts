// src/services/sg_geometry_srv.ts
//
// Service ánh xạ 1-1 với app/api/sg_geometry_api.py (router prefix "/geometrys").
// Mọi response bọc trong APIResponse -> SGAPIResponse<T>, field dữ liệu là `items`.

import axios, { AxiosError } from 'axios'
import apiClient from '@/utils/api'
import { SGAPIError, type SGAPIResponse } from '@/types/sg_site_type'
import type { SGGeometryCreate, SGGeometryRead, SGGeometryUpdate } from '@/types/sg_geometry'
import { GEOMETRY_STATUS, GEOMETRY_TYPE } from '@/constants/sg_engr_geometry_const'

// ======================================================
// API CONSTANTS
// ======================================================
// Backend router: APIRouter(prefix="/geometrys"). Đổi tiền tố cho khớp gateway nếu cần.
const API_URL = '/api/v1/geometrys'

// ======================================================
// RESPONSE HELPERS
// ======================================================
function validateBusinessResponse<T>(response: SGAPIResponse<T>): SGAPIResponse<T> {
  if (response.status !== 200) {
    throw new SGAPIError(response.message || 'Business validation error', response.status)
  }

  return response
}

// Backend có thể serialize Decimal (leng/width/height, delta_*, grading_*, scales) thành CHUỖI JSON ("5.00").
// Ép về number ngay khi nhận response để phần còn lại của app luôn nhận đúng kiểu
// `number` như type đã khai báo — nếu để nguyên chuỗi, sg_input_number sẽ hiểu nhầm
// dấu '.' là dấu phân cách hàng nghìn (locale vi-VN) và hiển thị sai.
function normalizeGeometry(geometry: SGGeometryRead): SGGeometryRead {
  return {
    ...geometry,
    leng: Number(geometry.leng) || 0,
    width: Number(geometry.width) || 0,
    height: Number(geometry.height) || 0,
    delta_x: Number(geometry.delta_x) || 1,
    delta_y: Number(geometry.delta_y) || 1,
    delta_z: Number(geometry.delta_z) || 1,
    grading_x: Number(geometry.grading_x) || 1,
    grading_y: Number(geometry.grading_y) || 1,
    grading_z: Number(geometry.grading_z) || 1,
    scales: Number(geometry.scales) || 1
  }
}

function handleAxiosError(error: unknown, source: string): never {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<SGAPIResponse & { detail?: unknown }>

    const data = axiosError.response?.data
    const detail = data?.detail

    // FastAPI/Pydantic validation error (vd: HTTP 422): detail = [{ loc, msg, type }, ...]
    const message = Array.isArray(detail)
      ? detail
          .map((item: { loc?: unknown[]; msg?: string }) => {
            const field = Array.isArray(item?.loc) ? item.loc.join('.') : item?.loc
            return field ? `${field}: ${item?.msg}` : item?.msg
          })
          .join('; ')
      : data?.message || axiosError.message || 'Unknown axios error'

    const status = data?.status || axiosError.response?.status || 0

    throw new SGAPIError(`${source}: ${message}`, status, detail)
  }

  if (error instanceof Error) {
    throw new SGAPIError(`${source}: ${error.message}`, 0)
  }

  throw new SGAPIError(`${source}: Unknown error`, 0)
}

// ======================================================
// FACTORY
// ======================================================
export function newSGGeometryRead(): SGGeometryRead {
  return {
    geometry_id: 0,
    geometry_code: '', // toi da 50 ky tu
    geometry_name: '', // toi da 100 ky tu
    project_id: 0,
    leng: 0, // Decimal(14, 2), default 0.00 - chieu dai
    width: 0, // Decimal(14, 2), default 0.00
    height: 0, // Decimal(14, 2), default 0.00
    cad_file_path: '', // toi da 200 ky tu
    obj_file_path: '', // toi da 200 ky tu
    geometry_type: GEOMETRY_TYPE.BOX,
    geometry_status: GEOMETRY_STATUS.DRAFT,
    delta_x: 0,
    delta_y: 0,
    delta_z: 0,
    grading_x: 0,
    grading_y: 0,
    grading_z: 0,
    scales: 0
  }
}

export function newSGGeometryCreate(): SGGeometryCreate {
  return {
    geometry_code: '', // max_length=50
    geometry_name: '', // max_length=100
    project_id: 0,
    leng: 0, // Decimal(14, 2), default 0.00
    width: 0, // Decimal(14, 2), default 0.00
    height: 0, // Decimal(14, 2), default 0.00
    cad_file_path: null, // max_length=200
    obj_file_path: null, // max_length=200
    geometry_type: GEOMETRY_TYPE.BOX,
    geometry_status: GEOMETRY_STATUS.DRAFT,
    delta_x: 0,
    delta_y: 0,
    delta_z: 0,
    grading_x: 0,
    grading_y: 0,
    grading_z: 0,
    scales: 0
  }
}

//======================================================
// LIST
// GET /geometrys/  -> get_geometrys
// ======================================================
export async function getGeometrys(): Promise<SGGeometryRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGGeometryRead[]>>(`${API_URL}/`)

    const data = validateBusinessResponse(res.data)

    return data.items.map(normalizeGeometry)
  } catch (error) {
    handleAxiosError(error, 'sg_geometry_srv/getGeometrys')
  }
}

// ======================================================
// LIST BY PROJECT
// GET /geometrys/by-project/{project_id}  -> get_geometry_by_project
// ======================================================
export async function getGeometryByproject(projectId: number): Promise<SGGeometryRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGGeometryRead[]>>(
      `${API_URL}/by-project/${projectId}`
    )

    const data = validateBusinessResponse(res.data)

    return data.items.map(normalizeGeometry)
  } catch (error) {
    handleAxiosError(error, 'sg_geometry_srv/getGeometryByproject')
  }
}

// ======================================================
// DETAIL
// GET /geometrys/by-id/{geometry_id}  -> get_geometry
// ======================================================
export async function getGeometry(geometryId: number): Promise<SGGeometryRead> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGGeometryRead>>(`${API_URL}/by-id/${geometryId}`)

    const data = validateBusinessResponse(res.data)

    return normalizeGeometry(data.items)
  } catch (error) {
    handleAxiosError(error, 'sg_geometry_srv/getGeometry')
  }
}

// ======================================================
// GET GEOMETRY STL
// GET /geometrys/get-geometry-stl?geometry_id=&job_id=  -> get_geometry_stl
// items = đường dẫn/URL tới file STL của geometry theo job
// ======================================================
export async function getGeometryStl(geometryId: number, jobId: number): Promise<string> {
  try {
    const res = await apiClient.get<SGAPIResponse<string>>(`${API_URL}/get-geometry-obj`, {
      params: { geometry_id: geometryId, job_id: jobId }
    })

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_geometry_srv/getGeometryStl')
  }
}

// ======================================================
// RUN SIMULATION
// POST /geometrys/run-simulation  -> run_simulation (payload: SGGeometryRead)
// items = job id của simulation vừa khởi chạy
// ======================================================
export async function runSimulation(payload: SGGeometryRead): Promise<number> {
  try {
    const res = await apiClient.post<SGAPIResponse<number>>(`${API_URL}/run-simulation`, payload)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_geometry_srv/runSimulation')
  }
}

// ======================================================
// STOP SIMULATION
// POST /geometrys/stop-simulation/{job_id}  -> stop_simulation
// items = job id của simulation vừa dừng
// ======================================================
export async function stopSimulation(jobId: number): Promise<number> {
  try {
    const res = await apiClient.post<SGAPIResponse<number>>(`${API_URL}/stop-simulation/${jobId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_geometry_srv/stopSimulation')
  }
}

// ======================================================
// CREATE
// POST /geometrys/  -> create_geometry (payload: SGGeometryCreate)
// ======================================================
export async function createGeometry(payload: SGGeometryCreate): Promise<SGGeometryRead> {
  try {
    const res = await apiClient.post<SGAPIResponse<SGGeometryRead>>(`${API_URL}/`, payload)

    const data = validateBusinessResponse(res.data)

    return normalizeGeometry(data.items)
  } catch (error) {
    handleAxiosError(error, 'sg_geometry_srv/createGeometry')
  }
}

// ======================================================
// UPDATE
// PUT /geometrys/by-id/{geometry_id}  -> update_geometry (payload: SGGeometryUpdate)
// ======================================================
export async function updateGeometry(
  geometryId: number,
  payload: SGGeometryUpdate
): Promise<SGGeometryRead> {
  try {
    const res = await apiClient.put<SGAPIResponse<SGGeometryRead>>(
      `${API_URL}/by-id/${geometryId}`,
      payload
    )

    const data = validateBusinessResponse(res.data)

    return normalizeGeometry(data.items)
  } catch (error) {
    handleAxiosError(error, 'sg_geometry_srv/updateGeometry')
  }
}

// ======================================================
// BUILD BLOCK MESH DICT WITH OPENINGS
// POST /geometrys/block-mesh-dict  -> build_block_mesh_dict_with_openings (payload: SGGeometryCreate)
// items = đường dẫn tương đối tới file blockMeshDict đã sinh
// ======================================================
export async function buildBlockMeshDictWithOpenings(payload: SGGeometryRead): Promise<string> {
  try {
    const res = await apiClient.post<SGAPIResponse<string>>(`${API_URL}/block-mesh-dict`, payload)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_geometry_srv/buildBlockMeshDictWithOpenings')
  }
}

// ======================================================
// CHECK MESH
// POST /geometrys/check-mesh  -> check_mesh (payload: SGGeometryRead)
// items = đường dẫn tương đối tới file blockMeshDict đã kiểm tra
// ======================================================
export async function checkMesh(payload: SGGeometryRead): Promise<string> {
  try {
    const res = await apiClient.post<SGAPIResponse<string>>(`${API_URL}/check-mesh`, payload)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_geometry_srv/checkMesh')
  }
}

// ======================================================
// DELETE
// DELETE /geometrys/by-id/{geometry_id}  -> delete_geometry (items = null)
// ======================================================
export async function deleteGeometry(geometryId: number): Promise<null> {
  try {
    const res = await apiClient.delete<SGAPIResponse<null>>(`${API_URL}/by-id/${geometryId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_geometry_srv/deleteGeometry')
  }
}
