// src/services/sg_job_ws_srv.ts
//
// Kênh WebSocket tới gateway (hvac_fastapi_v1_1, app/api/v1/sg_job_api.py):
//   ws /api/v1/jobs/{job_id}/ws?token=<JWT>
// Gateway gửi ngay 1 ảnh chụp trạng thái, sau đó mỗi lần tiến độ thay đổi (~5s) một
// SGJobProgressMessage đầy đủ (progress %, current_step, iteration, residuals...).
// Đóng kết nối:
//   - 1000: job COMPLETED/FAILED (đã gửi thông điệp cuối) -> không kết nối lại.
//   - 4000 + HTTP code (4401/4403/4404/4500): lỗi nghiệp vụ, trước đó gửi envelope
//     APIResponse { status, message } -> báo lỗi, không kết nối lại.
//   - Mã khác (1006 mất mạng, 1012 server restart...): kết nối lại.
// Ping/pong giữ kết nối do uvicorn xử lý ở tầng giao thức, client không cần gửi gì.

import { ENV } from '@/config/env'
import type { SGJobProgressMessage } from '@/types/sg_job'
import {
  SESSION_EXPIRED_STATUS,
  SESSION_EXPIRED_WS_CODE,
  handleSessionExpired
} from '@/utils/sg_session_expired'

// ======================================================
// API CONSTANTS
// ======================================================
const API_URL = '/api/v1/jobs'

// Kết nối lại với backoff 1s, 2s, 4s, ... tối đa MAX_RECONNECT_DELAY_MS.
const MAX_RECONNECT_ATTEMPTS = 5
const MAX_RECONNECT_DELAY_MS = 15_000

// Khớp WS_TERMINAL_STATUSES trong app/constants/sg_job_const.py.
export const PROGRESS_STATUS = {
  PENDING: 'PENDING',
  QUEUED: 'QUEUED',
  RUNNING: 'RUNNING',
  COMPLETED: 'COMPLETED',
  FAILED: 'FAILED'
} as const

export function isProgressSuccess(status: string | null | undefined): boolean {
  return status === PROGRESS_STATUS.COMPLETED
}

export function isProgressFailed(status: string | null | undefined): boolean {
  return status === PROGRESS_STATUS.FAILED
}

export function isProgressTerminal(status: string | null | undefined): boolean {
  return isProgressSuccess(status) || isProgressFailed(status)
}

// TODO: chưa nối đăng nhập thật — dùng chung khoá "token" với interceptor (đang tắt)
// trong src/utils/api.ts. Không có token thì gateway dev vẫn chấp nhận.
function getAuthToken(): string | null {
  try {
    return localStorage.getItem('token')
  } catch {
    return null
  }
}

// http(s)://host/... -> ws(s)://host/... ; chưa cấu hình VITE_API_URL thì dùng origin
// của trang (dev server proxy).
export function buildJobProgressWsUrl(jobId: number): string {
  const base = String(ENV.API_URL || window.location.origin).replace(/\/+$/, '')
  const wsBase = base.replace(/^http/i, 'ws')
  const token = getAuthToken()
  const query = token ? `?token=${encodeURIComponent(token)}` : ''
  return `${wsBase}${API_URL}/${jobId}/ws${query}`
}

// ======================================================
// CONNECTION
// ======================================================
export interface JobProgressSocketHandlers {
  onOpen?: () => void
  onMessage: (message: SGJobProgressMessage) => void
  // Envelope lỗi từ gateway (không có progress_percentage), vd: 404 job không tồn tại.
  onServerError?: (message: string, status: number | null) => void
  // Gateway đóng kết nối chủ động (1000 hoặc 4xxx) — không kết nối lại.
  onClosed?: (code: number) => void
  // Mất kết nối ngoài ý muốn; `retryIn` = ms trước lần kết nối lại.
  onReconnecting?: (attempt: number, retryIn: number) => void
  // Hết số lần kết nối lại -> nơi gọi tự chọn phương án dự phòng (vd: polling REST).
  onGiveUp?: () => void
}

export interface JobProgressSocket {
  close: () => void
}

export function connectJobProgress(
  jobId: number,
  handlers: JobProgressSocketHandlers
): JobProgressSocket {
  let socket: WebSocket | null = null
  let reconnectTimer: ReturnType<typeof setTimeout> | null = null
  let attempts = 0
  // close() đã được gọi -> không kết nối lại, không gọi handler nữa.
  let closedByClient = false

  function open(): void {
    // Dựng URL mỗi lần mở để lấy token mới nhất.
    socket = new WebSocket(buildJobProgressWsUrl(jobId))

    socket.onopen = () => {
      if (closedByClient) return
      attempts = 0
      handlers.onOpen?.()
    }

    socket.onmessage = (event: MessageEvent) => {
      if (closedByClient) return
      let data: Record<string, unknown>
      try {
        data = JSON.parse(String(event.data))
      } catch {
        return
      }
      if (data?.progress_percentage === undefined) {
        // Envelope lỗi: APIResponse { status, message, ... }
        const status = typeof data?.status === 'number' ? data.status : null
        if (status === SESSION_EXPIRED_STATUS) handleSessionExpired()
        handlers.onServerError?.(String(data?.message ?? 'Lỗi WebSocket từ gateway.'), status)
        return
      }
      handlers.onMessage(data as unknown as SGJobProgressMessage)
    }

    socket.onclose = (event: CloseEvent) => {
      socket = null
      if (closedByClient) return
      if (event.code === 1000 || event.code >= 4000) {
        // 4401: hết thời gian đăng nhập / chưa đăng nhập -> thông báo và quay về login.
        if (event.code === SESSION_EXPIRED_WS_CODE) handleSessionExpired()
        handlers.onClosed?.(event.code)
        return
      }
      if (attempts >= MAX_RECONNECT_ATTEMPTS) {
        handlers.onGiveUp?.()
        return
      }
      attempts++
      const delay = Math.min(1000 * 2 ** (attempts - 1), MAX_RECONNECT_DELAY_MS)
      handlers.onReconnecting?.(attempts, delay)
      reconnectTimer = setTimeout(open, delay)
    }
    // Lỗi WS luôn kèm onclose ngay sau -> xử lý kết nối lại ở onclose.
  }

  function close(): void {
    closedByClient = true
    if (reconnectTimer) clearTimeout(reconnectTimer)
    reconnectTimer = null
    if (socket && socket.readyState <= WebSocket.OPEN) socket.close(1000, 'client closed')
    socket = null
  }

  open()

  return { close }
}
