// src/services/sg_outlet_srv.ts
//
// Service ánh xạ 1-1 với app/api/sg_outlet_api.py (router prefix "/outlets").
// Mọi response bọc trong APIResponse -> SGAPIResponse<T>, field dữ liệu là `items`.

import axios, { AxiosError } from 'axios'
import apiClient from '@/utils/api'
import { SGAPIError, type SGAPIResponse } from '@/types/sg_site_type'
import type { SGOutletCreate, SGOutletRead, SGOutletUpdate } from '@/types/sg_outlet'
import {
  DEFAULT_OUTLET_BACK_TEMP,
  DEFAULT_OUTLET_FLOW_RATE,
  DEFAULT_OUTLET_PRESSURE,
  DEFAULT_OUTLET_SIZE_H,
  DEFAULT_OUTLET_SIZE_W,
  OUTLET_CONTROL_MODE
} from '@/constants/sg_engr_outlet_const'

// ======================================================
// API CONSTANTS
// ======================================================
// Backend router: APIRouter(prefix="/outlets"). Đổi tiền tố cho khớp gateway nếu cần.
const API_URL = '/api/v1/outlets'

// ======================================================
// RESPONSE HELPERS
// ======================================================
function validateBusinessResponse<T>(response: SGAPIResponse<T>): SGAPIResponse<T> {
  if (response.status !== 200) {
    throw new SGAPIError(response.message || 'Business validation error', response.status)
  }

  return response
}

// Backend serialize Decimal(14, 2) thành CHUỖI JSON ("5.00"). Ép về number ngay khi
// nhận response để phần còn lại của app luôn nhận đúng kiểu `number` như type đã khai báo
// — nếu để nguyên chuỗi, sg_input_number sẽ hiểu nhầm dấu '.' là dấu phân cách hàng nghìn
// (locale vi-VN) và hiển thị sai.
function normalizeOutlet(outlet: SGOutletRead): SGOutletRead {
  return {
    ...outlet,
    flow_rate: Number(outlet.flow_rate) || 0,
    pressure: Number(outlet.pressure) || 0,
    back_temp: Number(outlet.back_temp) || 0,
    turbulence: Number(outlet.turbulence) || 0,
    pos_x: Number(outlet.pos_x) || 0,
    pos_y: Number(outlet.pos_y) || 0,
    pos_z: Number(outlet.pos_z) || 0,
    size_w: Number(outlet.size_w) || 0,
    size_h: Number(outlet.size_h) || 0
  }
}

function handleAxiosError(error: unknown, source: string): never {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<SGAPIResponse & { detail?: unknown }>

    const data = axiosError.response?.data
    const detail = data?.detail

    // FastAPI/Pydantic validation error (vd: HTTP 422): detail = [{ loc, msg, type }, ...]
    const message = Array.isArray(detail)
      ? detail
          .map((item: { loc?: unknown[]; msg?: string }) => {
            const field = Array.isArray(item?.loc) ? item.loc.join('.') : item?.loc
            return field ? `${field}: ${item?.msg}` : item?.msg
          })
          .join('; ')
      : data?.message || axiosError.message || 'Unknown axios error'

    const status = data?.status || axiosError.response?.status || 0

    throw new SGAPIError(`${source}: ${message}`, status, detail)
  }

  if (error instanceof Error) {
    throw new SGAPIError(`${source}: ${error.message}`, 0)
  }

  throw new SGAPIError(`${source}: Unknown error`, 0)
}

// ======================================================
// FACTORY
// ======================================================
export function newSGOutletRead(): SGOutletRead {
  return {
    outlet_id: 0,
    outlet_code: '', // max_length=30
    outlet_name: null, // max_length=100
    control_mode: OUTLET_CONTROL_MODE.PRESSURE_OUTLET,
    flow_rate: DEFAULT_OUTLET_FLOW_RATE,
    pressure: DEFAULT_OUTLET_PRESSURE, // Decimal(14, 2), default 0.00
    back_temp: DEFAULT_OUTLET_BACK_TEMP, // Decimal(14, 2), default 0.00
    turbulence: 0, // Decimal(8, 2), default 0.00
    pos_x: 0, // Decimal(14, 2), default 0.00
    pos_y: 0, // Decimal(14, 2), default 0.00
    pos_z: 0, // Decimal(14, 2), default 0.00
    size_w: DEFAULT_OUTLET_SIZE_W, // Decimal(14, 2), default 0.00
    size_h: DEFAULT_OUTLET_SIZE_H, // Decimal(14, 2), default 0.00
    geometry_id: 0
  }
}

export function newSGOutletCreate(): SGOutletCreate {
  return {
    outlet_code: '', // max_length=30
    outlet_name: null, // max_length=100
    control_mode: OUTLET_CONTROL_MODE.PRESSURE_OUTLET,
    flow_rate: DEFAULT_OUTLET_FLOW_RATE,
    pressure: DEFAULT_OUTLET_PRESSURE, // Decimal(14, 2), default 0.00
    back_temp: DEFAULT_OUTLET_BACK_TEMP, // Decimal(14, 2), default 0.00
    turbulence: 0, // Decimal(8, 2), default 0.00
    pos_x: 0, // Decimal(14, 2), default 0.00
    pos_y: 0, // Decimal(14, 2), default 0.00
    pos_z: 0, // Decimal(14, 2), default 0.00
    size_w: DEFAULT_OUTLET_SIZE_W, // Decimal(14, 2), default 0.00
    size_h: DEFAULT_OUTLET_SIZE_H, // Decimal(14, 2), default 0.00
    geometry_id: 0
  }
}

// ======================================================
// LIST
// GET /outlets/  -> get_outlets
// ======================================================
export async function getOutlets(): Promise<SGOutletRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGOutletRead[]>>(`${API_URL}/`)

    const data = validateBusinessResponse(res.data)

    return data.items.map(normalizeOutlet)
  } catch (error) {
    handleAxiosError(error, 'sg_outlet_srv/getOutlets')
  }
}

// ======================================================
// LIST BY GEOMETRY
// GET /outlets/by-geometry/{geometry_id}  -> get_outlets_by_geometry
// (đặt tên theo quy ước by-project của sg_geometry_srv; đổi cho khớp router backend nếu cần)
// ======================================================
export async function getOutletsByGeometry(geometryId: number): Promise<SGOutletRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGOutletRead[]>>(
      `${API_URL}/by-geometry/${geometryId}`
    )

    const data = validateBusinessResponse(res.data)

    return data.items.map(normalizeOutlet)
  } catch (error) {
    handleAxiosError(error, 'sg_outlet_srv/getOutletsByGeometry')
  }
}

// ======================================================
// DETAIL
// GET /outlets/by-id/{outlet_id}  -> get_outlet
// ======================================================
export async function getOutlet(outletId: number): Promise<SGOutletRead> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGOutletRead>>(`${API_URL}/by-id/${outletId}`)

    const data = validateBusinessResponse(res.data)

    return normalizeOutlet(data.items)
  } catch (error) {
    handleAxiosError(error, 'sg_outlet_srv/getOutlet')
  }
}

// ======================================================
// CREATE
// POST /outlets/  -> create_outlet (payload: SGOutletCreate)
// ======================================================
export async function createOutlet(payload: SGOutletCreate): Promise<SGOutletRead> {
  try {
    const res = await apiClient.post<SGAPIResponse<SGOutletRead>>(`${API_URL}/`, payload)

    const data = validateBusinessResponse(res.data)

    return normalizeOutlet(data.items)
  } catch (error) {
    handleAxiosError(error, 'sg_outlet_srv/createOutlet')
  }
}

// ======================================================
// UPDATE
// PUT /outlets/by-id/{outlet_id}  -> update_outlet (payload: SGOutletUpdate)
// ======================================================
export async function updateOutlet(
  outletId: number,
  payload: SGOutletUpdate
): Promise<SGOutletRead> {
  try {
    const res = await apiClient.put<SGAPIResponse<SGOutletRead>>(
      `${API_URL}/by-id/${outletId}`,
      payload
    )

    const data = validateBusinessResponse(res.data)

    return normalizeOutlet(data.items)
  } catch (error) {
    handleAxiosError(error, 'sg_outlet_srv/updateOutlet')
  }
}

// ======================================================
// DELETE
// DELETE /outlets/by-id/{outlet_id}  -> delete_outlet (items = null)
// ======================================================
export async function deleteOutlet(outletId: number): Promise<null> {
  try {
    const res = await apiClient.delete<SGAPIResponse<null>>(`${API_URL}/by-id/${outletId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_outlet_srv/deleteOutlet')
  }
}
