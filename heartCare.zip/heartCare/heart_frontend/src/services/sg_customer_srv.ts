// src/services/sg_customer_srv.ts
//
// Service ánh xạ 1-1 với app/api/sg_customer_api.py (router prefix "/customers").
// Mọi response bọc trong APIResponse -> SGAPIResponse<T>, field dữ liệu là `items`.

import axios, { AxiosError } from 'axios'
import apiClient from '@/utils/api'
import { SGAPIError, type SGAPIResponse } from '@/types/sg_site_type'
import type {
  SGCustomerCreate,
  SGCustomerPagedParams,
  SGCustomerPagedRes,
  SGCustomerRead,
  SGCustomerUpdate
} from '@/types/sg_customer'

// ======================================================
// API CONSTANTS
// ======================================================
// Backend router: APIRouter(prefix="/customers"). Đổi tiền tố cho khớp gateway nếu cần.
const API_URL = '/api/v1/customers'

// ======================================================
// RESPONSE HELPERS
// ======================================================
function validateBusinessResponse<T>(response: SGAPIResponse<T>): SGAPIResponse<T> {
  if (response.status !== 200) {
    throw new SGAPIError(response.message || 'Business validation error', response.status)
  }

  return response
}

function handleAxiosError(error: unknown, source: string): never {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<SGAPIResponse & { detail?: unknown }>

    const data = axiosError.response?.data
    const detail = data?.detail

    // FastAPI/Pydantic validation error (vd: HTTP 422): detail = [{ loc, msg, type }, ...]
    const message = Array.isArray(detail)
      ? detail
          .map((item: { loc?: unknown[]; msg?: string }) => {
            const field = Array.isArray(item?.loc) ? item.loc.join('.') : item?.loc
            return field ? `${field}: ${item?.msg}` : item?.msg
          })
          .join('; ')
      : data?.message || axiosError.message || 'Unknown axios error'

    const status = data?.status || axiosError.response?.status || 0

    throw new SGAPIError(`${source}: ${message}`, status, detail)
  }

  if (error instanceof Error) {
    throw new SGAPIError(`${source}: ${error.message}`, 0)
  }

  throw new SGAPIError(`${source}: Unknown error`, 0)
}

export function newSGCustomerCreate(): SGCustomerCreate {
  return {
    customer_name: '', // max_length=100
    addr: '', // max_length=200
    phone: null, // max_length=50
    email: null // max_length=50
  }
}

// ======================================================
// LIST
// GET /customers/  -> get_customers
// ======================================================
export async function getCustomers(): Promise<SGCustomerRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGCustomerRead[]>>(`${API_URL}/`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_customer_srv/getCustomers')
  }
}

// ======================================================
// LIST (PAGED)
// POST /customers/page  -> get_customer_page (payload: SGCustomerPagred)
// Response bọc trong APIResponsePage: { items, status, message, page, page_size, total, total_pages }
// ======================================================
export async function getCustomerPaged(filter: SGCustomerPagedParams): Promise<SGCustomerPagedRes> {
  try {
    const res = await apiClient.post<SGCustomerPagedRes>(`${API_URL}/page`, filter)

    const data = res.data

    if (data.status !== 200) {
      throw new SGAPIError(data.message || 'Business validation error', data.status)
    }

    return data
  } catch (error) {
    handleAxiosError(error, 'sg_customer_srv/getCustomerPaged')
  }
}

// ======================================================
// DETAIL
// GET /customers/{customer_id}  -> get_customer
// ======================================================
export async function getCustomer(customerId: number): Promise<SGCustomerRead> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGCustomerRead>>(`${API_URL}/by-id/${customerId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_customer_srv/getCustomer')
  }
}

// ======================================================
// CREATE
// POST /customers/  -> create_customer (payload: SGCustomerCreate)
// ======================================================
export async function createCustomer(payload: SGCustomerCreate): Promise<SGCustomerRead> {
  try {
    const res = await apiClient.post<SGAPIResponse<SGCustomerRead>>(`${API_URL}/`, payload)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_customer_srv/createCustomer')
  }
}

// ======================================================
// UPDATE
// PUT /customers/{customer_id}  -> update_customer (payload: SGCustomerUpdate)
// ======================================================
export async function updateCustomer(
  customerId: number,
  payload: SGCustomerUpdate
): Promise<SGCustomerRead> {
  try {
    const res = await apiClient.put<SGAPIResponse<SGCustomerRead>>(
      `${API_URL}/${customerId}`,
      payload
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_customer_srv/updateCustomer')
  }
}

// ======================================================
// DELETE
// DELETE /customers/{customer_id}  -> delete_customer (items = null)
// ======================================================
export async function deleteCustomer(customerId: number): Promise<null> {
  try {
    const res = await apiClient.delete<SGAPIResponse<null>>(`${API_URL}/${customerId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_customer_srv/deleteCustomer')
  }
}
