// src/services/sg_openfoam_runner_srv.ts

import axios, { AxiosError } from 'axios'
import apiClient from '@/utils/api'
import { SGAPIError, type SGAPIResponse } from '@/types/sg_site_type'
import type { SGSetupRoomBase } from '@/types/sg_setup_room'
import type { SGSimulationStartResult, SGSimulationStatusResult } from '@/types/sg_openfoam_runner'

// ======================================================
// API CONSTANTS
// ======================================================
const API_URL = '/api/v1/engineer/simulation'

// ======================================================
// RESPONSE HELPERS
// ======================================================
function validateBusinessResponse<T>(response: SGAPIResponse<T>): SGAPIResponse<T> {
  if (response.status !== 200) {
    throw new SGAPIError(response.message || 'Business validation error', response.status)
  }

  return response
}

function handleAxiosError(error: unknown, source: string): never {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<SGAPIResponse & { detail?: unknown }>

    const data = axiosError.response?.data
    const detail = data?.detail

    // FastAPI/Pydantic validation error (vd: HTTP 422): detail = [{ loc, msg, type }, ...]
    const message = Array.isArray(detail)
      ? detail
          .map((item: { loc?: unknown[]; msg?: string }) => {
            const field = Array.isArray(item?.loc) ? item.loc.join('.') : item?.loc
            return field ? `${field}: ${item?.msg}` : item?.msg
          })
          .join('; ')
      : data?.message || axiosError.message || 'Unknown axios error'

    const status = data?.status || axiosError.response?.status || 0

    throw new SGAPIError(`${source}: ${message}`, status, detail)
  }

  if (error instanceof Error) {
    throw new SGAPIError(`${source}: ${error.message}`, 0)
  }

  throw new SGAPIError(`${source}: Unknown error`, 0)
}

// ======================================================
// RUN SIMULATION
// (POST /simulation/run-simulation) - Kich hoat mo phong OpenFOAM chay ngam
// ======================================================
export async function runSimulation(payload: SGSetupRoomBase): Promise<SGSimulationStartResult> {
  try {
    const res = await apiClient.post<SGAPIResponse<SGSimulationStartResult>>(
      `${API_URL}/run-simulation`,
      payload
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_openfoam_runner_srv/runSimulation')
  }
}

// ======================================================
// GET STATUS
// (GET /simulation/get-status/{task_id}) - Kiem tra trang thai tien trinh mo phong
// ======================================================
export async function getSimulationStatus(taskId: string): Promise<SGSimulationStatusResult> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGSimulationStatusResult>>(
      `${API_URL}/get-status/${taskId}`
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_openfoam_runner_srv/getSimulationStatus')
  }
}
