// src/services/sg_company_srv.ts
//
// Service ánh xạ 1-1 với app/api/sg_company_api.py (router prefix "/companys").
// Mọi response bọc trong APIResponse -> SGAPIResponse<T>, field dữ liệu là `items`.

import axios, { AxiosError } from 'axios'
import apiClient from '@/utils/api'
import { SGAPIError, type SGAPIResponse } from '@/types/sg_site_type'
import type {
  SGCompanyCreate,
  SGCompanyPagedParams,
  SGCompanyPageRes,
  SGCompanyRead,
  SGCompanyUpdate
} from '@/types/sg_company'

// ======================================================
// API CONSTANTS
// ======================================================
// Backend router: APIRouter(prefix="/companys"). Đổi tiền tố cho khớp gateway nếu cần.
const API_URL = '/api/v1/companys'

// ======================================================
// RESPONSE HELPERS
// ======================================================
function validateBusinessResponse<T>(response: SGAPIResponse<T>): SGAPIResponse<T> {
  if (response.status !== 200) {
    throw new SGAPIError(response.message || 'Business validation error', response.status)
  }

  return response
}

function handleAxiosError(error: unknown, source: string): never {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<SGAPIResponse & { detail?: unknown }>

    const data = axiosError.response?.data
    const detail = data?.detail

    // FastAPI/Pydantic validation error (vd: HTTP 422): detail = [{ loc, msg, type }, ...]
    const message = Array.isArray(detail)
      ? detail
          .map((item: { loc?: unknown[]; msg?: string }) => {
            const field = Array.isArray(item?.loc) ? item.loc.join('.') : item?.loc
            return field ? `${field}: ${item?.msg}` : item?.msg
          })
          .join('; ')
      : data?.message || axiosError.message || 'Unknown axios error'

    const status = data?.status || axiosError.response?.status || 0

    throw new SGAPIError(`${source}: ${message}`, status, detail)
  }

  if (error instanceof Error) {
    throw new SGAPIError(`${source}: ${error.message}`, 0)
  }

  throw new SGAPIError(`${source}: Unknown error`, 0)
}

export function newSGCompanyCreate(): SGCompanyCreate {
  return {
    company_name: '', // max_length=100
    tax: null, // max_length=20
    tels: null, // max_length=30
    emails: null, // max_length=20
    website: null, // max_length=50
    addr: null, // max_length=200
    province_id: 0,
    country_id: 0,
    comp_locale: '', // max_length=20
    comp_timezone: '', // max_length=20
    comp_currency: '' // max_length=20
  }
}

// ======================================================
// LIST
// GET /companys/  -> get_companys
// ======================================================
export async function getCompanys(): Promise<SGCompanyRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGCompanyRead[]>>(`${API_URL}/`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_company_srv/getCompanys')
  }
}

// ======================================================
// LIST (PAGED)
// POST /companys/page  -> get_company_page (payload: SGCompanyPagred)
// Response bọc trong APIResponsePage: { items, status, message, page, page_size, total, total_pages }
// ======================================================
export async function getCompanyPaged(filter: SGCompanyPagedParams): Promise<SGCompanyPageRes> {
  try {
    const res = await apiClient.post<SGCompanyPageRes>(`${API_URL}/page`, filter)

    const data = res.data

    if (data.status !== 200) {
      throw new SGAPIError(data.message || 'Business validation error', data.status)
    }

    return data
  } catch (error) {
    handleAxiosError(error, 'sg_company_srv/getCompanyPaged')
  }
}

// ======================================================
// DETAIL
// GET /companys/by-id/{company_id}  -> get_company
// ======================================================
export async function getCompany(companyId: number): Promise<SGCompanyRead> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGCompanyRead>>(`${API_URL}/by-id/${companyId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_company_srv/getCompany')
  }
}

// ======================================================
// CREATE
// POST /companys/  -> create_company (payload: SGCompanyCreate)
// ======================================================
export async function createCompany(payload: SGCompanyCreate): Promise<SGCompanyRead> {
  try {
    const res = await apiClient.post<SGAPIResponse<SGCompanyRead>>(`${API_URL}/`, payload)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_company_srv/createCompany')
  }
}

// ======================================================
// UPDATE
// PUT /companys/by-id/{company_id}  -> update_company (payload: SGCompanyUpdate)
// ======================================================
export async function updateCompany(
  companyId: number,
  payload: SGCompanyUpdate
): Promise<SGCompanyRead> {
  try {
    const res = await apiClient.put<SGAPIResponse<SGCompanyRead>>(
      `${API_URL}/by-id/${companyId}`,
      payload
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_company_srv/updateCompany')
  }
}

// ======================================================
// DELETE
// DELETE /companys/by-id/{company_id}  -> delete_company (items = null)
// ======================================================
export async function deleteCompany(companyId: number): Promise<null> {
  try {
    const res = await apiClient.delete<SGAPIResponse<null>>(`${API_URL}/by-id/${companyId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_company_srv/deleteCompany')
  }
}
