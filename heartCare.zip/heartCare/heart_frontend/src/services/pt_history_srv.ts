// src/services/pt_history_srv.ts
//
// Service ánh xạ 1-1 với app/api/history_api.py (router prefix "/histories").
// Mọi response bọc trong APIResponse -> SGAPIResponse<T>, field dữ liệu là `items`.
// Tất cả API đều yêu cầu header Authorization: Bearer <access_token>.

import axios, { AxiosError } from 'axios'
import apiClient from '@/utils/api'
import { SGAPIError, type SGAPIResponse } from '@/types/sg_site_type'
import type {
  HistoryPagedParams,
  HistoryPagedRes,
  PTHistoryCreate,
  PTHistoryListParams,
  PTHistoryRead,
  PTHistoryUpdate
} from '@/types/pt_history'

// ======================================================
// API CONSTANTS
// ======================================================
// Backend router: APIRouter(prefix="/histories"). Đổi tiền tố cho khớp gateway nếu cần.
const API_URL = '/api/histories'

// ======================================================
// RESPONSE HELPERS
// ======================================================
function validateBusinessResponse<T>(response: SGAPIResponse<T>): SGAPIResponse<T> {
  if (response.status !== 200) {
    // Gắn chi tiết lỗi từng field (vd: "risk_level: Giá trị không hợp lệ") vào message
    const fieldErrors = response.errors ?? response.err_items
    const detail = fieldErrors?.length
      ? ` (${fieldErrors.map((e) => `${e.field}: ${e.message}`).join('; ')})`
      : ''

    throw new SGAPIError(
      (response.message || 'Business validation error') + detail,
      response.status,
      fieldErrors
    )
  }

  return response
}

function handleAxiosError(error: unknown, source: string): never {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<SGAPIResponse & { detail?: unknown }>

    const data = axiosError.response?.data
    const detail = data?.detail

    // FastAPI/Pydantic validation error (vd: HTTP 422): detail = [{ loc, msg, type }, ...]
    const message = Array.isArray(detail)
      ? detail
          .map((item: { loc?: unknown[]; msg?: string }) => {
            const field = Array.isArray(item?.loc) ? item.loc.join('.') : item?.loc
            return field ? `${field}: ${item?.msg}` : item?.msg
          })
          .join('; ')
      : data?.message ||
        (typeof detail === 'string' ? detail : null) ||
        axiosError.message ||
        'Unknown axios error'

    const status = data?.status || axiosError.response?.status || 0

    throw new SGAPIError(`${source}: ${message}`, status, detail)
  }

  if (error instanceof Error) {
    throw new SGAPIError(`${source}: ${error.message}`, 0)
  }

  throw new SGAPIError(`${source}: Unknown error`, 0)
}

export function newPTHistoryCreate(): PTHistoryCreate {
  return {
    users_id: 0,
    metric_id: 0,
    model_version: '', // max_length=50, vd: 'XGBoost_v1.0'
    risk_score: 0, // 0..100, 2 chữ số thập phân
    risk_level: 1 // 1: 'Low', 2: 'Medium', 3: 'High'
  }
}

// ======================================================
// LIST (admin)
// GET /histories/?skip=&limit=  -> list_histories
// ======================================================
export async function getHistories(params?: PTHistoryListParams): Promise<PTHistoryRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<PTHistoryRead[]>>(`${API_URL}/`, { params })

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_history_srv/getHistories')
  }
}

// ======================================================
// LIST (PAGED - admin)
// POST /histories/page  -> page_histories (payload: HistoryPagedParams, body rỗng -> page=1, page_size=20)
// Backend bọc kết quả trong APIResponse: items = HistoryPageRes { items, page, page_size, total, total_pages }
// ======================================================
export async function getHistoryPaged(filter?: HistoryPagedParams): Promise<HistoryPagedRes> {
  try {
    const res = await apiClient.post<SGAPIResponse<HistoryPagedRes>>(
      `${API_URL}/page`,
      filter ?? null
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_history_srv/getHistoryPaged')
  }
}

// ======================================================
// LIST BY USER (chính chủ hoặc admin)
// GET /histories/by_user/{users_id}?skip=&limit=  -> list_histories_by_user
// ======================================================
export async function getHistoriesByUser(
  usersId: number,
  params?: PTHistoryListParams
): Promise<PTHistoryRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<PTHistoryRead[]>>(
      `${API_URL}/by_user/${usersId}`,
      { params }
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_history_srv/getHistoriesByUser')
  }
}

// ======================================================
// DETAIL (chính chủ hoặc admin)
// GET /histories/{history_id}  -> read_history
// ======================================================
export async function getHistory(historyId: number): Promise<PTHistoryRead> {
  try {
    const res = await apiClient.get<SGAPIResponse<PTHistoryRead>>(`${API_URL}/${historyId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_history_srv/getHistory')
  }
}

// ======================================================
// CREATE (patient chỉ được tạo cho chính mình, admin tạo cho bất kỳ ai)
// POST /histories/  -> create_history_api (payload: PTHistoryCreate)
// ======================================================
export async function createHistory(payload: PTHistoryCreate): Promise<PTHistoryRead> {
  try {
    const res = await apiClient.post<SGAPIResponse<PTHistoryRead>>(`${API_URL}/`, payload)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_history_srv/createHistory')
  }
}

// ======================================================
// UPDATE (admin)
// PUT /histories/by_id/{history_id}  -> update_history_api (payload: PTHistoryUpdate)
// ======================================================
export async function updateHistory(
  historyId: number,
  payload: PTHistoryUpdate
): Promise<PTHistoryRead> {
  try {
    const res = await apiClient.put<SGAPIResponse<PTHistoryRead>>(
      `${API_URL}/by_id/${historyId}`,
      payload
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_history_srv/updateHistory')
  }
}

// ======================================================
// DELETE (admin)
// DELETE /histories/by_id/{history_id}  -> delete_history_api (items = history đã xóa)
// ======================================================
export async function deleteHistory(historyId: number): Promise<PTHistoryRead> {
  try {
    const res = await apiClient.delete<SGAPIResponse<PTHistoryRead>>(
      `${API_URL}/by_id/${historyId}`
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_history_srv/deleteHistory')
  }
}
