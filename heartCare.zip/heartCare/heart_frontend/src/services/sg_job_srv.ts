// src/services/sg_job_srv.ts
//
// Service ánh xạ 1-1 với app/api/sg_job_api.py (router prefix "/jobs").
// Mọi response bọc trong APIResponse -> SGAPIResponse<T>, field dữ liệu là `items`.

import axios, { AxiosError } from 'axios'
import apiClient from '@/utils/api'
import { SGAPIError, type SGAPIResponse } from '@/types/sg_site_type'
import type { SGJobCreate, SGJobRead, SGJobResultsRead, SGJobUpdate } from '@/types/sg_job'

// ======================================================
// API CONSTANTS
// ======================================================
// Backend router: APIRouter(prefix="/jobs"). Đổi tiền tố cho khớp gateway nếu cần.
const API_URL = '/api/v1/jobs'

// ======================================================
// RESPONSE HELPERS
// ======================================================
function validateBusinessResponse<T>(response: SGAPIResponse<T>): SGAPIResponse<T> {
  if (response.status !== 200) {
    throw new SGAPIError(response.message || 'Business validation error', response.status)
  }

  return response
}

function handleAxiosError(error: unknown, source: string): never {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<SGAPIResponse & { detail?: unknown }>

    const data = axiosError.response?.data
    const detail = data?.detail

    // FastAPI/Pydantic validation error (vd: HTTP 422): detail = [{ loc, msg, type }, ...]
    const message = Array.isArray(detail)
      ? detail
          .map((item: { loc?: unknown[]; msg?: string }) => {
            const field = Array.isArray(item?.loc) ? item.loc.join('.') : item?.loc
            return field ? `${field}: ${item?.msg}` : item?.msg
          })
          .join('; ')
      : data?.message || axiosError.message || 'Unknown axios error'

    const status = data?.status || axiosError.response?.status || 0

    throw new SGAPIError(`${source}: ${message}`, status, detail)
  }

  if (error instanceof Error) {
    throw new SGAPIError(`${source}: ${error.message}`, 0)
  }

  throw new SGAPIError(`${source}: Unknown error`, 0)
}

// ======================================================
// FACTORY
// ======================================================
export function newSGJobCreate(): SGJobCreate {
  return {
    job_code: null, // max_length=30, để null thì Service backend tự sinh
    job_version: null, // max_length=10
    job_status: 0,
    job_stage: 0,
    job_pct: 0, // 0 - 100
    geometry_id: 0
  }
}

// ======================================================
// LIST
// GET /jobs/  -> get_jobs
// ======================================================
export async function getJobs(): Promise<SGJobRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGJobRead[]>>(`${API_URL}/`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_job_srv/getJobs')
  }
}

// ======================================================
// LIST BY GEOMETRY
// GET /jobs/by-geometry/{geometry_id}  -> get_jobs_by_geometry
// ======================================================
export async function getJobsByGeometry(geometryId: number): Promise<SGJobRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGJobRead[]>>(
      `${API_URL}/by-geometry/${geometryId}`
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_job_srv/getJobsByGeometry')
  }
}

// ======================================================
// DETAIL
// GET /jobs/by-id/{job_id}  -> get_job
// ======================================================
export async function getJob(jobId: number): Promise<SGJobRead> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGJobRead>>(`${API_URL}/by-id/${jobId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_job_srv/getJob')
  }
}

// ======================================================
// RESULTS
// GET /jobs/{job_id}/results  -> get_job_results
// Trả manifest.json kèm presigned URL (TTL = expires_in giây) cho từng file kết quả.
// Job chưa SUCCESS -> backend trả status 409. Các file presigned phải được tải thẳng
// bằng fetch, KHÔNG qua apiClient (header Authorization làm S3 từ chối chữ ký).
// ======================================================
export async function getJobResults(jobId: number): Promise<SGJobResultsRead> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGJobResultsRead>>(`${API_URL}/${jobId}/results`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_job_srv/getJobResults')
  }
}

// ======================================================
// CREATE
// POST /jobs/  -> create_job (payload: SGJobCreate)
// user_id do backend gán = email của user hiện tại.
// ======================================================
export async function createJob(payload: SGJobCreate): Promise<SGJobRead> {
  try {
    const res = await apiClient.post<SGAPIResponse<SGJobRead>>(`${API_URL}/`, payload)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_job_srv/createJob')
  }
}

// ======================================================
// UPDATE
// PUT /jobs/by-id/{job_id}  -> update_job (payload: SGJobUpdate)
// ======================================================
export async function updateJob(jobId: number, payload: SGJobUpdate): Promise<SGJobRead> {
  try {
    const res = await apiClient.put<SGAPIResponse<SGJobRead>>(`${API_URL}/by-id/${jobId}`, payload)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_job_srv/updateJob')
  }
}

// ======================================================
// DELETE
// DELETE /jobs/by-id/{job_id}  -> delete_job (items = null)
// ======================================================
export async function deleteJob(jobId: number): Promise<null> {
  try {
    const res = await apiClient.delete<SGAPIResponse<null>>(`${API_URL}/by-id/${jobId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_job_srv/deleteJob')
  }
}
