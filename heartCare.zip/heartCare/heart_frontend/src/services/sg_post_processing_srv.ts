// src/services/sg_post_processing_srv.ts

import axios, { AxiosError, type AxiosResponse } from 'axios'
import apiClient from '@/utils/api'
import { SGAPIError, type SGAPIResponse } from '@/types/sg_site_type'

// ======================================================
// API CONSTANTS
// ======================================================
const API_URL = '/api/v1/engineer/post-processing'

// ======================================================
// RESPONSE HELPERS
// ======================================================
// Cac API trong nhom nay khi thanh cong tra ve file nhi phan (PNG/STL) truc
// tiep (FileResponse), khong boc trong SGAPIResponse - chi khi loi (400/404/500)
// backend moi tra ve JSON APIResponse. Vi vay can doc rieng thong diep loi tu Blob.
async function extractErrorFromBlob(
  blob: Blob
): Promise<{ message: string; status?: number; err_items?: unknown }> {
  try {
    const text = await blob.text()
    const data = JSON.parse(text) as SGAPIResponse & { detail?: unknown }

    const detail = data?.detail

    // FastAPI/Pydantic validation error (vd: HTTP 422): detail = [{ loc, msg, type }, ...]
    const message = Array.isArray(detail)
      ? detail
          .map((item: { loc?: unknown[]; msg?: string }) => {
            const field = Array.isArray(item?.loc) ? item.loc.join('.') : item?.loc
            return field ? `${field}: ${item?.msg}` : item?.msg
          })
          .join('; ')
      : data?.message

    return { message: message || 'Unknown error', status: data?.status, err_items: detail }
  } catch {
    return { message: 'Unknown error' }
  }
}

// Backend nhom API nay tra ve loi nghiep vu (vd: chua co ket qua, task_id
// khong ton tai) bang HTTP 200 kem JSON envelope { status, message, items }
// thay vi HTTP 4xx/5xx hoac file nhi phan - axios vi vay khong throw, va
// Blob nhan duoc thuc chat la text JSON chu khong phai anh. Phai kiem tra
// Content-Type cua response truoc khi coi no la file nhi phan hop le.
async function ensureBinaryResponse(res: AxiosResponse<Blob>, source: string): Promise<Blob> {
  const contentType = res.headers?.['content-type'] ?? ''

  if (typeof contentType === 'string' && contentType.includes('application/json')) {
    const { message, status } = await extractErrorFromBlob(res.data)
    throw new SGAPIError(`${source}: ${message}`, status || 0)
  }

  return res.data
}

async function handleBlobAxiosError(error: unknown, source: string): Promise<never> {
  if (error instanceof SGAPIError) {
    throw error
  }

  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError
    const data = axiosError.response?.data

    if (data instanceof Blob) {
      const { message, status } = await extractErrorFromBlob(data)
      throw new SGAPIError(`${source}: ${message}`, status || axiosError.response?.status || 0)
    }

    throw new SGAPIError(
      `${source}: ${axiosError.message || 'Unknown axios error'}`,
      axiosError.response?.status || 0
    )
  }

  if (error instanceof Error) {
    throw new SGAPIError(`${source}: ${error.message}`, 0)
  }

  throw new SGAPIError(`${source}: Unknown error`, 0)
}

// ======================================================
// 1. LAY ANH CAT 2D DAI MAU NHIET DO (Giai doan MVP)
// (GET /post-processing/slice-image/2d-mesh/{task_id})
// ======================================================

// URL truc tiep de gan vao <img src> (backend tu sinh anh neu chua co)
export function getSliceImage2DUrl(taskId: string): string {
  return `${import.meta.env.VITE_API_URL}${API_URL}/slice-image/2d-mesh/${taskId}`
}

export async function getSliceImage2D(taskId: string): Promise<Blob> {
  try {
    const res = await apiClient.get<Blob>(`${API_URL}/slice-image/2d-mesh/${taskId}`, {
      responseType: 'blob'
    })

    return await ensureBinaryResponse(res, 'sg_post_processing_srv/getSliceImage2D')
  } catch (error) {
    return await handleBlobAxiosError(error, 'sg_post_processing_srv/getSliceImage2D')
  }
}

// ======================================================
// 2. LAY DU LIEU MO HINH 3D (Cho nang cap VTK.js sau nay)
// (GET /post-processing/slice-image/3d-mesh/{task_id})
// ======================================================

// URL truc tiep de gan vao <a href>/download hoac loader 3D
export function get3DMeshUrl(taskId: string): string {
  return `${import.meta.env.VITE_API_URL}${API_URL}/slice-image/3d-mesh/${taskId}`
}

export async function get3DMesh(taskId: string): Promise<Blob> {
  try {
    const res = await apiClient.get<Blob>(`${API_URL}/slice-image/3d-mesh/${taskId}`, {
      responseType: 'blob'
    })

    return await ensureBinaryResponse(res, 'sg_post_processing_srv/get3DMesh')
  } catch (error) {
    return await handleBlobAxiosError(error, 'sg_post_processing_srv/get3DMesh')
  }
}
