// src/services/sg_setup_room_srv.ts

import axios, { AxiosError } from 'axios'
import apiClient from '@/utils/api'
import { SGAPIError, type SGAPIResponse } from '@/types/sg_site_type'
import type { SGSetupRoomBase } from '@/types/sg_setup_room'

// ======================================================
// API CONSTANTS
// ======================================================
const API_URL = '/api/v1/engineer'

// ======================================================
// RESPONSE HELPERS
// ======================================================
function validateBusinessResponse<T>(response: SGAPIResponse<T>): SGAPIResponse<T> {
  if (response.status !== 200) {
    throw new SGAPIError(response.message || 'Business validation error', response.status)
  }

  return response
}

function handleAxiosError(error: unknown, source: string): never {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<SGAPIResponse & { detail?: unknown }>

    const data = axiosError.response?.data
    const detail = data?.detail

    // FastAPI/Pydantic validation error (vd: HTTP 422): detail = [{ loc, msg, type }, ...]
    const message = Array.isArray(detail)
      ? detail
          .map((item: { loc?: unknown[]; msg?: string }) => {
            const field = Array.isArray(item?.loc) ? item.loc.join('.') : item?.loc
            return field ? `${field}: ${item?.msg}` : item?.msg
          })
          .join('; ')
      : data?.message || axiosError.message || 'Unknown axios error'

    const status = data?.status || axiosError.response?.status || 0

    throw new SGAPIError(`${source}: ${message}`, status, detail)
  }

  if (error instanceof Error) {
    throw new SGAPIError(`${source}: ${error.message}`, 0)
  }

  throw new SGAPIError(`${source}: Unknown error`, 0)
}

export function newSGSetupRoomBaseCreate(): SGSetupRoomBase {
  return {
    // Kích thước khối hộp (mét)
    length: 0, // Chiều dài khối hộp (m)")
    width: 0, // Chiều rộng khối hộp (m)
    height: 0, // Chiều cao khối hộp (m)

    // Điều kiện biên
    temp_inlet: 0, // Nhiệt độ khí đầu vào (K) - Ví dụ: 298.15 cho 25°C
    velocity_inlet: 0 // Vận tốc gió đầu vào (m/s)
  }
}

// ======================================================
// CREATE
// ======================================================
export async function createRoom(payload: SGSetupRoomBase): Promise<SGSetupRoomBase> {
  try {
    const res = await apiClient.post<SGAPIResponse<SGSetupRoomBase>>(
      `${API_URL}/generate_case`,
      payload
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_setup_room_srv/createsetup_room')
  }
}
