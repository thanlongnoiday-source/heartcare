// src/services/sg_wall_srv.ts
//
// Service ánh xạ 1-1 với app/api/sg_wall_api.py (router prefix "/walls").
// Mọi response bọc trong APIResponse -> SGAPIResponse<T>, field dữ liệu là `items`.

import axios, { AxiosError } from 'axios'
import apiClient from '@/utils/api'
import { SGAPIError, type SGAPIResponse } from '@/types/sg_site_type'
import type { SGWallCreate, SGWallRead, SGWallUpdate } from '@/types/sg_wall'
import {
  DEFAULT_WALL_AMBIENT_TEMP,
  DEFAULT_WALL_EMISSIVITY,
  DEFAULT_WALL_FIXED_POWER,
  DEFAULT_WALL_FIXED_POWER_UNIT,
  DEFAULT_WALL_FIXED_TEMP,
  DEFAULT_WALL_HEAT_POWER_0,
  DEFAULT_WALL_HEAT_TRANSFER_COEFFICIENT,
  DEFAULT_WALL_ROUGHNESS,
  DEFAULT_WALL_TRANSMISSIVITY,
  SLIP_MODE,
  THERMAL_MODE,
  TRANSMISSIVITY_MODE
} from '@/constants/sg_engr_wall_const'

// ======================================================
// API CONSTANTS
// ======================================================
// Backend router: APIRouter(prefix="/walls"). Đổi tiền tố cho khớp gateway nếu cần.
const API_URL = '/api/v1/walls'

// ======================================================
// RESPONSE HELPERS
// ======================================================
function validateBusinessResponse<T>(response: SGAPIResponse<T>): SGAPIResponse<T> {
  if (response.status !== 200) {
    throw new SGAPIError(response.message || 'Business validation error', response.status)
  }

  return response
}

// Backend serialize Decimal(8, 2) thành CHUỖI JSON ("5.00"). Ép về number ngay khi
// nhận response để phần còn lại của app luôn nhận đúng kiểu `number` như type đã khai báo.
function normalizeWall(wall: SGWallRead): SGWallRead {
  return {
    ...wall,
    roughness: Number(wall.roughness) || 0,
    heat_power_0: Number(wall.heat_power_0) || 0,
    fixed_temp: Number(wall.fixed_temp) || 0,
    heat_power: Number(wall.heat_power) || 0,
    heat_transfer_coefficient: Number(wall.heat_transfer_coefficient) || 0,
    ambient_temp: Number(wall.ambient_temp) || 0,
    emissivity: Number(wall.emissivity) || 0,
    transmissivity: Number(wall.transmissivity) || 0
  }
}

function handleAxiosError(error: unknown, source: string): never {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<SGAPIResponse & { detail?: unknown }>

    const data = axiosError.response?.data
    const detail = data?.detail

    // FastAPI/Pydantic validation error (vd: HTTP 422): detail = [{ loc, msg, type }, ...]
    const message = Array.isArray(detail)
      ? detail
          .map((item: { loc?: unknown[]; msg?: string }) => {
            const field = Array.isArray(item?.loc) ? item.loc.join('.') : item?.loc
            return field ? `${field}: ${item?.msg}` : item?.msg
          })
          .join('; ')
      : data?.message || axiosError.message || 'Unknown axios error'

    const status = data?.status || axiosError.response?.status || 0

    throw new SGAPIError(`${source}: ${message}`, status, detail)
  }

  if (error instanceof Error) {
    throw new SGAPIError(`${source}: ${error.message}`, 0)
  }

  throw new SGAPIError(`${source}: Unknown error`, 0)
}

// ======================================================
// FACTORY
// ======================================================
export function newSGWallCreate(): SGWallCreate {
  return {
    wall_code: null, // max_length=30 — null để backend tự sinh mã
    wall_name: null, // max_length=100
    slip_mode: SLIP_MODE.No_SLIP,
    roughness: DEFAULT_WALL_ROUGHNESS, // Decimal(8, 2)
    thermal_mode: THERMAL_MODE.ADIABATIC,
    heat_power_0: DEFAULT_WALL_HEAT_POWER_0, // Decimal(8, 2), luôn = 0
    fixed_temp: DEFAULT_WALL_FIXED_TEMP, // Decimal(8, 2)
    heat_power: DEFAULT_WALL_FIXED_POWER, // Decimal(8, 2)
    unit_id: DEFAULT_WALL_FIXED_POWER_UNIT, // FK -> SGUnitRead.unit_id (sg_unit.ts) — 6: W; 8: W/m²
    heat_transfer_coefficient: DEFAULT_WALL_HEAT_TRANSFER_COEFFICIENT, // Decimal(8, 2)
    ambient_temp: DEFAULT_WALL_AMBIENT_TEMP, // Decimal(8, 2)
    emissivity: DEFAULT_WALL_EMISSIVITY, // Decimal(8, 2)
    transmissivity_mode: TRANSMISSIVITY_MODE.NO_TRANSMISSIVITY,
    transmissivity: DEFAULT_WALL_TRANSMISSIVITY, // Decimal(8, 2)
    geometry_id: 0
  }
}

export function newSGWallRead(): SGWallRead {
  return {
    ...newSGWallCreate(),
    wall_id: 0,
    wall_code: '' // max_length=30
  }
}

// ======================================================
// LIST
// GET /walls/  -> get_walls
// ======================================================
export async function getWalls(): Promise<SGWallRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGWallRead[]>>(`${API_URL}/`)

    const data = validateBusinessResponse(res.data)

    return data.items.map(normalizeWall)
  } catch (error) {
    handleAxiosError(error, 'sg_wall_srv/getWalls')
  }
}

// ======================================================
// LIST BY GEOMETRY
// GET /walls/by-geometry/{geometry_id}  -> get_walls_by_geometry
// ======================================================
export async function getWallsByGeometry(geometryId: number): Promise<SGWallRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGWallRead[]>>(
      `${API_URL}/by-geometry/${geometryId}`
    )

    const data = validateBusinessResponse(res.data)

    return data.items.map(normalizeWall)
  } catch (error) {
    handleAxiosError(error, 'sg_wall_srv/getWallsByGeometry')
  }
}

// ======================================================
// DETAIL
// GET /walls/by-id/{wall_id}  -> get_wall
// ======================================================
export async function getWall(wallId: number): Promise<SGWallRead> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGWallRead>>(`${API_URL}/by-id/${wallId}`)

    const data = validateBusinessResponse(res.data)

    return normalizeWall(data.items)
  } catch (error) {
    handleAxiosError(error, 'sg_wall_srv/getWall')
  }
}

// ======================================================
// CREATE
// POST /walls/  -> create_wall (payload: SGWallCreate)
// ======================================================
export async function createWall(payload: SGWallCreate): Promise<SGWallRead> {
  try {
    const res = await apiClient.post<SGAPIResponse<SGWallRead>>(`${API_URL}/`, payload)

    const data = validateBusinessResponse(res.data)

    return normalizeWall(data.items)
  } catch (error) {
    handleAxiosError(error, 'sg_wall_srv/createWall')
  }
}

// ======================================================
// UPDATE
// PUT /walls/by-id/{wall_id}  -> update_wall (payload: SGWallUpdate)
// ======================================================
export async function updateWall(wallId: number, payload: SGWallUpdate): Promise<SGWallRead> {
  try {
    const res = await apiClient.put<SGAPIResponse<SGWallRead>>(
      `${API_URL}/by-id/${wallId}`,
      payload
    )

    const data = validateBusinessResponse(res.data)

    return normalizeWall(data.items)
  } catch (error) {
    handleAxiosError(error, 'sg_wall_srv/updateWall')
  }
}

// ======================================================
// DELETE
// DELETE /walls/by-id/{wall_id}  -> delete_wall (items = null)
// ======================================================
export async function deleteWall(wallId: number): Promise<null> {
  try {
    const res = await apiClient.delete<SGAPIResponse<null>>(`${API_URL}/by-id/${wallId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_wall_srv/deleteWall')
  }
}
