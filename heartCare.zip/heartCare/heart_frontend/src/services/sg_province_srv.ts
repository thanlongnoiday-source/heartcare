// src/services/sg_province_srv.ts
//
// Service ánh xạ 1-1 với app/api/sg_province_api.py (router prefix "/provinces").
// Mọi response bọc trong APIResponse -> SGAPIResponse<T>, field dữ liệu là `items`.

import axios, { AxiosError } from 'axios'
import apiClient from '@/utils/api'
import { SGAPIError, type SGAPIResponse } from '@/types/sg_site_type'
import type {
  SGProvinceCreate,
  SGProvincePagedParams,
  SGProvincePageRes,
  SGProvinceRead,
  SGProvinceUpdate
} from '@/types/sg_province'

// ======================================================
// API CONSTANTS
// ======================================================
// Backend router: APIRouter(prefix="/provinces"). Đổi tiền tố cho khớp gateway nếu cần.
const API_URL = '/api/v1/provinces'

// ======================================================
// RESPONSE HELPERS
// ======================================================
function validateBusinessResponse<T>(response: SGAPIResponse<T>): SGAPIResponse<T> {
  if (response.status !== 200) {
    throw new SGAPIError(response.message || 'Business validation error', response.status)
  }

  return response
}

function handleAxiosError(error: unknown, source: string): never {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<SGAPIResponse & { detail?: unknown }>

    const data = axiosError.response?.data
    const detail = data?.detail

    // FastAPI/Pydantic validation error (vd: HTTP 422): detail = [{ loc, msg, type }, ...]
    const message = Array.isArray(detail)
      ? detail
          .map((item: { loc?: unknown[]; msg?: string }) => {
            const field = Array.isArray(item?.loc) ? item.loc.join('.') : item?.loc
            return field ? `${field}: ${item?.msg}` : item?.msg
          })
          .join('; ')
      : data?.message || axiosError.message || 'Unknown axios error'

    const status = data?.status || axiosError.response?.status || 0

    throw new SGAPIError(`${source}: ${message}`, status, detail)
  }

  if (error instanceof Error) {
    throw new SGAPIError(`${source}: ${error.message}`, 0)
  }

  throw new SGAPIError(`${source}: Unknown error`, 0)
}

export function newSGProvinceCreate(): SGProvinceCreate {
  return {
    province_name: '' // max_length=100
  }
}

// ======================================================
// LIST
// GET /provinces/  -> get_provinces
// ======================================================
export async function getProvinces(): Promise<SGProvinceRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGProvinceRead[]>>(`${API_URL}/`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_province_srv/getProvinces')
  }
}

// ======================================================
// LIST (PAGED)
// POST /provinces/page  -> get_province_page (payload: SGProvincePagred)
// Response bọc trong APIResponsePage: { items, status, message, page, page_size, total, total_pages }
// ======================================================
export async function getProvincePaged(filter: SGProvincePagedParams): Promise<SGProvincePageRes> {
  try {
    const res = await apiClient.post<SGProvincePageRes>(`${API_URL}/page`, filter)

    const data = res.data

    if (data.status !== 200) {
      throw new SGAPIError(data.message || 'Business validation error', data.status)
    }

    return data
  } catch (error) {
    handleAxiosError(error, 'sg_province_srv/getProvincePaged')
  }
}

// ======================================================
// DETAIL
// GET /provinces/by-id/{province_id}  -> get_province
// ======================================================
export async function getProvince(provinceId: number): Promise<SGProvinceRead> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGProvinceRead>>(
      `${API_URL}/by-id/${provinceId}`
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_province_srv/getProvince')
  }
}

// ======================================================
// CREATE
// POST /provinces/  -> create_province (payload: SGProvinceCreate)
// ======================================================
export async function createProvince(payload: SGProvinceCreate): Promise<SGProvinceRead> {
  try {
    const res = await apiClient.post<SGAPIResponse<SGProvinceRead>>(`${API_URL}/`, payload)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_province_srv/createProvince')
  }
}

// ======================================================
// UPDATE
// PUT /provinces/by-id/{province_id}  -> update_province (payload: SGProvinceUpdate)
// ======================================================
export async function updateProvince(
  provinceId: number,
  payload: SGProvinceUpdate
): Promise<SGProvinceRead> {
  try {
    const res = await apiClient.put<SGAPIResponse<SGProvinceRead>>(
      `${API_URL}/by-id/${provinceId}`,
      payload
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_province_srv/updateProvince')
  }
}

// ======================================================
// DELETE
// DELETE /provinces/by-id/{province_id}  -> delete_province (items = null)
// ======================================================
export async function deleteProvince(provinceId: number): Promise<null> {
  try {
    const res = await apiClient.delete<SGAPIResponse<null>>(`${API_URL}/by-id/${provinceId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_province_srv/deleteProvince')
  }
}
