// src/services/pt_metric_srv.ts
//
// Service ánh xạ 1-1 với app/api/metric_api.py (router prefix "/metrics").
// Mọi response bọc trong APIResponse -> SGAPIResponse<T>, field dữ liệu là `items`.
// Tất cả API đều yêu cầu header Authorization: Bearer <access_token>.

import axios, { AxiosError } from 'axios'
import apiClient from '@/utils/api'
import { SGAPIError, type SGAPIResponse } from '@/types/sg_site_type'
import type {
  MetricPagedParams,
  MetricPagedRes,
  PTMetricCreate,
  PTMetricListParams,
  PTMetricRead,
  PTMetricUpdate
} from '@/types/pt_metric'

// ======================================================
// API CONSTANTS
// ======================================================
// Backend router: APIRouter(prefix="/metrics"). Đổi tiền tố cho khớp gateway nếu cần.
const API_URL = '/api/metrics'

// ======================================================
// RESPONSE HELPERS
// ======================================================
function validateBusinessResponse<T>(response: SGAPIResponse<T>): SGAPIResponse<T> {
  if (response.status !== 200) {
    // Gắn chi tiết lỗi từng field (vd: "cholesterol: Giá trị không hợp lệ") vào message
    const fieldErrors = response.errors ?? response.err_items
    const detail = fieldErrors?.length
      ? ` (${fieldErrors.map((e) => `${e.field}: ${e.message}`).join('; ')})`
      : ''

    throw new SGAPIError(
      (response.message || 'Business validation error') + detail,
      response.status,
      fieldErrors
    )
  }

  return response
}

function handleAxiosError(error: unknown, source: string): never {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<SGAPIResponse & { detail?: unknown }>

    const data = axiosError.response?.data
    const detail = data?.detail

    // detail dạng mảng: Pydantic [{ loc, msg, type }, ...] hoặc HTTPException(detail=[str, ...])
    // (vd: 422 từ predict_srv khi giá trị nằm ngoài khoảng của mô hình dự đoán)
    const message = Array.isArray(detail)
      ? detail
          .map((item: string | { loc?: unknown[]; msg?: string }) => {
            if (typeof item === 'string') return item
            const field = Array.isArray(item?.loc) ? item.loc.join('.') : item?.loc
            return field ? `${field}: ${item?.msg}` : item?.msg
          })
          .join('; ')
      : data?.message ||
        (typeof detail === 'string' ? detail : null) ||
        axiosError.message ||
        'Unknown axios error'

    const status = data?.status || axiosError.response?.status || 0

    throw new SGAPIError(`${source}: ${message}`, status, detail)
  }

  if (error instanceof Error) {
    throw new SGAPIError(`${source}: ${error.message}`, 0)
  }

  throw new SGAPIError(`${source}: Unknown error`, 0)
}

export function newPTMetricCreate(): PTMetricCreate {
  return {
    users_id: 0,
    age: 0, // 1..120
    sex: 1, // 1: Nam, 0: Nữ
    cp: 0, // 0..3
    resting_bp: 0, // 1..400
    cholesterol: 0, // 1..1000
    fasting_bs: 0, // 1: Đúng, 0: Sai
    restecg: 0, // 0..2
    max_hr: 0, // 1..400
    exercise_angina: 0, // 1: Có, 0: Không
    oldpeak: 0, // 0..20
    slope: 0, // 0..2
    ca: 0, // 0..4
    thal: 1 // 1..3
  }
}

// ======================================================
// LIST (admin)
// GET /metrics/?skip=&limit=  -> list_metrics
// ======================================================
export async function getMetrics(params?: PTMetricListParams): Promise<PTMetricRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<PTMetricRead[]>>(`${API_URL}/`, { params })

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_metric_srv/getMetrics')
  }
}

// ======================================================
// LIST (PAGED - admin)
// POST /metrics/page  -> page_metrics (payload: MetricPagedParams, body rỗng -> page=1, page_size=20)
// Backend bọc kết quả trong APIResponse: items = MetricPageRes { items, page, page_size, total, total_pages }
// ======================================================
export async function getMetricPaged(filter?: MetricPagedParams): Promise<MetricPagedRes> {
  try {
    const res = await apiClient.post<SGAPIResponse<MetricPagedRes>>(
      `${API_URL}/page`,
      filter ?? null
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_metric_srv/getMetricPaged')
  }
}

// ======================================================
// LIST BY USER (chính chủ hoặc admin)
// GET /metrics/by_user/{users_id}?skip=&limit=  -> list_metrics_by_user
// ======================================================
export async function getMetricsByUser(
  usersId: number,
  params?: PTMetricListParams
): Promise<PTMetricRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<PTMetricRead[]>>(
      `${API_URL}/by_user/${usersId}`,
      { params }
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_metric_srv/getMetricsByUser')
  }
}

// ======================================================
// DETAIL (chính chủ hoặc admin)
// GET /metrics/{metric_id}  -> read_metric
// ======================================================
export async function getMetric(metricId: number): Promise<PTMetricRead> {
  try {
    const res = await apiClient.get<SGAPIResponse<PTMetricRead>>(`${API_URL}/${metricId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_metric_srv/getMetric')
  }
}

// ======================================================
// CREATE (patient chỉ được tạo cho chính mình, admin tạo cho bất kỳ ai)
// POST /metrics/  -> create_metric_api (payload: PTMetricCreate)
// ======================================================
export async function createMetric(payload: PTMetricCreate): Promise<PTMetricRead> {
  try {
    const res = await apiClient.post<SGAPIResponse<PTMetricRead>>(`${API_URL}/`, payload)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_metric_srv/createMetric')
  }
}

// ======================================================
// UPDATE (chính chủ hoặc admin; chỉ admin được đổi users_id sang người khác)
// PUT /metrics/by_id/{metric_id}  -> update_metric_api (payload: PTMetricUpdate)
// ======================================================
export async function updateMetric(
  metricId: number,
  payload: PTMetricUpdate
): Promise<PTMetricRead> {
  try {
    const res = await apiClient.put<SGAPIResponse<PTMetricRead>>(
      `${API_URL}/by_id/${metricId}`,
      payload
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_metric_srv/updateMetric')
  }
}

// ======================================================
// DELETE (chính chủ hoặc admin)
// DELETE /metrics/by_id/{metric_id}  -> delete_metric_api (items = metric đã xóa)
// ======================================================
export async function deleteMetric(metricId: number): Promise<PTMetricRead> {
  try {
    const res = await apiClient.delete<SGAPIResponse<PTMetricRead>>(
      `${API_URL}/by_id/${metricId}`
    )

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'pt_metric_srv/deleteMetric')
  }
}
