// src/services/sg_inlet_srv.ts
//
// Service ánh xạ 1-1 với app/api/sg_inlet_api.py (router prefix "/inlets").
// Mọi response bọc trong APIResponse -> SGAPIResponse<T>, field dữ liệu là `items`.

import axios, { AxiosError } from 'axios'
import apiClient from '@/utils/api'
import { SGAPIError, type SGAPIResponse } from '@/types/sg_site_type'
import type { SGInletCreate, SGInletRead, SGInletUpdate } from '@/types/sg_inlet'
import {
  DEFAULT_INLET_FLOW_RATE_FIX,
  DEFAULT_INLET_FLOW_UNIT_ID,
  DEFAULT_INLET_SIZE_H,
  DEFAULT_INLET_SIZE_W,
  DEFAULT_INLET_TEMP_COOLING,
  HYDRAULIC_DIAMETER
} from '@/constants/sg_engr_inlet_const'

// ======================================================
// API CONSTANTS
// ======================================================
// Backend router: APIRouter(prefix="/inlets"). Đổi tiền tố cho khớp gateway nếu cần.
const API_URL = '/api/v1/inlets'

// ======================================================
// RESPONSE HELPERS
// ======================================================
function validateBusinessResponse<T>(response: SGAPIResponse<T>): SGAPIResponse<T> {
  if (response.status !== 200) {
    throw new SGAPIError(response.message || 'Business validation error', response.status)
  }

  return response
}

// Backend serialize Decimal (14,2 / 10,2 / 8,2) thành CHUỖI JSON ("5.00"). Ép về number ngay khi
// nhận response để phần còn lại của app luôn nhận đúng kiểu `number` như type đã khai báo
// — nếu để nguyên chuỗi, sg_input_number sẽ hiểu nhầm dấu '.' là dấu phân cách hàng nghìn
// (locale vi-VN) và hiển thị sai.
function normalizeInlet(inlet: SGInletRead): SGInletRead {
  return {
    ...inlet,
    flow_rate: Number(inlet.flow_rate) || 0,
    temperature: Number(inlet.temperature) || 0,
    pos_x: Number(inlet.pos_x) || 0,
    pos_y: Number(inlet.pos_y) || 0,
    pos_z: Number(inlet.pos_z) || 0,
    size_w: Number(inlet.size_w) || 0,
    size_h: Number(inlet.size_h) || 0,
    u_x: Number(inlet.u_x) || 0,
    u_y: Number(inlet.u_y) || 0,
    u_z: Number(inlet.u_z) || 0,
    turbulence: Number(inlet.turbulence) || 0,
    hyd_diameter: Number(inlet.hyd_diameter) || 0
  }
}

function handleAxiosError(error: unknown, source: string): never {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<SGAPIResponse & { detail?: unknown }>

    const data = axiosError.response?.data
    const detail = data?.detail

    // FastAPI/Pydantic validation error (vd: HTTP 422): detail = [{ loc, msg, type }, ...]
    const message = Array.isArray(detail)
      ? detail
          .map((item: { loc?: unknown[]; msg?: string }) => {
            const field = Array.isArray(item?.loc) ? item.loc.join('.') : item?.loc
            return field ? `${field}: ${item?.msg}` : item?.msg
          })
          .join('; ')
      : data?.message || axiosError.message || 'Unknown axios error'

    const status = data?.status || axiosError.response?.status || 0

    throw new SGAPIError(`${source}: ${message}`, status, detail)
  }

  if (error instanceof Error) {
    throw new SGAPIError(`${source}: ${error.message}`, 0)
  }

  throw new SGAPIError(`${source}: Unknown error`, 0)
}

// ======================================================
// FACTORY
// ======================================================
export function newSGInletCreate(): SGInletCreate {
  return {
    inlet_code: '', // max_length=30
    inlet_name: null, // max_length=100
    flow_rate: DEFAULT_INLET_FLOW_RATE_FIX,
    temperature: DEFAULT_INLET_TEMP_COOLING,
    pos_x: 0,
    pos_y: 0,
    pos_z: 0,
    size_w: DEFAULT_INLET_SIZE_W,
    size_h: DEFAULT_INLET_SIZE_H,
    geometry_id: 0,
    flow_unit_id: DEFAULT_INLET_FLOW_UNIT_ID,
    control_mode: 0,
    direction: 0,
    u_x: 0,
    u_y: 0,
    u_z: 0,
    turbulence: 0,
    hyd_diameter: 0,
    hyd_diameter_auto: HYDRAULIC_DIAMETER.AUTO
  }
}

// ======================================================
// LIST
// GET /inlets/  -> get_inlets
// ======================================================
export async function getInlets(): Promise<SGInletRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGInletRead[]>>(`${API_URL}/`)

    const data = validateBusinessResponse(res.data)

    return data.items.map(normalizeInlet)
  } catch (error) {
    handleAxiosError(error, 'sg_inlet_srv/getInlets')
  }
}

// ======================================================
// LIST BY GEOMETRY
// GET /inlets/by-geometry/{geometry_id}  -> get_inlets_by_geometry
// (đặt tên theo quy ước by-project của sg_geometry_srv; đổi cho khớp router backend nếu cần)
// ======================================================
export async function getInletsByGeometry(geometryId: number): Promise<SGInletRead[]> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGInletRead[]>>(
      `${API_URL}/by-geometry/${geometryId}`
    )

    const data = validateBusinessResponse(res.data)

    return data.items.map(normalizeInlet)
  } catch (error) {
    handleAxiosError(error, 'sg_inlet_srv/getInletsByGeometry')
  }
}

// ======================================================
// DETAIL
// GET /inlets/by-id/{inlet_id}  -> get_inlet
// ======================================================
export async function getInlet(inletId: number): Promise<SGInletRead> {
  try {
    const res = await apiClient.get<SGAPIResponse<SGInletRead>>(`${API_URL}/by-id/${inletId}`)

    const data = validateBusinessResponse(res.data)

    return normalizeInlet(data.items)
  } catch (error) {
    handleAxiosError(error, 'sg_inlet_srv/getInlet')
  }
}

// ======================================================
// CREATE
// POST /inlets/  -> create_inlet (payload: SGInletCreate)
// ======================================================
export async function createInlet(payload: SGInletCreate): Promise<SGInletRead> {
  try {
    const res = await apiClient.post<SGAPIResponse<SGInletRead>>(`${API_URL}/`, payload)

    const data = validateBusinessResponse(res.data)

    return normalizeInlet(data.items)
  } catch (error) {
    handleAxiosError(error, 'sg_inlet_srv/createInlet')
  }
}

// ======================================================
// UPDATE
// PUT /inlets/by-id/{inlet_id}  -> update_inlet (payload: SGInletUpdate)
// ======================================================
export async function updateInlet(inletId: number, payload: SGInletUpdate): Promise<SGInletRead> {
  try {
    const res = await apiClient.put<SGAPIResponse<SGInletRead>>(
      `${API_URL}/by-id/${inletId}`,
      payload
    )

    const data = validateBusinessResponse(res.data)

    return normalizeInlet(data.items)
  } catch (error) {
    handleAxiosError(error, 'sg_inlet_srv/updateInlet')
  }
}

// ======================================================
// DELETE
// DELETE /inlets/by-id/{inlet_id}  -> delete_inlet (items = null)
// ======================================================
export async function deleteInlet(inletId: number): Promise<null> {
  try {
    const res = await apiClient.delete<SGAPIResponse<null>>(`${API_URL}/by-id/${inletId}`)

    const data = validateBusinessResponse(res.data)

    return data.items
  } catch (error) {
    handleAxiosError(error, 'sg_inlet_srv/deleteInlet')
  }
}
