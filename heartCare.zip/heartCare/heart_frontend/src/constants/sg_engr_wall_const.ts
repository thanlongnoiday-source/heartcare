// src/constants/sg_engr_wall_const.ts

import type { SGSelectItem } from '@/types/sg_site_type'

export const SLIP_MODE = {
  No_SLIP: 1, // Không trượt
  SLIP: 2 // Trượt tự do
} as const

export const THERMAL_MODE = {
  ADIABATIC: 1, // Cách nhiệt hoàn toàn (Adiabatic / Zero Heat Flux)
  FIXED_TEMP: 2, // Nhiệt độ bề mặt cố định (Fixed Temperature)
  FIXED_POWER: 3, // Tỏa nhiệt hằng số (Fixed Heat Flux / Power)
  HEAT_TRANS: 4 // Truyền nhiệt đối lưu ngoài (Convective Heat Transfer)
} as const

export const TRANSMISSIVITY_MODE = {
  TRANSMISSIVITY: 1, // Xuyên sáng
  NO_TRANSMISSIVITY: 2 // Không xuyên sáng
} as const

export const HEAT_FLUX_UNIT = {
  WATT: 6, // Tổng công suất (W) — quy đổi sang W/m² theo diện tích mặt khi lưu
  WATT_PER_M2: 8 // Mật độ dòng nhiệt (W/m²)
} as const

export const DEFAULT_WALL_HEAT_POWER_0 = 0 // Cách nhiệt hoàn toàn (Adiabatic / Zero Heat Flux) q = 0 W/m²
export const DEFAULT_WALL_ROUGHNESS = 0 // mm, độ nhám bề mặt Ks
export const DEFAULT_WALL_TRANSMISSIVITY = 0.7 // Factor (0 - 1), Transmissivity / SHGC
export const DEFAULT_WALL_FIXED_TEMP = 26 // Dành cho FIXED_TEMP, 26(oC) = 299.15(K) - (T + 273.15)
export const DEFAULT_WALL_FIXED_POWER = 150 // W/m^2, q uniform 150
export const DEFAULT_WALL_FIXED_POWER_UNIT = 6 // W
export const DEFAULT_WALL_THICKNESS = 0.2 // 0.2 (Tường gạch) hoặc 0.008 (Kính)
export const DEFAULT_WALL_THERMAL_CONDUCTIVITY = 0.81 // 0.81 (Tường gạch) hoặc 0.80 (Kính), W/m.K, kappaLayers (0.81)
export const DEFAULT_WALL_HEAT_TRANSFER_COEFFICIENT = 25 // W/m.K h uniform 25
export const DEFAULT_WALL_AMBIENT_TEMP = 35 // oC = 308.15 K
export const DEFAULT_WALL_EMISSIVITY = 0.9 // Factor (0 - 1)

export const THERMAL_TYPE_LABEL: Record<number, string> = {
  [THERMAL_MODE.ADIABATIC]: 'Cách nhiệt',
  [THERMAL_MODE.FIXED_TEMP]: 'Nhiệt độ cố định',
  [THERMAL_MODE.FIXED_POWER]: 'Tỏa nhiệt hằng số',
  [THERMAL_MODE.HEAT_TRANS]: 'Truyền nhiệt đối lưu ngoài'
}

// Danh sách chọn cho ô lọc / form (dùng với sg_select).
export const THERMAL_TYPE_OPTIONS: SGSelectItem[] = Object.entries(THERMAL_TYPE_LABEL).map(
  ([value, label]) => ({ label, value: Number(value) })
)
