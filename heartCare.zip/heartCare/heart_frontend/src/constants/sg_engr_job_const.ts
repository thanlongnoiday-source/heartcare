// src/constants/sg_engr_job_const.ts
//
// Khớp với app/constants/sg_job_const.py (JOB_STATUS) của hvac_fastapi_v1_1.

export const JOB_STATUS = {
  PENDING: 1, // Chờ xử lý
  ACCEPTED: 2, // Worker đã nhận
  RUNNING: 3, // Đang chạy
  SUCCESS: 4, // Hoàn tất
  FAILED: 5 // Thất bại
} as const

export type JobStatusValue = (typeof JOB_STATUS)[keyof typeof JOB_STATUS]

// Nhãn tiếng Việt theo mã trạng thái.
export const JOB_STATUS_LABEL: Record<number, string> = {
  [JOB_STATUS.PENDING]: 'Chờ xử lý',
  [JOB_STATUS.ACCEPTED]: 'Đã tiếp nhận',
  [JOB_STATUS.RUNNING]: 'Đang chạy',
  [JOB_STATUS.SUCCESS]: 'Hoàn tất',
  [JOB_STATUS.FAILED]: 'Thất bại'
}

export function getJobStatusLabel(value: number | null | undefined): string {
  if (value === null || value === undefined) return ''
  return JOB_STATUS_LABEL[value] ?? String(value)
}

// Khớp với JOB_STAGE trong app/constants/sg_job_const.py của hvac_fastapi_v1_1.
export const JOB_STAGE = {
  START_TASK: 1,
  DOWNLOADING: 2,
  MESHING: 3,
  CHECK_MESH: 4,
  SOLVING: 5,
  POST_PROCESSING: 6,
  UPLOADING: 7,
  DONE: 8
} as const

export const JOB_STAGE_LABEL: Record<number, string> = {
  [JOB_STAGE.START_TASK]: 'Khởi tạo tác vụ',
  [JOB_STAGE.DOWNLOADING]: 'Tải dữ liệu đầu vào',
  [JOB_STAGE.MESHING]: 'Chia lưới',
  [JOB_STAGE.CHECK_MESH]: 'Kiểm tra lưới',
  [JOB_STAGE.SOLVING]: 'Đang giải',
  [JOB_STAGE.POST_PROCESSING]: 'Hậu xử lý',
  [JOB_STAGE.UPLOADING]: 'Tải kết quả lên',
  [JOB_STAGE.DONE]: 'Kết thúc'
}

export function getJobStageLabel(value: number | null | undefined): string {
  if (value === null || value === undefined) return ''
  return JOB_STAGE_LABEL[value] ?? String(value)
}
