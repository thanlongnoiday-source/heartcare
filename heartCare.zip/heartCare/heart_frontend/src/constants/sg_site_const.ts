import type { NumberFormatOptions } from '@/types/sg_site_type'

export const DEFAULT_LOCALE = 'vi-VN'

export const DEFAULT_NUMBER_STYLE = 'decimal'

export const DEFAULT_CURRENCY_STYLE = 'currency'

export const DEFAULT_CURRENCY = 'VND'

export const DEFAULT_TIMEZONE = 'Asia/Ho_Chi_Minh'

export const DEFAULT_DATE_FORMAT = 'dd/MM/yyyy'

export const DEFAULT_DATETIME_FORMAT = 'dd/MM/yyyy HH:mm:ss'

export const DEFAULT_DECIMAL_DIGITS = 2

export const DEFAULT_CURRENCY_DIGITS = 0

export const DEFAULT_NUMBER_OPTION: NumberFormatOptions = {
  locale: DEFAULT_LOCALE,
  style: DEFAULT_NUMBER_STYLE,
  currency: DEFAULT_CURRENCY,
  minimumFractionDigits: 0,
  maximumFractionDigits: 2
}

export const DEFAULT_CURRENCY_OPTION: NumberFormatOptions = {
  locale: DEFAULT_LOCALE,
  style: DEFAULT_CURRENCY_STYLE,
  currency: DEFAULT_CURRENCY,
  minimumFractionDigits: 0,
  maximumFractionDigits: 2
}
