// src/constants/sg_engr_geometry_const.ts

import type { SGSelectItem } from '@/types/sg_site_type'

export const GEOMETRY_TYPE = {
  BOX: 1,
  CAD_FILE: 2
} as const

export const GEOMETRY_STATUS = {
  DRAFT: 1, // Nháp / mới tạo
  ACTIVE: 2, // Đang hoạt động
  INACTIVE: 3 // Dừng hoạt động
} as const

export type GeometryStatusValue = (typeof GEOMETRY_STATUS)[keyof typeof GEOMETRY_STATUS]

// Nhãn tiếng Việt theo mã trạng thái.
export const GEOMETRY_STATUS_LABEL: Record<number, string> = {
  [GEOMETRY_STATUS.DRAFT]: 'Nháp',
  [GEOMETRY_STATUS.ACTIVE]: 'Đang hoạt động',
  [GEOMETRY_STATUS.INACTIVE]: 'Dừng hoạt động'
}

export function getGeometryStatusLabel(value: number | null | undefined): string {
  if (value === null || value === undefined) return ''
  return GEOMETRY_STATUS_LABEL[value] ?? String(value)
}

// Danh sách chọn cho ô lọc / form (dùng với sg_select).
export const GEOMETRY_STATUS_OPTIONS: SGSelectItem[] = Object.entries(GEOMETRY_STATUS_LABEL).map(
  ([value, label]) => ({ label, value: Number(value) })
)
