// export const STAY_TYPE = {
//   HOURLY: 1,
//   DAYS: 2,
//   NIGHT: 3,
//   LONG_DAY: 4
// } as const
