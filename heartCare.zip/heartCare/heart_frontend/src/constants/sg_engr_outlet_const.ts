// src/constants/sg_engr_outlet_const.ts

import type { SGSelectItem } from '@/types/sg_site_type'

export const OUTLET_CONTROL_MODE = {
  PRESSURE_OUTLET: 1, // Xả gió tự do
  FLOW_RATE: 2 // Quạt hút cưỡng bức
} as const

export const DEFAULT_OUTLET_FLOW_RATE = 500 // Tự động bằng Tổng gió cấp, m³/h = 0.1389 m³/s (flow_rate/3600)
export const DEFAULT_OUTLET_BACK_TEMP = 25 // Nhiệt độ dòng ngược, 25(oC) = 298.15(K) - (T + 273.15)
export const DEFAULT_OUTLET_PRESSURE = 0 // Áp suất dư tại cửa xả (Pa)
export const DEFAULT_OUTLET_SIZE_W = 0.5 // Chiều rộng, (m)
export const DEFAULT_OUTLET_SIZE_H = 0.5 // Chiều cao, (m)

export const OUTLET_CONTROL_MODE_LABEL: Record<number, string> = {
  [OUTLET_CONTROL_MODE.PRESSURE_OUTLET]: 'Xả gió tự do',
  [OUTLET_CONTROL_MODE.FLOW_RATE]: 'Quạt hút cưỡng bức'
}

// Danh sách chọn cho ô lọc / form (dùng với sg_select).
export const OUTLET_CONTROL_MODE_OPTIONS: SGSelectItem[] = Object.entries(
  OUTLET_CONTROL_MODE_LABEL
).map(([value, label]) => ({ label, value: Number(value) }))
