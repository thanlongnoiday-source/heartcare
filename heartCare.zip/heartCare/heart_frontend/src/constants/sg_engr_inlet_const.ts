// src/constants/sg_engr_inlet_const.ts

export const DEFAULT_INLET_TEMP_COOLING = 18 // chế độ lám lạnh, 18(oC) = 291.15(K) - (T + 273.15),
export const DEFAULT_INLET_TEMP_HEATING = 18 // chế độ sưởi, 30(oC) = 303.15(K) - (T + 273.15)
export const DEFAULT_INLET_FLOW_RATE_FIX = 500 // Cố định, m³/h = 0.1389 m³/s (flow_rate/3600)
export const DEFAULT_INLET_FLOW_RATE_AUTO = 500 // Tự động, 6 - 8 (ACH), (V_phòng x ACH / 3600) (m³/s)
export const DEFAULT_INLET_FLOW_UNIT_ID = 1 // Đơn vị lưu lượng mặc định: m³/h
export const DEFAULT_INLET_SIZE_W = 0.5 // Chiều rộng, (m)
export const DEFAULT_INLET_SIZE_H = 0.5 // Chiều cao, (m)
export const DEFAULT_INLET_VELOCITY = 1.5 // Vận tốc gió thổi 1.5 - 2.0 (m/s), uniform (0 0 -1.5)

// ======================================================================
// Cấu hình điều kiện biên: Miệng cấp (INLET)
// ======================================================================

/** Phương thức thiết lập điều kiện động lực học */
export const CONTROL_MODE = {
  FLOW_RATE: 1,
  VELOCITY: 2,
  TOTAL_PRESSURE: 3
} as const

export const INLET_FLOW_MODE = {
  FLOW_RATE: 'flowRate',
  VELOCITY: 'velocity',
  TOTAL_PRESSURE: 'totalPressure'
} as const

export type SGInletFlowMode = (typeof INLET_FLOW_MODE)[keyof typeof INLET_FLOW_MODE]

/** Hướng thổi — dùng khi flow_mode = velocity */
export const INLET_DIRECTION = {
  NORMAL: 1,
  VECTOR: 2
} as const

export const INLET_DIRECTION_MODE = {
  NORMAL: 'normal',
  VECTOR: 'vector'
} as const

/** Đơn vị lưu lượng cấp gió */
export const INLET_FLOW_RATE_UNIT = {
  M3_H: 'm3/h',
  L_S: 'L/s',
  CFM: 'CFM'
} as const

/** Tính toán tự động D_h
 * — D_h = 4A/P (với A là diện tích, P là chu vi miệng thổi do hệ thống tự tính từ hình học CAD
 **/
export const HYDRAULIC_DIAMETER = {
  AUTO: 1,
  MANUAL: 2
} as const

export type SGHydraulicDiameter = (typeof HYDRAULIC_DIAMETER)[keyof typeof HYDRAULIC_DIAMETER]
