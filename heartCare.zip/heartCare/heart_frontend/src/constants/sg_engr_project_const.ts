// src/features/engineer/constants/sg_engr_project_const.ts
//
// Hằng số dùng chung cho các trang / modal "Dự án" của actor Engineer.
// project_status trong backend là số nguyên (SGProjectBase.project_status: int).

import type { SGSelectItem } from '@/types/sg_site_type'

// Mã trạng thái dự án.
export const PROJECT_STATUS = {
  DRAFT: 1, // Nháp / mới tạo
  ACTIVE: 2, // Đang hoạt động
  INACTIVE: 3 // Dừng hoạt động
} as const

export type ProjectStatusValue = (typeof PROJECT_STATUS)[keyof typeof PROJECT_STATUS]

// Nhãn tiếng Việt theo mã trạng thái.
export const PROJECT_STATUS_LABEL: Record<number, string> = {
  [PROJECT_STATUS.DRAFT]: 'Nháp',
  [PROJECT_STATUS.ACTIVE]: 'Đang hoạt động',
  [PROJECT_STATUS.INACTIVE]: 'Dừng hoạt động'
}

export function getProjectStatusLabel(value: number | null | undefined): string {
  if (value === null || value === undefined) return ''
  return PROJECT_STATUS_LABEL[value] ?? String(value)
}

// Danh sách chọn cho ô lọc / form (dùng với sg_select).
export const PROJECT_STATUS_OPTIONS: SGSelectItem[] = Object.entries(PROJECT_STATUS_LABEL).map(
  ([value, label]) => ({ label, value: Number(value) })
)
