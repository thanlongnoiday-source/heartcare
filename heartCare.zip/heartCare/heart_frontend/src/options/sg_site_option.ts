import type { SGSelectItem } from '@/types/sg_site_type'

export const PAGE_SIZE_OPTIONS: SGSelectItem[] = [
  { label: '5 dòng / trang', value: 5 },
  { label: '10 dòng / trang', value: 10 },
  { label: '20 dòng / trang', value: 20 },
  { label: '50 dòng / trang', value: 50 }
]

// Hệ số nhân tỉ lệ (Scale) — đổi đơn vị kích thước về mét.
export const SCALE_OPTIONS: SGSelectItem[] = [
  { label: 'mm', value: 0.001 },
  { label: 'cm', value: 0.01 },
  { label: 'm', value: 1 }
]
