// src/utils/sg_session_expired.ts
//
// Xử lý chung khi backend báo hết thời gian đăng nhập / chưa đăng nhập (401):
// xoá token + user, hiện thông báo, rồi quay về màn hình login.
// Được gọi từ interceptor axios (src/utils/api.ts) và kênh WebSocket job
// (src/services/sg_job_ws_srv.ts) — mọi kênh gọi backend mới cũng phải gọi hàm này.

import router from '@/router'
import { useAuthStore } from '@/stores/sg_auth_store'
import { useToast } from '@/utils/sg_use_toast'

export const SESSION_EXPIRED_STATUS = 401
// WebSocket gateway đóng bằng 4000 + HTTP code.
export const SESSION_EXPIRED_WS_CODE = 4000 + SESSION_EXPIRED_STATUS

const LOGIN_ROUTE_NAME = 'sg-login'
const SESSION_EXPIRED_MESSAGE =
  'Phiên đăng nhập đã hết hạn hoặc bạn chưa đăng nhập. Vui lòng đăng nhập lại.'

// Nhiều request song song cùng nhận 401 -> chỉ thông báo và điều hướng một lần.
let handling = false

export function handleSessionExpired(): void {
  if (handling) return
  // Đang ở trang login (vd: request trễ trả về sau khi đã điều hướng) -> bỏ qua.
  if (router.currentRoute.value.name === LOGIN_ROUTE_NAME) return
  handling = true

  try {
    localStorage.removeItem('token')
  } catch {
    // Bỏ qua — trình duyệt chặn storage
  }
  useAuthStore().logout()
  useToast().warning(SESSION_EXPIRED_MESSAGE, { duration: 5000 })

  router.replace({ name: LOGIN_ROUTE_NAME }).finally(() => {
    handling = false
  })
}
