// src/utils/sg_presigned_url.ts
//
// Tiện ích cho presigned URL S3/MinIO (SigV4) mà backend trả về, ví dụ
// SGGeometryRead.obj_file_path. Trình duyệt tải file trực tiếp từ S3 bằng URL này,
// không đi qua FastAPI.

// Bỏ phần query (?X-Amz-...) -> chỉ còn endpoint/bucket/key. Chữ ký đổi theo mỗi
// lần backend sinh URL, phần còn lại thì cố định, nên dùng được làm khóa ổn định.
export function stripUrlQuery(url: string): string {
  return url.split('?')[0]
}

// Presigned URL đã (hoặc sắp, trong `marginSeconds`) hết hạn chưa — dựa vào
// X-Amz-Date (YYYYMMDDTHHMMSSZ) + X-Amz-Expires (giây). URL không phải presigned
// thì coi như không hết hạn.
export function isPresignedUrlExpired(url: string, marginSeconds = 60): boolean {
  let params: URLSearchParams
  try {
    params = new URL(url, window.location.origin).searchParams
  } catch {
    return false
  }

  const amzDate = params.get('X-Amz-Date')
  const expires = Number(params.get('X-Amz-Expires'))
  if (!amzDate || !Number.isFinite(expires)) return false

  const m = /^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})Z$/.exec(amzDate)
  if (!m) return false

  const signedAt = Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6])
  return Date.now() >= signedAt + (expires - marginSeconds) * 1000
}
