// src/utils/sg_use_date_time.ts

import { STAY_TYPE } from '@/constants/sg_stay_type_const'
import dayjs from 'dayjs'

/**
 * 
 * Tính số đêm giữa 2 ngày (Ngày đến - Ngày đi).
 * - Số đêm = số ngày lịch chênh lệch giữa 2 mốc thời gian (làm tròn lên).
 * - Trả về 0 nếu thiếu tham số, ngày không hợp lệ, hoặc ngày đi không sau ngày đến.
 * 
 * - Chuổi ngày hợp lệ
     "2026-08-12" — ISO date
     "2026-08-12T14:30:00" — ISO date-time
     "2026-08-12T14:30:00.000Z" — ISO date-time UTC
     "2026-08-12T14:30:00+07:00" — ISO date-time có offset
 *  
 * @param checkIn - Ngày/giờ nhận phòng
 * @param checkOut - Ngày/giờ trả phòng
 */
export function calculateNights(
  checkIn: string | number | Date | dayjs.Dayjs,
  checkOut: string | number | Date | dayjs.Dayjs
): number {
  if (!checkIn || !checkOut) return 0

  const start = dayjs(checkIn)
  const end = dayjs(checkOut)
  if (!start.isValid() || !end.isValid() || !end.isAfter(start)) return 0

  // Chuyển về mốc 00:00:00 để chỉ so sánh ngày, tránh sai lệch do giờ/phút
  start.startOf('day')
  end.startOf('day')

  const totalDays = end.diff(start, 'day')
  return totalDays
}

// "Số lượng lưu trú" không cho người dùng nhập tay — luôn được tính lại tự động từ "Loại hình
// lưu trú" + "Ngày đến" + "Ngày đi":
// - Theo giờ: Số lượng lưu trú = số giờ chênh giữa Ngày đến và Ngày đi (làm tròn lên)
// - Theo ngày: Số lượng lưu trú = 1 ngày, thời gian kết thúc là 17h cùng ngày
// - Theo đêm: Số lượng lưu trú = 1 đêm, thời gian kết thúc là 8h ngày hôm sau
// - Qua đêm: Số lượng lưu trú = số đêm giữa Ngày đến và Ngày đi
// - Dài hạn: Số lượng lưu trú = số tháng chênh giữa Ngày đến và Ngày đi (làm tròn lên)
export function calcQtyStayType(
  stayType: number,
  arrivalFull: string,
  departureFull: string
): number {
  if (!arrivalFull || !departureFull) return 0

  const arrival = dayjs(arrivalFull)
  const departure = dayjs(departureFull)
  if (!arrival.isValid() || !departure.isValid() || !departure.isAfter(arrival)) return 0

  switch (stayType) {
    case STAY_TYPE.HOURLY: {
      const totalMinutes = departure.diff(arrival, 'minute')
      return Math.max(1, Math.ceil(totalMinutes / 60))
    }
    case STAY_TYPE.DAY_USE:
    case STAY_TYPE.NIGHT:
      return 1
    case STAY_TYPE.OVERNIGHT: {
      // Chuyển về mốc 00:00:00 để chỉ so sánh ngày, tránh sai lệch do giờ/phút
      const start = arrival.startOf('day')
      const end = departure.startOf('day')
      return end.diff(start, 'day')
    }
    case STAY_TYPE.LONG_DAY: {
      // Số tháng chênh lệch, làm tròn lên (vd: 1 tháng 2 ngày -> tính là 2 tháng)
      const totalMonths = departure.diff(arrival, 'month', true)
      return Math.max(1, Math.ceil(totalMonths))
    }
    default:
      return 0
  }
}
