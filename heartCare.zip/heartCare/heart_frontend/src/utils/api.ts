import axios, { type InternalAxiosRequestConfig } from "axios";
import { SESSION_EXPIRED_STATUS, handleSessionExpired } from "@/utils/sg_session_expired";

// TODO: tạm bỏ, backend chưa yêu cầu token trong quá trình dev — bật lại khi nối JWT thật
// const HARD_CODED_TOKEN =
//   "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhZG1pbkBleGFtcGxlLmNvbSIsImhvdGVsX2lkIjoiSDAxIiwiZXhwIjoxNzY1NzgwOTg3fQ.kAipmB_OoUYkGXB4APCS8quIzcXooqrHMpWcp45Sgm8";

const apiClient = axios.create({
  // Dev: gọi tương đối (/api/...) qua Vite proxy để tránh CORS; production gọi thẳng VITE_API_URL
  baseURL: import.meta.env.DEV ? "" : import.meta.env.VITE_API_URL,
  headers: {
    "Content-Type": "application/json",
    // Authorization: `Bearer ${HARD_CODED_TOKEN}`, // TODO: tạm bỏ, backend chưa yêu cầu token trong quá trình dev
  },
  timeout: Number(import.meta.env.VITE_API_TIMEOUT) || 30000,
});

// Interceptor to add auth token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    // config.headers.Authorization = `Bearer ${HARD_CODED_TOKEN}`; // TODO: tạm bỏ, backend chưa yêu cầu token trong quá trình dev
    return config;
  },
  (error) => Promise.reject(error)
);

// API đăng nhập trả 401 khi sai tài khoản/mật khẩu — không coi là hết phiên.
function isLoginRequest(config?: InternalAxiosRequestConfig): boolean {
  return !!config?.url?.includes("/users/login");
}

// Backend có thể báo lỗi nghiệp vụ bằng HTTP 200 + envelope { status, message };
// với responseType "blob" thì envelope JSON nằm trong Blob.
async function getEnvelopeStatus(data: unknown, contentType: unknown): Promise<unknown> {
  if (data instanceof Blob) {
    if (typeof contentType !== "string" || !contentType.includes("application/json")) return null;
    try {
      return JSON.parse(await data.text())?.status;
    } catch {
      return null;
    }
  }
  return (data as { status?: unknown } | null)?.status;
}

// Interceptor xử lý lỗi: hết thời gian đăng nhập / chưa đăng nhập (401) -> thông báo
// và quay về màn hình login (xem src/utils/sg_session_expired.ts).
apiClient.interceptors.response.use(
  async (response) => {
    if (!isLoginRequest(response.config)) {
      const status = await getEnvelopeStatus(response.data, response.headers?.["content-type"]);
      if (status === SESSION_EXPIRED_STATUS) handleSessionExpired();
    }
    return response;
  },
  async (error) => {
    if (axios.isAxiosError(error) && error.response && !isLoginRequest(error.config)) {
      const envelopeStatus = await getEnvelopeStatus(
        error.response.data,
        error.response.headers?.["content-type"]
      );
      if (
        error.response.status === SESSION_EXPIRED_STATUS ||
        envelopeStatus === SESSION_EXPIRED_STATUS
      ) {
        handleSessionExpired();
      }
    }
    return Promise.reject(error);
  }
);

export default apiClient;

export function buildImageUrl(dir_path?: string | null, file_name?: string | null): string {
  if (!dir_path) {
    return '/no-image-circle.png'
  }

  if (!file_name) {
    return '/no-image-circle.png'
  }

  // Nếu backend đã trả URL tuyệt đối
  if (dir_path.startsWith('http://') || dir_path.startsWith('https://')) {
    return `${dir_path}/${file_name}`
  }

  const cleanPath = dir_path.replace(/^\/+/, '') + "/" + file_name

  return `${import.meta.env.VITE_API_URL}/${cleanPath}`
}


