// src/utils/formatters.ts

// import { DEFAULT_LOCALE, DEFAULT_NUMBER_OPTION } from '@/constants/sg_site_const'
// import type { NumberFormatOptions } from '@/types/sg_site_type'
import { computed } from 'vue'
import {
  DEFAULT_COMPANY_CURRENCY,
  DEFAULT_COMPANY_LOCALE,
  DEFAULT_COMPANY_TIMEZONE,
  useCompanyStore
} from '@/stores/sg_company_store'

// ========== Timezone safety ==========
// Dữ liệu company_timezone từ API có thể là giá trị rác/chưa seed đúng (vd: "string").
// Intl.DateTimeFormat ném RangeError với timezone không hợp lệ, làm crash cả render.
// -> luôn đi qua resolveTimeZone() để có fallback an toàn.
const timeZoneValidityCache = new Map<string, boolean>()

function isValidTimeZone(timeZone: string): boolean {
  const cached = timeZoneValidityCache.get(timeZone)
  if (cached !== undefined) return cached

  let valid = true
  try {
    new Intl.DateTimeFormat(undefined, { timeZone })
  } catch {
    valid = false
  }

  timeZoneValidityCache.set(timeZone, valid)
  return valid
}

/**
 * Resolve timezone dùng cho các hàm định dạng ngày giờ.
 * Không truyền `timeZone` -> tự động lấy từ useCompanyStore().timezone.
 */
function resolveTimeZone(timeZone?: string): string {
  const tz = timeZone ?? useCompanyStore().timezone

  return isValidTimeZone(tz) ? tz : DEFAULT_COMPANY_TIMEZONE
}

// ========== Locale safety ==========
// Tương tự timezone, company_locale từ API cũng có thể là giá trị rác.
// Intl.NumberFormat/DateTimeFormat ném RangeError với locale không hợp lệ.
// -> luôn đi qua resolveLocale() để có fallback an toàn.
const localeValidityCache = new Map<string, boolean>()

function isValidLocale(locale: string): boolean {
  const cached = localeValidityCache.get(locale)
  if (cached !== undefined) return cached

  let valid = true
  try {
    new Intl.NumberFormat(locale)
  } catch {
    valid = false
  }

  localeValidityCache.set(locale, valid)
  return valid
}

/**
 * Resolve locale dùng cho các hàm định dạng số/tiền tệ/ngày giờ.
 * Không truyền `locale` -> tự động lấy từ useCompanyStore().locale.
 */
function resolveLocale(locale?: string): string {
  const loc = locale ?? useCompanyStore().locale

  return isValidLocale(loc) ? loc : DEFAULT_COMPANY_LOCALE
}

// ========== Currency safety ==========
// Tương tự locale/timezone, company_currency từ API cũng có thể là giá trị rác.
// Intl.NumberFormat ném RangeError với mã currency không hợp lệ.
// -> luôn đi qua resolveCurrency() để có fallback an toàn.
const currencyValidityCache = new Map<string, boolean>()

function isValidCurrency(currency: string): boolean {
  const cached = currencyValidityCache.get(currency)
  if (cached !== undefined) return cached

  let valid = true
  try {
    new Intl.NumberFormat(undefined, { style: 'currency', currency })
  } catch {
    valid = false
  }

  currencyValidityCache.set(currency, valid)
  return valid
}

/**
 * Resolve mã tiền tệ ISO dùng cho formatCurrency.
 * Không truyền `currency` -> tự động lấy từ useCompanyStore().currency.
 */
function resolveCurrency(currency?: string): string {
  const cur = currency ?? useCompanyStore().currency

  return isValidCurrency(cur) ? cur : DEFAULT_COMPANY_CURRENCY
}

// ========== Number & Currency Utilities ==========

/**
 * Lấy ký tự phân cách hàng nghìn (group) và thập phân (decimal) theo locale
 * Ví dụ: 'vi-VN' -> { group: '.', decimal: ',' } ; 'en-US' -> { group: ',', decimal: '.' }
 */
function getLocaleSeparators(locale: string): { group: string; decimal: string } {
  const parts = new Intl.NumberFormat(locale).formatToParts(1234.5)
  const group = parts.find((p) => p.type === 'group')?.value ?? ','
  const decimal = parts.find((p) => p.type === 'decimal')?.value ?? '.'
  return { group, decimal }
}

/**
 * Định dạng số nguyên/số thực có dấu phân cách hàng nghìn
 * @param val - Số cần định dạng, hoặc chuỗi số (vd: 1500000, '1500000', '1.500.000')
 * @param locale - Ngôn ngữ định dạng (bỏ trống -> lấy từ useCompanyStore().locale)
 * @param options - Tùy chọn Intl.NumberFormat bổ sung (vd { notation: 'scientific' })
 */
export const formatNumber = (
  val: number | string,
  locale?: string,
  options?: Intl.NumberFormatOptions
): string => {
  const loc = resolveLocale(locale)
  const num = typeof val === 'string' ? parseNumber(val, loc) : val
  if (isNaN(num)) return 'NaN'
  return new Intl.NumberFormat(loc, options).format(num)
}

/**
 * Định dạng số thành chuỗi tiền tệ theo locale và currency cụ thể
 * @param amount - Số tiền cần định dạng, hoặc chuỗi số/tiền tệ (vd: 1500000, '1500000', '1.500.000 ₫')
 * @param currency - Mã tiền tệ ISO (bỏ trống -> lấy từ useCompanyStore().currency)
 * @param locale - Ngôn ngữ định dạng (bỏ trống -> lấy từ useCompanyStore().locale)
 */
export const formatCurrency = (
  amount: number | string,
  currency?: string,
  locale?: string
): string => {
  const loc = resolveLocale(locale)
  const cur = resolveCurrency(currency)
  const num = typeof amount === 'string' ? parseNumber(amount, loc) : amount
  if (isNaN(num)) return '0 ₫'
  return new Intl.NumberFormat(loc, {
    style: 'currency',
    currency: cur,
    maximumFractionDigits: cur === 'VND' ? 0 : 2
  }).format(num)
}

/**
 * Parse chuỗi số hoặc chuỗi tiền tệ thành number.
 * Tự động loại bỏ ký hiệu tiền tệ (₫, $, VND...), khoảng trắng và chữ cái, chỉ giữ lại
 * chữ số, dấu `.`, `,`, `-`. Dấu thập phân được suy ra từ hình dạng chuỗi (không tin
 * tuyệt đối vào locale, vì input string có thể tới từ nguồn khác locale, vd `Number.toFixed()`
 * luôn trả về dấu `.` bất kể locale):
 * - Có cả `.` và `,` -> ký tự xuất hiện sau cùng là dấu thập phân, ký tự còn lại là phân cách hàng nghìn.
 * - Chỉ có 1 loại dấu, xuất hiện nhiều lần -> chắc chắn là phân cách hàng nghìn (vd '1.500.000').
 * - Chỉ có 1 loại dấu, xuất hiện đúng 1 lần:
 *   - Theo sau đúng 3 chữ số VÀ đúng là dấu group của `locale` -> coi là phân cách hàng nghìn (vd '1.234' ở vi-VN).
 *   - Ngược lại -> coi là dấu thập phân (vd '1000000.00', '1.5', '1,5' ở vi-VN).
 * @param input - Chuỗi hoặc số cần parse (vd: '1.500.000', '1.500.000 ₫', '1,500,000.50', '1000000.00', 1500000)
 * @param locale - Locale dùng để phân xử trường hợp mơ hồ (bỏ trống -> lấy từ useCompanyStore().locale)
 * @returns number đã parse, hoặc NaN nếu chuỗi rỗng/không hợp lệ
 */
export function parseNumber(input: string | number, locale?: string): number {
  if (typeof input === 'number') return input
  if (!input || !input.trim()) return NaN

  // Chỉ giữ lại: chữ số, dấu trừ, dấu chấm, dấu phẩy
  // -> loại bỏ ký hiệu tiền tệ (₫, $, VND...), khoảng trắng, chữ cái còn lại
  const cleaned = input.trim().replace(/[^0-9.,-]/g, '')
  if (!cleaned) return NaN

  const lastDot = cleaned.lastIndexOf('.')
  const lastComma = cleaned.lastIndexOf(',')

  let decimalChar: '.' | ',' | null = null

  if (lastDot !== -1 && lastComma !== -1) {
    // Có cả 2 loại dấu -> dấu nào xuất hiện sau cùng là dấu thập phân
    decimalChar = lastDot > lastComma ? '.' : ','
  } else if (lastDot !== -1 || lastComma !== -1) {
    const sep = lastDot !== -1 ? '.' : ','
    const occurrences = cleaned.split(sep).length - 1
    const digitsAfterLast = cleaned.length - cleaned.lastIndexOf(sep) - 1
    const { group } = getLocaleSeparators(resolveLocale(locale))

    // Xuất hiện nhiều lần -> chắc chắn là phân cách hàng nghìn (không thể có 2 dấu thập phân)
    // Xuất hiện 1 lần, đúng 3 chữ số sau và đúng là dấu group của locale -> nhiều khả năng
    // cũng là phân cách hàng nghìn (vd '1.234' ở vi-VN); còn lại coi là dấu thập phân
    const isGroupSeparator = occurrences > 1 || (digitsAfterLast === 3 && sep === group)
    decimalChar = isGroupSeparator ? null : sep
  }

  // Bỏ mọi dấu không phải decimalChar (phân cách hàng nghìn), chuẩn hoá decimalChar về '.'
  let normalized = cleaned
  for (const sep of ['.', ',']) {
    if (sep !== decimalChar) normalized = normalized.split(sep).join('')
  }
  if (decimalChar) normalized = normalized.replace(decimalChar, '.')

  return Number(normalized)
}

/**
 * Alias ngữ nghĩa của parseNumber, dùng khi input chắc chắn là chuỗi tiền tệ
 * (vd: '1.500.000 ₫', '$1,500.00')
 */
export const parseCurrency = (input: string | number, locale?: string): number =>
  parseNumber(input, locale)

/**
 * Làm tròn 1 số thực về tối đa `decimals` chữ số thập phân (mặc định 2).
 *
 * QUY ƯỚC DÙNG CHUNG TOÀN DỰ ÁN: mọi field số thực (Decimal ở backend, vd
 * Decimal(14, 2)) PHẢI đi qua hàm này trước khi đưa vào payload gọi API
 * (create/update). Số thực trong JS (vd kết quả của phép chia, phép tính hộp bao
 * 3D...) có thể có rất nhiều chữ số thập phân (vd `5 / 3` = `1.6666666666666667`),
 * khiến Pydantic báo lỗi `decimal_max_digits` ("... should have no more than 14
 * digits in total") dù giá trị hiển thị/nhập vào trông hợp lệ.
 * @param value - Số cần làm tròn
 * @param decimals - Số chữ số thập phân giữ lại (mặc định 2, khớp Decimal(x, 2) phổ biến ở backend)
 */
export function roundDecimal(value: number, decimals = 2): number {
  if (!Number.isFinite(value)) return value
  const factor = 10 ** decimals
  return Math.round(value * factor) / factor
}

export type CompanyDateTime = {
  date: string
  time: string
}

/**
 * Định dạng chuỗi ngày giờ UTC từ API thành giờ theo Timezone của Công ty
 * @param dateInput - Chuỗi ISO UTC (ví dụ: '2026-08-04T01:30:00Z') hoặc đối tượng Date
 * @param timeZone - Múi giờ Công ty (bỏ trống -> lấy từ useCompanyStore().timezone)
 * @param locale - Ngôn ngữ định dạng (bỏ trống -> lấy từ useCompanyStore().locale)
 */
export function formatToCompanyDateTime(
  dateInput: string | Date,
  timeZone?: string,
  locale?: string
): string {
  if (!dateInput) return ''

  const date = typeof dateInput === 'string' ? new Date(dateInput) : dateInput

  return new Intl.DateTimeFormat(resolveLocale(locale), {
    timeZone: resolveTimeZone(timeZone),
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false // Dùng định dạng 24h
  }).format(date)
}

/**
 * Định dạng chuỗi ngày giờ UTC từ API thành ngày và giờ (dạng 24h) theo Timezone của Công ty
 * @param dateInput - Chuỗi ISO UTC (ví dụ: '2026-08-04T01:30:00Z') hoặc đối tượng Date
 * @param timeZone - Múi giờ Công ty (bỏ trống -> lấy từ useCompanyStore().timezone)
 * @param locale - Ngôn ngữ định dạng (bỏ trống -> lấy từ useCompanyStore().locale)
 */
export function formatToCompanyDateAndTime(
  dateInput: string | Date,
  timeZone?: string,
  locale?: string
): CompanyDateTime {
  if (!dateInput) return { date: '', time: '' }

  const date = typeof dateInput === 'string' ? new Date(dateInput) : dateInput

  const parts = new Intl.DateTimeFormat(resolveLocale(locale), {
    timeZone: resolveTimeZone(timeZone),
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false // Dùng định dạng 24h
  }).formatToParts(date)

  const get = (type: Intl.DateTimeFormatPartTypes) =>
    parts.find((p) => p.type === type)?.value ?? ''

  return {
    date: `${get('year')}-${get('month')}-${get('day')}`,
    time: `${get('hour')}:${get('minute')}`
  }
}

/**
 * Định dạng chuỗi ngày giờ UTC từ API thành ngày (chỉ ngày, không có giờ) theo Timezone của Công ty
 * @param dateInput - Chuỗi ISO UTC (ví dụ: '2026-08-04T01:30:00Z') hoặc đối tượng Date
 * @param timeZone - Múi giờ Công ty (bỏ trống -> lấy từ useCompanyStore().timezone)
 * @param locale - Ngôn ngữ định dạng (bỏ trống -> lấy từ useCompanyStore().locale)
 */
export function formatToCompanyDate(
  dateInput: string | Date,
  timeZone?: string,
  locale?: string
): string {
  if (!dateInput) return ''

  const date = typeof dateInput === 'string' ? new Date(dateInput) : dateInput

  return new Intl.DateTimeFormat(resolveLocale(locale), {
    timeZone: resolveTimeZone(timeZone),
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(date)
}

/**
 * Chuyển đổi chuỗi ngày giờ theo Timezone của Công ty về UTC (ISO string)
 * @param companyDateTime - Chuỗi ngày giờ theo giờ Công ty (ví dụ: '2026-08-04 10:00' hoặc '2026-08-04T10:00:00')
 * @param timeZone - Múi giờ Công ty (bỏ trống -> lấy từ useCompanyStore().timezone)
 */
export function formatToUtcDateTime(companyDateTime: string, timeZone?: string): string {
  if (!companyDateTime) return ''

  const match = companyDateTime.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/)
  if (!match) return ''

  const tz = resolveTimeZone(timeZone)
  const [, year, month, day, hour, minute, second = '00'] = match

  // Xem chuỗi input như một mốc UTC tạm thời, rồi tính lệch múi giờ thực tế
  // giữa UTC và timeZone Công ty tại mốc đó để bù trừ lại
  const asUTC = Date.UTC(
    Number(year),
    Number(month) - 1,
    Number(day),
    Number(hour),
    Number(minute),
    Number(second)
  )

  const tzOffset =
    new Date(new Date(asUTC).toLocaleString('en-US', { timeZone: 'UTC' })).getTime() -
    new Date(new Date(asUTC).toLocaleString('en-US', { timeZone: tz })).getTime()

  return new Date(asUTC + tzOffset).toISOString()
}

/**
 * Tách 1 chuỗi ngày giờ gộp (vd 'YYYY-MM-DD', 'YYYY-MM-DDTHH:mm' hoặc 'YYYY-MM-DD HH:mm')
 * thành 2 phần { date, time } riêng biệt.
 * Dùng khi 1 mốc thời gian được nhập qua 2 input riêng (type="date" + type="time")
 * nhưng vẫn cần lưu chung dưới dạng 1 chuỗi.
 */
export function splitDateTime(value: string): { date: string; time: string } {
  if (!value) return { date: '', time: '' }
  const [date, time = ''] = value.split(/[T ]/)
  return { date, time }
}

/**
 * Ghép { date, time } riêng biệt lại thành 1 chuỗi ('YYYY-MM-DD' nếu không có time,
 * ngược lại 'YYYY-MM-DDTHH:mm'). Ngược lại của splitDateTime.
 */
export function joinDateTime(date: string, time: string): string {
  if (!date) return ''
  return time ? `${date}T${time}` : date
}

/**
 * Tạo computed 2 chiều cho phần "ngày" của 1 field ngày-giờ gộp (getFull/setFull),
 * dùng để bind với input type="date" khi mốc thời gian đó được nhập qua cặp
 * input date + time riêng biệt (xem splitDateTime/joinDateTime).
 */
export function makeDatePart(getFull: () => string, setFull: (value: string) => void) {
  return computed<string>({
    get: () => splitDateTime(getFull()).date,
    set: (val) => setFull(joinDateTime(val, splitDateTime(getFull()).time))
  })
}

/**
 * Tạo computed 2 chiều cho phần "giờ" của 1 field ngày-giờ gộp (getFull/setFull),
 * dùng để bind với input type="time". Xem thêm makeDatePart.
 */
export function makeTimePart(getFull: () => string, setFull: (value: string) => void) {
  return computed<string>({
    get: () => splitDateTime(getFull()).time,
    set: (val) => setFull(joinDateTime(splitDateTime(getFull()).date, val))
  })
}

/**
 * Lấy thời gian hiện tại chuẩn Múi giờ Công ty (dạng ISO YYYY-MM-DD)
 */
export function getCompanyCurrentDate(timeZone?: string): string {
  const now = new Date()
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: resolveTimeZone(timeZone),
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  })
  return formatter.format(now) // Trả về dạng YYYY-MM-DD
}

export type CompanyCurrentDatetime = {
  datetime: string
  date: string
  time: string
}

/**
 * Lấy ngày giờ hiện tại chuẩn Múi giờ Công ty
 * Trả về 3 field riêng biệt: datetime (YYYY-MM-DD HH:mm), date (YYYY-MM-DD), time (HH:mm)
 */
export function getCompanyCurrentDatetime(timeZone?: string): CompanyCurrentDatetime {
  const now = new Date()
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: resolveTimeZone(timeZone),
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  }).formatToParts(now)

  const get = (type: Intl.DateTimeFormatPartTypes) =>
    parts.find((p) => p.type === type)?.value ?? ''

  const date = `${get('year')}-${get('month')}-${get('day')}`
  const time = `${get('hour')}:${get('minute')}`

  return { datetime: `${date} ${time}`, date, time }
}

/**
 * Chuyển 1 chuỗi ngày hoặc ngày-giờ theo giờ Công ty về UTC (ISO string), an toàn với
 * chuỗi chỉ có ngày (vd input type="date", không có HH:mm): tự bù giờ hiện hành theo
 * Timezone Công ty thay vì mặc định 00:00, trước khi chuyển đổi.
 * @param dateOrDateTime - 'YYYY-MM-DD' hoặc 'YYYY-MM-DD HH:mm'/'YYYY-MM-DDTHH:mm'
 * @param timeZone - Múi giờ Công ty (bỏ trống -> lấy từ useCompanyStore().timezone)
 */
export function toUtcDateTimeSafe(dateOrDateTime: string, timeZone?: string): string {
  if (!dateOrDateTime) return ''

  const hasTime = /\d{2}:\d{2}/.test(dateOrDateTime)
  const input = hasTime
    ? dateOrDateTime
    : `${dateOrDateTime} ${getCompanyCurrentDatetime(timeZone).time}`

  return formatToUtcDateTime(input, timeZone)
}

// ========== String Utilities ==========
export function capitalizeFirstLetter(str: string): string {
  if (!str) return ''

  return str.charAt(0).toUpperCase() + str.slice(1)
}

export function truncateText(str: string, maxLength: number): string {
  if (!str) return ''

  return str.length > maxLength ? str.substring(0, maxLength) + '...' : str
}
