// src/utils/sg_use_toast.ts
import { useToastStore } from '@/stores/sg_toast.store'
import type { ToastOptions, ToastType } from '@/types/sg_toast.types'

type ToastMessageOptions = Partial<Omit<ToastOptions, 'type' | 'message'>>

export function useToast() {
  const store = useToastStore()

  // `type`/`message` spread last so a stray `type`/`message` in `options`
  // can never silently override the toast kind the caller asked for.
  const notify = (type: ToastType, message: string, options?: ToastMessageOptions) =>
    store.push({ ...options, type, message })

  return {
    success: (message: string, options?: ToastMessageOptions) => notify('success', message, options),
    error: (message: string, options?: ToastMessageOptions) => notify('error', message, options),
    warning: (message: string, options?: ToastMessageOptions) => notify('warning', message, options),
    info: (message: string, options?: ToastMessageOptions) => notify('info', message, options)
  }
}
