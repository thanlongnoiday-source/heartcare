export const ENV = {
  APP_NAME: import.meta.env.VITE_APP_NAME,

  API_URL: import.meta.env.VITE_API_URL,

  // Endpoint public của S3/MinIO (vd: http://192.168.7.25:9000) — dùng để ghép URL
  // tới object key trong bucket. Chưa cấu hình thì fallback về API_URL.
  S3_URL: import.meta.env.VITE_S3_URL,

  API_TIMEOUT: Number(import.meta.env.VITE_API_TIMEOUT),

  ENABLE_LOG:
    import.meta.env.VITE_ENABLE_LOG === 'true',
}
