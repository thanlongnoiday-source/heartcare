// ==============================================================================
// 1. BASE SCHEMA (Cac truong thuoc tinh du lieu chung)
// ==============================================================================
export interface SGUnitBase {
  unit_name: string // Tên đơn vị (tối đa 100 ký tự)
}

// ==============================================================================
// 2. CREATE SCHEMA (Du lieu gui len khi them moi)
// ==============================================================================
export type SGUnitCreate = SGUnitBase

// ==============================================================================
// 3. UPDATE SCHEMA (Du lieu gui len khi cap nhat - tat ca deu optional)
// ==============================================================================
export interface SGUnitUpdate {
  unit_name?: string | null
}

// ==============================================================================
// 4. READ SCHEMA (Du lieu tra ve tu backend)
// ==============================================================================
export interface SGUnitRead extends SGUnitBase {
  unit_id: number
}

// ==============================================================================
// 5. PAGED PARAMS (Tham so query khi phan trang / tim kiem)
// ==============================================================================
export interface SGUnitPagedParams {
  page: number // Default 1, >= 1
  page_size: number // Default 20, 1..200
  unit_name?: string | null // Optional, max 100
}

// ==============================================================================
// 6. PAGED RESPONSE (Du lieu tra ve tu backend - APIResponsePage)
// ==============================================================================
export interface SGUnitPageRes {
  items: SGUnitRead[]
  status: number
  message: string
  page: number
  page_size: number
  total: number
  total_pages: number
}
