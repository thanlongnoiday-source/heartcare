// ==============================================================================
// 1. BASE SCHEMA (Cac truong thuoc tinh du lieu chung)
// ==============================================================================
export interface SGProvinceBase {
  province_name: string // Tên tỉnh/thành (tối đa 100 ký tự)
}

// ==============================================================================
// 2. CREATE SCHEMA (Du lieu gui len khi them moi)
// ==============================================================================
export type SGProvinceCreate = SGProvinceBase

// ==============================================================================
// 3. UPDATE SCHEMA (Du lieu gui len khi cap nhat - tat ca deu optional)
// ==============================================================================
export interface SGProvinceUpdate {
  province_name?: string | null
}

// ==============================================================================
// 4. READ SCHEMA (Du lieu tra ve tu backend)
// ==============================================================================
export interface SGProvinceRead extends SGProvinceBase {
  province_id: number
}

// ==============================================================================
// 5. PAGED PARAMS (Tham so query khi phan trang / tim kiem)
// ==============================================================================
export interface SGProvincePagedParams {
  page: number // Default 1, >= 1
  page_size: number // Default 20, 1..200
  province_name?: string | null // Optional, max 100
}

// ==============================================================================
// 6. PAGED RESPONSE (Du lieu tra ve tu backend - APIResponsePage)
// ==============================================================================
export interface SGProvincePageRes {
  items: SGProvinceRead[]
  status: number
  message: string
  page: number
  page_size: number
  total: number
  total_pages: number
}
