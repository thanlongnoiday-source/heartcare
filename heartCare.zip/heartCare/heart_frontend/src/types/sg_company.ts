// ==============================================================================
// 1. BASE SCHEMA (Cac truong thuoc tinh du lieu chung)
// ==============================================================================
export interface SGCompanyBase {
  company_name: string // Tên công ty (tối đa 100 ký tự)
  tax?: string | null // Mã số thuế (tối đa 20 ký tự)
  tels?: string | null // Số điện thoại (tối đa 30 ký tự)
  emails?: string | null // Email (tối đa 20 ký tự)
  website?: string | null // Website (tối đa 50 ký tự)
  addr?: string | null // Địa chỉ (tối đa 200 ký tự)
  province_id: number // ID tỉnh/thành
  country_id: number // ID quốc gia
  comp_locale: string // Locale (tối đa 20 ký tự)
  comp_timezone: string // Múi giờ (tối đa 20 ký tự)
  comp_currency: string // Đơn vị tiền tệ (tối đa 20 ký tự)
}

// ==============================================================================
// 2. CREATE SCHEMA (Du lieu gui len khi them moi)
// ==============================================================================
export type SGCompanyCreate = SGCompanyBase

// ==============================================================================
// 3. UPDATE SCHEMA (Du lieu gui len khi cap nhat - tat ca deu optional)
// ==============================================================================
export interface SGCompanyUpdate {
  company_name?: string | null
  tax?: string | null
  tels?: string | null
  emails?: string | null
  website?: string | null
  addr?: string | null
  province_id?: number | null
  country_id?: number | null
  comp_locale?: string | null
  comp_timezone?: string | null
  comp_currency?: string | null
}

// ==============================================================================
// 4. READ SCHEMA (Du lieu tra ve tu backend)
// ==============================================================================
export interface SGCompanyRead extends SGCompanyBase {
  company_id: number
}

// ==============================================================================
// 5. PAGED PARAMS (Tham so query khi phan trang / tim kiem)
// ==============================================================================
export interface SGCompanyPagedParams {
  page: number // Default 1, >= 1
  page_size: number // Default 20, 1..200
  company_name?: string | null // Optional, max 100
  tax?: string | null // Optional, max 20
  province_id?: number | null // Optional
  country_id?: number | null // Optional
}

// ==============================================================================
// 6. PAGED RESPONSE (Du lieu tra ve tu backend - APIResponsePage)
// ==============================================================================
export interface SGCompanyPageRes {
  items: SGCompanyRead[]
  status: number
  message: string
  page: number
  page_size: number
  total: number
  total_pages: number
}
