export interface SGSimulationStartResult {
  task_id: string
}

export interface SGSimulationStatusResult {
  task_id: string
  status: string
  progress?: number
  message?: string
}
