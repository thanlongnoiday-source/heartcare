// ==============================================================================
// Type tương ứng với app/schemas/sg_geometry_sch.py (backend Pydantic)
// Quy ước: Decimal (backend) -> number (frontend); `X | None` -> `X | null` + optional.
// ==============================================================================

// ------------------------------------------------------------------------------
// Phụ thuộc: các schema con được import trong file backend
//   from app.schemas.sg_inlet_sch  import SGInletCreate
//   from app.schemas.sg_outlet_sch import SGOutletCreate
//   from app.schemas.sg_wall_sch   import SGWallCreate
// Chưa có file schema tương ứng ở frontend -> khai báo placeholder ở đây,
// tách ra @/types/sg_inlet, @/types/sg_outlet, @/types/sg_wall khi backend cung cấp.
// ------------------------------------------------------------------------------
export type SGInletCreate = Record<string, unknown>
export type SGOutletCreate = Record<string, unknown>
export type SGWallCreate = Record<string, unknown>

// ------------------------------------------------------------------------------
// class SGGeometryBase(BaseModel)
// ------------------------------------------------------------------------------
export interface SGGeometryBase {
  // Trong DB bắt buộc và không trùng (theo project_id); nếu không truyền,
  // Service backend sẽ tự sinh. max_length=50
  geometry_code?: string | null
  geometry_name: string // max_length=100
  project_id: number
  leng: number // Decimal(14, 2), default 0.00 — chiều dài
  width: number // Decimal(14, 2), default 0.00
  height: number // Decimal(14, 2), default 0.00
  cad_file_path?: string | null // max_length=200
  geometry_type: number
  notes?: string | null // max_length=100
}

// ------------------------------------------------------------------------------
// class SGGeometryCreate(SGGeometryBase) — pass
// ------------------------------------------------------------------------------
export type SGGeometryCreate = SGGeometryBase

// ------------------------------------------------------------------------------
// class SGGeometryUpdate(BaseModel) — tất cả optional
// ------------------------------------------------------------------------------
export interface SGGeometryUpdate {
  geometry_name?: string | null
  project_id?: number | null
  leng?: number | null
  width?: number | null
  height?: number | null
  cad_file_path?: string | null
  geometry_type?: number | null
  notes?: string | null
}

// ------------------------------------------------------------------------------
// class SGGeometryRead(SGGeometryBase)
// ------------------------------------------------------------------------------
export interface SGGeometryRead extends SGGeometryBase {
  geometry_id: number
}

// ------------------------------------------------------------------------------
// class SGGeometryMeshDivisions(BaseModel)
// ------------------------------------------------------------------------------
export interface SGGeometryMeshDivisions {
  nx: number
  ny: number
  nz: number
}

// ------------------------------------------------------------------------------
// class SGGeometryPreProcessing(BaseModel)
// ------------------------------------------------------------------------------
export interface SGGeometryPreProcessing {
  geometry: SGGeometryCreate
  inlets?: SGInletCreate[] | null
  outlets?: SGOutletCreate[] | null
  walls?: SGWallCreate[] | null
}

// ------------------------------------------------------------------------------
// class SGGeometryMeshResult(BaseModel)
// Response payload cho pipeline blockMesh của box-geometry
// (sinh system/blockMeshDict + enqueue blockMesh qua Celery).
// ------------------------------------------------------------------------------
export interface SGGeometryMeshResult {
  case_ref: string // đường dẫn case-dir (storage_mode=local) hoặc object key S3/MinIO (storage_mode=s3)
  from_object_store: boolean
  cell_size: number // Decimal
  divisions: SGGeometryMeshDivisions
  task_id?: string | null // set khi bước enqueue blockMesh qua Redis/Celery được nối
  stl_ref: string // đường dẫn case-dir hoặc object key S3/MinIO của box STL đã sinh
  stl_url: string // URL tải được trên trình duyệt để WebUI render box (presigned ở chế độ s3)
}
