// ==============================================================================
// Type tuong ung voi app/schemas/sg_wall_sch.py (backend Pydantic)
// Quy uoc: Decimal (backend) -> number (frontend); `X | None` -> `X | null` + optional.
// Luu y: backend lam tron cac truong Decimal ve 2 chu so thap phan (ROUND_HALF_UP)
// truoc khi validate, nen FE co the gui so float co sai so bieu dien.
// ==============================================================================

// ==============================================================================
// 1. BASE SCHEMA (Cac truong thuoc tinh du lieu chung)
// ==============================================================================
export interface SGWallBase {
  wall_code: string // toi da 30 ky tu
  wall_name?: string | null // toi da 100 ky tu
  slip_mode: number // default 0
  roughness: number // Decimal(8, 2), default 0.00
  thermal_mode: number // default 0
  heat_power_0: number // Decimal(8, 2), luon = 0
  fixed_temp: number // Decimal(8, 2), default 0.00
  heat_power: number // Decimal(8, 2), default 0.00
  unit_id: number // FK -> SGUnitRead.unit_id (src/types/sg_unit.ts)
  heat_transfer_coefficient: number // Decimal(8, 2), default 0.00
  ambient_temp: number // Decimal(8, 2), default 0.00
  emissivity: number // Decimal(8, 2), default 0.00
  transmissivity_mode: number // TRANSMISSIVITY_MODE (src/constants/sg_engr_wall_const.ts)
  transmissivity: number // Decimal(8, 2), default 0.00
  geometry_id: number
}

// ==============================================================================
// 2. CREATE SCHEMA (Du lieu gui len khi them moi)
// wall_code optional — neu khong truyen, backend tu sinh ma (SGWallSrv.create_wall)
// ==============================================================================
export interface SGWallCreate extends Omit<SGWallBase, 'wall_code'> {
  wall_code?: string | null // toi da 30 ky tu
}

// ==============================================================================
// 3. UPDATE SCHEMA (Du lieu gui len khi cap nhat - tat ca deu optional)
// ==============================================================================
export interface SGWallUpdate {
  wall_code?: string | null // toi da 30 ky tu
  wall_name?: string | null // toi da 100 ky tu
  slip_mode?: number | null
  roughness?: number | null // Decimal(8, 2)
  thermal_mode?: number | null
  heat_power_0?: number | null // Decimal(8, 2), luon = 0
  fixed_temp?: number | null // Decimal(8, 2)
  heat_power?: number | null // Decimal(8, 2)
  unit_id?: number | null // FK -> SGUnitRead.unit_id
  heat_transfer_coefficient?: number | null // Decimal(8, 2)
  ambient_temp?: number | null // Decimal(8, 2)
  emissivity?: number | null // Decimal(8, 2)
  transmissivity_mode?: number | null // TRANSMISSIVITY_MODE
  transmissivity?: number | null // Decimal(8, 2)
  geometry_id?: number | null
}

// ==============================================================================
// 4. READ SCHEMA (Du lieu tra ve tu backend)
// ==============================================================================
export interface SGWallRead extends SGWallBase {
  wall_id: number
}
