// src/types/toast.types.ts
export type ToastType = "success" | "error" | "warning" | "info"
export type ToastPosition = "top-right" | "bottom-right"

export interface ToastOptions {
  id?: number
  type?: ToastType
  message: string
  duration?: number
  closable?: boolean
}

export interface ToastItem extends Required<ToastOptions> {
  id: number
  position: ToastPosition
}


