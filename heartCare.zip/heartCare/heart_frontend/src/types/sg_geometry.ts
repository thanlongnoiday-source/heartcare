// ==============================================================================
// Type tuong ung voi app/schemas/sg_geometry_sch.py (backend Pydantic)
// Quy uoc: Decimal (backend) -> number (frontend); `X | None` -> `X | null` + optional.
// ==============================================================================

// ==============================================================================
// 1. BASE SCHEMA (Cac truong thuoc tinh du lieu chung)
// ==============================================================================
export interface SGGeometryBase {
  geometry_code: string // toi da 50 ky tu
  geometry_name: string // toi da 100 ky tu
  project_id: number
  leng: number // Decimal(14, 2), default 0.00 - chieu dai
  width: number // Decimal(14, 2), default 0.00
  height: number // Decimal(14, 2), default 0.00
  cad_file_path?: string | null // toi da 200 ky tu
  obj_file_path?: string | null // toi da 200 ky tu
  geometry_type: number
  geometry_status: number
  delta_x: number
  delta_y: number
  delta_z: number
  grading_x: number
  grading_y: number
  grading_z: number
  scales: number
}

// ==============================================================================
// 2. CREATE SCHEMA (Du lieu gui len khi them moi)
// ==============================================================================
export type SGGeometryCreate = SGGeometryBase

// ==============================================================================
// 3. UPDATE SCHEMA (Du lieu gui len khi cap nhat - tat ca deu optional)
// ==============================================================================
export interface SGGeometryUpdate {
  geometry_code?: string | null // toi da 50 ky tu
  geometry_name?: string | null // toi da 100 ky tu
  project_id?: number | null
  leng?: number | null // Decimal(14, 2)
  width?: number | null // Decimal(14, 2)
  height?: number | null // Decimal(14, 2)
  cad_file_path?: string | null // toi da 200 ky tu
  obj_file_path?: string | null // toi da 200 ky tu
  geometry_type?: number | null
  geometry_status?: number | null
  delta_x?: number | null
  delta_y?: number | null
  delta_z?: number | null
  grading_x?: number | null
  grading_y?: number | null
  grading_z?: number | null
  scales?: number | null
}

// ==============================================================================
// 4. READ SCHEMA (Du lieu tra ve tu backend)
// ==============================================================================
export interface SGGeometryRead extends SGGeometryBase {
  geometry_id: number
}

// ------------------------------------------------------------------------------
// class SGGeometryMeshDivisions(BaseModel)
// ------------------------------------------------------------------------------
export interface SGGeometryMeshDivisions {
  nx: number
  ny: number
  nz: number
}

// ------------------------------------------------------------------------------
// class SGGeometryMeshResult(BaseModel)
// Response payload cho pipeline blockMesh của box-geometry
// (sinh system/blockMeshDict + enqueue blockMesh qua Celery).
// ------------------------------------------------------------------------------
export interface SGGeometryMeshResult {
  case_ref: string // đường dẫn case-dir (storage_mode=local) hoặc object key S3/MinIO (storage_mode=s3)
  from_object_store: boolean
  cell_size: number // Decimal
  divisions: SGGeometryMeshDivisions
  task_id?: string | null // set khi bước enqueue blockMesh qua Redis/Celery được nối
  stl_ref: string // đường dẫn case-dir hoặc object key S3/MinIO của box STL đã sinh
  stl_url: string // URL tải được trên trình duyệt để WebUI render box (presigned ở chế độ s3)
}
