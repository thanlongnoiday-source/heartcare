// ==============================================================================
// Type tuong ung voi app/schemas/sg_outlet_sch.py (backend Pydantic)
// Quy uoc: Decimal (backend) -> number (frontend); `X | None` -> `X | null` + optional.
// ==============================================================================

// ==============================================================================
// 1. BASE SCHEMA (Cac truong thuoc tinh du lieu chung)
// ==============================================================================
export interface SGOutletBase {
  outlet_code: string // toi da 30 ky tu
  outlet_name?: string | null // toi da 100 ky tu
  control_mode: number // OUTLET_CONTROL_MODE (src/constants/sg_engr_outlet_const.ts)
  flow_rate: number // Decimal(14, 2), default 0.00 (Lưu lượng hút (m3/h) nếu là quạt hút cưỡng bức)
  pressure: number // Decimal(14, 2), default 0.00 (Áp suất dư tại cửa xả (p_rgh))
  back_temp: number // Decimal(14, 2), default 0.00 (Nhiệt độ dòng ngược)
  turbulence: number // Decimal(8, 2), default 0.00 (Cường độ xáo trộn)
  pos_x: number // Decimal(14, 2), default 0.00
  pos_y: number // Decimal(14, 2), default 0.00
  pos_z: number // Decimal(14, 2), default 0.00
  size_w: number // Decimal(14, 2), default 0.00
  size_h: number // Decimal(14, 2), default 0.00
  geometry_id: number
}

// ==============================================================================
// 2. CREATE SCHEMA (Du lieu gui len khi them moi)
// ==============================================================================
export type SGOutletCreate = SGOutletBase

// ==============================================================================
// 3. UPDATE SCHEMA (Du lieu gui len khi cap nhat - tat ca deu optional)
// ==============================================================================
export interface SGOutletUpdate {
  outlet_code?: string | null // toi da 30 ky tu
  outlet_name?: string | null // toi da 100 ky tu
  control_mode?: number | null
  flow_rate?: number | null // Decimal(14, 2)
  pressure?: number | null // Decimal(14, 2)
  back_temp?: number | null // Decimal(14, 2)
  turbulence?: number | null // Decimal(8, 2)
  pos_x?: number | null // Decimal(14, 2)
  pos_y?: number | null // Decimal(14, 2)
  pos_z?: number | null // Decimal(14, 2)
  size_w?: number | null // Decimal(14, 2)
  size_h?: number | null // Decimal(14, 2)
  geometry_id?: number | null
}

// ==============================================================================
// 4. READ SCHEMA (Du lieu tra ve tu backend)
// ==============================================================================
export interface SGOutletRead extends SGOutletBase {
  outlet_id: number
}
