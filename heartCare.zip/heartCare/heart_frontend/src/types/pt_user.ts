// Tuong ung voi backend schema: user_sch.py

export type PTUserGender = 1 | 2 // 1: Nam, 2: Nữ
export type PTUserRole = 1 | 2 // 1: 'patient', 2: 'admin'

// ==============================================================================
// 1. BASE SCHEMA (Cac truong thuoc tinh du lieu chung)
// ==============================================================================
export interface PTUserBase {
  username: string // Tên đăng nhập (tối đa 50 ký tự)
  full_name?: string | null // Họ tên (tối đa 100 ký tự)
  dob: string // Ngày sinh (ISO datetime)
  gender: PTUserGender
  addr: string // Địa chỉ
  roles?: PTUserRole // Mặc định 1 ('patient')
}

// ==============================================================================
// 2. CREATE SCHEMA (Du lieu gui len khi them moi)
// ==============================================================================
export interface PTUserCreate extends PTUserBase {
  pw?: string | null // Mật khẩu (tối đa 100 ký tự)
}

// ==============================================================================
// 3. UPDATE SCHEMA (Du lieu gui len khi cap nhat - tat ca deu optional)
// ==============================================================================
export interface PTUserUpdate {
  username?: string | null
  pw?: string | null
  full_name?: string | null
  dob?: string | null
  gender?: PTUserGender | null
  addr?: string | null
  roles?: PTUserRole | null
}

// ==============================================================================
// 4. LOGIN SCHEMA (Du lieu gui len khi dang nhap)
// ==============================================================================
export interface PTUserLogin {
  username: string // Tối đa 50 ký tự
  password?: string | null // Tối đa 100 ký tự
}

// ==============================================================================
// 5. READ SCHEMA (Du lieu tra ve tu backend)
// ==============================================================================
export interface PTUserRead extends PTUserBase {
  roles: PTUserRole // Backend luon tra ve gia tri
  users_id: number
  created_at: string // ISO datetime
}

// Query params cho GET /users/ (danh sach nguoi dung - admin)
export interface PTUserListParams {
  skip?: number // Default 0, >= 0
  limit?: number // Default 100, 1..100
}

export interface UserPagedParams {
  page: number // Default 1
  page_size: number // Default 20
  full_name?: string | null // Optional
}

export interface UserPagedRes {
  items: PTUserRead[]
  status: number
  message: string
  page: number
  page_size: number
  total: number
  total_pages: number
}

// ==============================================================================
// 6. TOKEN SCHEMA (Du lieu tra ve sau khi dang nhap)
// ==============================================================================
export interface PTUserToken {
  access_token: string
  token_type: string // Mặc định 'bearer'
  user: PTUserRead
}
