// ==============================================================================
// Type tuong ung voi app/schemas/sg_job_sch.py (backend Pydantic)
// Quy uoc: `X | None` -> `X | null` + optional; datetime -> string (ISO 8601).
// ==============================================================================

// ==============================================================================
// 1. BASE SCHEMA (Cac truong thuoc tinh du lieu chung)
// ==============================================================================
export interface SGJobBase {
  // Trong DB, job_code la bat buoc
  // Trong Schema, neu job_code khong truyen thi Service tu sinh
  job_code?: string | null // toi da 30 ky tu
  job_version?: string | null // toi da 10 ky tu
  job_status: number
  job_stage: number
  job_pct: number // 0 - 100
  geometry_id: number
}

// ==============================================================================
// 2. CREATE SCHEMA (Du lieu gui len khi them moi)
// ==============================================================================
export type SGJobCreate = SGJobBase

// ==============================================================================
// 3. UPDATE SCHEMA (Du lieu gui len khi cap nhat - tat ca deu optional)
// ==============================================================================
export interface SGJobUpdate {
  job_code?: string | null // toi da 30 ky tu
  job_version?: string | null // toi da 10 ky tu
  job_status?: number | null
  job_stage?: number | null
  job_pct?: number | null // 0 - 100
  geometry_id?: number | null
}

// ==============================================================================
// 4. READ SCHEMA (Du lieu tra ve tu backend)
// ==============================================================================
export interface SGJobRead extends SGJobBase {
  job_id: number
  // Server-derived, khong phai input tu client: user_id lay tu current user
  // trong Service, created_at la DB default now().
  user_id: string
  created_at: string // datetime (ISO 8601)
}

// ==============================================================================
// 5. RESULTS SCHEMA (GET /jobs/{job_id}/results -> SGJobResultsRead)
// manifest.json do hvac_openfoam_v1_1 sinh ra (app/postprocessing/sg_web_exporter.py,
// version 1); gateway gắn thêm `url` presigned vào mỗi node có `file`.
// ==============================================================================
export interface SGResultFieldInfo {
  label: string // vd: "Nhiệt độ"
  unit: string // vd: "K", "m/s", "Pa"
  components: number // 1 = scalar, 3 = vector (U)
  range: [number, number] // min/max trên toàn miền -> thang màu chung cho mọi layer
}

export type SGResultLayerType = 'surface' | 'slice' | 'streamlines'

export interface SGResultLayer {
  id: string
  type: SGResultLayerType
  name: string
  file: string // đường dẫn tương đối trong web/
  url?: string | null // presigned GET URL (null nếu path không an toàn)
  fields: string[]
  n_points: number
  n_cells: number
  size_bytes: number
  axis?: 'x' | 'y' | 'z' // chỉ có ở layer slice
  position?: number // chỉ có ở layer slice (m)
}

export interface SGResultImage {
  file: string
  url?: string | null
  size_bytes: number
}

export interface SGResultManifest {
  version: number
  job_code: string
  generated_at: string // ISO 8601
  time: number // bước thời gian cuối (latestTime)
  bounds: [number, number, number, number, number, number] // xmin, xmax, ymin, ymax, zmin, zmax
  fields: Record<string, SGResultFieldInfo>
  layers: SGResultLayer[]
  images: SGResultImage[]
}

export interface SGJobResultsRead {
  job_id: number
  job_version?: string | null
  expires_in: number // TTL (giây) của các presigned URL
  // false: job SUCCESS nhưng không có web/manifest.json -> không xem 3D được
  available: boolean
  archive_url?: string | null // presigned URL tải post-processing.tar.gz
  manifest?: SGResultManifest | null
}

// ==============================================================================
// 6. PROGRESS MESSAGE (ws /api/v1/jobs/{job_id}/ws -> SGJobProgressMsg, xem sg_job_ws_srv.ts)
// Mỗi thông điệp là ảnh chụp đầy đủ trạng thái hiện tại, không phải phần chênh lệch.
// ==============================================================================
export interface SGJobProgressMessage {
  job_id: number
  job_code: string
  status: string // PENDING | QUEUED | RUNNING | COMPLETED | FAILED
  progress_percentage: number // 0 - 100
  current_step: string // vd: "Solving Navier-Stokes equations"
  // null khi worker chưa báo (ngoài giai đoạn SOLVING)
  iteration?: number | null
  max_iterations?: number | null
  // Initial residual gần nhất của từng phương trình, vd: { continuity: 0.0012 }
  residuals: Record<string, number>
  result_url?: string | null // presigned URL web/manifest.json, chỉ có khi COMPLETED
  error_message?: string | null
  updated_at?: string | null
}
