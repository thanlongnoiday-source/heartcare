// src/types/sg_msg_box.types.ts
export type MsgType = 'success' | 'error' | 'warning' | 'info' | 'confirm'

export interface MsgBoxOptions {
    show: boolean
    type?: MsgType
    title: string
    message: string
    show_link?: boolean
    link_href?: string
    link_text?: string
    text_ok?: string
    text_cancel?: string
    text_danger?: string
    show_ok?: boolean
    show_cancel?: boolean
    show_danger?: boolean
}
