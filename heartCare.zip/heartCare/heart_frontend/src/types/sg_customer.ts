// ==============================================================================
// 1. BASE SCHEMA (Cac truong thuoc tinh du lieu chung)
// ==============================================================================
export interface SGCustomerBase {
  customer_name: string // Tên khách hàng (tối đa 100 ký tự)
  addr: string // Địa chỉ (tối đa 200 ký tự)
  phone?: string | null // Số điện thoại (tối đa 50 ký tự)
  email?: string | null // Email (tối đa 50 ký tự)
}

// ==============================================================================
// 2. CREATE SCHEMA (Du lieu gui len khi them moi)
// ==============================================================================
export type SGCustomerCreate = SGCustomerBase

// ==============================================================================
// 3. UPDATE SCHEMA (Du lieu gui len khi cap nhat - tat ca deu optional)
// ==============================================================================
export interface SGCustomerUpdate {
  customer_name?: string | null
  addr?: string | null
  phone?: string | null
  email?: string | null
}

// ==============================================================================
// 4. READ SCHEMA (Du lieu tra ve tu backend)
// ==============================================================================
export interface SGCustomerRead extends SGCustomerBase {
  customer_id: number
}

export interface SGCustomerPagedParams {
  page: number // Default 1
  page_size: number // Default 20
  customer_name?: string | null // Optional, max 100 - Ten khach hang (tim kiem gan dung)
  addr?: string | null // Optional, max 200
  phone?: string | null // Optional, max 50
  email?: string | null // Optional, max 50
}

export interface SGCustomerPagedRes {
  items: SGCustomerRead[]
  status: number
  message: string
  page: number
  page_size: number
  total: number
  total_pages: number
}
