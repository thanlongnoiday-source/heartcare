// ==============================================================================
// 1. BASE SCHEMA (Cac truong thuoc tinh du lieu chung)
// ==============================================================================
export interface SGSetupRoomBase {
  // Kích thước khối hộp (mét)
  length: number // Chiều dài khối hộp (m)")
  width: number // Chiều rộng khối hộp (m)
  height: number // Chiều cao khối hộp (m)

  // Điều kiện biên
  temp_inlet: number // Nhiệt độ khí đầu vào (K) - Ví dụ: 298.15 cho 25°C
  velocity_inlet: number // Vận tốc gió đầu vào (m/s)
}
