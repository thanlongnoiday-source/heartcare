// ==============================================================================
// Type tuong ung voi app/schemas/sg_inlet_sch.py (backend Pydantic)
// Quy uoc: Decimal (backend) -> number (frontend); `X | None` -> `X | null` + optional.
// ==============================================================================

import type {
  INLET_DIRECTION_MODE,
  INLET_FLOW_RATE_UNIT,
  SGHydraulicDiameter,
  SGInletFlowMode
} from '@/constants/sg_engr_inlet_const'

// ==============================================================================
// 1. BASE SCHEMA (Cac truong thuoc tinh du lieu chung)
// ==============================================================================
export interface SGInletBase {
  inlet_code: string // toi da 30 ky tu
  inlet_name?: string | null // toi da 100 ky tu
  flow_rate: number // Decimal(14, 2), default 0.00
  temperature: number // Decimal(14, 2), default 0.00
  pos_x: number // Decimal(10, 2), default 0.00
  pos_y: number // Decimal(10, 2), default 0.00
  pos_z: number // Decimal(10, 2), default 0.00
  size_w: number // Decimal(10, 2), default 0.00
  size_h: number // Decimal(10, 2), default 0.00
  geometry_id: number
  flow_unit_id: number
  control_mode: number // smallint [-32768, 32767], default 0
  direction: number // smallint [-32768, 32767], default 0
  u_x: number // Decimal(10, 2), default 0.00
  u_y: number // Decimal(10, 2), default 0.00
  u_z: number // Decimal(10, 2), default 0.00
  turbulence: number // Decimal(8, 2), default 0.00
  hyd_diameter: number // Decimal(8, 2), default 0.00
  hyd_diameter_auto: SGHydraulicDiameter // HYDRAULIC_DIAMETER: 1 = AUTO (tu dong tinh D_h), 2 = MANUAL
}

// ==============================================================================
// 2. CREATE SCHEMA (Du lieu gui len khi them moi)
// ==============================================================================
export interface SGInletCreate extends Omit<SGInletBase, 'inlet_code'> {
  // Co the bo trong — backend tu sinh ma (INL000001, ...).
  inlet_code?: string | null // toi da 30 ky tu
}

// ==============================================================================
// 3. UPDATE SCHEMA (Du lieu gui len khi cap nhat - tat ca deu optional)
// ==============================================================================
export interface SGInletUpdate {
  inlet_code?: string | null // toi da 30 ky tu
  inlet_name?: string | null // toi da 100 ky tu
  flow_rate?: number | null // Decimal(14, 2)
  temperature?: number | null // Decimal(14, 2)
  pos_x?: number | null // Decimal(10, 2)
  pos_y?: number | null // Decimal(10, 2)
  pos_z?: number | null // Decimal(10, 2)
  size_w?: number | null // Decimal(10, 2)
  size_h?: number | null // Decimal(10, 2)
  geometry_id?: number | null
  flow_unit_id?: number | null
  control_mode?: number | null // smallint [-32768, 32767]
  direction?: number | null // smallint [-32768, 32767]
  u_x?: number | null // Decimal(10, 2)
  u_y?: number | null // Decimal(10, 2)
  u_z?: number | null // Decimal(10, 2)
  turbulence?: number | null // Decimal(8, 2)
  hyd_diameter?: number | null // Decimal(8, 2)
  hyd_diameter_auto?: SGHydraulicDiameter | null
}

// ==============================================================================
// 4. READ SCHEMA (Du lieu tra ve tu backend)
// ==============================================================================
export interface SGInletRead extends SGInletBase {
  inlet_id: number
}

export type SGInletDirectionMode = (typeof INLET_DIRECTION_MODE)[keyof typeof INLET_DIRECTION_MODE]

export type SGInletFlowRateUnit = (typeof INLET_FLOW_RATE_UNIT)[keyof typeof INLET_FLOW_RATE_UNIT]

export interface SGInletBoundary {
  /** Tên miệng cấp gió */
  inlet_name: string
  /** Phương thức thiết lập điều kiện động lực học */
  flow_mode: SGInletFlowMode
  /** Lưu lượng thể tích (theo flow_rate_unit) — dùng khi flow_mode = flowRate */
  flow_rate: number
  /** Đơn vị của flow_rate */
  flow_rate_unit: SGInletFlowRateUnit
  /** Độ lớn vận tốc (m/s) — dùng khi flow_mode = velocity */
  velocity_magnitude: number
  /** Hướng thổi — dùng khi flow_mode = velocity */
  direction_mode: SGInletDirectionMode
  /** Thành phần vector hướng thổi — dùng khi direction_mode = vector */
  direction_x: number
  direction_y: number
  direction_z: number
  /** Áp suất tổng (Pa) — dùng khi flow_mode = totalPressure */
  total_pressure: number
  /** Nhiệt độ gió cấp — Supply T (°C) */
  supply_temperature: number
  /** Cường độ xáo động — Intensity (%) */
  turbulence_intensity: number
  /** Đường kính thủy lực D_h (m) — bỏ qua khi hydraulic_diameter_auto = true */
  hydraulic_diameter: number
  /** true = tự động tính D_h từ hình học miệng gió */
  hydraulic_diameter_auto: boolean
}
