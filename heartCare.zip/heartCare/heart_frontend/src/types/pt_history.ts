// Tuong ung voi backend schema: history_sch.py

export type PTHistoryRiskLevel = 1 | 2 | 3 // 1: 'Low', 2: 'Medium', 3: 'High'

// Decimal cua Pydantic v2 duoc serialize thanh chuoi trong JSON (vd: "78.50"),
// gui len co the dung number hoac string
export type PTHistoryRiskScore = number | string

// ==============================================================================
// 1. BASE SCHEMA (Cac truong thuoc tinh du lieu chung)
// ==============================================================================
export interface PTHistoryBase {
  users_id: number
  metric_id: number
  model_version: string // Ví dụ: 'XGBoost_v1.0' (tối đa 50 ký tự)
  risk_score?: PTHistoryRiskScore // Tỷ lệ % nguy cơ 0..100, 2 chữ số thập phân (mặc định 0.00)
  risk_level: PTHistoryRiskLevel
}

// ==============================================================================
// 2. CREATE SCHEMA (Du lieu gui len khi them moi)
// ==============================================================================
export type PTHistoryCreate = PTHistoryBase

// ==============================================================================
// 3. UPDATE SCHEMA (Du lieu gui len khi cap nhat - tat ca deu optional)
// ==============================================================================
export interface PTHistoryUpdate {
  users_id?: number | null
  metric_id?: number | null
  model_version?: string | null
  risk_score?: PTHistoryRiskScore | null
  risk_level?: PTHistoryRiskLevel | null
}

// ==============================================================================
// 4. READ SCHEMA (Du lieu tra ve tu backend)
// ==============================================================================
export interface PTHistoryRead extends PTHistoryBase {
  risk_score: PTHistoryRiskScore // Backend luon tra ve gia tri
  history_id: number
  created_at: string // ISO datetime
}

// Query params cho GET /histories/ va GET /histories/by_user/{users_id}
export interface PTHistoryListParams {
  skip?: number // Default 0, >= 0
  limit?: number // Default 100, 1..100
}

// ==============================================================================
// 5. PAGED SCHEMA (Phan trang danh sach lich su)
// ==============================================================================
export interface HistoryPagedParams {
  page: number // Default 1
  page_size: number // Default 20
  full_name?: string | null // Optional, tối đa 100 ký tự
}

// Phần tử của danh sách phân trang: kèm thông tin bệnh nhân lấy từ bảng users
// (tương ứng HistoryPageItem trong history_sch.py)
export interface PTHistoryPageItem extends PTHistoryRead {
  full_name: string | null
  addr: string | null
}

export interface HistoryPagedRes {
  items: PTHistoryPageItem[]
  page: number
  page_size: number
  total: number
  total_pages: number
}
