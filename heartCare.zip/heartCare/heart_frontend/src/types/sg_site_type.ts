export interface SidebarItem {
  name: string
  path: string
  icon: unknown
}

export interface SGSelectItem {
  label: string
  value: string | number
}

export type SupportedLocale = 'vi-VN' | 'en-EN'

export type NumberStyle = 'decimal' | 'currency' | 'percent'

export type NumberCurrency = 'VND' | 'USD'

export interface NumberFormatOptions {
  locale?: SupportedLocale
  style?: NumberStyle
  currency?: NumberCurrency
  minimumFractionDigits?: number
  maximumFractionDigits?: number
}

// ======================================================
// BASE RESPONSE TYPES
// ======================================================
export interface SGErrorFieldRes {
  code?: number | null
  field: string
  message: string
}

export interface SGAPIResponse<T = unknown> {
  status: number
  message: string
  items: T
  err_items?: SGErrorFieldRes[] | null | undefined
  // Backend (APIResponse.errors) trả lỗi theo từng field khi validate thất bại
  errors?: SGErrorFieldRes[] | null | undefined
}

export interface SGAPIPageResponse<T> {
  status: number
  message: string
  items: T[]
  page: number
  page_size: number
  total: number
  total_pages: number
}

export class SGError extends Error {
  original: Error

  constructor(message: string, original: Error) {
    super(message)

    this.name = message
    this.original = original
  }
}

export class SGAPIError extends Error {
  status!: number | string
  err_items?: unknown

  constructor(message: string, status: number | string, err_items?: unknown) {
    super(message)

    this.name = 'SGAPIError'
    this.status = status
    this.err_items = err_items
  }
}
