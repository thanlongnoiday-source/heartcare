// ==============================================================================
// 1. BASE SCHEMA (Cac truong thuoc tinh du lieu chung)
// ==============================================================================
export interface SGProjectBase {
  // Trong DB, project_code la bat buoc.
  // Trong Schema, neu project_code khong truyen thi Service tu sinh.
  project_code?: string | null // Ma du an (toi da 50 ky tu)
  project_name: string // Ten du an (toi da 100 ky tu)
  project_date: string // Ngay du an (ISO datetime string)
  customer_id: number // ID khach hang
  project_status: number // Trang thai du an
}

// ==============================================================================
// 2. CREATE SCHEMA (Du lieu gui len khi them moi)
// ==============================================================================
export type SGProjectCreate = SGProjectBase

// ==============================================================================
// 3. UPDATE SCHEMA (Du lieu gui len khi cap nhat - tat ca deu optional)
// ==============================================================================
export interface SGProjectUpdate {
  project_name?: string | null // toi da 100 ky tu
  project_date?: string | null // ISO datetime string
  customer_id?: number | null
  project_status?: number | null
}

// ==============================================================================
// 4. READ SCHEMA (Du lieu tra ve tu backend)
// ==============================================================================
export interface SGProjectRead extends SGProjectBase {
  project_id: number
}

// ==============================================================================
// 5. PAGED PARAMS (Tham so loc / phan trang)
// ==============================================================================
export interface SGProjectPagedParams {
  page: number // Default 1, >= 1
  page_size: number // Default 20, 1..200
  project_code?: string | null // Optional, max 50
  project_name?: string | null // Optional, max 100
  // customer_name chi dung lam dieu kien loc (join sang SGCustomerMod o service),
  // khong nam trong du lieu tra ve.
  customer_name?: string | null // Optional, max 100
  project_status?: number | null
}

// ==============================================================================
// 6. PAGED RESPONSE (Du lieu tra ve co phan trang - boc trong APIResponsePage)
// ==============================================================================
export interface SGProjectPagedRes {
  items: SGProjectRead[]
  status: number
  message: string
  page: number // Default 1
  page_size: number // Default 20
  total: number // Default 0
  total_pages: number // Default 0
}
