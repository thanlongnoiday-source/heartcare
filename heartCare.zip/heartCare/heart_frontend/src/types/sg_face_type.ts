// Loại lệnh chọn từ menu con nổi cạnh mặt đang chọn trên viewer (sự kiện `face-edit`).
export type FaceEditKind = 'inlet' | 'outlet' | 'wall'

// Payload phát ra qua sự kiện `face-select` khi người dùng bấm chọn / bỏ chọn
// một mặt phẳng của khối hình học. Toạ độ theo hệ trục file OBJ (mét) — trùng
// hệ trục thế giới trong viewport.
export interface ObjFaceSelection {
  /** Pháp tuyến đơn vị của mặt. */
  normal: { x: number; y: number; z: number }
  /** Trọng tâm (trung bình theo diện tích) của mặt. */
  center: { x: number; y: number; z: number }
  /** Tâm hình học của mặt (tâm hộp bao) đã chiếu ĐÚNG lên mặt phẳng của mặt —
   *  dùng làm mốc gắn nhãn tên ngay giữa mặt. */
  planeCenter: { x: number; y: number; z: number }
  /** Góc bao (bounding box) của mặt. */
  min: { x: number; y: number; z: number }
  max: { x: number; y: number; z: number }
  /** Diện tích mặt (m²). */
  area: number
  /** Trục vuông góc với mặt nếu mặt song song một mặt phẳng trục, '—' nếu chéo. */
  axis: 'X' | 'Y' | 'Z' | '—'
  /** Số tam giác gộp thành mặt. */
  triangleCount: number
}

// Ba loại đối tượng gắn vào mô hình: miệng cấp (supply) / miệng xả (return) / tường
// (obstacle) — dùng làm khoá cho menu Sidebar, nhãn hiển thị và màu khối trên viewer.
export type GeometryPartKind = 'supply' | 'return' | 'obstacle'

export const GEOMETRY_PART_KIND_LABEL: Record<GeometryPartKind, string> = {
  supply: 'Miệng cấp',
  return: 'Miệng xả',
  obstacle: 'Tường'
}

// Một miệng cấp (inlet) hiển thị dạng khối trên mô hình 3D — ánh xạ từ SGInletRead:
// tâm khối theo pos_x/pos_y/pos_z, kích thước theo size_w (rộng, trục Y) / size_h
// (cao, trục Z). Bề dày theo trục X chỉ để dựng khối/bắt chọn, không phải trường
// dữ liệu thật của inlet.
export interface InletBlock {
  id: number
  name: string
  center: { x: number; y: number; z: number }
  size: { w: number; h: number }
}

// Một Miệng xả (outlet) hiển thị dạng khối trên mô hình 3D — ánh xạ từ SGOutletRead:
// tâm khối theo pos_x/pos_y/pos_z, kích thước theo size_w (rộng, trục Y) / size_h
// (cao, trục Z). Bề dày theo trục X chỉ để dựng khối/bắt chọn, không phải trường
// dữ liệu thật của outlet.
export interface OutletBlock {
  id: number
  name: string
  center: { x: number; y: number; z: number }
  size: { w: number; h: number }
}
