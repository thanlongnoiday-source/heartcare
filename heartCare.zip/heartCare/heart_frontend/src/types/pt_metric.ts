// Tuong ung voi backend schema: metric_sch.py

export type PTMetricSex = 0 | 1 // 1: Nam, 0: Nữ
export type PTMetricBinary = 0 | 1 // 1: Đúng/Có, 0: Sai/Không
export type PTMetricCp = 0 | 1 | 2 | 3 // Loại đau ngực (0-3)
export type PTMetricRestecg = 0 | 1 | 2 // Điện tâm đồ lúc nghỉ (0-2)
export type PTMetricSlope = 0 | 1 | 2 // Độ dốc đoạn ST (0-2)
export type PTMetricCa = 0 | 1 | 2 | 3 | 4 // Số mạch máu chính soi tia X (0-4)
export type PTMetricThal = 1 | 2 | 3 // Thallium scan (1-3)

// Decimal cua Pydantic v2 duoc serialize thanh chuoi trong JSON (vd: "130.00"),
// gui len co the dung number hoac string
export type PTMetricDecimal = number | string

// ==============================================================================
// 1. BASE SCHEMA (Cac truong thuoc tinh du lieu chung)
// ==============================================================================
export interface PTMetricBase {
  users_id: number
  age: number // 1..120
  sex: PTMetricSex
  cp: PTMetricCp
  resting_bp: PTMetricDecimal // Huyết áp lúc nghỉ (trestbps), 1..400
  cholesterol: PTMetricDecimal // Hàm lượng Cholesterol (chol), 1..1000
  fasting_bs: PTMetricBinary // Đường huyết lúc đói > 120 mg/dl
  restecg: PTMetricRestecg
  max_hr: PTMetricDecimal // Nhịp tim tối đa (thalach), 1..400
  exercise_angina: PTMetricBinary // Đau ngực khi vận động
  oldpeak: PTMetricDecimal // Chênh xuống ST, 0..20
  slope: PTMetricSlope
  ca: PTMetricCa
  thal: PTMetricThal
}

// ==============================================================================
// 2. CREATE SCHEMA (Du lieu gui len khi them moi)
// ==============================================================================
export type PTMetricCreate = PTMetricBase

// ==============================================================================
// 3. UPDATE SCHEMA (Du lieu gui len khi cap nhat - tat ca deu optional)
// ==============================================================================
export interface PTMetricUpdate {
  users_id?: number | null
  age?: number | null
  sex?: PTMetricSex | null
  cp?: PTMetricCp | null
  resting_bp?: PTMetricDecimal | null
  cholesterol?: PTMetricDecimal | null
  fasting_bs?: PTMetricBinary | null
  restecg?: PTMetricRestecg | null
  max_hr?: PTMetricDecimal | null
  exercise_angina?: PTMetricBinary | null
  oldpeak?: PTMetricDecimal | null
  slope?: PTMetricSlope | null
  ca?: PTMetricCa | null
  thal?: PTMetricThal | null
}

// ==============================================================================
// 4. READ SCHEMA (Du lieu tra ve tu backend)
// ==============================================================================
export interface PTMetricRead extends PTMetricBase {
  metric_id: number
  recorded_at: string // ISO datetime
}

// Query params cho GET /metrics/ va GET /metrics/by_user/{users_id}
export interface PTMetricListParams {
  skip?: number // Default 0, >= 0
  limit?: number // Default 100, 1..100
}

// ==============================================================================
// 5. PAGED SCHEMA (Phan trang danh sach chi so)
// ==============================================================================
export interface MetricPagedParams {
  page: number // Default 1
  page_size: number // Default 20
  full_name?: string | null // Optional, tối đa 100 ký tự
  age?: number | null // Optional, 1..120
}

export interface MetricPagedRes {
  items: PTMetricRead[]
  page: number
  page_size: number
  total: number
  total_pages: number
}
