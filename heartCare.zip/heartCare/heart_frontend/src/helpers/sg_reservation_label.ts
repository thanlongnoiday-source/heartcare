// import { RSVN_STATUS } from '@/constants/sg_setup_room_const'

// export const getRSVNStatusLabel = (value: number): string => {
//   let re = 'Nháp'

//   if (value === RSVN_STATUS.CONFIRMED) {
//     re = 'Đã xác nhận'
//   } else if (value === RSVN_STATUS.CANCELLED) {
//     re = 'Đã hủy'
//   } else if (value === RSVN_STATUS.NO_SHOW) {
//     re = 'Không đến'
//   } else if (value === RSVN_STATUS.CHECKED_IN) {
//     re = 'Đã Check-in'
//   } else if (value === RSVN_STATUS.CHECKED_OUT) {
//     re = 'Đã Check-out'
//   } else {
//     re = 'Đang chờ duyệt'
//   }

//   return re
// }
