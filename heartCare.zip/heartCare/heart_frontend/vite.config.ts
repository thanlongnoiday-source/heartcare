import { defineConfig, loadEnv } from 'vite'
import vue from '@vitejs/plugin-vue'
import path from 'path'

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')

  return {
    plugins: [vue()],
    resolve: {
      alias: [
        { find: '@', replacement: path.resolve(__dirname, 'src') },
        // vtk.js (IO/XML/XMLReader) import 'xmlbuilder2'. Bản mặc định (lib/index) là bản
        // Node: kế thừa EventEmitter của module 'events' mà Vite loại khỏi bản trình duyệt
        // -> lỗi "Class extends value undefined". Dùng bản bundle dành cho trình duyệt.
        {
          find: /^xmlbuilder2$/,
          replacement: path.resolve(__dirname, 'node_modules/xmlbuilder2/lib/xmlbuilder2.min.js')
        }
      ]
    },
    server: {
      port: 5173,
      strictPort: true,
      // Dev: proxy /api sang backend (VITE_API_URL) để tránh lỗi CORS — trình duyệt chỉ gọi
      // cùng origin localhost:5173, Vite chuyển tiếp request sang backend.
      proxy: env.VITE_API_URL
        ? {
            '/api': {
              target: env.VITE_API_URL,
              changeOrigin: true
            }
          }
        : undefined
    }
  }
})
