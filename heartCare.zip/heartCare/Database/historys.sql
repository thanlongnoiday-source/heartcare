-- Table: heart.historys

-- DROP TABLE IF EXISTS heart.historys;

CREATE TABLE IF NOT EXISTS heart.historys
(
	history_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    users_id bigint NOT NULL,
    metric_id bigint NOT NULL,
    model_version character varying(50) COLLATE pg_catalog."default" NOT NULL, -- Ví dụ: 'XGBoost_v1.0''
    risk_score numeric(8,2) NOT NULL DEFAULT 0.00, -- Tỷ lệ phần trăm nguy cơ (vd: 78.50)
    risk_level smallint NOT NULL, -- 1: 'Low', 2: 'Medium', 3: 'High'
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    CONSTRAINT historys_pkey PRIMARY KEY (history_id)
)

TABLESPACE pg_default;
