-- Table: heart.users

-- DROP TABLE IF EXISTS heart.users;

CREATE TABLE IF NOT EXISTS heart.users
(
    users_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    username character varying(50) COLLATE pg_catalog."default" NOT NULL,
    pw character varying(100) COLLATE pg_catalog."default",
    full_name character varying(100) COLLATE pg_catalog."default",
	addr character varying(100) COLLATE pg_catalog."default",
	dob timestamp with time zone NOT NULL, -- Ngày sinh
	gender smallint NOT NULL, -- 1: Nam, 2: Nữ
	roles smallint NOT NULL, -- 1: 'patient', 2: 'admin'
	created_at timestamp with time zone NOT NULL DEFAULT now(),
    CONSTRAINT users_pkey PRIMARY KEY (users_id)
)

TABLESPACE pg_default;
