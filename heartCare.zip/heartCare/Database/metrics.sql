-- Table: heart.metrics

-- DROP TABLE IF EXISTS heart.metrics;

CREATE TABLE IF NOT EXISTS heart.metrics
(
	metric_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    users_id bigint NOT NULL,
    age smallint NOT NULL,
    sex smallint NOT NULL, -- 1: Nam, 2: Nữ
    cp smallint NOT NULL, -- Loại đau ngực (0-3)
    resting_bp numeric(8,2) NOT NULL DEFAULT 0.00, -- Huyết áp lúc nghỉ (trestbps)
    cholesterol numeric(8,2) NOT NULL DEFAULT 0.00, -- Hàm lượng Cholesterol (chol)
    fasting_bs smallint NOT NULL, -- Đường huyết lúc đói > 120 mg/dl (1: Đúng, 0: Sai)
    restecg smallint NOT NULL, -- Điện tâm đồ lúc nghỉ (0-2)
    max_hr numeric(8,2) NOT NULL DEFAULT 0.00, -- Nhịp tim tối đa (thalach)
    exercise_angina smallint NOT NULL, -- Đau ngực khi vận động (1: Có, 0: Không)
    oldpeak numeric(8,2) NOT NULL DEFAULT 0.00, -- Chênh xuống ST
    slope smallint NOT NULL, -- Độ dốc đoạn ST (0-2)
    ca smallint NOT NULL, -- Số mạch máu chính soi tia X (0-3)
    thal smallint NOT NULL, -- Thallium scan (1-3)
    recorded_at timestamp with time zone NOT NULL DEFAULT now(),
    CONSTRAINT metrics_pkey PRIMARY KEY (metric_id)
)

TABLESPACE pg_default;
